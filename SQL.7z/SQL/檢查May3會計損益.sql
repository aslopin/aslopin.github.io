declare @���s nvarchar(50) set @���s='J1040001'

select sum(a.volume*(b.LastPrice-a.LastPrice)*b.Delta) as PLDiff
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.Stadate=a.stadate and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.Stadate=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
and a.StockID like '%F%' and a.Volume<>0
and a.[User]=@���s

select sum(a.volume*(b.LastPrice-a.LastPrice)) as PLDiff
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.Stadate=a.stadate and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.Stadate=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
and a.StockID not like '%F%' and a.Volume<>0
and a.[User]=@���s

select a.Underlying,sum(a.volume*(b.LastPrice-a.LastPrice)*b.Delta) as PLDiff
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.Stadate=a.stadate and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.Stadate=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
and a.StockID like '%F%' and a.Volume<>0
and a.[User]=@���s
group by a.Underlying
order by sum(a.volume*(b.LastPrice-a.LastPrice)*b.Delta)

select a.Underlying,a.StockID,sum(a.volume*(b.LastPrice-a.LastPrice)) as PLDiff,avg(a.LastPrice),avg(b.LastPrice)
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.Stadate=a.stadate and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.Stadate=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
and a.StockID not like '%F%' and a.Volume<>0
and a.[User]=@���s
group by a.Underlying,a.StockID
order by sum(a.volume*(b.LastPrice-a.LastPrice)*b.Delta)
