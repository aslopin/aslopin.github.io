declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)



select b.�i��ťN�X
,b.�i��ŦW��
,b.�����
,b.�ഫ����
,b.�ഫ�Ъ�
,c.[CPY_NAME]
,c.[CPY_TYPE]
,c.[CPY_REGISTERID]
,c.[CPY_PSR_LIMIT]
,a.CREATME, a.UPDUSR, a.UPDTME, ASW_ID, ASW_CB_FV_ORG, ASW_TRADEDATE, ASW_STARTDATE, ASW_ENDDATE, ASW_CF_ENDDATE, ASW_BS, ASW_PRINCIPAL, ASW_PRINCIPAL_FINAL, ASW_PUTPRICE, ASW_PERIOD, ASW_PAYMENT_TYPE, ASW_RATE, ASW_FLOAT_SPREAD, ASW_FLOAT_REF, ASW_PARTIAL_LOTS, ASW_EX_ENDDATE, ASW_POS_TYPE, ASW_MARKETER, ASW_OPT_COST, ASW_IRS_COST, ASW_CB_COST
from db2.TSDB.dbo.ASW a
left join CB.dbo.CBData b on b.TxDate=@t and b.�i��ťN�X=a.ASW_CB
left join db2.[TSDB].[dbo].[CLIENT] c on c.CPY_NBR=a.ASW_CP
where a.CREATME>=@t

select b.�i��ťN�X
,b.�i��ŦW��
,b.�����
,b.�ഫ����
,c.[CPY_NAME]
,c.[CPY_TYPE]
,c.[CPY_REGISTERID]
,c.[CPY_PSR_LIMIT]
,a.CREATME, a.UPDUSR, a.UPDTME, ASW_ID, ASW_CB_FV_ORG, ASW_TRADEDATE, ASW_STARTDATE, ASW_ENDDATE, ASW_CF_ENDDATE, ASW_BS, ASW_PRINCIPAL, ASW_PRINCIPAL_FINAL, ASW_PUTPRICE, ASW_PERIOD, ASW_PAYMENT_TYPE, ASW_RATE, ASW_FLOAT_SPREAD, ASW_FLOAT_REF, ASW_PARTIAL_LOTS, ASW_EX_ENDDATE, ASW_POS_TYPE, ASW_MARKETER, ASW_OPT_COST, ASW_IRS_COST, ASW_CB_COST
from db2.TSDB.dbo.ASW a
left join CB.dbo.CBData b on b.TxDate=@t and b.�i��ťN�X=a.ASW_CB
left join db2.[TSDB].[dbo].[CLIENT] c on c.CPY_NBR=a.ASW_CP
--where a.CREATME>=@t

--select * from cmoney.dbo.�馬�L���Ʀ� where ���='2016/5/16' and �Ѳ��N��='3380'
