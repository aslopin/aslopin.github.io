declare @BT nvarchar(50) set @BT='12450000'
declare @ET nvarchar(50) set @ET='13300000'
declare @n decimal(20,6) set @n=300

create table #temp3(Ser int,Tradingdate datetime)
insert #temp3
select ser,Tradingdate
from db.dbmain.dbo.tradingdate

create table #temp4(Ser int,[TimeTag] nvarchar(50))
insert #temp4
select ser,[TimeTag]
from db.dbmain.[dbo].[TimeTag_FU]

create Table #Buy (TxDate datetime,Symbol nvarchar(50),Ask decimal(20,6),Bid decimal(20,6))
insert #Buy
select a.TxDate,a.StockId,isnull(a.A1_Price,a.Tick_Price),isnull(a.B1_Price,a.Tick_Price)
from intraday.[dbo].[DailyTick_01min_FU] a
join dbmain.[dbo].[TXOTarget] b on b.[TxDate]=a.TxDate and b.Symbol=a.StockId
where a.TimeTag=@BT

create Table #Sell (SellDate datetime,TxDate datetime,Symbol nvarchar(50),Bid decimal(20,6))
insert #Sell
select a.TxDate,b.TxDate,a.StockId,isnull(a.B1_Price,a.Tick_Price)
from intraday.[dbo].[DailyTick_01min_FU] a
--join dbmain.[dbo].[TXOTarget] b on b.Selldate=a.TxDate and b.Symbol=a.StockId
join dbmain.[dbo].[TXOTarget] b on b.TxDate=a.TxDate and b.Symbol=a.StockId
where a.TimeTag=@ET

select b.TxDate
,sum(
 100*(s.Bid-b.Ask)*50
-Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100
*(isnull(fs.A1_Price,fs.Tick_Price)-isnull(fb.B1_Price,fb.Tick_Price))
*50
-15*2*(100+
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
-0.001*(50*(b.Ask+s.Bid)*100  )
-0.00002*(50*(isnull(fb.B1_Price,fb.Tick_Price)+isnull(fs.A1_Price,fs.Tick_Price))*
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
  ) over(order by b.TxDate)
 as Net

,sum(
 Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(s.Bid,isnull(fs.B1_Price,fs.Tick_Price),o.strike,null,((301-st.ser)/@n+te.ser-ts.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
-Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
 ) over(order by b.TxDate)
 as Vega

,sum(
 Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-st.ser)/@n+te.ser-ts.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
-Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
 ) over(order by b.TxDate)
 as Theta

,sum(
 -15*2*(100+
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
+-0.001*(50*(b.Ask+s.Bid)*100  )
+-0.00002*(50*(isnull(fb.B1_Price,fb.Tick_Price)+isnull(fs.A1_Price,fs.Tick_Price))*
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
 ) over(order by b.TxDate)
as TranCost

,sum(
 100*50*(b.Bid-b.Ask)
+abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C'))*100*50
  *(isnull(fb.B1_Price,fb.Tick_Price)-isnull(fb.A1_Price,fb.Tick_Price))
 ) over(order by b.TxDate)
as Spread

,sum(
 100*(s.Bid-b.Ask)*50
-Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100
*(isnull(fs.A1_Price,fs.Tick_Price)-isnull(fb.B1_Price,fb.Tick_Price))
*50
  ) over(order by b.TxDate)

-sum(
 Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(s.Bid,isnull(fs.B1_Price,fs.Tick_Price),o.strike,null,((301-st.ser)/@n+te.ser-ts.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
-Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
 ) over(order by b.TxDate)

-sum(
 Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-st.ser)/@n+te.ser-ts.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
-Theodata.[dbo].Optvlu(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C',1)*100*50
 ) over(order by b.TxDate)

-sum(
 100*50*(b.Bid-b.Ask)
+abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C'))*100*50
  *(isnull(fb.B1_Price,fb.Tick_Price)-isnull(fb.A1_Price,fb.Tick_Price))
 ) over(order by b.TxDate)
as Gamma

,100*(s.Bid-b.Ask)*50
-Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100
*(isnull(fs.A1_Price,fs.Tick_Price)-isnull(fb.B1_Price,fb.Tick_Price))
*50
 as PL_Daily

,100*(s.Bid-b.Ask)*50
-Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100
*(isnull(fs.A1_Price,fs.Tick_Price)-isnull(fb.B1_Price,fb.Tick_Price))
*50
-15*2*(100+
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
-0.001*(50*(b.Ask+s.Bid)*100  )
-0.00002*(50*(isnull(fb.B1_Price,fb.Tick_Price)+isnull(fs.A1_Price,fs.Tick_Price))*
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
 as Net_Daily

,100*(s.Bid-b.Ask)*50
 as OptPL_Daily
,
-Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100
*(isnull(fs.A1_Price,fs.Tick_Price)-isnull(fb.B1_Price,fb.Tick_Price))
*50
as HgPL_Daily

,-15*2*(100+
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
as ����O_Daily
,-0.001*(50*(b.Ask+s.Bid)*100  )
as �|O_Daily
,-0.00002*(50*(isnull(fb.B1_Price,fb.Tick_Price)+isnull(fs.A1_Price,fs.Tick_Price))*
abs(Theodata.[dbo].OptDelta(isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252.
  ,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
  ,0.01,'C')*100)
  )
as �|F_Daily

,Theodata.[dbo].Implied_vol(b.Bid,isnull(fb.B1_Price,fb.Tick_Price),o.strike,null,((301-bt.ser)/@n+te.ser-tb.ser)/252. ,0.01,'C',1)
 as VolB
,Theodata.[dbo].Implied_vol(s.Bid,isnull(fs.B1_Price,fs.Tick_Price),o.strike,null,((301-st.ser)/@n+te.ser-ts.ser)/252. ,0.01,'C',1)
 as VolS
,((301-bt.ser)/300.+te.ser-tb.ser)
,((301-st.ser)/300.+te.ser-ts.ser)
,b.Symbol
,b.Ask as Opt�R��
,s.Bid as Opt���
,isnull(fb.B1_Price,fb.Tick_Price)
 as Fut���
,isnull(fs.A1_Price,fs.Tick_Price)
 as Fut�R��
from #Buy b
left join #Sell s on s.TxDate=b.Txdate
left join dbmain.[dbo].[TXOTarget] o on o.Txdate=b.TxDate and o.symbol=b.symbol
left join #temp3 tb on tb.Tradingdate=o.Txdate
left join #temp3 te on te.Tradingdate=o.expireddate
left join #temp3 ts on ts.Tradingdate=s.selldate
left join #temp4 bt on bt.[TimeTag]=@BT
left join #temp4 st on st.[TimeTag]=@ET
left join intraday.[dbo].[DailyTick_01min_FU] fb on fb.TxDate=b.TxDate and fb.StockId='TXF'+right(b.Symbol,2) and fb.TimeTag=@BT
left join intraday.[dbo].[DailyTick_01min_FU] fs on fs.TxDate=s.SellDate and fs.StockId='TXF'+right(s.Symbol,2) and fs.TimeTag=@ET

drop Table #Buy
drop Table #Sell
drop table #temp3
drop table #temp4
