
/*
exec CB.dbo.CBAS�򥻸�� '','W1'
*/
alter procedure dbo.CBAS�򥻸�� @t datetime,@tag nvarchar(50)
as
--declare @t datetime set @t='2017/10/31'
if @t='' begin set @t=(select max(stadate) from pl.dbo.inventory) end

declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)



create table #ASW(ASWD_ID nvarchar(50),ASWD_RECDAT nvarchar(50),USR_USERID nvarchar(50),USR_DEPTID nvarchar(50))
insert #ASW
select x.ASWD_ID,x.ASWD_RECDAT,b.USR_USERID,b.USR_DEPTID
from (
	select t.ASWD_ID,max(t.ASWD_RECDAT) as ASWD_RECDAT
	,a.ASW_TRADER
	from DBbondopen.tsdb.dbo.[ASW_DAILY] t
	left join DBbondopen.tsdb.dbo.[ASW] a on a.ASW_ID=t.ASWD_ID
	where t.ASWD_TYPE='INTERNAL'
	and t.ASWD_RECDAT<=@tt
	group by t.ASWD_ID,a.ASW_TRADER
) x
left join DBbondopen.tsdb.dbo.[USERS] b on b.USR_USERID=x.ASW_TRADER

--select * from DBbondopen.tsdb.dbo.[ASW_DAILY] t where t.ASWD_TYPE='INTERNAL' and t.ASWD_RECDAT between '20170827' and '20170905'  and t.ASWD_ID like '%_TC'order by ASWD_RECDAT

create table #ASO(ASOD_ID nvarchar(50),ASOD_RECDAT nvarchar(50),USR_USERID nvarchar(50),USR_DEPTID nvarchar(50))
insert #ASO
select x.ASOD_ID,x.ASOD_RECDAT,b.USR_USERID,b.USR_DEPTID
from (
	select t.ASOD_ID,max(t.ASOD_RECDAT) as ASOD_RECDAT
	,a.ASO_TRADER
	from DBbondopen.tsdb.dbo.[ASO_DAILY] t
	left join DBbondopen.tsdb.dbo.[ASO] a on a.ASO_ID=t.ASOD_ID
	where t.ASOD_TYPE='INTERNAL'
	and t.ASOD_RECDAT<=@tt
	group by t.ASOD_ID,a.ASO_TRADER
) x
left join DBbondopen.tsdb.dbo.[USERS] b on b.USR_USERID=x.ASO_TRADER

if @tag='W1'
	begin
	select x.Txdate, x.ASW_ID, x.ASW_CB, ASW_CB_FV_ORG, x.ASW_TRADEDATE, x.ASW_STARTDATE, x.ASW_ENDDATE, x.ASW_CF_ENDDATE, x.ASW_BS, x.ASW_PRINCIPAL_ORG, x.ASW_PRINCIPAL, x.ASW_PRINCIPAL_FINAL, x.ASW_PUTPRICE, x.ASW_PERIOD, x.ASW_PAYMENT_TYPE, x.ASW_RATE, x.ASW_FLOAT_SPREAD, ASW_FLOAT_REF, ASW_PARTIAL_LOTS, ASW_EX_ENDDATE, ASW_POS_TYPE, ASW_OPT_COST, ASW_IRS_COST, ASW_CB_COST
	from DBmain.[dbo].[CBAS_ASW] x
	join DBbondopen.tsdb.dbo.[USERS] b on b.USR_USERID=x.ASW_TRADER and b.USR_DEPTID='FIXED_INCOME1'
	where x.TxDate=@t
	end

if @tag='O1'
	begin
	select x.Txdate, x.ASO_ID, x.ASO_CB, x.ASO_TRADEDATE, x.ASO_STARTDATE, x.ASO_ENDDATE, x.ASO_EX_ENDDATE, x.ASO_BS, x.ASO_PRINCIPAL_ORG, x.ASO_PRINCIPAL, x.ASO_PUTPRICE, ASO_PARTIAL_LOTS, ASO_EX_ENDDATE, ASO_POS_TYPE, ASO_OPT_COST, ASO_CB_COST
	from DBmain.[dbo].[CBAS_ASO] x
	join DBbondopen.tsdb.dbo.[USERS] b on b.USR_USERID=x.ASO_TRADER and b.USR_DEPTID='FIXED_INCOME1'
	left join cmoney.dbo.�i�ऽ�q�Ŧ��L c on c.���=@t and c.�N��=x.ASO_CB
	left join cb.dbo.CBData d on d.TxDate=@t and d.�i��ťN�X=x.ASO_CB
	where x.TxDate=@t
	end

if @tag='W2'
	begin
	select x.Txdate, x.ASW_ID, x.ASW_CB, ASW_CB_FV_ORG, x.ASW_TRADEDATE, x.ASW_STARTDATE, x.ASW_ENDDATE, x.ASW_CF_ENDDATE, x.ASW_BS, x.ASW_PRINCIPAL_ORG, x.ASW_PRINCIPAL, x.ASW_PRINCIPAL_FINAL, x.ASW_PUTPRICE, x.ASW_PERIOD, x.ASW_PAYMENT_TYPE, x.ASW_RATE, x.ASW_FLOAT_SPREAD, ASW_FLOAT_REF, ASW_PARTIAL_LOTS, ASW_EX_ENDDATE, ASW_POS_TYPE, ASW_OPT_COST, ASW_IRS_COST, ASW_CB_COST
	from DBmain.[dbo].[CBAS_ASW] x
	join DBbondopen.tsdb.dbo.[USERS] b on b.USR_USERID=x.ASW_TRADER and b.USR_DEPTID='FIXED_INCOME2'
	where x.TxDate=@t
	end

if @tag='O2'
	begin
	select x.Txdate, x.ASO_ID, x.ASO_CB, x.ASO_TRADEDATE, x.ASO_STARTDATE, x.ASO_ENDDATE, x.ASO_EX_ENDDATE, x.ASO_BS, x.ASO_PRINCIPAL_ORG, x.ASO_PRINCIPAL, x.ASO_PUTPRICE, ASO_PARTIAL_LOTS, ASO_EX_ENDDATE, ASO_POS_TYPE, ASO_OPT_COST, ASO_CB_COST
	from DBmain.[dbo].[CBAS_ASO] x
	join DBbondopen.tsdb.dbo.[USERS] b on b.USR_USERID=x.ASO_TRADER and b.USR_DEPTID='FIXED_INCOME2'
	left join cmoney.dbo.�i�ऽ�q�Ŧ��L c on c.���=@t and c.�N��=x.ASO_CB
	left join cb.dbo.CBData d on d.TxDate=@t and d.�i��ťN�X=x.ASO_CB
	where x.TxDate=@t
	end

drop table #ASW
drop table #ASO

