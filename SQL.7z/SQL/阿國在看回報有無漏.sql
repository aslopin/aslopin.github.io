declare @t datetime set @t = convert(date, getdate())


declare @temp_IT table (TransactTime datetime, Trader nvarchar(20) ,NowTime nvarchar(20)
,Symbol nvarchar(20),side nvarchar(20),account nvarchar(20),TwseOrdType int,LastQty dec(20,5),LastPx dec(20,5))
insert @temp_IT
select 
TransactTime, Trader,
replicate('0', 2 - len(datepart(hour,TransactTime))) + cast(datepart(hour,TransactTime) as nvarchar(20))
+ replicate('0', 2 - len(datepart(minute,TransactTime)))+ cast(datepart(minute,TransactTime)  as nvarchar(20))
+ replicate('0', 2 - len(datepart(second,TransactTime))) + cast(datepart(second,TransactTime) as nvarchar(20))
,Symbol,side,account,TwseOrdType,LastQty,LastPx
from [Trade_DB].[dbo].[tblOrderReport](nolock)
where 
LastQty<>0
and OrdStatus in ('1','2')
--and Symbol = '2603'
order by TransactTime


declare @temp_400 table (TransactTime datetime, Trader nvarchar(20)  , NowTime nvarchar(20)
,Symbol nvarchar(20),side nvarchar(20),account nvarchar(20),TwseOrdType int,OrderQty dec(20,5),Price dec(20,5))
insert @temp_400
select 
TransactTime, Trader ,
replicate('0', 2 - len(datepart(hour,TransactTime))) + cast(datepart(hour,TransactTime) as nvarchar(20))
+ replicate('0', 2 - len(datepart(minute,TransactTime)))+ cast(datepart(minute,TransactTime)  as nvarchar(20))
+ replicate('0', 2 - len(datepart(second,TransactTime))) + cast(datepart(second,TransactTime) as nvarchar(20))
,Symbol,side,account,TwseOrdType,OrderQty,Price
from [Trade_DB].[dbo].[tblExecutionReport400] (nolock)
where TransactTime>= @t
and account in ('8888888','8888885')
order by TransactTime



select max(TransactTime), 'IT' , count(TransactTime)from @temp_IT
select max(TransactTime), '400' , count(TransactTime) from @temp_400

/*
select * from @temp_IT 
--where Symbol = '16261'
order by TransactTime


select * from @temp_400
--where Symbol = '16261'
 order by TransactTime
*/
select sum((case when side = 1 then 1 else -1 end)* LastQty *1000) as Vol,  sum((case when side = 1 then 1 else -1 end)* LastQty* LastPx*1000) as [$]
from @temp_IT

select sum((case when side = 1 then 1 else -1 end)* OrderQty *1000) as Vol,  sum((case when side = 1 then 1 else -1 end)* OrderQty* Price*1000) as [$]
from @temp_400



--********************************************
select '400�|',a.Trader,a.TransactTime,a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType
,a.LastQty,a.LastPx 
from @temp_IT as a
left join @temp_400 as b on a.NowTime = b.NowTime
and a.Symbol = b.Symbol and a.side = b.side and a.account = b.account
where b.Symbol is null

select 'IT�|',b.Trader,b.TransactTime,b.NowTime,b.Symbol,b.side,b.account,b.TwseOrdType,b.OrderQty,b.Price
from @temp_IT as a
right join @temp_400 as b on a.NowTime = b.NowTime
and a.Symbol = b.Symbol and a.side = b.side and a.account = b.account
where a.Symbol is null

--********************************************
declare @Sum_IT table (NowTime nvarchar(20)
,Symbol nvarchar(20),side nvarchar(20),account nvarchar(20),TwseOrdType int,LastQty dec(20,5)
,MaxLastPx dec(20,5),MinLastPx dec(20,5))
insert @Sum_IT
select  a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType
, sum(a.LastQty), max(a.LastPx), min(a.LastPx) 
from @temp_IT as a
group by  a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType


declare @Sum_400 table (NowTime nvarchar(20)
,Symbol nvarchar(20),side nvarchar(20),account nvarchar(20),TwseOrdType int,OrderQty dec(20,5)
,MAxPrice dec(20,5), MinPrice dec(20,5))
insert @Sum_400 
select  a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType
, sum(a.OrderQty), max(a.Price), min(a.Price) 
from @temp_400 as a
group by  a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType

--********************************************
select a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType,a.LastQty,b.OrderQty, a.MaxLastPx,a.MinLastPx,b.MAxPrice,b.MinPrice 
from @Sum_IT  as a
left join @Sum_400 as b on a.NowTime =b.NowTime and a.Symbol = b.Symbol and a.side = b.side and a.account = b.account 
where a.LastQty <> b.OrderQty 

select a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType,a.LastQty,b.OrderQty, a.MaxLastPx,a.MinLastPx,b.MAxPrice,b.MinPrice 
from @Sum_IT  as a
left join @Sum_400 as b on a.NowTime =b.NowTime and a.Symbol = b.Symbol and a.side = b.side and a.account = b.account 
where b.Symbol is null

select a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType,a.LastQty,b.OrderQty, a.MaxLastPx,a.MinLastPx,b.MAxPrice,b.MinPrice 
from @Sum_400  as b
left join @Sum_IT as a on a.NowTime =b.NowTime and a.Symbol = b.Symbol and a.side = b.side and a.account = b.account 
where a.LastQty <> b.OrderQty 

select a.NowTime,a.Symbol,a.side,a.account,a.TwseOrdType,a.LastQty,b.OrderQty, a.MaxLastPx,a.MinLastPx,b.MAxPrice,b.MinPrice 
from @Sum_400  as b
left join @Sum_IT as a on a.NowTime =b.NowTime and a.Symbol = b.Symbol and a.side = b.side and a.account = b.account 
where b.Symbol is null



/*
select *
from [Trade_DB].[dbo].[tblOrderReport]
order by TransactTime desc

select *
from [Trade_DB].[dbo].[tblExecutionReport400] 
order by TransactTime desc
*/

/*
--declare @t datetime set @t = (select max (���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
--�d�ʺ|���e�U�渹
SELECT [OrderId]
FROM [Trade_DB].[dbo].[tblExecutionReport400]
where OrderID not in (select  [OrderID] FROM [Trade_DB].[dbo].[tblOrderReport] where [OrdStatus] in (1, 2))
and TransactTime >= @t and Channel not in('S82', 'S70')

--�ˬdDB2�O�_���ʺ|���e�U�渹
select * FROM [DB2].[Trade_DB].[dbo].[tblOrderReport] where [OrdStatus] in (1, 2) 
and OrderID in (SELECT [OrderId]
FROM [Trade_DB].[dbo].[tblExecutionReport400]
where OrderID not in (select  [OrderID] FROM [Trade_DB].[dbo].[tblOrderReport] where [OrdStatus] in (1, 2))
and TransactTime >= @t and Channel not in('S82', 'S70'))

--�ƶq�@�P�N�qDB2�g�^
INSERT INTO [Trade_DB].[dbo].[tblOrderReport]
([PKey],[Account],[AvgPx],[Channel],[ChannelType],[CumQty],[Errorcode],[ExecID],[ExecType],[IsReSend],[LastPx],[LastQty]
,[LeavesQty],[Market],[OrderID],[OrderQty],[OrdRejReason],[OrdStatus],[OrdType],[Price],[SerialNo],[Side],[Symbol],[Text],[TimeInForce]
,[Trader],[TransactTime],[TwseExCode],[TwseIvacnoFlag],[TwseOrdType])
SELECT [PKey],[Account],[AvgPx],[Channel],[ChannelType],[CumQty],[Errorcode],[ExecID],[ExecType],[IsReSend],[LastPx],[LastQty]
,[LeavesQty],[Market],[OrderID],[OrderQty],[OrdRejReason],[OrdStatus],[OrdType],[Price],[SerialNo],[Side],[Symbol],[Text],[TimeInForce]
,[Trader],[TransactTime],[TwseExCode],[TwseIvacnoFlag],[TwseOrdType]
FROM (select * FROM [DB2].[Trade_DB].[dbo].[tblOrderReport] where [OrdStatus] in (1, 2) 
and OrderID in (SELECT [OrderId]
FROM [Trade_DB].[dbo].[tblExecutionReport400]
where OrderID not in (select  [OrderID] FROM [Trade_DB].[dbo].[tblOrderReport] where [OrdStatus] in (1, 2))
and TransactTime >= @t and Channel not in('S82', 'S70'))) T



*/

select '400', left(NowTime, 4) , count(left(NowTime, 4))
from @temp_400 
group by left(NowTime, 4)
order by left(NowTime, 4) desc

select 'IT', left(NowTime, 4) , count(left(NowTime, 4))
from @temp_IT
group by left(NowTime, 4)
order by left(NowTime, 4) desc
