/*
declare @b datetime,@e datetime,@t datetime
set @b='2015/9/16'
set @e='2015/9/16'
set @t=@b
while @t<=@e
  begin
  print @t
  exec [DailyInsert].dbo.PL_TGIndex @t
  set @t=DBMain.dbo.tradingdateadd(1,@t)
  end

select * from pl.dbo.TGIndex order by TxDate
*/
create procedure [dbo].[PL_TGIndex] @t datetime
as
--declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
 declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)

declare @out table(WarrantID nvarchar(50),WarrantName nvarchar(50),StockID nvarchar(50),StockName nvarchar(50)
,VectorA decimal(20,8),VectorB decimal(20,8),Volume decimal(20,8),VolumeY decimal(20,8),QV decimal(20,8),ThetaY decimal(20,8),r decimal(20,8))
insert @out
select w.WarrantID,w.WarrantName,w.StockID,w.StockName
,a.ThetaY_PV/( (v.QV/sqrt(252.))*(v.QV/sqrt(252.)) )
 as VectorA
,( (v.QV/sqrt(252.))*(v.QV/sqrt(252.)) )
-( q.[���T(%)]/100.*q.[���T(%)]/100. )
 as VectorB

,a.Volume,isnull(i.Volume,0) as VolumeY,v.QV,a.ThetaY_PV,q.[���T(%)]/100. as r
from pl.[dbo].[WBreakDown_�Q�鳡��PV] a
join dbmain.dbo.WarrantProfileTS_Daily w on w.txdate=a.stadate and w.WarrantKey=a.Portfolio and w.WarrantID=a.StockID
left join pl.[dbo].[�ۮa�v�ҨC��QV] v on v.TxDate=a.stadate and v.Wrr_ID=a.StockID
left join pl.dbo.Inventory i on i.Stadate=@y and i.Portfolio=a.Portfolio and i.StockID=a.StockID
left join Cmoney.dbo.�馬�L�٭���Ʀ� q on q.���=a.stadate and q.�Ѳ��N��=w.StockID
where a.stadate=@t

delete pl.dbo.TGindex where TxDate=@t
insert pl.dbo.TGindex
select @t as TxDate
,sum(VectorA*VectorB) as Dot
,sqrt(sum(VectorA*VectorA)) as NormA
,sqrt(sum(VectorB*VectorB)) as NormB
,case when (sqrt(sum(VectorA*VectorA))*sqrt(sum(VectorB*VectorB)))=0 then 0 
 else sum(VectorA*VectorB)/(sqrt(sum(VectorA*VectorA))*sqrt(sum(VectorB*VectorB)))
 end
 as Costheta

,case when sum(ThetaY)=0 then 0 
 else sum(ThetaY*( r*r )/( (QV/sqrt(252.))*(QV/sqrt(252.)) ))/sum(ThetaY)
 end
 as TGIndex
from @out

/*
select *
from @out
order by StockID,WarrantID
*/