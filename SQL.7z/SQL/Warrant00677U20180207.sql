declare @t datetime set @t='2018/2/7'
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)

select a.StockID,a.StockName,a.Volume
,a.Volume
*(theodata.dbo.OptVlu(b.SLast, b.Strike, b.Barrier, b.T�����-2/252., b.PricingVol, b.r, a.StockID, b.Exer)
 -theodata.dbo.OptVlu(b.SLast, b.Strike, b.Barrier, b.T�����-1/252., b.PricingVol, b.r, a.StockID, b.Exer)
 )
 as Theta
,a.Volume*b.Exer*b.SLast
*(theodata.dbo.OptDelta(b.SLast*1.01, b.Strike, b.Barrier, b.T�����-2/252., b.PricingVol, b.r, a.StockID)
 -theodata.dbo.OptDelta(b.SLast*0.99, b.Strike, b.Barrier, b.T�����-1/252., b.PricingVol, b.r, a.StockID)
 )/2.
 as Gamma
,a.Volume
*(theodata.dbo.OptVlu(b.SLast*1.1, b.Strike, b.Barrier, b.T�����-3/252., b.PricingVol, b.r, a.StockID, b.Exer)
 -theodata.dbo.OptVlu(b.SLast, b.Strike, b.Barrier, b.T�����-1/252., b.PricingVol, b.r, a.StockID, b.Exer)
 )
 as [3�ѭԺ�10%]
,a.Volume
*(theodata.dbo.OptVlu(b.SLast*0.9, b.Strike, b.Barrier, b.T�����-3/252., b.PricingVol, b.r, a.StockID, b.Exer)
 -theodata.dbo.OptVlu(b.SLast, b.Strike, b.Barrier, b.T�����-1/252., b.PricingVol, b.r, a.StockID, b.Exer)
 )
 as [3�ѭԶ^10%]
,b.PricingVol as Vol
,case when right(a.StockID,1)='P' then b.Strike/b.SLast-1 else b.SLast/b.Strike-1 end as Moneyness
from pl.dbo.InventoryMay4 a
left join pro.dbo.�v�ҵ������ b on b.TxDate=(select max(TxDate) from pro.dbo.�v�ҵ������) and b.warrantid=a.Stockid
where a.[User]='J1040001' and a.Underlying='00677U' and a.StockID in ('06674P','06652P','06687P')
