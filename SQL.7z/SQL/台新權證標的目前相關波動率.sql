declare @t datetime set @t='2015/8/5'

declare @qv table(WarrantID nvarchar(50),QV decimal(20,6))
insert @qv
select Wrr_ID,cast(case when QV='' then null else QV end as decimal(20,6))/100.--,*
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
where TX_Date='20150804'

select b.StockID,min(a.StockName) as StockName
,cast(cast(round(b.HV*100,1,0) as decimal(20,1)) as nvarchar(50))+'%' as BookVol
,case when min(isnull(qv.qv,a.issuevol))=max(isnull(qv.qv,a.issuevol)) then cast(cast(round(min(isnull(qv.qv,a.issuevol))*100,1,0) as decimal(20,1)) as nvarchar(50))+'%'
      when min(isnull(qv.qv,a.issuevol))<max(isnull(qv.qv,a.issuevol)) then cast(cast(round(min(isnull(qv.qv,a.issuevol))*100,1,0) as decimal(20,1)) as nvarchar(50))+'-'+cast(cast(round(max(isnull(qv.qv,a.issuevol))*100,1,0) as decimal(20,1)) as nvarchar(50))+'%'
	  end
 as PricingVol
,cast(cast(round(min(hv.vol)*100,1,0) as decimal(20,1)) as nvarchar(50))+'%' as [5��Vol]
,cast(cast(round(min(hv2.vol)*100,1,0) as decimal(20,1)) as nvarchar(50))+'%' as [20��Vol]
,cast(cast(round(min(hv3.vol)*100,1,0) as decimal(20,1)) as nvarchar(50))+'%' as [60��Vol]
,count(*) as �ɼ�
from dbmain.dbo.WarrantProfileTS a
join dbmain.[dbo].[WarrantHedgeVolTS_BE]() b on @t between b.bdate and b.edate and b.stockid=a.stockid
left join @qv qv on qv.WarrantID=a.WarrantID
left join theodata.[dbo].[HistoryVol] hv on hv.Stadate='2015/8/4' and hv.seccode=a.stockid and hv.tag='5'
left join theodata.[dbo].[HistoryVol] hv2 on hv2.Stadate='2015/8/4' and hv2.seccode=a.stockid and hv2.tag='22'
left join theodata.[dbo].[HistoryVol] hv3 on hv3.Stadate='2015/8/4' and hv3.seccode=a.stockid and hv3.tag='66'
group by b.StockID,b.HV,hv.vol,hv2.vol,hv3.vol

select *
from dbmain.dbo.WarrantProfileTS a
join dbmain.[dbo].[WarrantHedgeVolTS_BE]() b on @t between b.bdate and b.edate and b.stockid=a.stockid
left join @qv qv on qv.WarrantID=a.WarrantID
left join theodata.[dbo].[HistoryVol] hv on hv.Stadate='2015/8/4' and hv.seccode=a.stockid and hv.tag='5'
left join theodata.[dbo].[HistoryVol] hv2 on hv2.Stadate='2015/8/4' and hv2.seccode=a.stockid and hv2.tag='22'
left join theodata.[dbo].[HistoryVol] hv3 on hv3.Stadate='2015/8/4' and hv3.seccode=a.stockid and hv3.tag='66'
where a.stockid='9802'

