declare @t datetime set @t='2022/12/31'
declare @mt datetime set @mt=(select max(tradingdate) from dbmain.dbo.tradingdate where tradingdate<=@t)

select a.交易員代碼,b.NameEn,a.股票代號,min(q.股票名稱) as 股票名稱
,sum(a.今日庫存成本) as 總成本
from pl.dbo.[400現股庫存檔wkstkx] a
join dbmain.[dbo].[AccountList_Temp] b on a.交易員代碼=b.Acc00 and @t between b.BDate and b.EDate and b.[2019_投資組合]='交易簿貳自營交易暨投資部位'
join [MarketData].[dbo].[ESG_data_IRPlatform] c on c.stk_no=a.股票代號 and c.DataFetchDate=@t and c.ranking='81%~100%'
left join cmoney.dbo.日收盤表排行 q on q.日期=a.庫存日期 and q.股票代號=a.股票代號
where a.庫存日期=@mt and a.交易員代碼 in ('355','387','393')
group by a.交易員代碼,b.NameEn,a.股票代號

select q.股票代號,q.股票名稱,q.產業名稱 from [MarketData].[dbo].[ESG_data_IRPlatform] a
join cmoney.dbo.上市櫃公司基本資料 q on q.股票代號=a.stk_no
where DataFetchDate='2022/12/31' and ranking='81%~100%'　
order by q.股票代號
/*
select *
from [MarketData].[dbo].[ESG_data_IRPlatform]
where DataFetchDate=@t
order by ranking

select *
from [MarketData].[dbo].[ESG_data_IRPlatform]
where stk_no='6811'
order by DataFetchDate desc

select *
from pl.dbo.[400現股庫存檔wkstkx] a
join dbmain.[dbo].[AccountList_Temp] b on a.交易員代碼=b.Acc00 and @t between b.BDate and b.EDate and b.[2019_投資組合]='交易簿貳自營交易暨投資部位'
left join [MarketData].[dbo].[ESG_data_IRPlatform] c on c.stk_no=a.股票代號 and c.esg_score='-' and c.DataFetchDate=@t
where a.庫存日期=@t
order by c.ranking 
*/

select a.交易員代碼,b.NameEn
,sum(a.今日庫存成本) as 總成本
,sum(case when c.ranking='81%~100%' then a.今日庫存成本 else 0 end) as G級成本
,case when sum(a.今日庫存成本)<>0 then sum(case when c.ranking='81%~100%' then a.今日庫存成本 else 0 end)/sum(a.今日庫存成本) end as 比例
from pl.dbo.[400現股庫存檔wkstkx] a
join dbmain.[dbo].[AccountList_Temp] b on a.交易員代碼=b.Acc00 and @t between b.BDate and b.EDate and b.[2019_投資組合]='交易簿貳自營交易暨投資部位'
left join [MarketData].[dbo].[ESG_data_IRPlatform] c on c.stk_no=a.股票代號 and c.esg_score='-' and c.DataFetchDate=@t
where a.庫存日期=@mt
group by a.交易員代碼,b.NameEn
order by a.交易員代碼,b.NameEn

select b.NameEn
,sum(a.今日庫存成本) as 總成本
,sum(case when c.ranking='81%~100%' then a.今日庫存成本 else 0 end) as G級成本
,case when sum(a.今日庫存成本)<>0 then sum(case when c.ranking='81%~100%' then a.今日庫存成本 else 0 end)/sum(a.今日庫存成本) end as 比例
from pl.dbo.[400現股庫存檔wkstkx] a
join dbmain.[dbo].[AccountList_Temp] b on a.交易員代碼=b.Acc00 and @t between b.BDate and b.EDate and b.[2019_投資組合]='交易簿貳自營交易暨投資部位'
left join [MarketData].[dbo].[ESG_data_IRPlatform] c on c.stk_no=a.股票代號 and c.esg_score='-' and c.DataFetchDate=@t
where a.庫存日期=@mt
group by b.NameEn
order by b.NameEn

select a.交易員代碼,a.今日庫存成本 as 庫存成本,c.ranking,a.股票代號,d.股票名稱,d.產業名稱,d.經營項目
from pl.dbo.[400現股庫存檔wkstkx] a
join dbmain.[dbo].[AccountList_Temp] b on a.交易員代碼=b.Acc00 and @t between b.BDate and b.EDate and b.[2019_投資組合]='交易簿貳自營交易暨投資部位'
join [MarketData].[dbo].[ESG_data_IRPlatform] c on c.stk_no=a.股票代號 and c.esg_score='-' and c.DataFetchDate=@t and c.ranking='81%~100%'
left join cmoney.[dbo].[上市櫃公司基本資料] d on d.股票代號=a.股票代號
where a.庫存日期=@mt
order by a.交易員代碼,b.NameEn


SELECT a.部門
,sum(a.市值) as 總市值
,sum(case when b.ranking='81%~100%' then a.市值 else 0 end) as G級市值
,case when sum(a.市值)<>0 then sum(case when b.ranking='81%~100%' then a.市值 else 0 end)/sum(a.市值) end as 比例
  FROM [PL].[dbo].[部位總Select_daily_his] a
  left join [MarketData].[dbo].[ESG_data_IRPlatform] b on b.stk_no=a.標的代號 and b.esg_score='-' and b.DataFetchDate=@t
  left join cmoney.dbo.上市櫃公司基本資料每日 c on c.TxDate=a.[日期] and c.股票代號=a.標的代號
  where a.[日期]=@mt
  group by a.部門
  order by a.部門


SELECT a.部門
,sum(a.市值) as 總市值
,sum(case when b.ranking='81%~100%' then a.市值 else 0 end) as G級市值
,case when sum(a.市值)<>0 then sum(case when b.ranking='81%~100%' then a.市值 else 0 end)/sum(a.市值) end as 比例
  FROM [PL].[dbo].[部位總Select_daily_his] a
  left join [MarketData].[dbo].[ESG_data_IRPlatform] b on b.stk_no=a.標的代號 and b.esg_score='-' and b.DataFetchDate=@t
  left join cmoney.dbo.上市櫃公司基本資料每日 c on c.TxDate=a.[日期] and c.股票代號=a.標的代號
  where a.[日期]=@mt
  group by a.部門
  order by a.部門


SELECT a.部門,a.部位種類,a.策略,c.產業名稱,a.標的代號,a.股票代號,a.股票名稱,b.ranking,sum(a.市值) as 市值
  FROM [PL].[dbo].[部位總Select_daily_his] a
  join [MarketData].[dbo].[ESG_data_IRPlatform] b on b.stk_no=a.標的代號 and b.ranking='81%~100%' and b.esg_score='-' and b.DataFetchDate=@t
  left join cmoney.dbo.上市櫃公司基本資料每日 c on c.TxDate=a.[日期] and c.股票代號=a.標的代號
  where a.[日期]=@mt
  group by a.部門,a.部位種類,a.策略,c.產業名稱,a.標的代號,a.股票代號,a.股票名稱,b.ranking
  order by c.產業名稱,a.標的代號,a.部門,a.部位種類,a.策略

