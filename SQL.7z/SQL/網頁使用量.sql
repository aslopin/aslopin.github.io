select a.Item as �϶�,a.[Title],a.NameOfPHP,a.����,a.[����(�������x)],a.[����(DM)],a.�ϥΤH��,a.BDate,a.EDate
from (
	select a.Item,a.[Title],a.NameOfPHP,isnull(b.N,0) as ����,isnull(b.NT,0) as [����(�������x)],isnull(b.NDM,0) as [����(DM)],b.BDate as BDate,b.EDate as EDate,b.�ϥΤH��
	from (
		select a.NameOfPHP,a.Item,a.[Title]
		from dbmain.dbo.IfYouCanSee a
		where a.[User]='David'
		group by a.NameOfPHP,a.Item,a.[Title]
	) a
	left join (
		select web,sum(1.) as N,sum(case when [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao','cindy','gary') then 1. else 0 end) as NT
		,sum(case when [name] in ('david','may') then 1. else 0 end) as NDM
		,min([date]) as BDate,max([date]) as EDate
		,Count(Distinct�@case when [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao','cindy','gary') then [name] end) as �ϥΤH��
		from (
			select case when  [name] like '%[0123456789]' and [name] not like '[0123456789]%' then left([name],len([name])-4) else [name] end as [name],[web],[date],[time],[net_tag]
			from monitor.dbo.weblog
			where [date]>='2023/7/1'-- and [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao')
		) a
		group by web
	) b on b.web=a.NameOfPHP
	where a.Item is not null and a.Title is not null and a.Item not in ('','�w�U�[������')-- and isnull(b.NT,0)<=5
) a
left join (
	select a.Item,a.[Title],a.NameOfPHP,isnull(b.N,0) as ����
	from (
		select a.NameOfPHP,a.Item,a.[Title]
		from dbmain.dbo.IfYouCanSee a
		where a.[User]='David'
		group by a.NameOfPHP,a.Item,a.[Title]
	) a
	left join (
		select web,count(*) as N
		from (
			select case when  [name] like '%[0123456789]' and [name] not like '[0123456789]%' then left([name],len([name])-4) else [name] end as [name],[web],[date],[time],[net_tag]
			from monitor.dbo.weblog
			where [date]>='2023/7/1'-- and [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao')
		) a
		group by web
	) b on b.web=a.NameOfPHP
	where a.Item is not null and a.Title is not null and a.Item not in ('','�w�U�[������') and isnull(b.N,0)=0
) b on b.Item=a.Item and b.Title=a.Title and b.NameOfPHP=a.NameOfPHP
where b.NameOfPHP is null
--order by a.Item,a.Title
order by a.[����(�������x)],a.Item,a.Title

/*
select * from monitor.dbo.weblog where [web]='Deri_CBIV' order by [date] desc


select * from monitor.dbo.weblog where [date]>='2023/3/1'
select a.*
from (
	select a.Item,a.[Title],a.NameOfPHP,isnull(b.N,0) as ����,isnull(b.NT,0) as [����(�������x)]
	from (
		select a.NameOfPHP,a.Item,a.[Title]
		from dbmain.dbo.IfYouCanSee a
		where a.[User]='hubert'
		group by a.NameOfPHP,a.Item,a.[Title]
	) a
	left join (
		select web,sum(1.) as N,sum(case when [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao') then 1. else 0 end) as NT
		from monitor.dbo.weblog
		where [date]>='2022/7/1'-- and [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao')
		group by web
	) b on b.web=a.NameOfPHP
	where a.Item is null and a.Title is not null-- and isnull(b.N,0)<=5
) a
left join (
	select a.Item,a.[Title],a.NameOfPHP,isnull(b.N,0) as ����
	from (
		select a.NameOfPHP,a.Item,a.[Title]
		from dbmain.dbo.IfYouCanSee a
		where a.[User]='hubert'
		group by a.NameOfPHP,a.Item,a.[Title]
	) a
	left join (
		select web,count(*) as N
		from monitor.dbo.weblog
		where [date]>='2022/7/1' and [name] not in ('hubert','nancy','justin','jack','vic','emily','mario','yao')
		group by web
	) b on b.web=a.NameOfPHP
	where a.Item is null and a.Title is not null and isnull(b.N,0)=0
) b on b.Title=a.Title and b.NameOfPHP=a.NameOfPHP
where b.NameOfPHP is null
--order by a.Item,a.Title
order by a.[����(�������x)]

select case when CHARINDEX('_',[name])>0 then left([name],len([name])-4) else [name] end as [name]
,web,[date],[time],net_tag
,case when CHARINDEX('_',[name])>0 then right([name],3) end as [IP]
from monitor.dbo.weblog
where [date]>='2022/7/1'
order by [date],right([time],2),left([time],8)
*/

