--衍商、期交、策交
declare @delta table(Txdate datetime, stockID nvarchar(20),Delta dec(30,6))
insert @delta
select  b.*
	from (select max(Tradingdate) Tradingdate from DBMain.dbo.Tradingdate where Tradingdate>='2018' group by YEAR(Tradingdate),MONTH(Tradingdate) ) a
	left join (
	select Txdate,StockID,會計_Delta from pl.dbo.DailyPLReport_期交  where 會計_Delta<>0 
	union all 
	select Txdate,StockID,會計_Delta from pl.dbo.DailyPLReport_策交 where  會計_Delta<>0 
	union all 
	select  Txdate,StockID,會計_Delta from pl.dbo.DailyPLReport_衍商自營 where 會計_Delta<>0 
	) b on b.TxDate = a.Tradingdate
	where TxDate>='2018' and b.StockID like '%20%' and len(StockID)>=7 and  dbmain.dbo.判斷類別(b.stockid)  !='fut' and  dbmain.dbo.判斷類別(b.stockid)  !='opt'
					--and  dbmain.dbo.判斷類別(b.stockid) not in ('stock','CB','ETF','Fut','opt','US','warrant','stock.HK') 

--債券部
------------昨庫存_群益 (債券部)------------
	DECLARE @昨庫存_群益 TABLE (匯入日期 datetime, Acc NVARCHAR(10), FTR_ID NVARCHAR(20), [YM] NVARCHAR(10), Volume DECIMAL(20,8), MktPrice DECIMAL(20,8) )
	INSERT @昨庫存_群益
	SELECT 匯入日期, 交易代號,FTR_ID1,FTR_MTH1
		  ,SUM(CASE WHEN BuySell1 = 'B' THEN 1 ELSE -1 END * 未平倉口數1) AS 昨庫存
		  ,AVG(結算價1)
	FROM pl.dbo.期貨_未平倉資料_群益  a
	join  DBMain.dbo.DefaultPortfolio_債券部 b on b.Acc = 交易代號 and a.匯入日期 between b.BDate and b.EDate
	join (select max(Tradingdate) Tradingdate from DBMain.dbo.Tradingdate  group by YEAR(Tradingdate),MONTH(Tradingdate) ) t on t.Tradingdate =a.匯入日期
	where 匯入日期 >='2018'
	GROUP BY 匯入日期, 交易代號,FTR_ID1,FTR_MTH1

	------------昨庫存_凱基 (債券部)------------
	DECLARE @昨庫存_凱基 TABLE (匯入日期 datetime,Acc NVARCHAR(10), FTR_ID NVARCHAR(20), [YM] NVARCHAR(10), Volume DECIMAL(20,8), MktPrice DECIMAL(20,8) )
	INSERT @昨庫存_凱基
	SELECT 匯入日期,交易代號,z.行情代號
		  ,FTR_MTH1
	  
		  ,SUM(CASE WHEN BuySell1 = 'B' THEN 1 ELSE -1 END * 未平倉口數1) AS 昨庫存
		  ,AVG(CASE WHEN FTR_ID1 = 'BP' THEN 100. WHEN FTR_ID1 = 'JY' THEN 1/100. WHEN FTR_ID1 = 'AD' THEN 100. ELSE 1. END *  結算價1) 
	FROM pl.dbo.期貨_未平倉資料 x 
	JOIN (SELECT 商品編號 FROM pl.dbo.期貨交易明細_國外 group by 商品編號) y on y.商品編號 = x.FTR_ID1
	left  join DBMain.dbo.海外期貨代號對照表 z on z.成交明細代號= case when x.FTR_ID1= 'VXT' then 'VX' else x.FTR_ID1 end 
	join  DBMain.dbo.DefaultPortfolio_債券部 b on b.Acc = 交易代號 and x.匯入日期 between b.BDate and b.EDate
	join (select max(Tradingdate) Tradingdate from DBMain.dbo.Tradingdate  group by YEAR(Tradingdate),MONTH(Tradingdate) ) t on t.Tradingdate =x.匯入日期
	where 匯入日期 >='2018'
	GROUP BY 匯入日期,交易代號,z.行情代號,FTR_MTH1

	declare @契約乘數 table (中台代號 nvarchar(20), 彭博契約乘數  dec(30,6) )
	insert @契約乘數
	select distinct left(中台代號,len(中台代號)-6) as 中台代號,彭博契約乘數 from [MDoutput].[dbo].[海外期貨價格] 

	------------Delta_群益 (債券部)------------
declare @delta_Bond table(Txdate datetime, stockID nvarchar(20),Delta dec(30,6))
insert @delta_Bond
	SELECT stk.匯入日期
		  ,stk.FTR_ID + stk.YM  as StockID
		  --,r.DR_Rate
		  --,isnull(stk.Volume,0)  as Position
		  ,case when  e.TDEPT in ('債券') then 
							case when stk.FTR_ID = 'XT' then (3 * (1 - power(1 / (1 + (100 -  isnull(bl.彭博原始價格,stk.MktPrice * (n.契約乘數 / z.彭博契約乘數)) ) / 200), 20)) / ((100 - isnull(bl.彭博原始價格,stk.MktPrice * (n.契約乘數 / z.彭博契約乘數)) ) / 200)) + 100 * power(1 / (1 + (100 - isnull(bl.彭博原始價格, stk.MktPrice * (n.契約乘數 / z.彭博契約乘數)) ) / 200), 20)
														  else   isnull(isnull(bl.彭博價格 ,m.價格 * (m.契約乘數 / z.彭博契約乘數)) ,stk.MktPrice * (n.契約乘數 / z.彭博契約乘數))  end		
										* z.彭博契約乘數 * isnull(stk.Volume,0) * r.DR_Rate 
					 else
							 case when stk.FTR_ID = 'XT' then (3 * (1 - power(1 / (1 + (100 - coalesce(ff.價格,isnull(bl.彭博原始價格, stk.MktPrice * (n.契約乘數 / z.彭博契約乘數))) ) / 200), 20)) / ((100 - coalesce(ff.價格,isnull(bl.彭博原始價格,stk.MktPrice * (n.契約乘數 / z.彭博契約乘數))) ) / 200)) + 100 * power(1 / (1 + (100 - coalesce(ff.價格,isnull(bl.彭博原始價格,stk.MktPrice * (n.契約乘數 / z.彭博契約乘數))) ) / 200), 20)
															else   coalesce(ff.價格,isnull(bl.彭博價格 ,m.價格 * (m.契約乘數 / z.彭博契約乘數)) ,stk.MktPrice * (n.契約乘數 / z.彭博契約乘數))  end	
											* z.彭博契約乘數 * isnull(stk.Volume,0) * r.DR_Rate
					end
			as Delta

	From @昨庫存_群益 stk
	LEFT JOIN [DBMain].[dbo].[海外期貨代號對照表_群益] n on n.行情代號 = stk.FTR_ID
	LEFT JOIN @契約乘數 z on z.中台代號 = n.中台代號
	LEFT JOIN Cmoney.dbo.外國期貨交易行情表_彭博 bl on bl.中台代號  = n.中台代號 + stk.YM and bl.日期 = stk.匯入日期
	left join cmoney.dbo.外國期貨交易行情表_策交 ff on ff.行情代號 = n.中台代號 and  ff.交割月份 = stk.YM and ff.日期 = stk.匯入日期
	LEFT JOIN Cmoney.dbo.外國期貨交易行情表_衍商自營 m on m.行情代號 = n.中台代號 and  m.交割月份 = stk.YM and m.日期 = stk.匯入日期
	LEFT JOIN [DB75].[IntraWeb].[dbo].[DailyRate] r on r.DR_Currency = n.幣別 and r.DR_Date = stk.匯入日期
	LEFT JOIN [DBMain].[dbo].[AccountList_Temp] a on stk.匯入日期 between a.BDate and a.EDate and a.FuAcc00 =stk.Acc
	LEFT JOIN [DBMain].[dbo].[EmployeeID] e on e.NameEn = a.NameEn 

	----------Delta_凱基 (債券部)------------
	insert @delta_Bond
	SELECT  stk.匯入日期
		  ,stk.FTR_ID+stk.YM  as StockID
		  --,r.DR_Rate
		  --,case when a.Acc00='711' then f7111.LastPrice
		  --     else coalesce(bl.彭博原始價格 ,m.價格 * (m.契約乘數 / z.彭博契約乘數) , stk.MktPrice* (n.契約乘數 / z.彭博契約乘數)  ) end  as [LastPrice]
		  --,isnull(stk.Volume,0)  as Position
		  ,case	when stk.FTR_ID ='ED' then stk.MktPrice * 2500. * r.DR_Rate * isnull(stk.Volume,0) 
					when stk.FTR_ID ='TU' then stk.MktPrice * 2000. * r.DR_Rate * isnull(stk.Volume,0) 
					else   ( case when a.acc00='711'	then f7111.LastPrice
									   when e.TDEPT in ('債券') 
											then  stk.MktPrice * (n.契約乘數 / z.彭博契約乘數) 
											else coalesce(bl.彭博原始價格 ,m.價格 * (m.契約乘數 / z.彭博契約乘數) , stk.MktPrice * (n.契約乘數 / z.彭博契約乘數) ) end) 
					* z.彭博契約乘數 * case when a.acc00='711' then isnull(stk.Volume,0)  else isnull(stk.Volume,0) end * r.DR_Rate  end
				as Delta
	From @昨庫存_凱基 stk
	LEFT JOIN [DBMain].[dbo].[海外期貨代號對照表] n on n.行情代號 = stk.FTR_ID
	LEFT JOIN @契約乘數 z on z.中台代號 = n.中台代號
	LEFT JOIN Cmoney.dbo.外國期貨交易行情表_彭博 bl on bl.中台代號 = n.中台代號 + stk.YM  and bl.日期 = stk.匯入日期
	LEFT JOIN Cmoney.dbo.外國期貨交易行情表_衍商自營 m on m.行情代號 = n.中台代號 and  m.交割月份 = stk.YM and m.日期 = stk.匯入日期
	LEFT JOIN Intraday.dbo.tblTickETFDaily m1 on m1.StockID =n.行情代號 + stk.YM and m1.TxDate=stk.匯入日期
	LEFT JOIN [DB75].[IntraWeb].[dbo].[DailyRate] r on r.DR_Currency = n.幣別 and r.DR_Date = stk.匯入日期
	LEFT JOIN [DBMain].[dbo].[AccountList_Temp] a on stk.匯入日期 between a.BDate and a.EDate and a.FuAcc00 = stk.Acc
	LEFT JOIN [DBMain].[dbo].[EmployeeID] e on e.NameEn = a.NameEn 
	left join pl.dbo.DailyPLReport_衍商自營 f7111 on f7111.TxDate=stk.匯入日期 and f7111.Acc=a.FuAcc00 and f7111.StockID=stk.FTR_ID + stk.YM

	/* 明細
	select a.*,case when d.Tag like '%匯率%' then '匯率' when  d.Tag like '%指數%' then '股權' when  d.Tag like '%利率%' then '債券' else c.分類 end as 分類 , isnull(d.Tag, c.名稱) as 名稱 
	from @delta a
	left join [DBMain].[dbo].[海外期貨分類] c on c.代號 = left(a.StockID,len(a.StockID)-6)
	left join(select distinct StockID,Tag from [FrontDeskW].[dbo].[股匯債代號對應] )d on d.[StockID] = left(a.StockID,len(a.StockID)-6)
	order by Txdate, case when d.Tag like '%匯率%' then '匯率' when  d.Tag like '%指數%' then '股權' when  d.Tag like '%利率%' then '債券' else c.分類 end

	select a.*,case when d.Tag like '%匯率%' then '匯率' when  d.Tag like '%指數%' then '股權' when  d.Tag like '%利率%' then '債券' else c.分類 end as 分類 , isnull(d.Tag, c.名稱) as 名稱
	from @delta_Bond a
	left join [DBMain].[dbo].[海外期貨分類] c on c.代號 = left(a.StockID,len(a.StockID)-6)
	left join(select distinct StockID,Tag from [FrontDeskW].[dbo].[股匯債代號對應] )d on d.[StockID] = left(a.StockID,len(a.StockID)-6)
	order by Txdate , case when d.Tag like '%匯率%' then '匯率' when  d.Tag like '%指數%' then '股權' when  d.Tag like '%利率%' then '債券' else c.分類 end
	*/


--Output
create table #tmp (TxDate nvarchar(20),分類 nvarchar(20), Delta dec(20,2))
insert #tmp
	select left(dbmain.dbo.DateTranslator( a.Txdate,3) ,6) as YM,case when d.Tag like '%匯率%' then '匯率' when  d.Tag like '%指數%' then '股權' when  d.Tag like '%利率%' then '債券' else c.分類 end as 分類
				,sum(Delta/1000000.) Delta
	from (
		select * from @delta
		union all
		select * from @delta_Bond
	) a
	left join [DBMain].[dbo].[海外期貨分類] c on c.代號 = left(a.StockID,len(a.StockID)-6)
	left join(select distinct StockID,Tag from [FrontDeskW].[dbo].[股匯債代號對應] )d on d.[StockID] = left(a.StockID,len(a.StockID)-6)
	group by left(dbmain.dbo.DateTranslator( a.Txdate,3) ,6),  case when d.Tag like '%匯率%' then '匯率' when  d.Tag like '%指數%' then '股權' when  d.Tag like '%利率%' then '債券' else c.分類 end 

DECLARE @cols AS NVARCHAR(MAX),
    @query  AS NVARCHAR(MAX)

select @cols = STUFF((SELECT ',' + QUOTENAME(Txdate) 
                    from #tmp
                    group by Txdate
                    order by Txdate
            FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)') 
        ,1,1,'')

--SELECT的欄位
DECLARE @select_columns NVARCHAR (MAX) = '[分類]';
SELECT @select_columns = @select_columns +  ',ISNULL(' +  QUOTENAME(T.Txdate) + ',0) as '  +QUOTENAME(T.Txdate) +''
FROM  (SELECT DISTINCT Txdate FROM #tmp) T
ORDER BY T.Txdate;


set @query = 'SELECT 分類' +@select_columns + ' from 
             (
                select Txdate, 分類, Delta
                from #tmp
            ) x
            pivot 
            (
                max(Delta)
                for Txdate in (' + @cols + ')
            ) p  '

execute(@query);

drop table #tmp