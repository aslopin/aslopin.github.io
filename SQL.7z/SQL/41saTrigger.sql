USE [master]
GO

/****** Object:  DdlTrigger [tr_connection_limit_sa]    Script Date: 2019/7/12 �W�� 08:03:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




































create TRIGGER [tr_connection_limit_sa]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'sa' 

     begin
		 if @ip in (select IP from DailyInsert.[dbo].[MDBreakList]) and @ap like '%Office%'
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Microsoft SQL Server Management Studio%' AND @ip not IN('172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.128','172.24.26.169','172.24.26.192')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%.Net SqlClient Data Provider%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.169','172.24.26.192')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Python%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.128','172.24.26.195','172.24.26.109','172.24.26.169','172.24.26.192')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%RStudio%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.128','172.24.26.195','172.24.26.109','172.24.26.169','172.24.26.192')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Office%' AND @ip not IN('172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.151','172.24.26.128','172.24.26.169','172.24.26.192')
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 end

		 if @ap not like '%Office%' AND @ap not like '%Microsoft SQL Server%' AND @ap not like '%Apache HTTP Server%' AND @ap not like '%SSIS%'
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end
	 end


  






























GO

ENABLE TRIGGER [tr_connection_limit_sa] ON ALL SERVER
GO


