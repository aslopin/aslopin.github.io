

select b.StockID,min(b.StockName) as [StockName]
,avg(c.Vol) as [GYVol]
,avg(c2.Vol) as [GYVol����e]
,avg(c.Vol)/avg(c2.Vol)-1 as [�W�ɴT��] 
,avg(a.Vol) as [BookVol]
,(avg(c.Vol)/avg(a.Vol))*(avg(c.Vol)/avg(a.Vol))-1
 as [GY_BookGamma]
,avg(c.Vol)/avg(a.Vol)
 as [GY_Book����]
,avg(pl.Theta�ۮa) as [Theta�ۮa]
,avg(pl.Theta�L�a) as [Theta�L�a]
,avg(d1.ADX7) as [ADX7]
,avg(d1.�Ͷի���) as [DMIScore]
,b.StockID+'_'+min(b.StockName) as [Underlying]
from pl.[dbo].[�ۮa�v�ҨC��BookVol�պ�] a
join dbmain.dbo.warrantprofileTS b on b.warrantid=a.warrantid and b.issuedate=a.issuedate
join theodata.dbo.historyvol c on c.Stadate=a.TxDate and c.seccode=b.stockid and c.Tag='GKYZ5'
join theodata.dbo.historyvol c2 on c2.Stadate='2017/6/20' and c2.seccode=b.stockid and c2.Tag='GKYZ5'
left join (
select  �Ъ��N��,sum(Theta�ۮa) as Theta�ۮa,sum(Theta�L�a) as Theta�L�a
from pl.[dbo].[DailyPLReport_WPV]
where Stadate='2017/6/27' 
group by �Ъ��N��
) pl on pl.�Ъ��N��=b.stockid
left join z.[dbo].[�v�����˫���_DMI] d1 on d1.txdate=a.Txdate and d1.�Ъ��N��=b.stockid
where a.TxDate='2017/6/27' and a.Tag='22_66_126�s����'
group by b.StockID
order by avg(c.Vol)/avg(a.Vol) desc
--order by avg(c.Vol) desc
--order by avg(c.Vol)/avg(c2.Vol) desc
/*
select a.Warrantid,b.StockID,a.Vol,c.Vol
from pl.[dbo].[�ۮa�v�ҨC��BookVol�պ�] a
join dbmain.dbo.warrantprofileTS b on b.warrantid=a.warrantid and b.issuedate=a.issuedate
join theodata.dbo.historyvol c on c.Stadate=a.TxDate and c.seccode=b.stockid and c.Tag='GKYZ5'
join theodata.dbo.historyvol c2 on c2.Stadate='2017/6/20' and c2.seccode=b.stockid and c2.Tag='GKYZ5'
where a.TxDate='2017/6/27' and a.Tag='22_66_126�s����'
*/