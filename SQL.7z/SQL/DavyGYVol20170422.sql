/*
exec DailyInsert.dbo.DB_Intraday_�L��GYVol
*/
alter procedure dbo.DB_Intraday_�L��GYVol
as
declare @t datetime set @t=(select max(���) from db.cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)

create table #StockID(StockID nvarchar(50))
insert #StockID
--select '3481'
select distinct(StockID) from db.dbmain.dbo.WarrantProfileTS where expireddate>=@t

create table #TickGY(StockID nvarchar(50),Tick_Time nvarchar(50),Tick_Price decimal(20,4),Tick_PriceMax decimal(20,4),Tick_PriceMin decimal(20,4),ser decimal(20,6))
insert #TickGY
select a.StockID,a.Tick_Time,Tick_Price,Tick_PriceMax,Tick_PriceMin,c.ser
from Tick.[dbo].[tbl_Tick_Today_S2017](nolock) a
join #StockID b on b.StockID=a.stockid
join dbmain.[dbo].[TimeTag] c on c.TimeTag=a.Tick_Time+'0000'


create table #TickGY2(StockID nvarchar(50),Tick_Time nvarchar(50)
,Tick_Price decimal(20,4),Tick_PriceMax decimal(20,4),Tick_PriceMin decimal(20,4),Tick_PriceO decimal(20,4),Tick_PricePre decimal(20,4),ser decimal(20,6))
insert #TickGY2
select a.StockID,a.Tick_Time,a.Tick_Price,b.Tick_PriceMax,b.Tick_PriceMin,isnull(d.Tick_Price,c.FairPrice) as Tick_PriceO,c.FairPrice as Tick_PricePre,a.ser
from #TickGY a
join (
	select a.StockID,a.Tick_Time,max(b.Tick_PriceMax) as Tick_PriceMax,min(b.Tick_PriceMin) as Tick_PriceMin
	from #TickGY a
	join #TickGY b on b.StockID=a.StockID and b.Tick_Time<=a.Tick_Time
	group by a.StockID,a.Tick_Time,a.Tick_Price
) b on b.StockID=a.StockID and b.Tick_Time=a.Tick_Time
join Tick.[dbo].[tbl_Day_MinMax] c on c.In_Time=@tt and c.StockId=a.StockID
left join #TickGY d on d.StockID=a.StockID and d.Tick_Time='0901'

delete db.intraday.dbo.�L��GYVol where TxDate=@t
insert db.intraday.dbo.�L��GYVol
select @t,a.Tick_Time,a.StockID,a.Tick_Price
/*
,a.*
*/
,sqrt(
 (log(Tick_PriceO/Tick_PricePre)*log(Tick_PriceO/Tick_PricePre))
+0.5*(log(Tick_PriceMax/Tick_PriceMin)*log(Tick_PriceMax/Tick_PriceMin))
-(2*log(2.)-1)*(log(Tick_Price/Tick_PriceO)*log(Tick_Price/Tick_PriceO))
 )*sqrt(252)--*sqrt(270/a.ser)
as GYVol
,a.Tick_PriceO,a.Tick_PriceMax,a.Tick_PriceMin,a.Tick_PricePre,a.ser
from #TickGY2 a
where a.Tick_Time>='0910'



drop table #StockID
drop table #TickGY
drop table #TickGY2

