declare @temp table(TxDate datetime,Tag nvarchar(50),MV decimal(20,4),[MV*R] decimal(20,4))
insert @temp
select a.TxDate,'�ŤG'
, sum( case when a.ASW_ID like 'ASWBI%' then 0 when a.ASW_BS='buy' then 1 else -1 end* case when a.TxDate>='2017/8/28' then a.ASW_PRINCIPAL else 0 end ) as MV
, sum( case when a.ASW_ID like 'ASWBI%' then 0 when a.ASW_BS='buy' then 1 else -1 end* case when a.TxDate>='2017/8/28' then a.ASW_PRINCIPAL*a.ASW_RATE/100. else 0 end ) as [MV*R]
from dbmain.dbo.CBAS_ASW a
join cb.dbo.CBData b on b.TxDate=a.TxDate and b.�i��ťN�X=a.ASW_CB
join cmoney.[dbo].[�W���d���q�򥻸��] c on c.�Ѳ��N��=b.�ഫ�Ъ�
where a.TxDate>='2017/8/28' and a.ASW_ID like '%_TC'
group by a.TxDate

insert @temp
select a.TxDate,'�ŤG'
, sum( case when a.ASW_ID like 'ASWBI%' then 0 when a.ASW_BS='buy' then 1 else -1 end* case when a.TxDate>='2017/8/28' then a.ASW_PRINCIPAL else 0 end) as MV
, sum( case when a.ASW_ID like 'ASWBI%' then 0 when a.ASW_BS='buy' then 1 else -1 end* case when a.TxDate>='2017/8/28' then a.ASW_PRINCIPAL*a.ASW_RATE/100. else 0 end) as [MV*R]
from dbmain.dbo.CBAS_ASW a
join cb.dbo.CBData b on b.TxDate=a.TxDate and b.�i��ťN�X=a.ASW_CB
join cmoney.[dbo].[�W���d���q�򥻸��] c on c.�Ѳ��N��=b.�ഫ�Ъ�
join DBbondopen.tsdb.[dbo].[USERS] as e on a.creator = e.Usr_USERID
where a.TxDate>='2017/8/28'
and e.usr_Deptid='FIXED_INCOME2'
group by a.TxDate

insert @temp
select a.TxDate,'�Ť@'
, sum( case when a.ASW_ID like 'ASWBI%' then 0 when a.ASW_BS='buy' then 1 else -1 end* a.ASW_PRINCIPAL) as MV
, sum( case when a.ASW_ID like 'ASWBI%' then 0 when a.ASW_BS='buy' then 1 else -1 end* a.ASW_PRINCIPAL*a.ASW_RATE/100.) as [MV*R]
from dbmain.dbo.CBAS_ASW a
join cb.dbo.CBData b on b.TxDate=a.TxDate and b.�i��ťN�X=a.ASW_CB
join cmoney.[dbo].[�W���d���q�򥻸��] c on c.�Ѳ��N��=b.�ഫ�Ъ�
join DBbondopen.tsdb.[dbo].[USERS] as e on a.creator = e.Usr_USERID
where a.TxDate>='2017/1/1'
and e.usr_Deptid='FIXED_INCOME1'
group by a.TxDate


insert @temp
select a.TxDate,'�ŤG'
, sum( case when a.ASO_BS='Sell' then 1 else 0 end* case when a.TxDate>='2017/8/28' then a.ASO_PRINCIPAL*100*1000 else 0 end ) as MV
, sum( case when a.ASO_BS='Sell' then 1 else 0 end* case when a.TxDate>='2017/8/28' then a.ASO_PRINCIPAL*100*1000*a.ASO_R/100. else 0 end ) as [MV*R]
from dbmain.dbo.CBAS_ASO a
join cb.dbo.CBData b on b.TxDate=a.TxDate and b.�i��ťN�X=a.ASO_CB
join cmoney.[dbo].[�W���d���q�򥻸��] c on c.�Ѳ��N��=b.�ഫ�Ъ�
where a.TxDate>='2017/8/28' and a.ASO_ID like '%_TC'
group by a.TxDate

insert @temp
select a.TxDate,'�ŤG'
, sum( case when a.ASO_BS='Sell' then 1 else 0 end* case when a.TxDate>='2017/8/28' then a.ASO_PRINCIPAL*100*1000 else 0 end ) as MV
, sum( case when a.ASO_BS='Sell' then 1 else 0 end* case when a.TxDate>='2017/8/28' then a.ASO_PRINCIPAL*100*1000*a.ASO_R/100. else 0 end ) as [MV*R]
from dbmain.dbo.CBAS_ASO a
join cb.dbo.CBData b on b.TxDate=a.TxDate and b.�i��ťN�X=a.ASO_CB
join cmoney.[dbo].[�W���d���q�򥻸��] c on c.�Ѳ��N��=b.�ഫ�Ъ�
join DBbondopen.tsdb.[dbo].[USERS] as e on a.creator = e.Usr_USERID
where a.TxDate>='2017/8/28'
and e.usr_Deptid='FIXED_INCOME2'
group by a.TxDate

insert @temp
select a.TxDate,'�Ť@'
, sum( case when a.ASO_BS='Sell' then 1 else 0 end* a.ASO_PRINCIPAL*100*1000 ) as MV
, sum( case when a.ASO_BS='Sell' then 1 else 0 end* a.ASO_PRINCIPAL*100*1000*a.ASO_R/100. ) as [MV*R]
from dbmain.dbo.CBAS_ASO a
join cb.dbo.CBData b on b.TxDate=a.TxDate and b.�i��ťN�X=a.ASO_CB
join cmoney.[dbo].[�W���d���q�򥻸��] c on c.�Ѳ��N��=b.�ഫ�Ъ�
join DBbondopen.tsdb.[dbo].[USERS] as e on a.creator = e.Usr_USERID
where a.TxDate>='2017/1/1'
and e.usr_Deptid='FIXED_INCOME1'
group by a.TxDate

select x.TxDate
,x.�Ť@����/100000000. as �Ť@����
,x.�ŤG����/100000000. as �ŤG����
,(x.�Ť@�Q�v-y.rate)*x.�Ť@����/252. as �Ť@�z��PL
,(x.�ŤG�Q�v-y.rate)*x.�ŤG����/252. as �ŤG�z��PL
,x.�Ť@�Q�v-y.rate as �Ť@�Q�t
,x.�ŤG�Q�v-y.rate as �ŤG�Q�t
,x.�Ť@�Q�v
,x.�ŤG�Q�v
from (
	select TxDate
	,sum(case when Tag='�Ť@' then MV else 0 end)
	 as �Ť@����
	,sum(case when Tag='�ŤG' then MV else 0 end)
	 as �ŤG����
	,case when sum(case when Tag='�Ť@' then MV else 0 end)<>0 then sum(case when Tag='�Ť@' then [MV*R] else 0 end)/sum(case when Tag='�Ť@' then MV else 0 end) end
	 as �Ť@�Q�v
	,case when sum(case when Tag='�ŤG' then MV else 0 end)<>0 then sum(case when Tag='�ŤG' then [MV*R] else 0 end)/sum(case when Tag='�ŤG' then MV else 0 end) end
	 as �ŤG�Q�v
	from @temp
	group by TxDate
) x
left join testpa.dbo.�]�ȳ��Q�v y on x.TxDate between y.Bdate and y.Edate
order by TxDate

select TxDate
,sum(case when Dept='�Ť@' then TotalPL else 0 end) as �Ť@
,sum(case when Dept='�ŤG' then TotalPL else 0 end) as �ŤG
from pl.[dbo].[CBASDailiPLReportMD]
where TxDate>='2017/11/1'
and [ID] like 'ASOB%'
group by TxDate
order by TxDate

select *
from pl.[dbo].[CBASDailiPLReportMD]
where TxDate>='2017/11/1'
and [ID] like 'ASOB%'
