declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

select sum(a.volume*(b.LastPrice-a.LastPrice)*case when dbmain.dbo.�P�_���O(a.StockID)='warrant' then 1 else b.delta end) as PL_Diff
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.stadate=@t and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.[User]='J1040001'
and a.Volume<>0

select a.underlying
,sum(a.volume*(b.LastPrice-a.LastPrice)*case when dbmain.dbo.�P�_���O(a.StockID)='warrant' then 1 else b.delta end) as PL_Diff
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.stadate=@t and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.[User]='J1040001'
and a.Volume<>0
group by a.underlying
order by sum(a.volume*(b.LastPrice-a.LastPrice)*case when dbmain.dbo.�P�_���O(a.StockID)='warrant' then 1 else b.delta end)


select a.volume*(b.LastPrice-a.LastPrice)*case when dbmain.dbo.�P�_���O(a.StockID)='warrant' then 1 else b.delta end as PL_Diff
,*
from pl.dbo.InventoryMay4 a
left join pl.dbo.inventory b on b.stadate=@t and b.portfolio=a.portfolio and b.[Type]=a.[Type] and b.StockID=a.StockID
where a.[User]='J1040001'
and a.Volume<>0
order by a.volume*(b.LastPrice-a.LastPrice)*case when dbmain.dbo.�P�_���O(a.StockID)='warrant' then 1 else b.delta end
