select Top 10 * from db2.tick.[dbo].[tbl_Tick_Today_New]

select min([No])from db2.tick.[dbo].[tbl_Tick_Today_New]

--insert db2.tick.[dbo].[tbl_Tick_Today_New](Out_Time, StockId, Tick_Time, Tick_Price, Tick_Qty, B1_Price, B1_Qty, B2_Price, B2_Qty, B3_Price, B3_Qty, B4_Price, B4_Qty, B5_Price, B5_Qty, A1_Price, A1_Qty, A2_Price, A2_Qty, A3_Price, A3_Qty, A4_Price, A4_Qty, A5_Price, A5_Qty, Sum_Qty, Normal_Try )
select Out_Time, StockId, Out_Time, Tick_Price, Tick_Qty, B1_Price, B1_Qty, B2_Price, B2_Qty, B3_Price, B3_Qty, B4_Price, B4_Qty, B5_Price, B5_Qty, A1_Price, A1_Qty, A2_Price, A2_Qty, A3_Price, A3_Qty, A4_Price, A4_Qty, A5_Price, A5_Qty, Sum_Qty, Normal_Try 
from db39.tick.[dbo].[tbl_Tick_Today_snapshot]
where Tick_Time between '100300000000' and '103000000000' and Normal_Try<>''


select * from db2.tick.[dbo].[tbl_Tick_Today_New] where stockid='2301'
order by Tick_Time


delete db2.tick.[dbo].[tbl_Tick_Today_New] where in_Time is null
