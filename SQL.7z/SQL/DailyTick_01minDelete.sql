declare @t datetime,@b datetime,@e datetime
set @b='2016/6/1'
set @e='2016/7/29'

set @t=@b

while @t<=@e
  begin
  print @t
  exec DailyInsert.[dbo].[Intraday_DailyTick_01min_NW] @t
  --delete intraday.[dbo].[DailyTick_01min] where [TxDate]=@t
  --delete intraday.[dbo].[DailyTick_01min_FU] where [TxDate]=@t
  set @t=dateadd(dd,1,@t)
  end

