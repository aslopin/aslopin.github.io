declare @t datetime set @t='2017/8/8'

select x.Stadate,sum(x.���l)/sum(x.����) as Ratio
from (
	select x.Stadate,x.Underlying
	,sum(x.abs_MTM_T) as ���l
	,avg(x.abs_MTM_Total) as ����
	from (
		select x.Stadate,x.Underlying
		,rank() over(partition by x.Stadate,x.Underlying order by abs(MTM_D) desc,[Hour],[Min],[Sec])
		 as Rnk
		,abs(MTM_D) as abs_MTM_T
		,sum(abs(MTM_D)) over(partition by x.Stadate,x.Underlying)
		 as abs_MTM_Total
		from (
			select Stadate,Underlying,[Hour],[Min],[Sec]
			,isnull(MTM_D-lag(MTM_D) over(partition by Stadate,Underlying order by [Hour],[Min],[Sec]),0)
			 as MTM_D
			from (
					select Stadate,[Hour],[Min],[Sec],Underlying,MTM_D
					from [Intraday].[dbo].[�L��May3����]
					where Stadate>='2017/5/1'
				 ) x
		) x
	) x
	where x.Rnk<=5
	group by x.Stadate,x.Underlying
) x
group by x.Stadate
order by x.Stadate


select x.Stadate,x.Underlying
,case when avg(x.abs_MTM_Total)<>0 then sum(x.abs_MTM_T)/avg(x.abs_MTM_Total) else 0 end
 as Ratio
from (
	select x.Stadate,x.Underlying
	,rank() over(partition by x.Stadate,x.Underlying order by abs(MTM_D) desc,[Hour],[Min],[Sec])
	 as Rnk
	,abs(MTM_D) as abs_MTM_T
	,sum(abs(MTM_D)) over(partition by x.Stadate,x.Underlying)
	 as abs_MTM_Total
	from (
		select Stadate,Underlying,[Hour],[Min],[Sec]
		,isnull(MTM_D-lag(MTM_D) over(partition by Stadate,Underlying order by [Hour],[Min],[Sec]),0)
		 as MTM_D
		from (
				select Stadate,[Hour],[Min],[Sec],Underlying,MTM_D
				from [Intraday].[dbo].[�L��May3����]
				where Stadate=@t
             ) x
	) x
) x
where x.Rnk<=5
group by x.Stadate,x.Underlying
order by case when avg(x.abs_MTM_Total)<>0 then sum(x.abs_MTM_T)/avg(x.abs_MTM_Total) else 0 end desc





