declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory) declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)

declare @TimeTag table(TimeTag nvarchar(50))
insert @TimeTag
select TimeTag
from dbmain.[dbo].[TimeTag]
where theodata.dbo.[mod](ser,5)=0
and ser between 20 and 260

declare @MaxVolume table(Stadate datetime,Portfolio nvarchar(50),WarrantID nvarchar(50),Volume decimal(20,4),MaxVolumeDate datetime,MaxVolume decimal(20,4))
insert @MaxVolume
select b.Stadate,b.Portfolio,a.WarrantID
,b.volume
,FIRST_VALUE(b.Stadate) OVER (PARTITION BY b.Portfolio,a.WarrantID ORDER BY b.Portfolio,a.WarrantID,b.volume) AS MaxVolumeDate
,FIRST_VALUE(b.volume) OVER (PARTITION BY b.Portfolio,a.WarrantID ORDER BY b.Portfolio,a.WarrantID,b.volume) AS MaxVolume

from dbmain.dbo.WarrantProfileTS a
join pl.dbo.inventory b on b.Portfolio=a.WarrantKey and b.StockID=a.WarrantID
order by b.Portfolio,a.WarrantID,b.volume

declare @MaxVolumeDate table(Portfolio nvarchar(50),WarrantID nvarchar(50),MaxVolumeDate datetime,MaxVolume decimal(20,4))
insert @MaxVolumeDate
select Portfolio,WarrantID,MaxVolumeDate,MaxVolume
from @MaxVolume
group by Portfolio,WarrantID,MaxVolumeDate,MaxVolume

declare @���ɧ����t table(Portfolio nvarchar(50),WarrantID nvarchar(50),���ɧ����t decimal(20,4))
insert @���ɧ����t
select a.Portfolio,a.WarrantID
,avg(mm.Ps1-mm.Pb1) as ���ɧ����t
from @MaxVolumeDate a
cross join @TimeTag t
left join intraday.[dbo].[WarrantMMOrder] mm on mm.TxDate=a.MaxVolumeDate and mm.[WarrantID]=a.warrantid and t.TimeTag>=mm.[BTime] and t.TimeTag<mm.[ETime]
where Ps1>Pb1
group by a.Portfolio,a.WarrantID

declare @out table(WarrantID nvarchar(50),WarrantName nvarchar(50),StockID nvarchar(50),StockName nvarchar(50),TimeTag nvarchar(50)
,Pb1 decimal(20,10),Ps1 decimal(20,10),TheoB decimal(20,10),TheoA decimal(20,10),WTax decimal(20,10),STax decimal(20,10),Fix decimal(20,10),Fee decimal(20,10),IssueCost decimal(20,10)
)
insert @out
select a.WarrantID,a.WarrantName,a.StockID,a.StockName
,t.TimeTag
,mm.Pb1,mm.Ps1
,theodata.dbo.optvlu(u.[B1_Price],b.Strike,b.Barrier,b.[T�����],b.PricingVol,b.r,a.warrantid,b.Exer)
 as TheoB
,theodata.dbo.optvlu(u.[A1_Price],b.Strike,b.Barrier,b.[T�����],b.PricingVol,b.r,a.warrantid,b.Exer)
 as TheoA
,theodata.dbo.optvlu(u.[A1_Price],b.Strike,b.Barrier,b.[T�����],b.PricingVol,b.r,a.warrantid,b.Exer)
*1/1000.
 as WTax
,theodata.dbo.optdelta(u.[A1_Price],b.Strike,b.Barrier,b.[T�����],b.PricingVol,b.r,a.warrantid)*b.Exer
*u.[A1_Price]
*case when left(a.StockID,2)='00' then 1 else 3 end/1000.
 as STax
,0.0000005 as Fix
,
(theodata.dbo.optvlu(u.[A1_Price],b.Strike,b.Barrier,b.[T�����],b.PricingVol,b.r,a.warrantid,b.Exer)
+theodata.dbo.optdelta(u.[A1_Price],b.Strike,b.Barrier,b.[T�����],b.PricingVol,b.r,a.warrantid)*b.Exer
*u.[A1_Price]
)*0.0001
 as Fee
,IssueCost/IssueUnits/1000.
 as IssueCost
from dbmain.[dbo].[WarrantProfileTS_Daily] a
left join pro.[dbo].[�v�ҵ������] b on b.TxDate=a.TxDate and b.warrantid=a.warrantid
cross join @TimeTag t
left join intraday.[dbo].[WarrantMMOrder] mm on mm.TxDate=a.TxDate and mm.[WarrantID]=a.warrantid and t.TimeTag>=mm.[BTime] and t.TimeTag<mm.[ETime]
left join db2.[Intraday].[dbo].[DailyTick_Underlying] u on u.TxDate=a.TxDate and u.StockID=a.StockID and t.TimeTag>=u.[BTime] and t.TimeTag<u.[ETime]
where a.TxDate=@t
--and a.WarrantID='034506'

declare @�ثe�����t table(WarrantID nvarchar(50),WarrantName nvarchar(50),StockID nvarchar(50),StockName nvarchar(50)
,�ثe�����t decimal(20,4),�z�׻��t decimal(20,4))
insert @�ثe�����t
select WarrantID,WarrantName,StockID,StockName
,avg(Ps1-Pb1) as �ثe�����t
,avg(TheoA+WTax+STax+Fix+Fee+IssueCost-TheoB) as �z�׻��t
--,avg(WTax) as WTax
--,avg(STax) as STax
--,avg(Fix+Fee+IssueCost) as Fee
from @out
where Ps1>Pb1
group by WarrantID,WarrantName,StockID,StockName


select a.WarrantID,a.WarrantName,a.StockID,a.StockName
,a.�ثe�����t*100 as �ثe�����t
,a.�z�׻��t*100 as �z�׻��t
,b.���ɧ����t*100 as ���ɧ����t
from @�ثe�����t a
left join @���ɧ����t b on b.WarrantID=a.WarrantID

/*
select WarrantID,WarrantName,StockID,StockName,TimeTag
,Pb1,Ps1,TheoB
,TheoA+WTax+STax+Fix+Fee+IssueCost
 as �������
,TheoA+WTax+STax+Fix+Fee+IssueCost-TheoB-(Ps1-Pb1)
 as ���W���t
,TheoA,WTax,STax,Fix,Fee,IssueCost
from @out
*/
