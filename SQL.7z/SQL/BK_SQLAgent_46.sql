USE [msdb]
GO

/****** Object:  Job [DB restory_daily]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DB restory_daily', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB restory_daily]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB restory_daily', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*

RESTORE DATABASE [Accounting] FROM  DISK = N''E:\MS SQL BAK.46\Accounting.BAK'' WITH  FILE = 1,  
MOVE N''Accounting'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Accounting'',  
MOVE N''Accounting_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Accounting_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [ATP] FROM  DISK = N''E:\MS SQL BAK.46\ATP.BAK'' WITH  FILE = 1,  
MOVE N''ATP'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\ATP'',  
MOVE N''ATP_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\ATP_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [CB] FROM  DISK = N''E:\MS SQL BAK.46\CB.BAK'' WITH  FILE = 1,  
MOVE N''CB'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CB'',  
MOVE N''CB_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CB_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Cmoney] FROM  DISK = N''E:\MS SQL BAK.46\Cmoney.BAK'' WITH  FILE = 1,  
MOVE N''Cmoney'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Cmoney'',  
MOVE N''Cmoney_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Cmoney_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Credit] FROM  DISK = N''E:\MS SQL BAK.46\Credit.BAK'' WITH  FILE = 1,  
MOVE N''Credit'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Credit'',  
MOVE N''Credit_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Credit_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [DailyInsert] FROM  DISK = N''E:\MS SQL BAK.46\DailyInsert.BAK'' WITH  FILE = 1,  
MOVE N''DailyInsert'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DailyInsert'',  
MOVE N''DailyInsert_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DailyInsert_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [DBMain] FROM  DISK = N''E:\MS SQL BAK.46\DBMain.BAK'' WITH  FILE = 1,  
MOVE N''DBMain'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMain'',  
MOVE N''DBMain_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMain_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [DBMonitor] FROM  DISK = N''E:\MS SQL BAK.46\DBMonitor.BAK'' WITH  FILE = 1,  
MOVE N''DBMonitor'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMonitor'',  
MOVE N''DBMonitor_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMonitor_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [FrontDeskW] FROM  DISK = N''E:\MS SQL BAK.46\FrontDeskW.BAK'' WITH  FILE = 1,  
MOVE N''FrontDeskW'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\FrontDeskW'',  
MOVE N''FrontDeskW_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\FrontDeskW_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Hubert] FROM  DISK = N''E:\MS SQL BAK.46\Hubert.BAK'' WITH  FILE = 1,  
MOVE N''Hubert'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Hubert'',  
MOVE N''Hubert_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Hubert_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [IDDataTransfer] FROM  DISK = N''E:\MS SQL BAK.46\IDDataTransfer.BAK'' WITH  FILE = 1,  
MOVE N''IDDataTransfer'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\IDDataTransfer'',  
MOVE N''IDDataTransfer_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\IDDataTransfer_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Intraday] FROM  DISK = N''E:\MS SQL BAK.46\Intraday.BAK'' WITH  FILE = 1,  
MOVE N''Intraday'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Intraday'',  
MOVE N''Intraday_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Intraday_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [LoginDefault] FROM  DISK = N''E:\MS SQL BAK.46\LoginDefault.BAK'' WITH  FILE = 1,  
MOVE N''LoginDefault'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\LoginDefault'',  
MOVE N''LoginDefault_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\LoginDefault_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [MarketData] FROM  DISK = N''E:\MS SQL BAK.46\MarketData.BAK'' WITH  FILE = 1,  
MOVE N''MarketData'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MarketData'',  
MOVE N''MarketData_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MarketData_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [MDoutput] FROM  DISK = N''E:\MS SQL BAK.46\MDoutput.BAK'' WITH  FILE = 1,  
MOVE N''MDoutput'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MDoutput'',  
MOVE N''MDoutput_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MDoutput_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Monitor] FROM  DISK = N''E:\MS SQL BAK.46\Monitor.BAK'' WITH  FILE = 1,  
MOVE N''Monitor'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Monitor'',  
MOVE N''Monitor_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Monitor_log'',  
NOUNLOAD,  REPLACE,  STATS = 5

RESTORE DATABASE [Myproject] FROM  DISK = N''E:\MS SQL BAK.46\Myproject.BAK'' WITH  FILE = 1,  
MOVE N''Myproject'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Myproject'',  
MOVE N''Myproject_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Myproject_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [OperationDesk] FROM  DISK = N''E:\MS SQL BAK.46\OperationDesk.BAK'' WITH  FILE = 1,  
MOVE N''OperationDesk'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OperationDesk'',  
MOVE N''OperationDesk_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OperationDesk_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [OTC] FROM  DISK = N''E:\MS SQL BAK.46\OTC.BAK'' WITH  FILE = 1,  
MOVE N''OTC'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OTC'',  
MOVE N''OTC_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OTC_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [PL] FROM  DISK = N''E:\MS SQL BAK.46\PL.BAK'' WITH  FILE = 1,  
MOVE N''PL'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\PL'',  
MOVE N''PL_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\PL_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Pro] FROM  DISK = N''E:\MS SQL BAK.46\Pro.BAK'' WITH  FILE = 1,  
MOVE N''Pro'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Pro'',  
MOVE N''Pro_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Pro_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Ray] FROM  DISK = N''E:\MS SQL BAK.46\Ray.BAK'' WITH  FILE = 1,  
MOVE N''Ray'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ray'',  
MOVE N''Ray_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ray_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Ronald] FROM  DISK = N''E:\MS SQL BAK.46\Ronald.BAK'' WITH  FILE = 1,  
MOVE N''Ronald'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ronald'',  
MOVE N''Ronald_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ronald_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [TestDB] FROM  DISK = N''E:\MS SQL BAK.46\TestDB.BAK'' WITH  FILE = 1,  
MOVE N''TestDB'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestDB'',  
MOVE N''TestDB_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestDB_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [TestErik] FROM  DISK = N''E:\MS SQL BAK.46\TestErik.BAK'' WITH  FILE = 1,  
MOVE N''TestErik'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestErik'',  
MOVE N''TestErik_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestErik_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [TestPA] FROM  DISK = N''E:\MS SQL BAK.46\TestPA.BAK'' WITH  FILE = 1,  
MOVE N''TestPA'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestPA'',  
MOVE N''TestPA_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestPA_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [TestSherlock] FROM  DISK = N''E:\MS SQL BAK.46\TestSherlock.BAK'' WITH  FILE = 1,  
MOVE N''TestSherlock'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestSherlock'',  
MOVE N''TestSherlock_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestSherlock_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [TheoData] FROM  DISK = N''E:\MS SQL BAK.46\TheoData.BAK'' WITH  FILE = 1,  
MOVE N''TheoData'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TheoData'',  
MOVE N''TheoData_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TheoData_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Tick] FROM  DISK = N''E:\MS SQL BAK.46\Tick.BAK'' WITH  FILE = 1,  
MOVE N''Tick'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Tick'',  
MOVE N''Tick_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Tick_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Trade_DB] FROM  DISK = N''E:\MS SQL BAK.46\Trade_DB.BAK'' WITH  FILE = 1,  
MOVE N''Trade_DB'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Trade_DB'',  
MOVE N''Trade_DB_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Trade_DB_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Vix] FROM  DISK = N''E:\MS SQL BAK.46\Vix.BAK'' WITH  FILE = 1,  
MOVE N''Vix'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Vix'',  
MOVE N''Vix_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Vix_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Web] FROM  DISK = N''E:\MS SQL BAK.46\Web.BAK'' WITH  FILE = 1,  
MOVE N''Web'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Web'',  
MOVE N''Web_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Web_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
 
RESTORE DATABASE [Z] FROM  DISK = N''E:\MS SQL BAK.46\Z.BAK'' WITH  FILE = 1,  
MOVE N''Z'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Z'',  
MOVE N''Z_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Z_log'',  
NOUNLOAD,  REPLACE,  STATS = 5
*/', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Accounting]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Accounting', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Accounting] FROM  DISK = N''E:\MS SQL BAK.46\Accounting.BAK'' WITH  FILE = 1,  
MOVE N''Accounting'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Accounting'',  
MOVE N''Accounting_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Accounting_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ATP]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ATP', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [ATP] FROM  DISK = N''E:\MS SQL BAK.46\ATP.BAK'' WITH  FILE = 1,  
MOVE N''ATP'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\ATP'',  
MOVE N''ATP_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\ATP_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [CB] FROM  DISK = N''E:\MS SQL BAK.46\CB.BAK'' WITH  FILE = 1,  
MOVE N''CB'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CB'',  
MOVE N''CB_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\CB_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Cmoney] FROM  DISK = N''E:\MS SQL BAK.46\Cmoney.BAK'' WITH  FILE = 1,  
MOVE N''Cmoney'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Cmoney'',  
MOVE N''Cmoney_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Cmoney_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Credit]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Credit', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Credit] FROM  DISK = N''E:\MS SQL BAK.46\Credit.BAK'' WITH  FILE = 1,  
MOVE N''Credit'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Credit'',  
MOVE N''Credit_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Credit_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyInsert]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyInsert', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [DailyInsert] FROM  DISK = N''E:\MS SQL BAK.46\DailyInsert.BAK'' WITH  FILE = 1,  
MOVE N''DailyInsert'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DailyInsert'',  
MOVE N''DailyInsert_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DailyInsert_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [DBMain] FROM  DISK = N''E:\MS SQL BAK.46\DBMain.BAK'' WITH  FILE = 1,  
MOVE N''DBMain'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMain'',  
MOVE N''DBMain_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMain_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMonitor]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMonitor', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [DBMonitor] FROM  DISK = N''E:\MS SQL BAK.46\DBMonitor.BAK'' WITH  FILE = 1,  
MOVE N''DBMonitor'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMonitor'',  
MOVE N''DBMonitor_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\DBMonitor_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [FrontDeskW] FROM  DISK = N''E:\MS SQL BAK.46\FrontDeskW.BAK'' WITH  FILE = 1,  
MOVE N''FrontDeskW'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\FrontDeskW'',  
MOVE N''FrontDeskW_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\FrontDeskW_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Hubert]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Hubert', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Hubert] FROM  DISK = N''E:\MS SQL BAK.46\Hubert.BAK'' WITH  FILE = 1,  
MOVE N''Hubert'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Hubert'',  
MOVE N''Hubert_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Hubert_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IDDataTransfer]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IDDataTransfer', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [IDDataTransfer] FROM  DISK = N''E:\MS SQL BAK.46\IDDataTransfer.BAK'' WITH  FILE = 1,  
MOVE N''IDDataTransfer'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\IDDataTransfer'',  
MOVE N''IDDataTransfer_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\IDDataTransfer_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Intraday] FROM  DISK = N''E:\MS SQL BAK.46\Intraday.BAK'' WITH  FILE = 1,  
MOVE N''Intraday'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Intraday'',  
MOVE N''Intraday_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Intraday_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LoginDefault]    Script Date: 2019/5/14 �U�� 05:36:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LoginDefault', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [LoginDefault] FROM  DISK = N''E:\MS SQL BAK.46\LoginDefault.BAK'' WITH  FILE = 1,  
MOVE N''LoginDefault'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\LoginDefault'',  
MOVE N''LoginDefault_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\LoginDefault_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [MarketData] FROM  DISK = N''E:\MS SQL BAK.46\MarketData.BAK'' WITH  FILE = 1,  
MOVE N''MarketData'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MarketData'',  
MOVE N''MarketData_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MarketData_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MDoutput]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MDoutput', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [MDoutput] FROM  DISK = N''E:\MS SQL BAK.46\MDoutput.BAK'' WITH  FILE = 1,  
MOVE N''MDoutput'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MDoutput'',  
MOVE N''MDoutput_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\MDoutput_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Myproject]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Myproject', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Myproject] FROM  DISK = N''E:\MS SQL BAK.46\Myproject.BAK'' WITH  FILE = 1,  
MOVE N''Myproject'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Myproject'',  
MOVE N''Myproject_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Myproject_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Monitor]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Monitor', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Monitor] FROM  DISK = N''E:\MS SQL BAK.46\Monitor.BAK'' WITH  FILE = 1,  
MOVE N''Monitor'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Monitor'',  
MOVE N''Monitor_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Monitor_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OperationDesk]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OperationDesk', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [OperationDesk] FROM  DISK = N''E:\MS SQL BAK.46\OperationDesk.BAK'' WITH  FILE = 1,  
MOVE N''OperationDesk'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OperationDesk'',  
MOVE N''OperationDesk_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OperationDesk_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OTC]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OTC', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [OTC] FROM  DISK = N''E:\MS SQL BAK.46\OTC.BAK'' WITH  FILE = 1,  
MOVE N''OTC'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OTC'',  
MOVE N''OTC_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\OTC_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [PL] FROM  DISK = N''E:\MS SQL BAK.46\PL.BAK'' WITH  FILE = 1,  
MOVE N''PL'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\PL'',  
MOVE N''PL_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\PL_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Pro] FROM  DISK = N''E:\MS SQL BAK.46\Pro.BAK'' WITH  FILE = 1,  
MOVE N''Pro'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Pro'',  
MOVE N''Pro_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Pro_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ray]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ray', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Ray] FROM  DISK = N''E:\MS SQL BAK.46\Ray.BAK'' WITH  FILE = 1,  
MOVE N''Ray'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ray'',  
MOVE N''Ray_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ray_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ronald]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ronald', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Ronald] FROM  DISK = N''E:\MS SQL BAK.46\Ronald.BAK'' WITH  FILE = 1,  
MOVE N''Ronald'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ronald'',  
MOVE N''Ronald_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Ronald_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestDB]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestDB', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [TestDB] FROM  DISK = N''E:\MS SQL BAK.46\TestDB.BAK'' WITH  FILE = 1,  
MOVE N''TestDB'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestDB'',  
MOVE N''TestDB_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestDB_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestErik]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestErik', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [TestErik] FROM  DISK = N''E:\MS SQL BAK.46\TestErik.BAK'' WITH  FILE = 1,  
MOVE N''TestErik'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestErik'',  
MOVE N''TestErik_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestErik_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestPA]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestPA', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [TestPA] FROM  DISK = N''E:\MS SQL BAK.46\TestPA.BAK'' WITH  FILE = 1,  
MOVE N''TestPA'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestPA'',  
MOVE N''TestPA_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestPA_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestSherlock]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestSherlock', 
		@step_id=28, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [TestSherlock] FROM  DISK = N''E:\MS SQL BAK.46\TestSherlock.BAK'' WITH  FILE = 1,  
MOVE N''TestSherlock'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestSherlock'',  
MOVE N''TestSherlock_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestSherlock_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TheoData]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TheoData', 
		@step_id=29, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [TheoData] FROM  DISK = N''E:\MS SQL BAK.46\TheoData.BAK'' WITH  FILE = 1,  
MOVE N''TheoData'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TheoData'',  
MOVE N''TheoData_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TheoData_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tick]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tick', 
		@step_id=30, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Tick] FROM  DISK = N''E:\MS SQL BAK.46\Tick.BAK'' WITH  FILE = 1,  
MOVE N''Tick'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Tick'',  
MOVE N''Tick_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Tick_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB', 
		@step_id=31, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Trade_DB] FROM  DISK = N''E:\MS SQL BAK.46\Trade_DB.BAK'' WITH  FILE = 1,  
MOVE N''Trade_DB'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Trade_DB'',  
MOVE N''Trade_DB_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Trade_DB_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Vix]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Vix', 
		@step_id=32, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Vix] FROM  DISK = N''E:\MS SQL BAK.46\Vix.BAK'' WITH  FILE = 1,  
MOVE N''Vix'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Vix'',  
MOVE N''Vix_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Vix_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Web]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Web', 
		@step_id=33, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Web] FROM  DISK = N''E:\MS SQL BAK.46\Web.BAK'' WITH  FILE = 1,  
MOVE N''Web'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Web'',  
MOVE N''Web_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Web_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z', 
		@step_id=34, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [Z] FROM  DISK = N''E:\MS SQL BAK.46\Z.BAK'' WITH  FILE = 1,  
MOVE N''Z'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Z'',  
MOVE N''Z_log'' TO N''D:\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Z_log'',  
NOUNLOAD,  REPLACE,  STATS = 5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DB restory_daily', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181106, 
		@active_end_date=99991231, 
		@active_start_time=50000, 
		@active_end_time=235959, 
		@schedule_uid=N'60a3fc8b-0bd0-4850-a9df-7797531b0dc4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [DBdrop_daily]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBdrop_daily', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBdrop_daily]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBdrop_daily', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Accounting''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''ATP''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''CB''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Cmoney''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Credit''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''DailyInsert''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''DBMain''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''DBMonitor''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''FrontDeskW''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Hubert''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''IDDataTransfer''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Intraday''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''LoginDefault''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''MarketData''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''MDoutput''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Monitor''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''MyProject''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''OperationDesk''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''OTC''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''PL''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Pro''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Ray''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Ronald''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestDB''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestErik''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestPA''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestSherlock''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TheoData''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Tick''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Trade_DB''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Vix''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Web''
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Z''


DROP DATABASE Accounting
DROP DATABASE ATP
DROP DATABASE CB
DROP DATABASE Cmoney
DROP DATABASE Credit
DROP DATABASE DailyInsert
DROP DATABASE DBMain
DROP DATABASE DBMonitor
DROP DATABASE FrontDeskW
DROP DATABASE Hubert
DROP DATABASE IDDataTransfer
DROP DATABASE Intraday
DROP DATABASE LoginDefault 
DROP DATABASE MarketData
DROP DATABASE MDoutput
DROP DATABASE Monitor
DROP DATABASE MyProject
DROP DATABASE OperationDesk
DROP DATABASE OTC
DROP DATABASE PL
DROP DATABASE Pro
DROP DATABASE Ray
DROP DATABASE Ronald
DROP DATABASE TestDB
DROP DATABASE TestErik
DROP DATABASE TestPA
DROP DATABASE TestSherlock
DROP DATABASE TheoData
DROP DATABASE Tick
DROP DATABASE Trade_DB
DROP DATABASE Vix
DROP DATABASE Web
DROP DATABASE Z
*/

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Accounting]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Accounting', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Accounting''
DROP DATABASE Accounting', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ATP]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ATP', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''ATP''
DROP DATABASE ATP', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''CB''
DROP DATABASE CB', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Cmoney''
DROP DATABASE Cmoney', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Credit]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Credit', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Credit''
DROP DATABASE Credit', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyInsert]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyInsert', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''DailyInsert''
DROP DATABASE DailyInsert', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''DBMain''
DROP DATABASE DBMain', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMonitor]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMonitor', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''DBMonitor''
DROP DATABASE DBMonitor', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''FrontDeskW''
DROP DATABASE FrontDeskW', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Hubert]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Hubert', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Hubert''
DROP DATABASE Hubert', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IDDataTransfer]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IDDataTransfer', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''IDDataTransfer''
DROP DATABASE IDDataTransfer', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Intraday''
DROP DATABASE Intraday', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LoginDefault]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LoginDefault', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''LoginDefault''
DROP DATABASE LoginDefault ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''MarketData''
DROP DATABASE MarketData', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MDoutput]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MDoutput', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''MDoutput''
DROP DATABASE MDoutput', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Monitor]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Monitor', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Monitor''
DROP DATABASE Monitor', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MyProject]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MyProject', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''MyProject''
DROP DATABASE MyProject', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OperationDesk]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OperationDesk', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''OperationDesk''
DROP DATABASE OperationDesk', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OTC]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OTC', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''OTC''
DROP DATABASE OTC', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''PL''
DROP DATABASE PL', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Pro''
DROP DATABASE Pro', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ray]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ray', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Ray''
DROP DATABASE Ray', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ronald]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ronald', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Ronald''
DROP DATABASE Ronald', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestDB]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestDB', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestDB''
DROP DATABASE TestDB', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestErik]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestErik', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestErik''
DROP DATABASE TestErik', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestPA]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestPA', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestPA''
DROP DATABASE TestPA', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestSherlock]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestSherlock', 
		@step_id=28, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TestSherlock''
DROP DATABASE TestSherlock', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TheoData]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TheoData', 
		@step_id=29, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''TheoData''
DROP DATABASE TheoData', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tick]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tick', 
		@step_id=30, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Tick''
DROP DATABASE Tick', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB', 
		@step_id=31, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Trade_DB''
DROP DATABASE Trade_DB', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Vix]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Vix', 
		@step_id=32, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Vix''
DROP DATABASE Vix', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Web]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Web', 
		@step_id=33, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Web''
DROP DATABASE Web', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z', 
		@step_id=34, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''Z''
DROP DATABASE Z', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DBdrop_daily', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180809, 
		@active_end_date=99991231, 
		@active_start_time=13000, 
		@active_end_time=235959, 
		@schedule_uid=N'0ff72c6f-329f-4c57-816a-84c79e703bf4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [syspolicy_purge_history]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'syspolicy_purge_history', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Verify that automation is enabled.]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Verify that automation is enabled.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (msdb.dbo.fn_syspolicy_is_automation_enabled() != 1)
        BEGIN
            RAISERROR(34022, 16, 1)
        END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge history.]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge history.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_syspolicy_purge_history', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Erase Phantom System Health Records.]    Script Date: 2019/5/14 �U�� 05:36:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Erase Phantom System Health Records.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'if (''$(ESCAPE_SQUOTE(INST))'' -eq ''MSSQLSERVER'') {$a = ''\DEFAULT''} ELSE {$a = ''''};
(Get-Item SQLSERVER:\SQLPolicy\$(ESCAPE_NONE(SRVR))$a).EraseSystemHealthPhantomRecords()', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'syspolicy_purge_history_schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20080101, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'6b6badcf-3d83-49c8-86dc-f6fd1da0d9b8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


