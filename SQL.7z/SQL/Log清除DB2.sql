use Tick
DBCC shrinkfile(Tick_log, 1)

use Intraday
DBCC shrinkfile(Intraday_log, 1)

use Trade_DB
DBCC shrinkfile(Trade_DB_log, 1)

use Trade_DB_Test
DBCC shrinkfile(Trade_DB_Test_log, 1)


