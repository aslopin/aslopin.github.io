USE [msdb]
GO

/****** Object:  Job [Update_Future_TXF]    Script Date: 2019/5/15 �W�� 09:21:05 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:21:05 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_Future_TXF', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tradingdate]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_Stock_IsETF]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_Stock_IsETF', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'  update [Trade_DB].[dbo].[tblDailyStockInfo]
  set [IsETF] = 0
  go

  update [Trade_DB].[dbo].[tblDailyStockInfo]
  set [IsETF] = 1
  where [StockId] in (select [�N��] from [Cmoney].[dbo].[ETF�򥻸��])
  go
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert_TWA00]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert_TWA00', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

  INSERT INTO [Trade_DB].[dbo].[tblDailyStockInfo]
           ([DayDate]
           ,[StockId]
           ,[StockName]
           ,[PrevOpen]
           ,[PrevHigh]
           ,[PrevLow]
           ,[PrevClose]
           ,[PrevAsk]
           ,[PrevAskQty]
           ,[PrevBid]
           ,[PrevBidQty]
           ,[MarketType]
           ,[IsDayTrade]
           ,[HedgePrediction]
           ,[HedgeFrequency]
           ,[OtherWarrant])
     VALUES
           (GETDATE()
           ,''TWA00''
           ,''�[�v����''
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,null
           ,null
           ,null)
GO', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_Future_TXF]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_Future_TXF', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--update [Trade_DB].[dbo].[tblDailyFutures]
--set UnderlyingId = ''00631L''
--where [FutureId] like ''TXF%''', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Update_Future_TXF', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151021, 
		@active_end_date=99991231, 
		@active_start_time=80500, 
		@active_end_time=235959, 
		@schedule_uid=N'9ce2f45f-49c8-44d6-bcf4-d44a176ff880'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Update_HedgeDeputy]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_HedgeDeputy', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Update_HedgeDeputy', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_HedgeDeputy]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_HedgeDeputy', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE [Trade_DB].[dbo].[Deputy_tblUserWarrantUnderlying]
SET [UserId] = ''Sam''
WHERE [UserId] = ''samb''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Update_Hdegedeputy', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160523, 
		@active_end_date=99991231, 
		@active_start_time=80300, 
		@active_end_time=235959, 
		@schedule_uid=N'46d022ea-4842-4243-9958-b257ae3573f4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Update_tblDailyWarrantInfo2]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_tblDailyWarrantInfo2', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Update_tblDailyWarrantInfo2', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_tblDailyWarrantInfo2]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_tblDailyWarrantInfo2', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
DELETE FROM [Trade_DB].[dbo].[tblDailyWarrantInfo2]

INSERT INTO [Trade_DB].[dbo].[tblDailyWarrantInfo2]
([DayDate],[WarrantId],[WarrantName],[StockId],[StockName],[CallPut],[Issuer],[LastTranDay],[MaturityDay],
[TradeDays],[Days],[StrikePrice],[Rho],[IV],[VolH],[VolQ],[Vol30D],[ExerciseRatio],[PrevClose],[PrevAsk],
[PrevAskQty],[PrevBid],[PrevBidQty],[IsSelf],[VolM],[MarketType],[VolDown],[�ۦ���],[�U�ժŶ�],[í�w��],[�`��],[mHR])
SELECT [DayDate],[WarrantId],[WarrantName],[StockId],[StockName],[CallPut],[Issuer],[LastTranDay],[MaturityDay],
[TradeDays],[Days],[StrikePrice],[Rho],[IV],[VolH],[VolQ],[Vol30D],[ExerciseRatio],[PrevClose],[PrevAsk],
[PrevAskQty],[PrevBid],[PrevBidQty],[IsSelf],[VolM],[MarketType],[VolDown],[�ۦ���],[�U�ժŶ�],[í�w��],[�`��],[mHR]
FROM [Trade_DB].[dbo].[tblDailyWarrantInfo]
WHERE [WarrantId] in (SELECT [Stock_Id] FROM [Trade_DB].[dbo].[tblPrevPL] WHERE [PL_QTY] > 0)

INSERT INTO [Trade_DB].[dbo].[tblDailyWarrantInfo2]
([DayDate],[WarrantId],[WarrantName],[StockId],[StockName],[CallPut],[Issuer],[LastTranDay],[MaturityDay],
[TradeDays],[Days],[StrikePrice],[Rho],[IV],[VolH],[VolQ],[Vol30D],[ExerciseRatio],[PrevClose],[PrevAsk],
[PrevAskQty],[PrevBid],[PrevBidQty],[IsSelf],[VolM],[MarketType],[VolDown],[�ۦ���],[�U�ժŶ�],[í�w��],[�`��],[mHR])
SELECT [DayDate],[WarrantId],[WarrantName],[StockId],[StockName],[CallPut],[Issuer],[LastTranDay],[MaturityDay],
[TradeDays],[Days],[StrikePrice],[Rho],[IV],[VolH],[VolQ],[Vol30D],[ExerciseRatio],[PrevClose],[PrevAsk],
[PrevAskQty],[PrevBid],[PrevBidQty],[IsSelf],[VolM],[MarketType],[VolDown],[�ۦ���],[�U�ժŶ�],[í�w��],[�`��],[mHR]
FROM [Trade_DB].[dbo].[tblDailyWarrantInfo]
WHERE [WarrantId] in (SELECT DISTINCT [Symbol] FROM [Trade_DB].[dbo].[tblOrderReport] WITH (NOLOCK) WHERE [Symbol] NOT IN (SELECT [WarrantId] FROM [Trade_DB].[dbo].[tblDailyWarrantInfo2]))
INSERT INTO [Trade_DB].[dbo].[tblDailyWarrantInfo2]
([DayDate],[WarrantId],[WarrantName],[StockId],[StockName],[CallPut],[Issuer],[LastTranDay],[MaturityDay],
[TradeDays],[Days],[StrikePrice],[Rho],[IV],[VolH],[VolQ],[Vol30D],[ExerciseRatio],[PrevClose],[PrevAsk],
[PrevAskQty],[PrevBid],[PrevBidQty],[IsSelf],[VolM],[MarketType],[VolDown],[�ۦ���],[�U�ժŶ�],[í�w��],[�`��],[mHR])
SELECT [DayDate],[WarrantId],[WarrantName],[StockId],[StockName],[CallPut],[Issuer],[LastTranDay],[MaturityDay],
[TradeDays],[Days],[StrikePrice],[Rho],[IV],[VolH],[VolQ],[Vol30D],[ExerciseRatio],[PrevClose],[PrevAsk],
[PrevAskQty],[PrevBid],[PrevBidQty],[IsSelf],[VolM],[MarketType],[VolDown],[�ۦ���],[�U�ժŶ�],[í�w��],[�`��],[mHR]
FROM [Trade_DB].[dbo].[tblDailyWarrantInfo]
WHERE [WarrantId] in (SELECT DISTINCT [WarrantId] FROM [Trade_DB].[dbo].[tblDailyWarrantInfo] WHERE [Issuer] in (''�x�s'',''���j'',''�Τ@'',''�Ͱ�'',''�X�w'',''�ثn'',''���'') and [WarrantId] NOT IN (SELECT [WarrantId] FROM [Trade_DB].[dbo].[tblDailyWarrantInfo2]))
AND [TradeDays] > 2

update  [Trade_DB].[dbo].[tblDailyWarrantInfo2]
set [VolH] = [VolQ]
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Update_tblDailyWarrantInfo2', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160523, 
		@active_end_date=99991231, 
		@active_start_time=80300, 
		@active_end_time=235959, 
		@schedule_uid=N'463e9063-1fca-4871-9a35-47afd299cf8e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Update_tblKGIOrderInfo_RealTime]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:21:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_tblKGIOrderInfo_RealTime', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Update_tblKGIOrderInfo_RealTime', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_tblKGIOrderInfo_RealTime]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_tblKGIOrderInfo_RealTime', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [Trade_DB].[dbo].[tblKGIOrderInfo_RealTime]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Update_Update_tblKGIOrderInfo_RealTime', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160627, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959, 
		@schedule_uid=N'5f754c90-48a4-4c6b-a220-c62c769f745b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Update_tblPrevPL_Future]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_tblPrevPL_Future', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Update_tblPrevPL_Future', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tradingdate]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'update tblPrevPL
set STOCK_TYPE = 2
where STOCK_ID in (select futureid from tblDailyFutures)

update tblPrevPL
set STOCK_TYPE = 1
where STOCK_ID in (select warrantid from tblDailyWarrantInfo)', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblPrevPL2]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblPrevPL2', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [Trade_DB].[dbo].[tblPrevPL2]
go

INSERT INTO [Trade_DB].[dbo].[tblPrevPL2]
([TXN_DT],[USER_ID],[TRADE_ID],[PORTFOLIO_ID],[STOCK_ID],[PL_QTY],[PL_AMT],[STOCK_TYPE],[PL_POS])
SELECT [TXN_DT],[USER_ID],[TRADE_ID],[PL_Underlying],[STOCK_ID],[PL_QTY],[PL_AMT],[STOCK_TYPE],[PL_POS]
FROM [Trade_DB].[dbo].[tblPrevPL]
go', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'update', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151001, 
		@active_end_date=99991231, 
		@active_start_time=80500, 
		@active_end_time=235959, 
		@schedule_uid=N'a7e2f402-4ed9-4c30-ade7-cdd41baf3280'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Update_tblTodaySBLSell]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_tblTodaySBLSell', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Update_tblTodaySBLSell', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_tblTodaySBLSell]    Script Date: 2019/5/15 �W�� 09:21:07 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_tblTodaySBLSell', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE [DB39].[Trade_DB].[dbo].[tblTodaySBLSell]
WHERE [Date] >= CAST(GETDATE() AS DATE)

INSERT INTO [DB39].[Trade_DB].[dbo].[tblTodaySBLSell]
([Date],[TraderId],[ProductId],[SBLSellInv])
SELECT CAST(GETDATE() AS DATE), [Trader], [Symbol], [SBLSell]
FROM (SELECT [Trader], [Symbol], SUM([OrderQty]) as [SBLSell]
FROM [Trade_DB].[dbo].[tblExecutionReport400]
WHERE [TransactTime] >= CAST(GETDATE() AS DATE) AND [TwseOrdType] = ''6''
GROUP BY [Trader], [Symbol]) TEMP', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Update_tblTodaySBLSell', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160525, 
		@active_end_date=99991231, 
		@active_start_time=195500, 
		@active_end_time=235959, 
		@schedule_uid=N'343347fd-7c2c-4981-96c5-344acd615e9c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


