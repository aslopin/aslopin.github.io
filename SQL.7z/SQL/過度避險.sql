declare @t datetime set @t='2017/1/13'
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)

create table #Tick(BTime nvarchar(50),ETime nvarchar(50),StockID nvarchar(50),Tick_Price decimal(20,4))
insert #Tick
select BTime,ETime,StockID,Tick_Price
from db2.[Intraday].[dbo].[DailyTick_Underlying]
where [TxDate]=@t

create table #Tick1min(ser int,TimeTag nvarchar(50),StockID nvarchar(50),Tick_Price decimal(20,4))
insert #Tick1min
select a.ser,a.TimeTag,b.StockID,b.Tick_Price
from dbmain.dbo.TimeTag a
left join #Tick b on a.TimeTag>=b.Btime and a.TimeTag<b.Etime
where a.ser between 0 and 271

create table #deal(TxTime nvarchar(50),Portfolio nvarchar(50),StockID nvarchar(50),DealVolume decimal(20,4),Tag nvarchar(50))
insert #deal
select a.TxTime,a.Portfolio,a.stockid,a.dealvolume,case when a.stockid=b.warrantid then 'Y' else 'N' end
from pl.dbo.Deallist a
left join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.txdate and b.WarrantKey=a.Portfolio
where a.txdate=@t

insert #deal
select '08450000',portfolio,stockid,volume,'Y'
from pl.dbo.inventory
where stadate=@y and volume<>0

create table #Fair(StockID nvarchar(50),FairPrice decimal(20,4))
insert #Fair
select StockID,FairPrice
from DB2.Tick.[dbo].[tbl_Day_MinMax] where In_Time=@tt

create table #delta(TimeTag nvarchar(50),UnderlyingID nvarchar(50),Portfolio nvarchar(50),StockID nvarchar(50),Tag nvarchar(50),Volume decimal(20,4),Spot decimal(20,4),PreSpot decimal(20,4))
insert #delta
select c.TimeTag,b.StockID as UnderlyingID,a.Portfolio,a.StockID,a.Tag,sum(a.DealVolume) as Volume,avg(e.Tick_Price) as Spot,avg(isnull(epre.Tick_Price,f.FairPrice)) as PreSpot
from #deal a
join dbmain.dbo.WarrantProfileTS_Daily b on b.txdate=@t and b.WarrantKey=a.portfolio and b.stockid='3008 '
join dbmain.dbo.TimeTag c on a.txtime<=c.TimeTag and c.Ser<=271
left join #Tick1min e on e.[Stockid]=b.stockid and c.TimeTag=e.TimeTag
left join #Tick1min epre on epre.[Stockid]=b.stockid and c.ser=epre.ser+1
left join #Fair f on f.StockID=b.stockid
group by c.TimeTag,b.StockID,a.Portfolio,a.StockID,a.Tag


select a.TimeTag,a.UnderlyingID
,sum(coalesce(theodata.dbo.optdelta(a.spot,d.[Strike],d.barrier,d.T�����,d.pricingVol,d.r,a.stockid)*d.exer*a.volume,c.��������*a.volume,a.volume))
 as Delta
,sum(coalesce(theodata.dbo.optdelta(a.spot,d.[Strike],d.barrier,d.T�����,d.pricingVol,d.r,a.stockid)*d.exer*case when a.tag='Y' then a.volume else 0 end,c.��������*case when a.tag='Y' then a.volume else 0 end,case when a.tag='Y' then a.volume else 0 end))
 as DeltaNoHg
,sum(coalesce(theodata.dbo.optdelta(a.prespot,d.[Strike],d.barrier,d.T�����,d.pricingVol,d.r,a.stockid)*d.exer*a.volume,c.��������*a.volume,a.volume))
 as DeltaPreSpot
,sum((theodata.dbo.optdelta(a.spot*1.01,d.[Strike],d.barrier,d.T�����,d.pricingVol,d.r,a.stockid)-theodata.dbo.optdelta(a.spot*0.99,d.[Strike],d.barrier,d.T�����,d.pricingVol,d.r,a.stockid))/2.*d.exer*a.volume)
 as Gamma
,avg(a.spot) as Spot
,avg(a.prespot) as prespot
from #delta a
join dbmain.dbo.WarrantProfileTS_Daily b on b.txdate=@t and b.WarrantKey=a.portfolio
left join marketdata.dbo.�C��ӪѴ��f�������� c on c.���=@t and c.�N��=left(a.stockid,3)
left join pro.dbo.�v�ҵ������ d on d.TxDate=@t and d.WarrantID=a.StockID
group by a.TimeTag,a.UnderlyingID
order by a.TimeTag,a.UnderlyingID

drop table #deal
drop table #delta
drop table #Tick
drop table #Tick1min
drop table #Fair

