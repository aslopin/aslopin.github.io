


select a.*,c.*
from monitor.[dbo].[買賣決策後執行檢討報告] a
join (select [日期],lag([日期]) over(order by [日期]) as PreD from dbmain.[dbo].[自營商進出週報表_周末日]) b on b.日期=a.編號
join monitor.[dbo].[買賣決策報告] c on c.編號=b.PreD and c.投資組合=a.投資組合 and c.代號=a.代碼 and c.名稱=a.證券名稱 and c.策略屬性=a.策略屬性 and a.自營帳號=c.操盤人 
and isnull(a.期貨代碼,'')=isnull(c.期貨代號,'')
where a.編號>='2023-09-01'
and a.總市值上限<>c.總市值上限

