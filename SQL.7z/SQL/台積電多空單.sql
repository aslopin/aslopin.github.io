/****** SSMS 中 SelectTopNRows 命令的指令碼  ******/
declare @t datetime set @t='2024/3/11'

select *
  FROM [PL].[dbo].[部位總Select_daily_his] a
  where a.日期=@t and a.標的代號='2330'-- and a.策略 not like '%warrant%'
  and 部位種類 not like '%債%'

SELECT *,(case when a.標的代號='TWA00' then 0.324117 when a.標的代號='TWB23' then 0.479332 else 0 end*市值)/100000000. as Total空單
  FROM [PL].[dbo].[部位總Select_daily_his] a
  where a.日期=@t and a.標的代號 in ('TWA00','TWB23')-- and a.策略 not in ('衍商_Warrant','衍商_Warrant_B','衍商_CB')
  order by (case when a.標的代號='TWA00' then 0.324117 when a.標的代號='TWB23' then 0.479332 else 0 end*市值)/100000000.
SELECT sum(市值)/100000000. as Total,sum(case when 部位種類 not like '%權證%' then 市值 else 0 end)/100000000. as [Total(不含權證)]
  FROM [PL].[dbo].[部位總Select_daily_his] a
  where a.日期=@t and a.標的代號='2330'-- and a.策略 not like '%warrant%'
  and 部位種類 not like '%債%'

SELECT sum(case when a.標的代號='TWA00' then 0.324117 when a.標的代號='TWB23' then 0.479332 else 0 end*市值)/100000000. as Total空單
  FROM [PL].[dbo].[部位總Select_daily_his] a
  where a.日期=@t and a.標的代號 in ('TWA00','TWB23')-- and a.策略 not in ('衍商_Warrant','衍商_Warrant_B','衍商_CB')

  /*
SELECT *
  FROM [PL].[dbo].[部位總Select_daily_his] a
  where a.日期=@t and a.股票代號 like 'TXF'-- and a.策略 not in ('衍商_Warrant','衍商_Warrant_B','衍商_CB')
  */

select *
from cmoney.dbo.日個股類股市值比重
where 日期='2024/3/11' and 股票代號='2330'

select *
from marketdata.[dbo].[TEJ指數成分股股數]
where [年月日]='2024/3/11'
and 成份股 like '2330%' 