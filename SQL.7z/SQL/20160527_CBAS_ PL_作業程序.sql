declare @t datetime set @t = '2016/5/30'

--1720 �Q�v��ƥX�ӫ�
--�Q�v���
select * from dbmain.dbo.Rate_Swap_Rate  where txdate = @t
--�Q�v���u
--exec DailyInsert.dbo.Credit_TermStructure_IRS @t

--*********************************************************
--���� CBAS�򥻸����J
 exec [DailyInsert].[dbo].[DBMain_CBAS_�C��򥻸�ƶפJ] @t
  

--declare @t datetime set @t = '2016/5/30'
   select * from dbmain.dbo.CBAS_ASW 
   where txdate = @t

   select * from dbmain.dbo.CBAS_ASO
   where txdate = @t

   select * from dbmain.dbo.CBAS_CB 
   where txdate = @t

   --*********************************************************
--���⤵��s�@�@ASW �I����
--declare @t datetime set @t = '2016/5/30'
 exec [DailyInsert].dbo.DBMain_CBAS_�I���� @t

 --declare @t datetime set @t = '2016/5/26'
 select * from dbmain.dbo.CBAS_�I����  where txdate = @t

 --*********************************************************
--declare @t datetime set @t = '2016/5/30'
-- ASW PL����
exec [DailyInsert].dbo.PL_CBAS_ASW_PL @t

--declare @t datetime set @t = '2016/5/30'
select * from pl.dbo.CBAS_ASW_PL  
where stadate = @t

--*********************************************************
--declare @t datetime set @t = '2016/5/30'
--ASO PL����
exec [DailyInsert].dbo.PL_CBAS_ASO_PL @t

--declare @t datetime set @t = '2016/5/30'
select * from pl.dbo.CBAS_ASO_PL  
where stadate = @t