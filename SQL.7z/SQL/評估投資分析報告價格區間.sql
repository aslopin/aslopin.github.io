select sum(a.Y1)/sum(a.N) as 機率1,sum(a.Y2)/sum(a.N) as 機率2
from (
	select a.投資組合,a.策略屬性,a.標的代號,a.報告年季,a.報告日期
	,a.價格區間_上,a.價格區間_下
	,a.價格區間_上/1.5*1.4 as 價格區間_上2
	,a.價格區間_上/1.5*0.75 as 價格區間_下2
	,c.日期,c.收盤價
	,case when c.收盤價 between a.價格區間_下 and a.價格區間_上 then 0 else 1 end as Y1
	,case when c.收盤價 between a.價格區間_上/1.5*0.75 and a.價格區間_上/1.5*1.4 then 0 else 1 end as Y2
	,1. as N
	from monitor.dbo.自動化投資分析報告 a
	join (
		select a.報告年季,a.投資組合,a.策略屬性,a.標的代號,min(a.報告日期) as 報告日期
		from monitor.dbo.自動化投資分析報告 a
		group by a.報告年季,a.投資組合,a.策略屬性,a.標的代號
	) b on b.投資組合=a.投資組合 and b.策略屬性=a.策略屬性 and b.標的代號=a.標的代號 and b.報告年季=a.報告年季 and b.報告日期=a.報告日期
	join cmoney.dbo.日收盤表排行 c on c.日期 between dateadd(dd,1,a.報告日期) and dateadd(dd,90,a.報告日期) and c.股票代號=a.標的代號
	where a.報告日期>='2023/1/1'
) a

select sum(case when Y1>0 then 1 else 0 end)/sum(1.) as 機率1
,sum(case when Y2>0 then 1 else 0 end)/sum(1.) as 機率2
from (
	select a.投資組合,a.策略屬性,a.標的代號,a.報告年季,sum(a.Y1) as Y1,sum(a.Y2) as Y2
	from (
		select a.投資組合,a.策略屬性,a.標的代號,a.報告年季,a.報告日期
		,a.價格區間_上,a.價格區間_下
		,a.價格區間_上/1.5*1.4 as 價格區間_上2
		,a.價格區間_上/1.5*0.75 as 價格區間_下2
		,c.日期,c.收盤價
		,case when c.收盤價 between a.價格區間_下 and a.價格區間_上 then 0 else 1 end as Y1
		,case when c.收盤價 between a.價格區間_上/1.5*0.75 and a.價格區間_上/1.5*1.4 then 0 else 1 end as Y2
		,1. as N
		from monitor.dbo.自動化投資分析報告 a
		join (
			select a.報告年季,a.投資組合,a.策略屬性,a.標的代號,min(a.報告日期) as 報告日期
			from monitor.dbo.自動化投資分析報告 a
			group by a.報告年季,a.投資組合,a.策略屬性,a.標的代號
		) b on b.投資組合=a.投資組合 and b.策略屬性=a.策略屬性 and b.標的代號=a.標的代號 and b.報告年季=a.報告年季 and b.報告日期=a.報告日期
		join cmoney.dbo.日收盤表排行 c on c.日期 between dateadd(dd,1,a.報告日期) and dateadd(dd,90,a.報告日期) and c.股票代號=a.標的代號
		where a.報告日期>='2023/1/1'
	) a
	group by a.投資組合,a.策略屬性,a.標的代號,a.報告年季
) a

select a.投資組合,a.策略屬性,a.標的代號,a.報告年季,a.報告日期
,a.價格區間_上,a.價格區間_下
,a.價格區間_上/1.5*1.4 as 價格區間_上2
,a.價格區間_上/1.5*0.75 as 價格區間_下2
,c.日期,c.收盤價
,case when c.收盤價 between a.價格區間_下 and a.價格區間_上 then 0 else 1 end as Y1
,case when c.收盤價 between a.價格區間_上/1.5*0.75 and a.價格區間_上/1.5*1.4 then 0 else 1 end as Y2
,1. as N
from monitor.dbo.自動化投資分析報告 a
join (
	select a.報告年季,a.投資組合,a.策略屬性,a.標的代號,min(a.報告日期) as 報告日期
	from monitor.dbo.自動化投資分析報告 a
	group by a.報告年季,a.投資組合,a.策略屬性,a.標的代號
) b on b.投資組合=a.投資組合 and b.策略屬性=a.策略屬性 and b.標的代號=a.標的代號 and b.報告年季=a.報告年季 and b.報告日期=a.報告日期
join cmoney.dbo.日收盤表排行 c on c.日期 between dateadd(dd,1,a.報告日期) and dateadd(dd,90,a.報告日期) and c.股票代號=a.標的代號
where a.報告日期>='2023/1/1'
order by a.投資組合,a.策略屬性,a.標的代號,a.報告年季,c.日期