USE [master]
GO
EXEC master.dbo.sp_addlinkedserver 
@server = 'DB75', 
@srvproduct='SQLNCLI', 
@provider='SQLOLEDB', 
@datasrc='172.24.19.75'
GO
USE [master]
GO
EXEC master.dbo.sp_addlinkedsrvlogin 
@rmtsrvname = 'DB75', 
@locallogin = NULL , 
@useself = 'False', 
@rmtuser = 'reportadmin', 
@rmtpassword = '@123admin'
GO



