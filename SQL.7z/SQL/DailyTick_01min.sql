
/*
exec [DailyInsert].[dbo].[Intraday_DailyTick_01min]
*/
create procedure [dbo].[Intraday_DailyTick_01min]
as
declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

create table #TickTemp(StockID nvarchar(50),[No] numeric(18,0))
create table #TickTemp2(StockID nvarchar(50),[No] numeric(18,0))
create table #TickTemp2out(StockID nvarchar(50),[Tick_Price] decimal(20,4),[Tick_Qty] decimal(20,4))

delete intraday.[dbo].[DailyTick_01min] where TxDate=@t

declare input cursor
for 
select [TimeTag]
from [DBMain].[dbo].[TimeTag]
where ser between 1 and 275
order by ser

open input

declare @TimeTag nvarchar(50)

fetch input into @TimeTag

while (@@fetch_status=0)
  begin
  truncate table #TickTemp
  truncate table #TickTemp2
  truncate table #TickTemp2out

  insert #TickTemp
  select StockID,max([No])
  from TestDB.[dbo].[tbl_Tick_Today]
  where In_Time<=@TimeTag
  group by StockID

  insert #TickTemp2
  select StockID,max([No])
  from TestDB.[dbo].[tbl_Tick_Today]
  where In_Time<=@TimeTag and [Tick_Price] is not null
  group by StockID

  insert #TickTemp2out
  select a.StockId, a.Tick_Price, a.Tick_Qty
  from TestDB.[dbo].[tbl_Tick_Today] a
  join #TickTemp2 b on b.StockID=a.StockID and b.[No]=a.[No]

  insert intraday.[dbo].[DailyTick_01min]
  select @t,@TimeTag, a.StockId
  , coalesce(a.Tick_Price,c.Tick_Price,0)
  , coalesce(a.Tick_Qty,c.Tick_Qty,0)
  , B1_Price, B1_Qty, B2_Price, B2_Qty, B3_Price, B3_Qty, B4_Price, B4_Qty, B5_Price, B5_Qty, A1_Price, A1_Qty, A2_Price, A2_Qty, A3_Price, A3_Qty, A4_Price, A4_Qty, A5_Price, A5_Qty
  from TestDB.[dbo].[tbl_Tick_Today] a
  join #TickTemp b on b.StockID=a.StockID and b.[No]=a.[No]
  left join #TickTemp2out c on c.StockID=a.StockID
  
  fetch input into @TimeTag
  end

close input
deallocate input


drop table #TickTemp
drop table #TickTemp2
drop table #TickTemp2out
