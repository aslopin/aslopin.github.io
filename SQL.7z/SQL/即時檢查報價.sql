declare @���s nvarchar(50) set @���s='J1040040' 

declare @trader table([name] nvarchar(50))
if @���s in ('J1040001','J1040002','J1040003','J1040040','J1040046','J1040037')
 begin
 insert @trader select [NameEn] from dbmain.[dbo].[EmployeeID]
 end
else
 begin
 insert @trader select [NameEn] from dbmain.[dbo].[EmployeeID] where [ID]=@���s
 end


declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @t1 datetime set @t1=dbmain.dbo.tradingdateadd(1,@t)
declare @tm datetime
set @tm=dbmain.dbo.tradingdateadd(-1,(select min(tradingdate) from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and datepart(mm,tradingdate)=datepart(mm,@t)))
declare @ty datetime
set @ty=dbmain.dbo.tradingdateadd(-1,(select min(tradingdate) from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t)))

declare @y datetime
set @y=dbmain.dbo.tradingdateadd(-1,@t)

declare @yb datetime set @yb=(select min(tradingdate) from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) )

declare @r decimal(20,6) set @r=0.01


create table #Stock(Portfolio nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50))
create table #�Q�w�s(TxDate datetime,Portfolio nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50)
,Volume decimal(20,3),Cost decimal(20,3),Tax decimal(20,3),Fee decimal(20,3),LastPrice decimal(20,3),Theoprice decimal(20,6)
,VolumeM decimal(20,3),CostM decimal(20,3),TaxM decimal(20,3),FeeM decimal(20,3),LastPriceM decimal(20,3),TheopriceM decimal(20,6)
,Delta decimal(20,6),Gamma decimal(20,6),DeltaM decimal(20,6))
create table #������(TxDate datetime,Portfolio nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50),B decimal(20,3),S decimal(20,3),DealVolume decimal(20,3),Cost decimal(20,3),Tax decimal(20,3),Fee decimal(20,3))
create table #������pre(TxDate datetime,Portfolio nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50),B decimal(20,3),S decimal(20,3),DealVolume decimal(20,3),Cost decimal(20,3),Tax decimal(20,3),Fee decimal(20,3))

declare @ser decimal(20,4) set @ser=(select ser from dbmain.dbo.tradingdate where tradingdate=@t)

declare @hour int set @hour=datepart(hour,getdate())
declare @minute int set @minute=datepart(minute,getdate())
declare @now nvarchar(50) set @now=case when @hour<10 then '0' else '' end+cast(@hour as nvarchar(50))
                                  +case when @minute<10 then '0' else '' end+cast(@minute as nvarchar(50))

declare @nowadj nvarchar(50) set @nowadj=case when @now<'09000000' then '09000000' when @now>'13300000' then '13300000' else @now end
declare @Tdecay decimal(20,8) set @Tdecay=(dbmain.[dbo].[TimeSecToDecimal](@nowadj)-dbmain.[dbo].[TimeSecToDecimal]('09000000'))/16200.

create table #hvtab(warrantid nvarchar(50),warrantname nvarchar(50)
,stockid nvarchar(50),hv decimal(20,6),hvy decimal(20,6),qv decimal(20,6)
,strike decimal(20,4),barrier decimal(20,4),exer decimal(20,4),ed datetime,r decimal(20,4),T decimal(20,4),T2 decimal(20,4))
insert #hvtab
select a.warrantid,a.warrantname,a.Stockid,hv.HV,hvy.HV,isnull(qv.qv,a.QuoteVol)
,[CurrentStrikePrice],[BarrierPrice],[AdjustedExerciseRate],expireddate,@r
,t.ser-@ser+1-@Tdecay,t.ser-@ser+1
--,dbmain.dbo.tradingdatediff(@t,expireddate)
from dbmain.[dbo].[WarrantProfileTS_Daily] a
left join dbmain.dbo.tradingdate t on t.Tradingdate=a.expireddate
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hv on hv.StockID=a.stockID
and @t between hv.bdate and hv.edate
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hvy on hvy.StockID=a.stockID
and @y between hvy.bdate and hvy.edate
left join PL.dbo.�ۮa�v�ҨC��QV qv on qv.txdate=@y and qv.[Wrr_ID]=a.warrantid
where a.TxDate=@t and @t between issuedate and expireddate

insert #hvtab
select a.�N��,a.�W��,a.�Ъ��N��,hv.HV,hvy.HV,isnull(case when qv.B1VolAvg between 0.05 and 1.5 then qv.B1VolAvg end,hv.HV)
,a.�̷s�i����,a.�̷s�������,a.�̷s������,a.������,@r
,t.ser-@ser+1-@Tdecay,t.ser-@ser+1
--,dbmain.dbo.tradingdatediff(@t,������)
from cmoney.dbo.�v�Ұ򥻸�ƪ��C�� a
left join dbmain.dbo.tradingdate t on t.Tradingdate=a.������
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hv on hv.StockID=a.�Ъ��N��
and @t between hv.bdate and hv.edate
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hvy on hvy.StockID=a.�Ъ��N��
and @y between hvy.bdate and hvy.edate
left join dbmain.[dbo].[WarrantProfileTS_Daily] w on w.TxDate=@t and @t between w.issuedate and w.expireddate
and w.WarrantID=a.�N��
left join intraday.[dbo].[�����v�ҧ�Vol] qv on qv.[���]=@y and qv.�N��=a.�N��
where a.���=@t
and a.[�@���ҡ�������]='false'
and w.WarrantID is null


insert #�Q�w�s
select @y, a.Portfolio, a.StockID,a.[Type], a.Volume, a.Cost, a.Tax, a.Fee, a.LastPrice,a.Theoprice
, isnull(b.Volume,0), isnull(b.Cost,0), isnull(b.Tax,0), isnull(b.Fee,0), isnull(b.LastPrice,0), isnull(b.Theoprice,0)
,a.delta,a.Gamma, isnull(b.delta,0)
from PL.dbo.Inventory a
left join pl.dbo.inventory b on b.stadate=@tm and b.portfolio=a.portfolio and b.StockID=a.StockID
where a.stadate=@y
/*
select Stadate, Portfolio, Trader, StockID,[Type], Volume, Cost, Tax, Fee, LastPrice
from PL.dbo.Inventory
where stadate=@y
*/

insert #������pre
select @t,a.Portfolio,a.StockID,a.[Type]
,0,0,0
,-1*isnull([�{���ѧQ�X�p(��)],0)*a.Volume
,0,0
from #�Q�w�s a
join cmoney.dbo.�ѧQ�F���� d on a.stockId=d.�Ѳ��N�� and d.������=@t

insert #������pre
select @t,a.Portfolio,a.StockID,a.[Type]
,case when a.Volume>0 then isnull([�Ѳ��ѧQ�X�p(��)],0)/10.*a.Volume else 0 end
,case when a.Volume<0 then isnull([�Ѳ��ѧQ�X�p(��)],0)/10.*a.Volume else 0 end
,isnull([�Ѳ��ѧQ�X�p(��)],0)/10.*a.Volume
,0
,0,0
from #�Q�w�s a
join cmoney.dbo.�ѧQ�F���� d on a.stockId=d.�Ѳ��N�� and d.���v��=@t

insert #������pre
select @t as TxDate,b.Portfolio,isnull(c.[�N���ഫFrom],a.Symbol),a.TwseOrdType
,case when a.side='0' then 1 else 0 end*a.LastQty*1000
,case when a.side='0' then 0 else -1 end*a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000*a.LastPx
,case when a.side='0' then 0 else 1 end*a.LastQty*1000*a.LastPx*case when dbmain.dbo.�P�_���O(a.Symbol) in ('warrant','ETF') then 0.001 else 0.003 end
,0
from [Trade_DB].[dbo].[tblOrderReport](nolock) a
--from DB2.[Trade_DB].[dbo].[tblOrderReport] a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.Symbol
left join testDB.dbo.�N���ഫ c on @t between c.BDate and c.EDate and c.[�N���ഫTo]=a.Symbol
where a.TransactTime between @t and @t1
and a.LastQty<>0
and a.OrdStatus in ('1','2')

declare @fdeal table(Symbol nvarchar(50),Side nvarchar(50),DealPrice decimal(20,6),DealQty decimal(20,6))
insert @fdeal
select [Symbol],[Side],[DealPrice],[DealQty]
from db2.[Trade_DB].[dbo].[KGI_Futu_Report_T]
where [InTime] between @t and @t1
and [RecType]='2'

insert #������pre
select @t,b.Portfolio,left(a.symbol,len(a.symbol)-2)+'201'+right(a.symbol,1)+m.�Ʀr��,'0'
,case when a.side='B' then 1 else 0 end*a.DealQty
,case when a.side='B' then 0 else -1 end*a.DealQty
,case when a.side='B' then 1 else -1 end*a.DealQty
,case when a.side='B' then 1 else -1 end*a.DealQty*a.DealPrice*fm.��������
,0,0
from @fdeal a
left join dbmain.[dbo].[���f_�^������Ӫ�] m on m.�^���=left(right(a.symbol,2),1)
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=left(a.symbol,len(a.symbol)-2)+'201'+right(a.symbol,1)+m.�Ʀr��
left join marketdata.[dbo].[�C��ӪѴ��f��������] fm on fm.���=@t and fm.�N��=left(a.symbol,len(a.symbol)-2)
/*
select @t,b.Portfolio,a.�ӫ~�s��+a.�����,'0'
,isnull(a.Buy,0)
,-isnull(a.Sell,0)
,isnull(a.Buy,0)-isnull(a.Sell,0)
,case when isnull(a.Sell,0)<>0 then -1 else 1 end*a.���� 
,a.Tax
,a.commisson
from pl.[dbo].[���f�������] a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.�ӫ~�s��+a.�����
where a.�����=@t
*/
insert #������
select TxDate,Portfolio,StockID,[Type]
,sum(B),sum(S),sum(dealvolume),sum(Cost),sum(tax),sum(fee)
from #������pre
where TxDate=@t
group by TxDate,Portfolio,StockID,[Type]
/*
select TxDate,Portfolio,Trader,StockID,[Type]
,sum(dealvolume),sum(dealamt),sum(tax),sum(fee)
from pl.dbo.Deallist
where TxDate=@t
group by TxDate,Portfolio,Trader,StockID,[Type]
*/
insert #Stock
select Portfolio,StockID,[Type] from #�Q�w�s
union
select Portfolio,StockID,[Type] from #������

declare @n decimal(20,4)
set @n=datediff(dd,@t,dbmain.dbo.tradingdateadd(1,@t))
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)

create table #Last(�Ѳ��N�� nvarchar(50),���L�� decimal(20,4))

if @now<'0835'
begin
insert #Last
select �Ѳ��N��,���L��
from cmoney.dbo.�馬�L���Ʀ�
where ���=@y
end
if @now<'0900'
begin
insert #Last
select [StockId],FairPrice
from DB2.Tick.[dbo].[tbl_Day_MinMax]
where [In_Time]=@tt
end
else if @now>='1500'
begin
insert #Last
select �Ѳ��N��,case when ���L��=0 then ����Ѧһ� else ���L�� end from cmoney.[dbo].[�C�馬�L��T73] where ���=@t
end
else
begin
insert #Last
select StockID,Price from db2.Tick.dbo.View_TickLast
end


/*
select StockID,coalesce([Tick_Price],B1_Price,A1_Price)
from DB2.Tick.[dbo].[tbl_Tick_Last]
*/
create table #FairPrice(StockID nvarchar(50),StockName nvarchar(50),FairPrice decimal(20,4),UpMaxPrice decimal(20,4),DownMinPrice decimal(20,4))
if @now<'0835'
begin
insert #FairPrice
select �Ѳ��N��,�Ѳ��W��,���L��,���L��*1.1,���L��*0.9
from cmoney.dbo.�馬�L���Ʀ�
where ���=@y
end
else
begin
insert #FairPrice
select [StockId],[StockCName],FairPrice,[UpMaxPrice],[DownMinPrice]
from DB2.Tick.[dbo].[tbl_Day_MinMax]
where [In_Time]=@tt
end

declare @portfolio table(Portfolio nvarchar(50),TraderM nvarchar(50),TraderH nvarchar(50))
insert @portfolio
select a.WarrantKey,b.TraderM,b.TraderH
from dbmain.dbo.WarrantProfileTS a
left join dbmain.[dbo].[WarrantTraderTS_BE]() b on b.warrantid=a.warrantid and b.issuedate=a.issuedate and @t between b.bdate and b.Edate


--Warrant
select @t as TxDate,m.Portfolio
,case when m.StockID=w.warrantid then por.TraderM else por.TraderH end as Trader
,m.StockID,m.[Type]

,coalesce(p.���L��,a2.LastPrice
 ,Theodata.dbo.optvlu(up.���L��,hv.strike,hv.barrier,hv.T/252.,hv.hv,hv.r,m.StockID,hv.Exer)
 ) 
 as LastPrice
,case when DBMain.dbo.�P�_���O(m.stockid) in ('warrant') then coalesce(Theodata.dbo.optvlu(up.���L��,hv.strike,hv.barrier,hv.T/252.,hv.hv,hv.r,m.StockID,hv.Exer),0)
      else coalesce(p.���L��,a2.LastPrice)
      end
 as TheoPrice

,case when DBMain.dbo.�P�_���O(m.stockid) in ('warrant') then coalesce(Theodata.dbo.optvlu(up.���L��,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,m.StockID,hv.Exer),0)
      else coalesce(p.���L��,a2.LastPrice)
      end
 as TheoPrice_QV
,up.���L��
,hv.*

from #Stock m
left join #������ a on m.Portfolio=a.Portfolio and m.StockID=a.StockID
left join #�Q�w�s a2 on m.Portfolio=a2.Portfolio and m.StockID=a2.StockID
left join #Last p on p.�Ѳ��N��=m.StockID
left join #hvtab hv on m.stockid=hv.warrantid
left join #Last up on up.�Ѳ��N��=isnull(hv.stockid,m.stockid)
left join dbmain.dbo.WarrantProfileTS w on w.WarrantKey=m.portfolio
left join @portfolio por on por.Portfolio=m.Portfolio
left join #FairPrice fp on fp.StockID=isnull(hv.stockid,m.stockid)
where dbmain.dbo.�P�_���O(m.StockID) not in ('fut','opt')
order by m.StockID


drop table #�Q�w�s
drop table #������
drop table #������pre
drop table #Stock

drop table #hvtab
drop table #Last
drop table #FairPrice

