select a.中台完成人,a.加權分數 as [2023],b.加權分數 as [2022]
from (
	select 中台完成人,sum(1.) as 件數,sum(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2022/11/1' and '2023/10/31'
	group by 中台完成人
) a
left join (
	select 中台完成人,sum(1.) as 件數,sum(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2021/11/1' and '2022/10/31'
	group by 中台完成人
) b on b.中台完成人=a.中台完成人
order by a.加權分數 desc

select a.系統名稱,a.加權分數 as [2023],b.加權分數 as [2022]
from (
	select 系統名稱,sum(1.) as 件數,sum(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2022/11/1' and '2023/10/31'
	and 中台完成人 is not null
	group by 系統名稱
) a
left join (
	select 系統名稱,sum(1.) as 件數,sum(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2021/11/1' and '2022/10/31'
	and 中台完成人 is not null
	group by 系統名稱
) b on b.系統名稱=a.系統名稱
order by a.加權分數 desc

select a.[申請部門/單位],a.加權分數 as [2023],b.加權分數 as [2022]
from (
	select [申請部門/單位],sum(1.) as 件數,sum(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2022/11/1' and '2023/10/31'
	and 中台完成人 is not null
	group by [申請部門/單位]
) a
left join (
	select [申請部門/單位],sum(1.) as 件數,sum(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2021/11/1' and '2022/10/31'
	and 中台完成人 is not null
	group by [申請部門/單位]
) b on b.[申請部門/單位]=a.[申請部門/單位]
order by a.加權分數 desc


	select [申請時間],(case when 系統名稱='中台架構' then 10 when 系統名稱='外網' then 3 when 系統名稱='內網' then 2 else 1 end) as 加權分數, [申請部門/單位], [系統名稱], [需求說明與邏輯], [預期上線時間], [部門主管], [申請人], [部門主管簽核時間], [申請人簽核時間], [中台簽核], [中台簽核時間], [建立時間], [是否完成], [是否寄信], [中台完成人], [完成時間], [處長簽核時間]
	from monitor.dbo.mdrequisition_sign
	where isnull(完成時間,申請時間) between '2022/11/1' and '2023/10/31'
	and 中台完成人 is not null
	order by 申請時間
