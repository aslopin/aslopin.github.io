declare @Tag table(Tag nvarchar(50),Ser int)
insert @Tag
select '�j�L_Q',1
union
select '�j_Q',2
union
select '��_Q',3
union
select '�p_Q',4
union
select '�d�R_Q',5


select a.Tag,t.Ser,datepart(yy,a.TxDate) as YY
,sum(case when a.Ret-log(b.IndexT/b.IndexY)>0 then 1. else 0 end)
/sum(1.)
 as P
,sum(case when a.Ret-log(b.IndexT/b.IndexY)>0 then a.Ret-log(b.IndexT/b.IndexY) else 0 end)
/sum(1.)
 as U
,sum(case when a.Ret-log(b.IndexT/b.IndexY)<0 then a.Ret-log(b.IndexT/b.IndexY) else 0 end)
/sum(1.)
 as D 
from (
	select b.YY,b.EDate as TxDate,a.Tag,sum(a.Ret) as Ret
	from (select Tag,���,sum(ret)/30. as ret from [Z].[dbo].[�]�����ƿ��] where Tag in ('�j�L_Q','�j_Q','��_Q','�p_Q','�d�R_Q') group by Tag,���) a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,min(Tradingdate) as BDate,max(Tradingdate) as EDate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on a.��� between b.BDate and b.EDate
	group by b.YY,b.EDate,a.Tag
) a
join @Tag t on t.Tag=a.Tag
left join (
    select b.YY,a.��� as TxDate,a.���L�� as IndexT,lag(a.���L��) over(order by a.���) as IndexY
	from cmoney.dbo.�馬�L���Ʀ� a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.���
	where a.�Ѳ��N��='TWA02'
) b on b.Txdate=a.txdate 
where a.Txdate>='2014/1/1'-- and a.Tag like 'Pb%'
group by a.Tag,t.Ser,datepart(yy,a.TxDate)
order by datepart(yy,a.TxDate),t.Ser

