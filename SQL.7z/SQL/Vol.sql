/*
declare @b datetime,@e datetime,@t datetime
set @b='2015/7/22'
set @e='2015/7/22'
set @t=@b
while @t<=@e
  begin
  print @t
  exec [dbo].[Intraday_�v�ҽL�����Rnew] @t
  set @t=DBMain.dbo.tradingdateadd(1,@t)
  end

select * from Intraday.[dbo].[�v�ҽL�����Rnew] where TxDate='2015/7/22' order by [StockID],[WarrantID]
*/
alter procedure [dbo].[Intraday_�v�ҽL�����Rnew] @t datetime
as
--declare @t datetime set @t='2015/7/22'

declare @timetag table(ser int,TimeTag nvarchar(50))
insert @timetag
select ser,TimeTag
from dbmain.dbo.TimeTag
where ser between 1 and 265 and theodata.dbo.[MOD](ser,20)=0

declare @r decimal(20,6) set @r=0.01

declare @tick table([minP] decimal(20,4),[maxP] decimal(20,4),tick decimal(20,4))
insert @tick
select [minP],[maxP],[tick]
from dbmain.[dbo].[TickTable]
where Tag='warrant'

create table #Warrant1(WarrantID nvarchar(50),StockID nvarchar(50),TimeTag nvarchar(50)
,B1Vol decimal(20,6),A1Vol decimal(20,6)
,B1Qty decimal(20,6),A1Qty decimal(20,6),B2Qty decimal(20,6),A2Qty decimal(20,6),B5Qty decimal(20,6),A5Qty decimal(20,6)
,B1Amt decimal(20,6),A1Amt decimal(20,6),B2Amt decimal(20,6),A2Amt decimal(20,6),B5Amt decimal(20,6),A5Amt decimal(20,6),Spread decimal(20,6))
insert #Warrant1
select w.StockID,Term.StockID,w.TimeTag
,case when w.B1_Price is not null then
 Theodata.[dbo].[Implied_vol] (w.B1_Price
  ,case when right(term.WarrantID,1) not in ('P','Y','C') then s.B1_Price
                                                          else s.A1_Price
                                                          end
  ,term.strike,term.barrier
  ,datediff(dd,@t,term.expireddate)/365. ,@r,term.warrantid,term.exerciserate)
 end
as B1Vol
,case when w.A1_Price is not null then
 Theodata.[dbo].[Implied_vol] (w.A1_Price
  ,case when right(term.WarrantID,1) not in ('P','Y','C') then s.B1_Price
                                                          else s.A1_Price
                                                          end
  ,term.strike,term.barrier
  ,datediff(dd,@t,term.expireddate)/365. ,@r,term.warrantid,term.exerciserate)
 end
as A1Vol
,w.B1_Qty,w.A1_Qty
,w.B1_Qty+isnull(case when w.B2_Price>w.B1_Price-10*tb.tick then 1 else 0 end*w.B2_Qty,0)
as B2Qty
,w.A1_Qty+isnull(case when w.A2_Price<w.A1_Price+10*ta.tick then 1 else 0 end*w.A2_Qty,0)
as A2Qty
,w.B1_Qty+isnull(case when w.B2_Price>w.B1_Price-10*tb.tick then 1 else 0 end*w.B2_Qty,0)
                    +isnull(case when w.B3_Price>w.B1_Price-10*tb.tick then 1 else 0 end*w.B3_Qty,0)
                    +isnull(case when w.B4_Price>w.B1_Price-10*tb.tick then 1 else 0 end*w.B4_Qty,0)
                    +isnull(case when w.B5_Price>w.B1_Price-10*tb.tick then 1 else 0 end*w.B5_Qty,0)
as B5Qty
,w.A1_Qty+isnull(case when w.A2_Price<w.A1_Price+10*ta.tick then 1 else 0 end*w.A2_Qty,0)
                    +isnull(case when w.A3_Price<w.A1_Price+10*ta.tick then 1 else 0 end*w.A3_Qty,0)
                    +isnull(case when w.A4_Price<w.A1_Price+10*ta.tick then 1 else 0 end*w.A4_Qty,0)
                    +isnull(case when w.A5_Price<w.A1_Price+10*ta.tick then 1 else 0 end*w.A5_Qty,0)
as A5Qty
,w.B1_Price*w.B1_Qty
as B1Amt
,w.A1_Price*w.A1_Qty
as A1Amt
,w.B1_Price*w.B1_Qty+isnull(case when w.B2_Price>w.B1_Price-10*tb.tick then w.B2_Price else 0 end*w.B2_Qty,0)
as B2Amt
,w.A1_Price*w.A1_Qty+isnull(case when w.A2_Price<w.A1_Price+10*ta.tick then w.A2_Price else 0 end*w.A2_Qty,0)
as A2Amt
,w.B1_Price*w.B1_Qty+isnull(case when w.B2_Price>w.B1_Price-10*tb.tick then w.B2_Price else 0 end*w.B2_Qty,0)
                    +isnull(case when w.B3_Price>w.B1_Price-10*tb.tick then w.B3_Price else 0 end*w.B3_Qty,0)
                    +isnull(case when w.B4_Price>w.B1_Price-10*tb.tick then w.B4_Price else 0 end*w.B4_Qty,0)
                    +isnull(case when w.B5_Price>w.B1_Price-10*tb.tick then w.B5_Price else 0 end*w.B5_Qty,0)
as B5Amt
,w.A1_Price*w.A1_Qty+isnull(case when w.A2_Price<w.A1_Price+10*ta.tick then w.A2_Price else 0 end*w.A2_Qty,0)
                    +isnull(case when w.A3_Price<w.A1_Price+10*ta.tick then w.A3_Price else 0 end*w.A3_Qty,0)
                    +isnull(case when w.A4_Price<w.A1_Price+10*ta.tick then w.A4_Price else 0 end*w.A4_Qty,0)
                    +isnull(case when w.A5_Price<w.A1_Price+10*ta.tick then w.A5_Price else 0 end*w.A5_Qty,0)
as A5Amt
,(w.A1_Price-w.B1_Price)/w.A1_Price
as Spread
from db2.intraday.[dbo].[DailyTick_01min] w
join @timetag t on t.TimeTag=w.TimeTag
join dbmain.dbo.warrantdata term on term.TxDate=@t and term.warrantid=w.StockID
join db2.intraday.[dbo].[DailyTick_01min] s on s.[TxDate]=@t and s.TimeTag=w.TimeTag and s.StockID=term.Stockid
left join @tick tb on w.B1_Price between tb.minP and tb.maxP
left join @tick ta on w.B1_Price between ta.minP and ta.maxP
where w.[TxDate]=@t-- and w.[StockId]='034506'

create table #Warrant2(WarrantID nvarchar(50),StockID nvarchar(50)
,B1Vol decimal(20,6),A1Vol decimal(20,6)
,B1Qty decimal(20,6),A1Qty decimal(20,6),B2Qty decimal(20,6),A2Qty decimal(20,6),B5Qty decimal(20,6),A5Qty decimal(20,6)
,B1Amt decimal(20,6),A1Amt decimal(20,6),B2Amt decimal(20,6),A2Amt decimal(20,6),B5Amt decimal(20,6),A5Amt decimal(20,6),Spread decimal(20,6))
insert #Warrant2
select WarrantID,StockID
,case when sum(case when B1Vol is null then 0 else 1. end)>2 then (sum(B1Vol)-min(B1Vol)-max(B1Vol))/(sum(case when B1Vol is null then 0 else 1. end)-2)
      else avg(B1Vol) end
,case when sum(case when A1Vol is null then 0 else 1. end)>2 then (sum(A1Vol)-min(A1Vol)-max(A1Vol))/(sum(case when A1Vol is null then 0 else 1. end)-2)
      else avg(A1Vol) end

,case when sum(case when B1Qty is null then 0 else 1. end)>2 then (sum(B1Qty)-min(B1Qty)-max(B1Qty))/(sum(case when B1Qty is null then 0 else 1. end)-2)
      else avg(B1Qty) end
,case when sum(case when A1Qty is null then 0 else 1. end)>2 then (sum(A1Qty)-min(A1Qty)-max(A1Qty))/(sum(case when A1Qty is null then 0 else 1. end)-2)
      else avg(A1Qty) end
,case when sum(case when B2Qty is null then 0 else 1. end)>2 then (sum(B2Qty)-min(B2Qty)-max(B2Qty))/(sum(case when B2Qty is null then 0 else 1. end)-2)
      else avg(B2Qty) end
,case when sum(case when A2Qty is null then 0 else 1. end)>2 then (sum(A2Qty)-min(A2Qty)-max(A2Qty))/(sum(case when A2Qty is null then 0 else 1. end)-2)
      else avg(A2Qty) end
,case when sum(case when B5Qty is null then 0 else 1. end)>2 then (sum(B5Qty)-min(B5Qty)-max(B5Qty))/(sum(case when B5Qty is null then 0 else 1. end)-2)
      else avg(B5Qty) end
,case when sum(case when A5Qty is null then 0 else 1. end)>2 then (sum(A5Qty)-min(A5Qty)-max(A5Qty))/(sum(case when A5Qty is null then 0 else 1. end)-2)
      else avg(A5Qty) end

,case when sum(case when B1Amt is null then 0 else 1. end)>2 then (sum(B1Amt)-min(B1Amt)-max(B1Amt))/(sum(case when B1Amt is null then 0 else 1. end)-2)
      else avg(B1Amt) end
,case when sum(case when A1Amt is null then 0 else 1. end)>2 then (sum(A1Amt)-min(A1Amt)-max(A1Amt))/(sum(case when A1Amt is null then 0 else 1. end)-2)
      else avg(A1Amt) end
,case when sum(case when B2Amt is null then 0 else 1. end)>2 then (sum(B2Amt)-min(B2Amt)-max(B2Amt))/(sum(case when B2Amt is null then 0 else 1. end)-2)
      else avg(B2Amt) end
,case when sum(case when A2Amt is null then 0 else 1. end)>2 then (sum(A2Amt)-min(A2Amt)-max(A2Amt))/(sum(case when A2Amt is null then 0 else 1. end)-2)
      else avg(A2Amt) end
,case when sum(case when B5Amt is null then 0 else 1. end)>2 then (sum(B5Amt)-min(B5Amt)-max(B5Amt))/(sum(case when B5Amt is null then 0 else 1. end)-2)
      else avg(B5Amt) end
,case when sum(case when A5Amt is null then 0 else 1. end)>2 then (sum(A5Amt)-min(A5Amt)-max(A5Amt))/(sum(case when A5Amt is null then 0 else 1. end)-2)
      else avg(A5Amt) end
,case when sum(case when Spread is null then 0 else 1. end)>2 then (sum(Spread)-min(Spread)-max(Spread))/(sum(case when Spread is null then 0 else 1. end)-2)
      else avg(Spread) end
from #Warrant1
group by WarrantID,StockID


delete intraday.[dbo].[�v�ҽL�����Rnew] where TxDate=@t
insert intraday.[dbo].[�v�ҽL�����Rnew]
select @t as TxDate,* 
from #Warrant2

drop table #Warrant1
drop table #Warrant2

