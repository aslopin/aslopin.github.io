declare @tag nvarchar(50) set @tag='2'
declare @n int
set @n=1
declare @r dec(20,4) set @r=0.01

create table #volume(WarrantID nvarchar(50),Volume decimal(20,4))
insert #volume
select a.warrantid,1000000/b.���L�� as Volume
from dbmain.[dbo].[�L�a�v�Ҽ���135] a
join cmoney.dbo.�馬�L���Ʀ� b on b.���=a.bdate and b.�Ѳ��N��=a.warrantid
where a.Tag=@tag

create table #hvtab(TxDate datetime,WarrantID nvarchar(50),StockID nvarchar(50),qv decimal(20,6)
,strike decimal(20,4),barrier decimal(20,4),exer decimal(20,4),ed datetime,r decimal(20,4),T decimal(20,4),SLast decimal(20,4),ser int,T2 decimal(20,4))
insert #hvtab
select w.���,w.�N��,w.�Ъ��N��
,case when qv.[M1VolAvg] between 0.05 and 1.5 then qv.[M1VolAvg] 
      when qv.[B1VolAvg] between 0.05 and 1.5 then qv.[B1VolAvg] 
      else hv.Bookvol end
,w.�̷s�i����,w.�̷s�������,w.�̷s������,dbmain.dbo.tradingdateadd(0,w.������),@r
,dbmain.dbo.tradingdatediff(w.���,w.������)
,b.���L��
,t2.Ser
,t2.Ser-t1.ser
from cmoney.dbo.�v�Ұ򥻸�ƪ��C�� w
join dbmain.[dbo].[�L�a�v�Ҽ���135] a on w.�N��=a.warrantid and w.��� between a.bdate and a.edate and a.Tag=@tag
join marketdata.dbo.dailyquote b on b.���=w.��� and b.�Ѳ��N��=w.�Ъ��N��
join dbmain.dbo.tradingdate t1 on t1.tradingdate=a.bdate
join dbmain.dbo.tradingdate t2 on t2.Tradingdate=w.���
left join Intraday.dbo.�����v�ҧ�Vol qv on qv.���=w.��� and qv.�N��=w.�N�� and qv.�Ъ��N��=w.�Ъ��N��
left join pl.[dbo].[�L�a�v�ҨC��BookVol] hv on hv.[TxDate]=w.��� and hv.[�N��]=w.�N�� and hv.[�Ъ��N��]=w.�Ъ��N��

create table #Warrant(TxDate datetime,StockID nvarchar(50),WarrantID nvarchar(50)
,Sret decimal(20,4),Vol decimal(20,4)
,OpenDelta decimal(20,4),Gamma decimal(20,4),Theta decimal(20,4),Vega decimal(20,4),T2 int)
insert #Warrant
select hv.TxDate,hv.StockID,hv.WarrantID
,log(hv.SLast / hvy.SLast),hv.qv
------***********************
--OpenDeltaY
------***********************
--, (b.���L��T - b.���L��Y)*isnull(y.Volume,0)*y.Delta
, v.volume*isnull((hv.SLast - hvy.SLast),0)*isnull(Theodata.dbo.optdelta(hvy.SLast,hvy.strike,hvy.barrier,hvy.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID)*hvy.Exer,0)
 as OpenDelta
 ------***********************
--Gamma 
--���� GammaT
------***********************
,  v.volume*
(isnull((
theodata.dbo.OptVlu(hv.SLast,hv.strike,hv.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hv.r,hv.WarrantID,hv.Exer)
-theodata.dbo.OptVlu(hvy.SLast,hvy.strike,hvy.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID,hvy.Exer)
),0)
- isnull((hv.SLast - hvy.SLast),0)*isnull(Theodata.dbo.optdelta(hvy.SLast,hvy.strike,hvy.barrier,hvy.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID)*hvy.Exer,0)
)
as Gamma
------***********************
-- Theta
------***********************
,v.volume*isnull((
theodata.dbo.OptVlu(hvy.SLast,hvy.strike,hvy.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID,hvy.Exer)
-theodata.dbo.OptVlu(hvy.SLast,hvy.strike,hvy.barrier,hvy.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID,hvy.Exer)
),0)

--isnull(y.Volume,0) * a.Theta  
as Theta
------***********************
-- Vega
------***********************

-- �Q�鳡�� �p�� Vol �ܰʳy�� PL�t
,v.volume*( theodata.dbo.OptVlu(hv.SLast,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,hv.WarrantID,hv.Exer)
  - isnull(theodata.dbo.OptVlu(hv.SLast,hv.strike,hv.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hv.r,hv.WarrantID,hv.Exer),0))
-- ���鳡�� �p�⤵�駡 Vol  �P cost �y�� PL�t
as Vega
,hv.T2
from #hvtab hv
join #hvtab hvy on hvy.WarrantID=hv.WarrantID and hvy.StockID=hv.StockID and hvy.ser+@n=hv.ser
join #volume v on v.WarrantID=hv.WarrantID
where theodata.dbo.[MOD](hv.T2,@n)=0
order by hv.StockID,hv.WarrantID,hv.txdate

/*
select hv.TxDate,hv.StockID,hv.WarrantID
,hvy.SLast,hv.SLast,hv.T/252.,hvy.T/252.
,  v.volume*
(isnull((
theodata.dbo.OptVlu(hv.SLast,hv.strike,hv.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hv.r,hv.WarrantID,hv.Exer)
-theodata.dbo.OptVlu(hvy.SLast,hvy.strike,hvy.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID,hvy.Exer)
),0)
- isnull((hv.SLast - hvy.SLast),0)*isnull(Theodata.dbo.optdelta(hvy.SLast,hvy.strike,hvy.barrier,hvy.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID)*hvy.Exer,0)
)
as Gamma

,v.volume*isnull((
theodata.dbo.OptVlu(hvy.SLast,hvy.strike,hvy.barrier,hv.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID,hvy.Exer)
-theodata.dbo.OptVlu(hvy.SLast,hvy.strike,hvy.barrier,hvy.T/252.,isnull(hvy.qv,hv.qv),hvy.r,hv.WarrantID,hvy.Exer)
),0)

as Theta

from #hvtab hv
join #hvtab hvy on hvy.WarrantID=hv.WarrantID and hvy.StockID=hv.StockID and hvy.ser+@n=hv.ser
join #volume v on v.WarrantID=hv.WarrantID
where theodata.dbo.[MOD](hv.T2,@n)=0
and hv.WarrantID='049823'
order by hv.StockID,hv.WarrantID,hv.txdate
*/

select @n as N,StockID
,sum(OpenDelta) as OpenDelta
,sum(Gamma) as Gamma
,sum(Theta) as Theta
,sum(Vega) as Vega
,avg(abs(Sret)) as AvgSret
,avg(vol) as AvgVol
,avg(vol)/sqrt(252.) as AvgVol
from #Warrant
group by StockID
order by StockID

select *
from #Warrant
order by stockid,WarrantID,Txdate

select *
from #hvtab
order by stockid,WarrantID,Txdate

drop table #hvtab
drop table #volume
drop table #Warrant
