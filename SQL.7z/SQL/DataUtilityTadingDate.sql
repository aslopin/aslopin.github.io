select datediff(dd,'1900/1/1',dateadd(dd,a.ser-1,'2021/1/1'))+2 as [Excel�Ǹ�],dateadd(dd,a.ser-1,'2021/1/1') as ����,b.Tradingdate as �����,datepart(WEEKDAY,dateadd(dd,a.ser-1,'2021/1/1')) as [WEEKDAY]
from dbmain.dbo.tradingdate a
left join dbmain.dbo.tradingdate b on b.Tradingdate=dateadd(dd,a.ser-1,'2021/1/1')
where dateadd(dd,a.ser-1,'2021/1/1') <='2022/12/31' and datepart(WEEKDAY,dateadd(dd,a.ser-1,'2021/1/1'))=7
order by a.ser

select datediff(dd,'1900/1/1',dateadd(dd,a.ser-1,'2021/1/1'))+2 as [Excel�Ǹ�],dateadd(dd,a.ser-1,'2021/1/1') as ����,b.Tradingdate as �����,datepart(WEEKDAY,dateadd(dd,a.ser-1,'2021/1/1')) as [WEEKDAY]
from dbmain.dbo.tradingdate a
left join dbmain.dbo.tradingdate b on b.Tradingdate=dateadd(dd,a.ser-1,'2021/1/1')
where dateadd(dd,a.ser-1,'2021/1/1') <='2022/12/31' and datepart(WEEKDAY,dateadd(dd,a.ser-1,'2021/1/1')) not in (1,7) and b.Tradingdate is null
order by a.ser