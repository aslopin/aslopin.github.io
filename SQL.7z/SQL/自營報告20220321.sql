declare @b datetime,@e datetime set @b='2022/1/1' set @e='2022/3/31'

select x.策略
,sum(x.區間損益) as 區間損益
,sum(x.平均市值*x.RetTW) as Benchmark
,sum(x.平均市值*(x.RetS-x.RetTW)) as 選股
,sum(x.區間損益-x.平均市值*x.RetS) as 進出
from (
	select x.策略,x.StockID,max(x.股票名稱) as 股票名稱
	,sum(PL)+sum(TC) as 區間損益
	--,avg(市值) as 平均市值
	,case when sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end)<>0 
	      then sum(市值)/sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end) else 0 end as 平均市值
	,case when (case when sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end)<>0 then sum(市值)/sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end) else 0 end)<>0 
	      then (sum(PL)+sum(TC))/(case when sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end)<>0 then sum(市值)/sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end) else 0 end) end as RetPL
	,sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then RetS else 0 end) as RetS
	,sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then RetTW else 0 end) as RetTW
	from (
		select a.Txdate,s.策略盤中顯示 as 策略,a.StockID,c1.股票名稱,a.會計_Delta as 市值,a.會計_D as PL,-1*(a.費用_D+a.Tax_D) as TC
		,log(c1.收盤價/(c1.收盤價-c1.漲跌)) as RetS
		,log(c2.收盤價/c3.收盤價) as RetTW
		from pl.dbo.DailyPLReport_自營二組 a
		join dbmain.dbo.Strategy名稱轉換 s on a.Txdate between s.BDate and s.EDate and s.Strategy=a.Strategy
		left join dbmain.dbo.tradingdate t1 on t1.Tradingdate=a.Txdate
		left join dbmain.dbo.tradingdate t2 on t2.ser+1=t1.ser
		left join pl.dbo.DailyPLReport_自營二組 a2 on a2.txdate=t2.tradingdate and a2.Acc=a.acc and a2.StockID=a.StockID
		left join cmoney.dbo.日收盤表排行 c1 on c1.日期=a.Txdate and c1.股票代號=a.StockID
		left join cmoney.dbo.日收盤表排行 c2 on c2.日期=a.Txdate and c2.股票代號='TWA02'
		left join cmoney.dbo.日收盤表排行 c3 on c3.日期=t2.tradingdate and c3.股票代號='TWA02'
		where a.TxDate between @b and @e
	) x
	group by x.策略,x.StockID
) x
group by x.策略
having sum(x.區間損益)<>0
order by x.策略

select x.策略,x.StockID,x.股票名稱
,sum(x.區間損益) as 區間損益
,sum(x.平均市值*x.RetTW) as Benchmark
,sum(x.平均市值*(x.RetS-x.RetTW)) as 選股
,sum(x.區間損益-x.平均市值*x.RetS) as 進出
,avg(x.平均市值) as 平均市值
,sum(x.RetTW) as RetTW
,sum(x.RetS) as RetS
from (
	select x.策略,x.StockID,max(x.股票名稱) as 股票名稱
	,sum(PL)+sum(TC) as 區間損益
	--,avg(市值) as 平均市值
	,case when sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end)<>0 
	      then sum(市值)/sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end) else 0 end as 平均市值
	,case when (case when sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end)<>0 then sum(市值)/sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end) else 0 end)<>0 
	      then (sum(PL)+sum(TC))/(case when sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end)<>0 then sum(市值)/sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then 1. else 0 end) else 0 end) end as RetPL
	,sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then RetS else 0 end) as RetS
	,sum(case when abs(PL)+abs(TC)+abs(市值)<>0 then RetTW else 0 end) as RetTW
	from (
		select a.Txdate,s.策略盤中顯示 as 策略,a.StockID,c1.股票名稱,a.會計_Delta as 市值,a.會計_D as PL,-1*(a.費用_D+a.Tax_D) as TC
		,log(c1.收盤價/(c1.收盤價-c1.漲跌)) as RetS
		,log(c2.收盤價/c3.收盤價) as RetTW
		from pl.dbo.DailyPLReport_自營二組 a
		join dbmain.dbo.Strategy名稱轉換 s on a.Txdate between s.BDate and s.EDate and s.Strategy=a.Strategy
		left join dbmain.dbo.tradingdate t1 on t1.Tradingdate=a.Txdate
		left join dbmain.dbo.tradingdate t2 on t2.ser+1=t1.ser
		left join pl.dbo.DailyPLReport_自營二組 a2 on a2.txdate=t2.tradingdate and a2.Acc=a.acc and a2.StockID=a.StockID
		left join cmoney.dbo.日收盤表排行 c1 on c1.日期=a.Txdate and c1.股票代號=a.StockID
		left join cmoney.dbo.日收盤表排行 c2 on c2.日期=a.Txdate and c2.股票代號='TWA02'
		left join cmoney.dbo.日收盤表排行 c3 on c3.日期=t2.tradingdate and c3.股票代號='TWA02'
		where a.TxDate between @b and @e
	) x
	group by x.策略,x.StockID
) x
group by x.策略,x.StockID,x.股票名稱
having sum(x.區間損益)<>0
order by x.策略,x.StockID,x.股票名稱


		select a.Txdate,s.策略盤中顯示 as 策略,a.StockID,c1.股票名稱,a.會計_Delta as 市值,a.會計_D as PL,-1*(a.費用_D+a.Tax_D) as TC
		,log(c1.收盤價/(c1.收盤價-c1.漲跌)) as RetS
		,log(c2.收盤價/c3.收盤價) as RetTW
		from pl.dbo.DailyPLReport_自營二組 a
		join dbmain.dbo.Strategy名稱轉換 s on a.Txdate between s.BDate and s.EDate and s.Strategy=a.Strategy
		left join dbmain.dbo.tradingdate t1 on t1.Tradingdate=a.Txdate
		left join dbmain.dbo.tradingdate t2 on t2.ser+1=t1.ser
		left join pl.dbo.DailyPLReport_自營二組 a2 on a2.txdate=t2.tradingdate and a2.Acc=a.acc and a2.StockID=a.StockID
		left join cmoney.dbo.日收盤表排行 c1 on c1.日期=a.Txdate and c1.股票代號=a.StockID
		left join cmoney.dbo.日收盤表排行 c2 on c2.日期=a.Txdate and c2.股票代號='TWA02'
		left join cmoney.dbo.日收盤表排行 c3 on c3.日期=t2.tradingdate and c3.股票代號='TWA02'
		where a.TxDate between @b and @e and a.StockID='5347'
		order by s.策略盤中顯示,a.StockID,a.Txdate

/*
select x.策略,x.StockID
,sum(PL)+sum(TC) as 區間損益
,avg(市值) as 平均市值
,case when avg(市值)<>0 then (sum(PL)+sum(TC))/avg(市值) end as RetPL
,sum(RetS) as RetS
,sum(RetTW) as RetTW
from (
	select a.Txdate,s.策略盤中顯示 as 策略,a.StockID,a.會計_Delta as 市值,a.會計_D as PL,-1*(a.費用_D+a.Tax_D) as TC
	,log(c1.收盤價/(c1.收盤價-c1.漲跌)) as RetS
	,log(c2.收盤價/c3.收盤價) as RetTW
	from pl.dbo.DailyPLReport_自營二組 a
	join dbmain.dbo.Strategy名稱轉換 s on a.Txdate between s.BDate and s.EDate and s.Strategy=a.Strategy
	left join dbmain.dbo.tradingdate t1 on t1.Tradingdate=a.Txdate
	left join dbmain.dbo.tradingdate t2 on t2.ser+1=t1.ser
	left join pl.dbo.DailyPLReport_自營二組 a2 on a2.txdate=t2.tradingdate and a2.Acc=a.acc and a2.StockID=a.StockID
	left join cmoney.dbo.日收盤表排行 c1 on c1.日期=a.Txdate and c1.股票代號=a.StockID
	left join cmoney.dbo.日收盤表排行 c2 on c2.日期=a.Txdate and c2.股票代號='TWA02'
	left join cmoney.dbo.日收盤表排行 c3 on c3.日期=t2.tradingdate and c3.股票代號='TWA02'
	where a.TxDate between @b and @e
) x
group by x.策略,x.StockID
having case when avg(市值)<>0 then (sum(PL)+sum(TC))/avg(市值) end<>0
order by x.策略,x.StockID
*/
