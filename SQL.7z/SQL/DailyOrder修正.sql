declare @t datetime set @t='2020/3/23'
declare @warrantid nvarchar(50) set @warrantid='702039'

--exec DailyInsert.dbo.Intraday_WarrantMMOrder '2020/4/6','702039'

declare @y datetime
set @y=dbmain.dbo.tradingdateadd(-1,@t)

declare @t1 datetime
set @t1=dbmain.dbo.tradingdateadd(1,@t)

declare @tm datetime set @tm=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

create table #order(TxTime nvarchar(50),Account nvarchar(50),Portfolio nvarchar(50),Trader nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50)
,OrderID nvarchar(50) collate Chinese_Taiwan_Stroke_CS_AI,OrdStatus nvarchar(50),BS nvarchar(50),OrgVolume decimal(20,3),DealVolume decimal(20,3),Price decimal(20,3))

insert #order

select 
 right('0'+cast(datepart(hour,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(minute,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(second,a.TransactTime) as nvarchar(50)),2)
+'00'
 as [TxTime]
,a.Account
,b.Portfolio,b.Trader,a.Symbol as StockID
,a.TwseOrdType
 as [Type]
,a.OrderID
,a.OrdStatus
,case when a.side='0' then 'B' else 'S' end
 as BS
,a.LeavesQty*1000
 as Volume
,a.[LastQty]*1000
 as DealVolume
,a.[Price]
 as Price
from [Trade_DB].[dbo].[tblOrderReport_History] a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.Symbol
where a.TxDate=@t 
and a.TransactTime between @t and @t1
and a.OrdStatus not in ('4')
and Symbol=@warrantid


declare OrdetCursor cursor
for 
select TxTime,Account,Portfolio,Trader,StockID,[Type],OrderID,OrdStatus,BS,OrgVolume,DealVolume,Price
from #order
order by StockID,OrderID,TxTime,OrdStatus

open OrdetCursor

declare @TxTime nvarchar(50)
declare @Account nvarchar(50)
declare @Portfolio nvarchar(50)
declare @Trader nvarchar(50)
declare @StockID nvarchar(50)
declare @Type nvarchar(50)
declare @OrderID nvarchar(50)
declare @OrdStatus nvarchar(50)
declare @BS nvarchar(50)
declare @OrgVolume decimal(20,3)
declare @DealVolume decimal(20,3)
declare @Price decimal(20,3)

declare @PreOrderID nvarchar(50)
declare @PreTxTime nvarchar(50)
declare @OrderIDCnt int

create table #OrderTemp(BTime nvarchar(50),ETime nvarchar(50),Account nvarchar(50),Portfolio nvarchar(50),Trader nvarchar(50)
,StockID nvarchar(50),[Type] nvarchar(50),OrderID nvarchar(50) collate Chinese_Taiwan_Stroke_CS_AI,OrdStatus nvarchar(50),BS nvarchar(50)
,Volume decimal(20,3),Price decimal(20,3),Cnt int)

fetch OrdetCursor into @TxTime,@Account,@Portfolio,@Trader,@StockID,@Type,@OrderID,@OrdStatus,@BS,@OrgVolume,@DealVolume,@Price
while (@@fetch_status=0)
  begin
  set @OrderIDCnt=(select count(*) from #OrderTemp where OrderID=@OrderID)
  if @OrderIDCnt=0
    begin
	insert #OrderTemp
	select @TxTime,'13320000',@Account,@Portfolio,@Trader,@StockID,@Type,@OrderID,@OrdStatus,@BS,@OrgVolume,@Price,@OrderIDCnt
	end
  else if @OrderIDCnt>0 and @OrdStatus<>'3'
    begin
	update #OrderTemp
	set ETime=@TxTime,OrdStatus='3'
	where OrderID=@OrderID collate Chinese_Taiwan_Stroke_CS_AI and OrdStatus='0'

	insert #OrderTemp
	select @TxTime,'13320000',@Account,@Portfolio,@Trader,@StockID,@Type,@OrderID,@OrdStatus,@BS,@OrgVolume,@Price,@OrderIDCnt
	end
  else
    begin
	update #OrderTemp
	set ETime=@TxTime,OrdStatus=@OrdStatus
	where OrderID=@OrderID collate Chinese_Taiwan_Stroke_CS_AI and OrdStatus='0'
	end
    

  set @PreOrderID=@OrderID
  set @PreTxTime=@TxTime
  fetch OrdetCursor into @TxTime,@Account,@Portfolio,@Trader,@StockID,@Type,@OrderID,@OrdStatus,@BS,@OrgVolume,@DealVolume,@Price
  end

--input OrdetCursor while statement ���I
close OrdetCursor
deallocate OrdetCursor

delete Intraday.dbo.DailyOrder where TxDate=@t and Stockid=@warrantid
insert Intraday.dbo.DailyOrder
select @t as TxDate,BTime,ETime,Account,Portfolio,Trader
,StockID,[Type]
,OrderID+case when Cnt=0 then '' else '_'+cast(Cnt as nvarchar(50)) end
,OrdStatus,BS
,Volume,Price
from #OrderTemp
where Portfolio is not null
order by OrderID,BTime
--order by OrderID,BTime



drop table #OrderTemp
drop table #order




