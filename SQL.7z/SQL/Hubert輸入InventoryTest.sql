declare @t datetime set @t='2015/3/24'
declare @r decimal(20,6) set @r=0.01

insert PL.[dbo].[InventoryTest]
select @t,'TS02','J1040029',a.Seccode,null,null,null,null,null
,theodata.dbo.optvlu(c.[Last],b.strike,b.barrier,datediff(dd,@t,b.expireddate)/365.,a.bookvol,@r,a.Seccode,b.[ExerciseRate])
 as TheoPrice
,theodata.dbo.optdelta(c.[Last],b.strike,b.barrier,datediff(dd,@t,b.expireddate)/365.,a.bookvol,@r,a.Seccode)*b.[ExerciseRate]
 as Delta
,(theodata.dbo.optdelta(c.[Last]*1.01,b.strike,b.barrier,datediff(dd,@t,b.expireddate)/365.,a.bookvol,@r,a.Seccode)*b.[ExerciseRate]
 -theodata.dbo.optdelta(c.[Last]*0.99,b.strike,b.barrier,datediff(dd,@t,b.expireddate)/365.,a.bookvol,@r,a.Seccode)*b.[ExerciseRate])/2.
 as Gamma

from theodata.dbo.bookvoltest a
left join DBMain.dbo.warrantdata b on b.TxDate=@t
and b.warrantid=a.seccode
and b.warrantname=a.secname
left join marketdata.dbo.dailyquotetest c on c.TxDate=b.Txdate
and c.StockID=b.StockID
where a.seccode='085252'