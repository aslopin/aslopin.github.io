declare @trader nvarchar(50) set @trader='Michael'

select *
from DailyInsert.[dbo].[IPList]
where [NameEn]=@trader

select *
from DailyInsert.[dbo].[ProbMonitorList]
where [UserName]=@trader

select *
from dbmain.dbo.IfYouCanSee
where [User]=@trader

select *
from dbmain.[dbo].[EmployeeID]
where [NameEn]=@trader

delete DailyInsert.[dbo].[IPList]
where [NameEn]=@trader

delete DailyInsert.[dbo].[ProbMonitorList]
where [UserName]=@trader

delete dbmain.dbo.IfYouCanSee
where [User]=@trader

update dbmain.[dbo].[EmployeeID]
set Onthejob='N'
where [NameEn]=@trader

select * from dbmain.[dbo].[EmployeeID] order by [ID]

select TDept,sum(case when Onthejob='N' then 1. else 0 end)/sum(1.) as Ratio from dbmain.[dbo].[EmployeeID] where ID not like 'J104000[123]' group by TDept order by sum(case when Onthejob='N' then 1. else 0 end)/sum(1.)
