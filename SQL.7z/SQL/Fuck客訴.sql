declare @t datetime set @t='2015/8/26' declare @wid nvarchar(50) set @wid='036415'
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @yy nvarchar(50) set @yy=dbmain.dbo.datetranslator(@y,3)
declare @ser decimal(20,4) set @ser=(select ser from dbmain.dbo.tradingdate where tradingdate=@t)
declare @r decimal(20,6) set @r=0.01
--/*
declare @qv table(WarrantID nvarchar(50),qv decimal(20,6))
insert @qv
select Wrr_ID, QV from pl.[dbo].[�ۮa�v�ҨC��QV] where TxDate=@t

declare @b datetime set @b=dbmain.dbo.tradingdateadd(-23,@t)

--*/
create table #hvtab(warrantid nvarchar(50),warrantname nvarchar(50)
,stockid nvarchar(50),hv decimal(20,6),qv decimal(20,6)
,strike decimal(20,4),barrier decimal(20,4),exer decimal(20,4),ed datetime,r decimal(20,4),T decimal(20,4))
insert #hvtab
select a.warrantid,warrantname,a.Stockid
,hv.HV,q.qv
,[CurrentStrikePrice],[BarrierPrice],[AdjustedExerciseRate],expireddate,@r
,t.ser-@ser

--,dbmain.dbo.tradingdatediff(@t,expireddate)
from dbmain.[dbo].[WarrantProfileTS_Daily] a
left join dbmain.dbo.tradingdate t on t.Tradingdate=a.expireddate
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hv on hv.StockID=a.stockID
and @t between hv.bdate and hv.edate
left join @qv q on q.WarrantID=a.warrantid
where a.TxDate=@t and @t between issuedate and expireddate

declare @deal table(TimeTag nvarchar(50),deal decimal(20,4))
insert @deal
select b.TimeTag,isnull(sum(a.DealVolume)/1000.,0)
from dbmain.[dbo].[TimeTag] b
left join pl.dbo.deallist a on a.Txdate=@t and stockid=@wid and case when a.TxTime>='13250000' then '13250000' else a.TxTime end<=b.TimeTag
where theodata.dbo.[mod](b.Ser,5)=0 and b.TimeTag<='13350000'
group by b.TimeTag

select @t as ���,left(b.TimeTag,4) as �ɶ�
,a.Pb1 as �̨Ωe�R��
,a.Qb1/1000. as �̨Ωe�R�i��
,a.Ps1 as �̨Ωe���
,a.Qs1/1000. as �̨Ωe��i��
,(a.Ps1-a.Pb1)/0.01 as �ɭ����
from Intraday.dbo.WarrantMMOrder a
join dbmain.[dbo].[TimeTag] b on theodata.dbo.[mod](b.Ser,5)=0 and b.TimeTag>=a.BTime and b.TimeTag<a.ETime
where a.TxDate=@t and a.WarrantID=@wid
order by b.TimeTag

select @t as ���,left(b.TimeTag,4) as �ɶ�
,d.B1_Price as �Ъ��Ҩ�e�R��
,a.Pb1 as �{���v�ҩe�R��
,theodata.dbo.optvlu(d.B1_Price,c.strike,c.barrier,c.T/252.,c.qv,@r,a.WarrantID,c.exer) 
 as �v�Ҳz�׻���  
,theodata.dbo.Implied_vol(a.Pb1,d.B1_Price,c.strike,c.barrier,c.T/252.,@r,a.WarrantID,c.exer) 
 as �v�ҩe�R�������t�i�ʲv 
,c.qv as ���I�i�ʲv
,case when d.B1_Price/c.strike-1>=0 then d.B1_Price/c.strike-1 end
 as �����{��
,case when d.B1_Price/c.strike-1<0 then 1-d.B1_Price/c.strike end
 as ���~�{��
,c.T as �Z�����Ѽ�
,-1*(isnull(i.volume,0)/1000.+e.deal)
 as �b�~�y�q�i��
from Intraday.dbo.WarrantMMOrder a
join dbmain.[dbo].[TimeTag] b on theodata.dbo.[mod](b.Ser,5)=0 and b.TimeTag>=a.BTime and b.TimeTag<a.ETime
join #hvtab c on c.warrantid=a.WarrantID
left join pl.dbo.inventory i on i.stadate=@y and i.StockID=c.warrantid
left join db2.intraday.[dbo].[DailyTick_Underlying] d on d.[TxDate]=@t
and d.stockid=c.stockid
and b.TimeTag<d.ETime
and b.TimeTag>=d.BTime
left join @deal e on e.TimeTag=b.TimeTag
where a.TxDate=@t and a.WarrantID=@wid
order by b.TimeTag


select a.TxDate as ���,'1325' as �ɶ�,a.UPX as �Ъ��Ҩ�e�R��,a.Pb1 as �{���v�ҩe�R��
,theodata.dbo.optvlu(a.UPX,c.CurrentStrikePrice,c.BarrierPrice,dbmain.dbo.tradingdatediff(a.TxDate,c.expireddate)/252.,d.qv,@r,a.StockID,c.AdjustedExerciseRate) 
 as �v�Ҳz�׻���  
,theodata.dbo.Implied_vol(a.Pb1,a.UPX,c.CurrentStrikePrice,c.BarrierPrice,dbmain.dbo.tradingdatediff(a.TxDate,c.expireddate)/252.,@r,a.StockID,c.AdjustedExerciseRate) 
 as �v�ҩe�R�������t�i�ʲv 
,d.qv as ���I�i�ʲv
,case when a.UPX/c.CurrentStrikePrice-1>=0 then a.UPX/c.CurrentStrikePrice-1 end
 as �����{��
,case when a.UPX/c.CurrentStrikePrice-1<0 then 1-a.UPX/c.CurrentStrikePrice end
 as ���~�{��
,dbmain.dbo.tradingdatediff(a.TxDate,c.expireddate) as �Z�����Ѽ�
,-1*isnull(i.volume,0)/1000.
 as �b�~�y�q�i��
from FrontDeskW.[dbo].[B_IMP_Vol] a
join dbmain.[dbo].[WarrantProfileTS_Daily] c on c.TxDate=a.TxDate and c.warrantid=a.StockID
left join pl.[dbo].[�ۮa�v�ҨC��QV] d on d.TxDate=a.TxDate and d.wrr_id=a.StockID
left join pl.dbo.inventory i on i.stadate=a.TxDate and i.StockID=c.warrantid
where a.TxDate between @b and @t
and a.StockID=@wid
order by a.TxDate


drop table #hvtab