declare @t datetime set @t='2015/8/10'
declare @t1 datetime set @t1=dbmain.dbo.tradingdateadd(1,@t)

declare @tmax datetime set @tmax=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

declare @������ table(TxDate datetime,Account nvarchar(50),Portfolio nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50),BS nvarchar(50),TxTime nvarchar(50),Price decimal(20,3),B decimal(20,3),S decimal(20,3),DealVolume decimal(20,3),OriVolume decimal(20,3),Cost decimal(20,3),Tax decimal(20,3),Fee decimal(20,3))
if @t=@tmax begin
insert @������
select 
@t as TxDate,a.Account,b.Portfolio,isnull(c.[�N���ഫFrom],a.Symbol),a.TwseOrdType,case when a.side='0' then 'B' else 'S' end
,right('0'+cast(datepart(hour,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(minute,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(second,a.TransactTime) as nvarchar(50)),2)
+'00'
 as [TxTime]
,a.LastPx
,case when a.side='0' then 1 else 0 end*a.LastQty*1000
,case when a.side='0' then 0 else -1 end*a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000
,a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000*a.LastPx
,case when a.side='0' then 0 else 1 end*a.LastQty*1000*a.LastPx*case when dbmain.dbo.�P�_���O(a.Symbol) in ('warrant','ETF') then 0.001 else 0.003 end
,0
from [Trade_DB].[dbo].[tblOrderReport](nolock) a
--from DB2.[Trade_DB].[dbo].[tblOrderReport] a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.Symbol
left join testDB.dbo.�N���ഫ c on @t between c.BDate and c.EDate and c.[�N���ഫTo]=a.Symbol
where a.TransactTime between @t and @t1
and a.LastQty<>0
and a.OrdStatus in ('1','2')
end
else begin
insert @������
select 
@t as TxDate,a.Account,b.Portfolio,isnull(c.[�N���ഫFrom],a.Symbol),a.TwseOrdType,case when a.side='0' then 'B' else 'S' end
,right('0'+cast(datepart(hour,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(minute,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(second,a.TransactTime) as nvarchar(50)),2)
+'00'
 as [TxTime]
,a.LastPx
,case when a.side='0' then 1 else 0 end*a.LastQty*1000
,case when a.side='0' then 0 else -1 end*a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000
,a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000*a.LastPx
,case when a.side='0' then 0 else 1 end*a.LastQty*1000*a.LastPx*case when dbmain.dbo.�P�_���O(a.Symbol) in ('warrant','ETF') then 0.001 else 0.003 end
,0
from [Trade_DB].[dbo].[tblOrderReport_History](nolock) a
--from DB2.[Trade_DB].[dbo].[tblOrderReport] a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.Symbol
left join testDB.dbo.�N���ഫ c on @t between c.BDate and c.EDate and c.[�N���ഫTo]=a.Symbol
where a.TxDate=@t and a.TransactTime between @t and @t1
and a.LastQty<>0
and a.OrdStatus in ('1','2')
end


select @t as ���,a.StockID as �v�ҥN��,a.Account as �b��,a.TxTime as �ۧڦ���ɶ�,a.OriVolume/1000. as ����i,a.Price as �����
from @������ a
join @������ b on b.bs='S' and b.Stockid=a.Stockid and b.TxTime=a.TxTime and b.OriVolume=a.OriVolume and b.Price=a.Price
where a.bs='B'
order by a.StockID,a.TxTime

