select a.年月,a.券商名稱,a.FVPL股權_自營,a.FVPL股權_避險,c.FVPL債權_自營,c.FVPL債權_避險,c.FVPL債權_自營_國外,b.FVOCI股權,d.FVOCI債權 
from (
   select 年月,券商名稱
   ,sum(借方餘額) as FVPL股權  
   ,sum(case when 會計科目 like '%自營%' then 借方餘額 else 0 end) as FVPL股權_自營
   ,sum(case when 會計科目 like '%避險%' then 借方餘額 else 0 end) as FVPL股權_避險  
   from pl.dbo.同業交換報表_月計表  
   where 年月 in ('201812','201912','202012','202112','202204','202205') and 科目代號 in ('112261','112263','112264','112266','112281','112283','112284','112286')   
   group by 年月,券商名稱  
) a  
left join  (  
   select 年月,券商名稱,sum(借方餘額) as FVOCI股權  
   from pl.dbo.同業交換報表_月計表  
   where 年月 in ('201812','201912','202012','202112','202204','202205')  and 科目代號 in ('123211','113211')  
   group by 年月,券商名稱  
) b on b.券商名稱=a.券商名稱 and b.年月=a.年月  
left join  (  
   select 年月,券商名稱,sum(借方餘額) as FVPL債權  
   ,sum(case when 會計科目 like '%自營%' and 會計科目 not like '%國外%' then 借方餘額 else 0 end) as FVPL債權_自營  
   ,sum(case when 會計科目 like '%自營%' and 會計科目 like '%國外%' then 借方餘額 else 0 end) as FVPL債權_自營_國外  
   ,sum(case when 會計科目 like '%避險%' and 會計科目 not like '%國外%' then 借方餘額 else 0 end) as FVPL債權_避險  
   ,sum(case when 會計科目 like '%避險%' and 會計科目 like '%國外%' then 借方餘額 else 0 end) as FVPL債權_避險_國外  
   from pl.dbo.同業交換報表_月計表  
   where 年月 in ('201812','201912','202012','202112','202204','202205')  and 科目代號 in ('112262','112265','112268','112282','112285')  
   group by 年月,券商名稱  
) c on c.券商名稱=a.券商名稱 and c.年月=a.年月  
left join   (  
   select 年月,券商名稱,sum(借方餘額) as FVOCI債權  
   from pl.dbo.同業交換報表_月計表  
   where 年月 in ('201812','201912','202012','202112','202204','202205')  and 科目代號 in ('123221','113221')  
   group by 年月,券商名稱  
) d on d.券商名稱=a.券商名稱  and d.年月=a.年月  
where a.券商名稱 in ('台新證券','元富證券','元大證券','群益金鼎證券','富邦證券','凱基證券')   
order by 券商名稱,年月

   select 年月,券商名稱
   ,sum(case when 科目代號 like '112271' then 借方餘額 else 0 end) as [集中_權益工具]
   ,sum(case when 科目代號 like '112272' then 借方餘額 else 0 end) as [集中_債務工具]
   ,sum(case when 科目代號 like '112273' then 借方餘額 else 0 end) as [集中_其他]
   ,sum(case when 科目代號 like '112274' then 借方餘額 else 0 end) as [櫃檯_權益工具]
   ,sum(case when 科目代號 like '112275' then 借方餘額 else 0 end) as [櫃檯_債務工具]
   ,sum(case when 科目代號 like '112276' then 借方餘額 else 0 end) as [櫃檯_其他]
   ,sum(case when 科目代號 like '112278' then 借方餘額 else 0 end) as [國外]
   ,sum(case when 科目代號 like '112279' then 借方餘額 else 0 end) as [承銷評價調整]
   ,sum(case when 科目代號 like '112267' then 借方餘額 else 0 end) as [自營_興櫃]
   from pl.dbo.同業交換報表_月計表  
   where 年月 in ('201812','201912','202012','202112','202204','202205') and 科目代號 in ('112271','112272','112273','112274','112275','112276','112278','112279','112267') 
   group by 年月,券商名稱  
   order by 年月,券商名稱 desc  