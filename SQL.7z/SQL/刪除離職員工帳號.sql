select *
from dbmain.[dbo].[IfYouCanSee] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[User] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

select *
from [DailyInsert].[dbo].[IPList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[NameEn] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

select *
from [DailyInsert].[dbo].[ProbMonitorList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[UserName] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

select *
from [DailyInsert].[dbo].[ProbMonitorList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[TraderName] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

select *
from [DailyInsert].[dbo].[WarrantMonitorList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[UserName] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

select *
from [DailyInsert].[dbo].[WarrantMonitorList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[TraderName] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

/*
update a
set [Login]='�w��¾'
from [DailyInsert].[dbo].[IPList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[NameEn] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

delete a
from [DailyInsert].[dbo].[ProbMonitorList] a
join dbmain.[dbo].[EmployeeID] b on b.[NameEn]=a.[TraderName] and b.[Onthejob]='N' and b.NameEn not in ('Emily')

*/
