﻿alter TRIGGER [Proc_Alter_limit]
ON database WITH EXECUTE AS 'MD'
FOR ALTER_PROCEDURE 
AS
--BEGIN
/*
insert web.[dbo].[PhpHubertLog] select EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'),getdate()
*/
IF 
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.42')
     begin
	 insert web.[dbo].[PhpHubertLog] select EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'),getdate()
	 --ROLLBACK;
	 end

	 /*

IF ORIGINAL_LOGIN()= 'MD'
--允许test在本机和下面的IP登录
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.116','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.151')
     ROLLBACK;
	 */
/*
IF ORIGINAL_LOGIN()= 'MD'
--允许test在本机和下面的IP登录
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.103')
     ROLLBACK;

IF ORIGINAL_LOGIN()= 'patrick'
--允许test在本机和下面的IP登录
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.102')
     ROLLBACK;
	 */
/*
--限制test这个帐号的连接
IF ORIGINAL_LOGIN()= 'test'
--允许test在本机和下面的IP登录
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.102')
     ROLLBACK;
END;
*/