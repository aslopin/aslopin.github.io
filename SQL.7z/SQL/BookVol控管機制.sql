declare @t datetime set @t=(select max(stadate) from theodata.dbo.HistoryVol)
declare @tt nvarchar(50)
set @tt=dbmain.dbo.datetranslator(@t,3)
declare @t5 datetime
set @t5=dbmain.dbo.tradingdateadd(-5,@t)


select 
a.TxDate,a.WarrantID,a.WarrantName,a.StockID,a.StockName
,tr.TraderM as [Trader]
,dbmain.dbo.tradingdatediff(a.TxDate,a.Expireddate) as [�Z�����]

,case when datediff(dd,a.TxDate,a.Expireddate)>180 then case when bbv.BookVol_55-0.06<0 then 0 else bbv.BookVol_55-0.06 end
     when datediff(dd,a.TxDate,a.Expireddate)>30 then case when bbv.BookVol_55-0.08<0 then 0 else bbv.BookVol_55-0.08 end
     else case when bbv.BookVol_55-0.12<0 then 0 else bbv.BookVol_55-0.12 end
     end as [Vol_low]
,case when datediff(dd,a.TxDate,a.Expireddate)>180 then bbv.BookVol_55+0.06
     when datediff(dd,a.TxDate,a.Expireddate)>30 then bbv.BookVol_55+0.08
     else bbv.BookVol_55+0.12
     end as [Vol_up]
,case when datediff(dd,a.TxDate,a.Expireddate)>180 then bbv.BookVol_55
     when datediff(dd,a.TxDate,a.Expireddate)>30 then bbv.BookVol_55
     else bbv.BookVol_55
     end as [BenchMark]
,bv.HV  as [BookVol]

,case when datediff(dd,a.TxDate,a.Expireddate)>180 then case when bv.HV<bbv.BookVol_55-0.06 then 'BV�L�C' when bv.HV>bbv.BookVol_55+0.06 then 'BV�L��' else '' end
     when datediff(dd,a.TxDate,a.Expireddate)>30 then case when bv.HV<bbv.BookVol_55-0.08 then 'BV�L�C' when bv.HV>bbv.BookVol_55+0.08 then 'BV�L��' else '' end
     else case when bv.HV<bbv.BookVol_55-0.12 then 'BV�L�C' when bv.HV>bbv.BookVol_55+0.12 then 'BV�L��' else '' end
     end as [Alert]



from dbmain.dbo.WarrantProfileTS_Daily a
left join Theodata.dbo.�C�餽��BookVol bbv on a.stockID=bbv.stockid and bbv.TxDate=a.TxDate

left join dbmain.[dbo].[WarrantTraderTS_BE]() tr on a.warrantid=tr.warrantid and tr.issuedate=a.issuedate and @t between tr.bdate and tr.edate
left join dbmain.[dbo].[WarrantHedgeVolTS_BE]() bv on a.Stockid=bv.StockID and @t between bv.bdate and bv.edate
left join pl.dbo.inventory i on i.stadate=@t and i.stockid=a.warrantid
and i.Portfolio=a.warrantkey
where a.TxDate=@t
and @t between a.IssueDate and a.ExpiredDate
order by tr.TraderM,a.StockID,a.warrantkey


select 
a.TxDate,a.WarrantID,a.WarrantName,a.StockID,a.StockName
,tr.TraderM as [Trader]
,dbmain.dbo.tradingdatediff(a.TxDate,a.Expireddate) as [�Z�����]

,case when datediff(dd,a.TxDate,a.Expireddate)>180 then case when bbv.BookVol_55TS-0.06<0 then 0 else bbv.BookVol_55TS-0.06 end
     when datediff(dd,a.TxDate,a.Expireddate)>30 then case when bbv.BookVol_55TS-0.08<0 then 0 else bbv.BookVol_55TS-0.08 end
     else case when bbv.BookVol_55TS-0.12<0 then 0 else bbv.BookVol_55TS-0.12 end
     end as [Vol_low]
,case when datediff(dd,a.TxDate,a.Expireddate)>180 then bbv.BookVol_55TS+0.06
     when datediff(dd,a.TxDate,a.Expireddate)>30 then bbv.BookVol_55TS+0.08
     else bbv.BookVol_55TS+0.12
     end as [Vol_up]
,case when datediff(dd,a.TxDate,a.Expireddate)>180 then bbv.BookVol_55TS
     when datediff(dd,a.TxDate,a.Expireddate)>30 then bbv.BookVol_55TS
     else bbv.BookVol_55TS
     end as [BenchMark]
,bv.HV  as [BookVol]

,case when datediff(dd,a.TxDate,a.Expireddate)>180 then case when bv.HV<bbv.BookVol_55TS-0.06 then 'BV�L�C' when bv.HV>bbv.BookVol_55TS+0.06 then 'BV�L��' else '' end
     when datediff(dd,a.TxDate,a.Expireddate)>30 then case when bv.HV<bbv.BookVol_55TS-0.08 then 'BV�L�C' when bv.HV>bbv.BookVol_55TS+0.08 then 'BV�L��' else '' end
     else case when bv.HV<bbv.BookVol_55TS-0.12 then 'BV�L�C' when bv.HV>bbv.BookVol_55TS+0.12 then 'BV�L��' else '' end
     end as [Alert]



from dbmain.dbo.WarrantProfileTS_Daily a
left join Theodata.dbo.�C�餽��BookVol bbv on a.stockID=bbv.stockid and bbv.TxDate=a.TxDate

left join dbmain.[dbo].[WarrantTraderTS_BE]() tr on a.warrantid=tr.warrantid and tr.issuedate=a.issuedate and @t between tr.bdate and tr.edate
left join dbmain.[dbo].[WarrantHedgeVolTS_BE]() bv on a.Stockid=bv.StockID and @t between bv.bdate and bv.edate
left join pl.dbo.inventory i on i.stadate=@t and i.stockid=a.warrantid
and i.Portfolio=a.warrantkey
where a.TxDate=@t
and @t between a.IssueDate and a.ExpiredDate
order by tr.TraderM,a.StockID,a.warrantkey



