--SA Trigger�G�ȭ����x(�tDM)�BIT�BRonald
create TRIGGER [tr_connection_limit_SA]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'sa' 

     begin
		 if @ip in (select a.[IP] from DailyInsert.dbo.iplist a join dbmain.dbo.EmployeeID b on b.[NameEn]=a.NameEn and b.TDEPT not in ('���x','��x','IT') and b.[NameEn] not in ('Ronald'))
			 begin
			 set @file='saBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end

	 end


--MD Trigger�G�ȭ����x(�tDM)�B��x�BIT
alter TRIGGER [tr_connection_limit_MD]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'md' 

     begin
		 if @ip in (select a.[IP] from DailyInsert.dbo.iplist a join dbmain.dbo.EmployeeID b on b.[NameEn]=a.NameEn and b.TDEPT not in ('���x','��x','IT') and b.[NameEn] not in ('Ronald'))
			 begin
			 set @file='mdBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end

	 end


--MDExcel Trigger�G�ȭ����x(�tDM)�B��x�BAshley�BSam�BYuChien�BJerry�BJeff�BJoy�BPenny�BTiffany
create TRIGGER [tr_connection_limit_MDExcel]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'MDExcel' 

     begin
		 if @ip in (select a.[IP] from DailyInsert.dbo.iplist a join dbmain.dbo.EmployeeID b on b.[NameEn]=a.NameEn and b.TDEPT not in ('���x','��x') and b.[NameEn] not in ('Ashley','Sam','YuChien','Jerry','Jeff','Joy','penny','Tiffany'))
			 begin
			 set @file='MDExcelBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end

	 end