/*
exec FrontDeskW.dbo.�Y�ɳ����ˬd

select Wrr_ID,cast(case when QV='' then null else QV end as decimal(20,6))/100.
,isnull(cast(case when SP='' then null else SP end as decimal(20,6)),0)
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
where TX_Date='20150821'
*/
alter procedure dbo.�Y�ɳ����ˬd
as

declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @yy nvarchar(50) set @yy=dbmain.dbo.datetranslator(@y,3)

declare @serMax nvarchar(50) set @serMax=(select max(cast(In_Time as decimal(20,0))) from tick.[dbo].[tbl_Tick_Today_snapshot](nolock))

create table #BA(StockID nvarchar(50),B1_Price decimal(20,4),A1_Price decimal(20,4))
insert #BA
select StockID
,case when B1_Price='' then null else B1_Price end
,case when A1_Price='' then null else A1_Price end
from tick.[dbo].[tbl_Tick_Today_snapshot](nolock)
where In_Time=@serMax

declare @qvQ table(WarrantID nvarchar(50),QV decimal(20,6))
insert @qvQ
select Wrr_ID,cast(case when QV='' then null else QV end as decimal(20,6))/100.
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
where TX_Date=@yy and QV<>''

declare @qvS table(WarrantID nvarchar(50),SP decimal(20,6))
insert @qvS
select Wrr_ID,isnull(cast(case when SP='' then null else SP end as decimal(20,6)),0)
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
where TX_Date=@yy and SP<>''

declare @adj table(WarrantID nvarchar(50),TxTime nvarchar(50),QV decimal(20,6),SP decimal(20,6))
insert @adj
select Wrr_ID
,right('0'+cast(datepart(hour,TX_Time) as nvarchar(50)),2)
+right('0'+cast(datepart(minute,TX_Time) as nvarchar(50)),2)
+right('0'+cast(datepart(second,TX_Time) as nvarchar(50)),2)
+'00'
 as [TxTime]
,cast(case when QV='' then null else QV end as decimal(20,6))/100.
,cast(case when SP='' then null else SP end as decimal(20,6))
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Tmp]
where TX_Date=@tt

declare @QVadj table(WarrantID nvarchar(50),QV decimal(20,6))
insert @QVadj
select a.WarrantID,a.QV
from @adj a
join (select WarrantID,max(TxTime) as TxTime from @adj where QV is not null group by WarrantID) b on b.WarrantID=a.WarrantID and b.TxTime=a.TxTime

declare @SPadj table(WarrantID nvarchar(50),SP decimal(20,6))
insert @SPadj
select a.WarrantID,a.SP
from @adj a
join (select WarrantID,max(TxTime) as TxTime from @adj where SP is not null group by WarrantID) b on b.WarrantID=a.WarrantID and b.TxTime=a.TxTime

declare @r decimal(20,6) set @r=0.01

declare @ser decimal(20,4) set @ser=(select ser from dbmain.dbo.tradingdate where tradingdate=@t)
declare @hvtab table(warrantid nvarchar(50),warrantname nvarchar(50)
,stockid nvarchar(50),qv decimal(20,6),sp decimal(20,6)
,strike decimal(20,4),barrier decimal(20,4),exer decimal(20,4),ed datetime,r decimal(20,4),T decimal(20,4))
insert @hvtab
select a.warrantid,warrantname,a.Stockid,isnull(qv1.qv,qvq.qv),isnull(qv2.sp,qvs.sp)
,[CurrentStrikePrice],[BarrierPrice],[AdjustedExerciseRate],expireddate,@r
,t.ser-@ser--+1
--2015/9/14�_���A�[�@��
--,dbmain.dbo.tradingdatediff(@t,expireddate)
from dbmain.[dbo].[WarrantProfileTS_Daily] a
left join dbmain.dbo.tradingdate t on t.Tradingdate=a.expireddate
left join @qvq qvq on qvq.WarrantID=a.WarrantID
left join @qvs qvs on qvs.WarrantID=a.WarrantID
left join @QVadj qv1 on qv1.WarrantID=a.WarrantID
left join @SPadj qv2 on qv2.WarrantID=a.WarrantID
where a.Txdate=@t and @t between issuedate and expireddate

create table #Order(WarrantID nvarchar(50),TxTime nvarchar(50),BS nvarchar(50),Price decimal(20,6))
insert #Order
select a.Symbol
,right('0'+cast(datepart(hour,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(minute,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(second,a.TransactTime) as nvarchar(50)),2)
+'00' 
 as TxTime
,case when a.side='0' then 'B' else 'S' end
,a.Price
from [Trade_DB].[dbo].[tblOrderReport] a
left join [Trade_DB].[dbo].[tblOrderReport] b on b.OrderID=a.OrderID collate Chinese_Taiwan_Stroke_CS_AI and b.OrdStatus<>'0'
where a.account='8888885' and a.OrdStatus='0' and b.OrderID is null



declare @out table(Trader nvarchar(50),WarrantID nvarchar(50),WarrantName nvarchar(50),StockID nvarchar(50),StockName nvarchar(50)
,WB decimal(20,6),WA decimal(20,6),W�z��B decimal(20,6),W�z��A decimal(20,6),SB decimal(20,6),SA decimal(20,6),QV decimal(20,6),BIV decimal(20,6),SP decimal(20,6),T decimal(20,6))
insert @out
select tr.TraderM,w.WarrantID,w.WarrantName,w.StockID,w.StockName
,wba.B1_Price,wba.A1_Price
,round(
 case when w.CallPut='C' then theodata.dbo.optvlu(sba.B1_Price,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,w.WarrantID,hv.Exer)
      when w.CallPut='P' then theodata.dbo.optvlu(sba.A1_Price,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,w.WarrantID,hv.Exer)
	  end
 ,2,0)
 as W�z��B
,round(
 case when w.CallPut='C' then theodata.dbo.optvlu(sba.A1_Price,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,w.WarrantID,hv.Exer)
      when w.CallPut='P' then theodata.dbo.optvlu(sba.B1_Price,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,w.WarrantID,hv.Exer)
	  end
 ,2,0)
 as W�z��A
,sba.B1_Price,sba.A1_Price
,hv.qv

,case when w.CallPut='C' then theodata.[dbo].[Implied_vol](wba.B1_Price,sba.B1_Price,hv.strike,hv.barrier,hv.T/252.,hv.r,w.WarrantID,hv.Exer)
      when w.CallPut='P' then theodata.[dbo].[Implied_vol](wba.B1_Price,sba.A1_Price,hv.strike,hv.barrier,hv.T/252.,hv.r,w.WarrantID,hv.Exer)
	  end
 as BIV
,hv.Sp
,hv.T
from dbmain.[dbo].[WarrantProfileTS] w
left join (
         select WarrantID as StockID,max(case when BS='B' then Price end) as B1_Price,min(case when BS='S' then Price end) as A1_Price
         from #Order
         group by WarrantID
          ) wba on wba.StockID=w.warrantid
left join #BA sba on sba.StockID=w.StockID
left join @hvtab hv on hv.warrantid=w.WarrantID
left join dbmain.[dbo].[WarrantTraderTS_BE]() tr on tr.WarrantID=w.WarrantID and tr.IssueDate=w.IssueDate and @t between tr.BDate and tr.EDate
where @t between w.AvailableDate and w.lasttradedate

select @serMax as InTime,a.Trader,a.WarrantID,a.WarrantName,a.StockID,a.StockName,a.WB,a.WA
,a.W�z��B,a.W�z��A+b.Tick*a.Sp as W�z��A,a.SB,a.SA,a.QV,a.BIV
,a.Sp,a.T
from @out a
left join dbmain.dbo.TickTable b on b.Tag='warrant' and a.W�z��A between b.minP and b.maxP
--where abs(WB-W�z��B)>=0.02-- or abs(WA-W�z��A)>=0.02
order by a.WarrantID

drop table #BA
drop table #Order


