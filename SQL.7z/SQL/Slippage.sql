/*
declare @b datetime,@e datetime,@t datetime
set @b='2015/7/20'
set @e='2015/7/24'
set @t=@b
while @t<=@e
  begin
  print @t
  exec [dbo].[PL_���f���t�l�qT_�v�ҨC��Slippage] @t
  set @t=DBMain.dbo.tradingdateadd(1,@t)
  end

*/
create procedure [dbo].[PL_���f���t�l�qT_�v�ҨC��Slippage] @t datetime
as
--declare @t datetime set @t='2015/8/3'
declare @tt nvarchar(50) set @tt=dbmain.dbo.DateTranslator(@t,3)

create table #deltadeal(Underlying nvarchar(50),TxTime nvarchar(50),TradeSN nvarchar(50),Portfolio nvarchar(50),StockID nvarchar(50),account nvarchar(50),DeltaLot decimal(20,4))
insert #deltadeal
select a.Underlying,a.TxTime,a.TradeSN,a.Portfolio,a.Stockid,a.account
,case when a.BuySell='B' then 1 else -1 end*a.DeltaLot
from [PL].[dbo].[�v�ҨC��Markup] a
where a.[TxDate]=@t-- and a.Underlying='1536'

create table #Underlying([TxDate] datetime,[Stockid] nvarchar(50),[BTime] nvarchar(50),[ETime] nvarchar(50)
,[Tick_Price] decimal(20,4),[Tick_Qty] decimal(20,4))
insert #Underlying
select [TxDate],Stockid,[BTime],[ETime],[Tick_Price],[Tick_Qty]
from db2.intraday.[dbo].[DailyTick_Underlying] a
where a.[TxDate]=@t

create table #Fair([Stockid] nvarchar(50),fairprice decimal(20,4))
insert #Fair
select [Stockid],fairprice
from DB2.Tick.[dbo].[tbl_Day_MinMax] a
where a.In_Time=@tt


delete PL.dbo.���f���t�l�qT where TxDate=@t
insert PL.dbo.���f���t�l�qT
select a.TxDate,a.TxTime,a.Portfolio,a.Trader,a.StockID,a.DealVolume,a.DealAmt
,case when a.TxTime<='09000000' then e.fairprice else isnull(c.Tick_Price,d.���L��) end
as Sf
,(a.DealVolume*b.��������*f.�����-a.DealVolume*b.��������*d.���L��)
-(a.DealAmt-a.DealVolume*b.��������*case when a.TxTime<='09000000' then e.fairprice else isnull(c.Tick_Price,d.���L��) end)
as ���f���tT
,a.DealVolume*b.��������*d.���L��-a.DealVolume*b.��������*case when a.TxTime<='09000000' then e.fairprice else isnull(c.Tick_Price,d.���L��) end
as Hedge_AF
from pl.dbo.Deallist a
left join marketdata.[dbo].[�C��ӪѴ��f��������] b on b.���=@t and left(a.StockID,len(a.StockID)-6)=b.�N��
left join #Underlying c on c.Stockid=b.�Ъ��N�� and a.TxTime>=c.BTime and a.TxTime<c.ETime
left join cmoney.dbo.�馬�L���Ʀ� d on d.���=@t and d.�Ѳ��N��=b.�Ъ��N��
left join #Fair e on e.StockID=b.�Ъ��N��
left join cmoney.dbo.���f����污�� f on f.���=@t and a.StockID=f.�N��
where a.TxDate=@t and dbmain.dbo.�P�_���O(a.StockID)='fut'


delete PL.dbo.�v�ҨC��Slippage where [Stadate]=@t

declare SlippageCursor cursor
for 
select Underlying,Portfolio,TxTime,TradeSN,StockID,DeltaLot,case when account='8888885' then 'Y' else 'N' end
from #deltadeal
order by Underlying,TxTime,Portfolio,StockID

open SlippageCursor

declare @sec nvarchar(50)
declare @Stockid nvarchar(50)
declare @por nvarchar(50)
declare @TradeSN nvarchar(50)
declare @tag nvarchar(50)
declare @delta decimal(20,4)
declare @deltadone decimal(20,4)
declare @DealAmtTotal decimal(20,4)
declare @ifTS nvarchar(50)

declare @BT nvarchar(50)
declare @ET nvarchar(50)
declare @dealprice decimal(20,4)
declare @LotB decimal(20,4)
declare @LotS decimal(20,4)

set @deltadone=0
set @DealAmtTotal=0
fetch SlippageCursor into @sec,@por, @tag,@TradeSN,@Stockid,@delta,@ifTS

while (@@fetch_status=0)
  begin
  
  declare DelayCursor cursor
  for 
  select a.[BTime],a.[ETime],a.[Tick_Price],isnull(a.[Tick_Qty],0)*0.5*1000 as �i�R�q,-1*isnull(a.[Tick_Qty],0)*0.5*1000 as �i��q
  from #Underlying a
  where a.[TxDate]=@t and a.[Stockid]=@sec
  and a.[BTime]>@tag and a.[BTime]<'132500000000'
  order by a.[BTime]

  open DelayCursor

  fetch DelayCursor into @BT,@ET,@dealprice, @LotB,@LotS
  while (@@fetch_status=0)
    begin
    if @delta>0 and @delta-@deltadone>0 begin 
      if @LotB>=@delta-@deltadone begin set @DealAmtTotal=@DealAmtTotal+(@delta-@deltadone)*@dealprice
                                        set @deltadone=@deltadone+(@delta-@deltadone)
                                        end
                             else begin set @DealAmtTotal=@DealAmtTotal+@LotB*@dealprice
                                        set @deltadone=@deltadone+@LotB
                                        end
                                        end
    if @delta<0 and @delta-@deltadone<0 begin 
      if @LotS<=@delta-@deltadone begin set @DealAmtTotal=@DealAmtTotal+(@delta-@deltadone)*@dealprice
                                        set @deltadone=@deltadone+(@delta-@deltadone)
                                        end
                             else begin set @DealAmtTotal=@DealAmtTotal+@LotS*@dealprice
                                        set @deltadone=@deltadone+@LotS
                                        end
                                        end
    fetch DelayCursor into @BT,@ET,@dealprice, @LotB,@LotS
    end

  close DelayCursor
  deallocate DelayCursor  
  
  set @DealAmtTotal=@DealAmtTotal+(@delta-@deltadone)*@dealprice

  insert pl.dbo.�v�ҨC��Slippage
  select @t as Stadate,@sec as UnderlyingID,@por as Portfolio,@Stockid as WarrantID,@TradeSN, @tag as TxTime,@delta as DeltaLot
  ,@DealAmtTotal
  as DealAmt_Delay
  ,@ifTS

  from #Underlying a
  where a.[TxDate]=@t and a.stockid=@sec and a.ETime>@tag and a.BTime<=@tag

  set @deltadone=0
  set @DealAmtTotal=0
  fetch SlippageCursor into @sec,@por, @tag,@TradeSN,@Stockid,@delta,@ifTS
  end

--input cursor while statement ���I
close SlippageCursor
deallocate SlippageCursor


drop table #deltadeal
drop table #Underlying
drop table #Fair
