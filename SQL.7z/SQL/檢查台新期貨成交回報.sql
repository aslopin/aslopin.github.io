declare @t datetime set @t=(select max(日期) from cmoney.dbo.權證基本資料表每日)

select a.原始成交明細筆數,a.轉倉單筆數,a.原始應計筆數,b.中台成交明細筆數
from (
SELECT sum(1.) as 原始成交明細筆數
,sum(case when PRODUCTID like '%/%' then 1 else 0 end) as 轉倉單筆數
,sum(case when PRODUCTID like '%/%' then 2 else 1 end) as 原始應計筆數
FROM [Trade_DB].[dbo].[tblTSFut_DealReply] a
) a
cross join
(
SELECT count(*)  as 中台成交明細筆數
FROM PL.[dbo].[台新期貨盤中明細](@t)
) b


SELECT a.*  
FROM [Trade_DB].[dbo].[tblTSFut_DealReply] a
left join db41.dbmain.dbo.[tbl期自營帳號對應] fid on case when left([INVESTORACNO],7) = '9800063' then fid.ID + fid.上手帳號 else fid.上手帳號 end  = case when left([INVESTORACNO],7) = '9800063' then IDNO+substring([INVESTORACNO],CHARINDEX('-',[INVESTORACNO])+1,len([INVESTORACNO])) else a.INVESTORACNO end
where fid.上手帳號 is null



select b.策略,a.*
from (
	select Portfolio,Acc,Trader
	,STRING_AGG(StockID,',') as StockID
	,cast((sum(BAmt)+sum(SAmt))/1000000. as decimal(20,2)) as NetAmt_M
	,sum(BVolume) as BVolume
	,cast(sum(BAmt)/1000000. as decimal(20,2)) as BAmt_M
	,sum(SVolume) as SVolume
	,cast(sum(SAmt)/1000000. as decimal(20,2)) as SAmt_M
	,min(BTime) as BTime,max(ETime) as ETime	
	from (
		SELECT Portfolio,Acc,Trader,StockID,count(*) as 筆數
		,sum(BVolume) as BVolume
		,sum(case when BVolume>0 then dealamt else 0 end) as BAmt
		,sum(SVolume) as SVolume
		,sum(case when SVolume<0 then dealamt else 0 end) as SAmt
		,min(TxTime) as BTime,max(TxTime) as ETime
		FROM PL.[dbo].[台新期貨盤中明細](@t)
		group by Portfolio,Acc,Trader,StockID
	) a
	group by Portfolio,Acc,Trader
) a
join dbmain.dbo.Strategy名稱轉換 b on @t between b.BDate and b.EDate and b.Strategy=a.Portfolio
order by a.BTime desc
