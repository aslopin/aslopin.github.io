/*
exec Monitor.dbo.�Y��DB�污
*/
alter procedure dbo.�Y��DB�污
as

create table #TickLast(Tag nvarchar(50),Tick_Time nvarchar(50),StockID nvarchar(50),[Last] decimal(20,4))
insert #TickLast
select 'F' as Tag,[Tick_Time],StockID,case when Tick_Price<>'' then Tick_Price end as [Last] 
from db2.tick.dbo.tbl_Tick_Today_snapshot_FU_Peter
where StockID like 'TXF__'
insert #TickLast
select 'S' as Tag,[Tick_Time],StockID,case when Tick_Price<>'' then Tick_Price end as [Last] 
from db2.Tick.[dbo].[tbl_Tick_Today_snapshot_Peter]
/*
insert #TickLast
select 'F' as Tag,StockID, Tick_Price as [Last]  
FROM DB2.Tick.dbo.tbl_Tick_Today_snapshot_FF
*/

insert #TickLast
SELECT 'EX' as Tag,null,StkCode, max(Price) as [Last]   FROM DB2.DailyInsert.dbo.Tick_ExchangeRate_Snapshot NOLOCK group by StkCode
insert #TickLast
select 'NAV' as Tag,null,case when ETF_id like '00%' then ETF_id+'N' else ETF_id end as StockID,Price
from db2.Tick.dbo.[View_TickLast_ETFNAV]
insert #TickLast
select Top 1 'IX',[Tick_Time],'TSE',Tick_Price from db2.[Tick].dbo.[tbl_Tick_Today_Index_Peter] nolock where stockid='1' order by [No] desc

select *
from #TickLast
order by Tag,StockID

drop table #TickLast
