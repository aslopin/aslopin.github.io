declare @t datetime set @t='2017/4/19'
declare @trader nvarchar(50) set @trader='JOHNNY'

declare @Facc nvarchar(50) set @Facc=(select [FuAcc00] from dbmain.[dbo].[AccountList_Temp] where @t between BDate and EDate and NameEn=@trader and ���զX='warrant')
declare @t1 datetime set @t1=dbmain.dbo.tradingdateadd(1,@t)


--insert Trade_DB.[dbo].[tblKGIOrderInfo]
select @t,@trader,a.OrderNo,'','','',b.�Ъ��N��,a.Symbol,'','',0,0
from (
select [ASorderNo] collate Chinese_Taiwan_Stroke_CS_AI as OrderNo
,Symbol
from [Trade_DB].[dbo].[tblKGI_Report_Done_His]
  where txdate = @t and market <> 'R' 
and TraderID=@Facc
group by [ASorderNo] collate Chinese_Taiwan_Stroke_CS_AI,Symbol
) a
left join marketdata.[dbo].[�C��ӪѴ��f��������] b on b.���=@t and b.�N��=left(a.Symbol,3) and b.�Ъ��N��<>'TWA00'
where b.�Ъ��N�� in ('','','','')
/*
insert Trade_DB.[dbo].[tblKGIOrderInfo_RealTime]
select '2016-09-23 19:33:00.000',@trader,a.OrderNo,'','','',b.�Ъ��N��,a.Symbol,'','',0,0
from (
select OrderNo collate Chinese_Taiwan_Stroke_CS_AI as OrderNo
,Symbol
from db2.[Trade_DB].[dbo].[KGI_Futu_Report_T]
where [InTime] between @t and @t1
--and [RecType]='2'
and TraderID=@Facc
group by OrderNo collate Chinese_Taiwan_Stroke_CS_AI,Symbol
) a
left join marketdata.[dbo].[�C��ӪѴ��f��������] b on b.���=@t and b.�N��=left(a.Symbol,3) and b.�Ъ��N��<>'TWA00'
*/
/*
select *
into Trade_DB.[dbo].[tblKGIOrderInfo20170218]
from Trade_DB.[dbo].[tblKGIOrderInfo]
where OrderDate='2017/2/18'

delete Trade_DB.[dbo].[tblKGIOrderInfo]
where OrderDate='2017/2/18'
*/
/*
select *
from Trade_DB.[dbo].[tblKGIOrderInfo]
where OrderDate='2016/7/22'

select *
from Trade_DB.[dbo].[tblKGIOrderInfo_RealTime]
where OrderDate=(select max(OrderDate) from Trade_DB.[dbo].[tblKGIOrderInfo_RealTime])
*/