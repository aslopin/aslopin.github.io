/****** SSMS 中 SelectTopNRows 命令的指令碼  ******/
SELECT a.[Acc]
      ,sum(a.Irs_已實現_D+a.Irs_未實現_D)
  FROM [PL].[dbo].[CBASDailyPLReportMD_NEWSYS] a
  join dbmain.[dbo].[CBAS_ASW_NEWSYS] b on b.[TxDate]=a.TxDate and b.[ASW_ID]=a.ID and b.[ASW_STARTDATE]>='2023/11/17'
  where a.TxDate>='2023/11/17'
  group by a.[Acc]

  SELECT a.[Acc]
      ,sum(a.Irs_已實現_D+a.Irs_未實現_D)
  FROM [PL].[dbo].[CBASDailyPLReportMD_NEWSYS] a
  join dbmain.[dbo].[CBAS_ASO_NEWSYS] b on b.[TxDate]=a.TxDate and b.[ASO_ID]=a.ID and b.[ASO_STARTDATE]>='2023/11/17'
  where a.TxDate>='2023/11/17'
  group by a.[Acc]

select TxDAte,sum(funding) as funding
from pl.dbo.金交處彙整表_MD_日曆日
where Portfolio like '%CBAS%'
and TxDate>='2023/11/17'
group by TxDAte
order by TxDAte

select TxDAte,sum(funding) as funding
from pl.dbo.金交處彙整表_MD_日曆日
where (Portfolio like '%CBAS%' or Portfolio like '%ASW%')
and TxDate>='2023/11/17'
group by TxDAte
order by TxDAte

/****** SSMS 中 SelectTopNRows 命令的指令碼  ******/
SELECT TOP (1000) [Txdate]
      ,[Trader]
      ,[Strategy]
      ,[Acc]
      ,[StockID]
      ,[標的代碼]
      ,[Volume]
      ,[會計_D]
      ,[BOOK_D]
      ,[Tax_D]
      ,[會計_M]
      ,[BOOK_M]
      ,[Tax_M]
      ,[會計_Y]
      ,[BOOK_Y]
      ,[Tax_Y]
      ,[會計_Delta]
      ,[BOOK_Delta]
      ,[LastPrice]
      ,[TheoPrice]
      ,[費用_D]
      ,[費用_M]
      ,[費用_Y]
      ,[MTM_D_昨日部位]
      ,[MTM_D_今日部位]
      ,[BookPrice]
  FROM [PL].[dbo].[DailyPLReport_債券_海外_KGI]
  where acc='8627' and Volume<>0
  order by [Txdate] desc

  select * from pl.[dbo].[Inventory_債券_海外_KGI]
    where acc='8627' and Volume<>0 and TxDate>='2023/10/1'
	order by [Txdate] desc


select a.[交易員代號],sum([Net_D]),sum([Net_D2]),sum([DiffNet_D])
from (
	select a.[交易員代號],a.交易日
	,sum(a.[Net_D]) as [Net_D],sum(a.[面額]) as [面額],sum(b.[面額]) as [面額2]
	,sum(case when a.[面額]<>0 then a.[Net_D]/cast(a.[面額] as float)*cast(isnull(b.[面額],0) as float) else 0 end) as [Net_D2]
	,sum(case when a.[面額]<>0 then a.[Net_D]/cast(a.[面額] as float)*cast(isnull(b.[面額],0) as float)-a.[Net_D] else 0 end) as [DiffNet_D]
	from (
		select 交易日,[交易員代號]
		,sum([DV01]) as [DV01]
		,sum([庫存成本]) as [庫存成本]
		,sum([面額]) as [面額]
		,sum([Net_D]) as [Net_D]
		,sum([理論匯率損益_D]) as [理論匯率損益_D]
		from pl.[dbo].[DailyPLReport_公債公司債交易_分交易單_日曆日]
		where 交易日 between '2023/11/17' and '2024/3/7'
		group by 交易日,[交易員代號]
	) a
	left join (
		select 交易日,[交易員代號]
		,sum([DV01]) as [DV01]
		,sum([庫存成本]) as [庫存成本]
		,sum([面額]) as [面額]
		,sum([Net_D]) as [Net_D]
		,sum([理論匯率損益_D]) as [理論匯率損益_D]
		from pl.[dbo].[DailyPLReport_公債公司債交易_分交易單_日曆日]
		where 交易日='2023/11/17'
		group by 交易日,[交易員代號]
	) b on b.交易員代號=a.交易員代號 and b.交易日='2023/11/17'
	group by a.[交易員代號],a.交易日
) a
group by a.[交易員代號]
order by a.[交易員代號]

select a.[交易員代號],a.交易日,sum([Net_D]),sum([Net_D2]),sum([DiffNet_D]),sum([面額]),sum([面額2])
from (
	select a.[交易員代號],a.交易日
	,sum(a.[Net_D]) as [Net_D],sum(a.[面額]) as [面額],sum(b.[面額]) as [面額2]
	,sum(case when a.[面額]<>0 then a.[Net_D]/cast(a.[面額] as float)*cast(isnull(b.[面額],0) as float) else 0 end) as [Net_D2]
	,sum(case when a.[面額]<>0 then a.[Net_D]/cast(a.[面額] as float)*cast(isnull(b.[面額],0) as float)-a.[Net_D] else 0 end) as [DiffNet_D]
	from (
		select 交易日,[交易員代號]
		,sum([DV01]) as [DV01]
		,sum([庫存成本]) as [庫存成本]
		,sum([面額]) as [面額]
		,sum([Net_D]) as [Net_D]
		,sum([理論匯率損益_D]) as [理論匯率損益_D]
		from pl.[dbo].[DailyPLReport_公債公司債交易_分交易單_日曆日]
		where 交易日 between '2023/11/17' and '2024/3/7'
		group by 交易日,[交易員代號]
	) a
	left join (
		select 交易日,[交易員代號]
		,sum([DV01]) as [DV01]
		,sum([庫存成本]) as [庫存成本]
		,sum([面額]) as [面額]
		,sum([Net_D]) as [Net_D]
		,sum([理論匯率損益_D]) as [理論匯率損益_D]
		from pl.[dbo].[DailyPLReport_公債公司債交易_分交易單_日曆日]
		where 交易日='2023/11/17'
		group by 交易日,[交易員代號]
	) b on b.交易員代號=a.交易員代號 and b.交易日='2023/11/17'
	group by a.[交易員代號],a.交易日
) a
group by a.[交易員代號],a.交易日
order by a.[交易員代號],a.交易日

	select a.[交易員代號]
	,sum(a.[Net_D]) as [Net_D]
	,sum(case when a.[面額]<>0 then a.[Net_D]/a.[面額]*isnull(b.[面額],0) else 0 end) as [Net_D]

	from pl.[dbo].[DailyPLReport_公債公司債交易_分交易單_日曆日] a
	left join pl.[dbo].[DailyPLReport_公債公司債交易_分交易單_日曆日] b on b.交易日='2023/11/17' and b.[交易員代號]=a.[交易員代號] and b.交易單號=a.交易單號
	where a.交易日 between '2023/11/17' and '2024/3/7'
	group by a.[交易員代號]

