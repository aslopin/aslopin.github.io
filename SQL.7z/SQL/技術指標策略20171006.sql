declare @n int set @n=5

declare @SS table(TxDate datetime,ser int,StockID nvarchar(50),O decimal(20,10),H decimal(20,10),L decimal(20,10),C decimal(20,10))
insert @SS
select ���,b.ser,�Ѳ��N��,�}�L��,�̰���,�̧C��,���L��
from cmoney.dbo.�馬�L�٭���Ʀ� a
join dbmain.dbo.tradingdate b on b.Tradingdate=a.���
where ���>='2006/1/1' and �Ѳ��N��='2330'

declare @Out table(TxDate datetime,Cnt int,StockID nvarchar(50),C decimal(20,10),MA decimal(20,10),RSV decimal(20,10)
,K decimal(20,10),D decimal(20,10),EMA1 decimal(20,10),EMA2 decimal(20,10),DIF decimal(20,10),EMADIF decimal(20,10),OSC decimal(20,10))

declare input cursor
for 
select a.TxDate,a.StockID,avg(a.C),avg(b.C),(avg(a.C)-min(b.L))/(max(b.H)-min(b.L))*100 as RSV
from @SS a
join @SS b on b.StockID=a.StockID and b.ser between a.ser-@n+1 and a.ser
group by a.TxDate,a.StockID
order by a.TxDate,a.StockID

open input

declare @TxDate datetime
declare @StockID nvarchar(50)
declare @C decimal(20,10)
declare @MA decimal(20,10)
declare @RSV decimal(20,10)
declare @EMA1 decimal(20,10)
declare @EMA2 decimal(20,10)
declare @DIF decimal(20,10)
declare @EMADIF decimal(20,10)
declare @OSC decimal(20,10)

declare @K decimal(20,10)
declare @D decimal(20,10)
declare @cnt int
set @K=50
set @D=50
set @cnt=1

fetch input into @TxDate,@StockID,@C,@MA,@RSV
while (@@fetch_status=0)
  begin
  if @cnt=1 
	  begin
	  set @EMA1=@C
	  set @EMA2=@C
	  set @DIF=@EMA1-@EMA2
	  set @EMADIF=@DIF
	  end
  else
	  begin
	  set @EMA1=@EMA1+(2/(@n+1.))*(@C-@EMA1)
	  set @EMA2=@EMA2+(2/(2*@n+2.+1.))*(@C-@EMA2)
	  set @DIF=@EMA1-@EMA2
	  set @EMADIF=@EMADIF+(2/(9.+1.))*(@DIF-@EMADIF)
	  end
  set @OSC=@DIF-@EMADIF
  set @K=2*@K/3.+@RSV/3.
  set @D=2*@D/3.+@K/3.
  insert @Out select @TxDate,@cnt,@StockID,@C,@MA,@RSV,@K,@D,@EMA1,@EMA2,@DIF,@EMADIF,@OSC

  set @cnt=@cnt+1
  fetch input into @TxDate,@StockID,@C,@MA,@RSV
  end

--input cursor while statement ���I
close input
deallocate input




declare @Out2 table(StockID nvarchar(50),TxDate datetime,Cnt int,C decimal(20,10),MA decimal(20,10),RSV decimal(20,10),K decimal(20,10),D decimal(20,10),OSC decimal(20,10)
,PosK decimal(20,10),PosKV decimal(20,10),PosKDX decimal(20,10),PosMACD decimal(20,10),PosMA decimal(20,10))

declare @RSVpre decimal(20,10)
declare @OSCpre decimal(20,10)

declare @PosK decimal(20,10)
declare @PosKV decimal(20,10)
declare @PosKDX decimal(20,10)
declare @PosMACD decimal(20,10)
declare @PosMA decimal(20,10)


declare input2 cursor
for 
select StockID,TxDate,Cnt,C,MA,RSV,K,D,OSC
from @out
order by TxDate

open input2

fetch input2 into @StockID,@TxDate,@Cnt,@C,@MA,@RSV,@K,@D,@OSC
while (@@fetch_status=0)
  begin

  set @PosK=case when @RSV>80 then 1 when @RSV<20 then -1 else 0 end
  set @PosKV=case when @RSVpre<=20 and @RSV>20 then 1
                  when @RSVpre>=80 and @RSV<80 then -1
				  else isnull(@PosKV,0)
				  end
  set @PosKDX=case when @cnt=1 then 0 when @K>@D then 1 when @K<@D then -1 else @PosKDX end
  set @PosMACD=case when @OSCpre>0 and @OSC>0 and @OSC>@OSCpre then 1
                    when @OSCpre<0 and @OSC<0 and @OSC<@OSCpre then -1
				    else 0
				    end
  set @PosMA=case when @C>@MA then 1
                  when @C<@MA then -1
				  else isnull(@PosMA,0)
				  end

  insert @Out2 
  select @StockID,@TxDate,@Cnt,@C,@MA,@RSV,@K,@D,@OSC,@PosK,@PosKV,@PosKDX,@PosMACD,@PosMA


  set @RSVpre=@RSV
  set @OSCpre=@OSC
  fetch input2 into @StockID,@TxDate,@Cnt,@C,@MA,@RSV,@K,@D,@OSC
  end

--input cursor while statement ���I
close input2
deallocate input2


select StockID,TxDate,Cnt,C,MA,RSV,K,D,OSC
,PosK,PosKV,PosKDX,PosMACD,PosMA
from @out2
order by TxDate
