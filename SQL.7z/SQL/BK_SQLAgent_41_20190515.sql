USE [msdb]
GO

/****** Object:  Job [1330 ETF����污]    Script Date: 2019/5/15 �W�� 09:23:31 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:31 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'1330 ETF����污', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'1330 ETF�污', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		 @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ˬd�O�_�������]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ˬd�O�_�������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�x�W���L�ɶ�1330�污]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�x�W���L�ɶ�1330�污', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date = getdate()
exec DailyInsert.[dbo].[Intraday_tblTickETFDaily] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1330 Snapshot]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1330 Snapshot', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE FROM Tick.dbo.tbl_Tick_Today_snapshot
INSERT INTO Tick.dbo.tbl_Tick_Today_snapshot
 SELECT In_Time, Out_Time, StockId, Tick_Time, Tick_Price, Tick_Qty, 
   B1_Price, B1_Qty, B2_Price, B2_Qty, B3_Price, B3_Qty, B4_Price, B4_Qty, B5_Price, B5_Qty,
   A1_Price, A1_Qty, A2_Price, A2_Qty, A3_Price, A4_Qty, A4_Price, A4_Qty, A5_Price, A5_Qty,
   Sum_Qty, Normal_Try
 FROM DB2.Tick.dbo.tbl_Tick_Today_snapshot', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�����U��1331', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20161013, 
		@active_end_date=99991231, 
		@active_start_time=133100, 
		@active_end_time=235959, 
		@schedule_uid=N'13cacbf0-f006-4d2f-b0d5-60c51d09568a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [1800 �����L���ƾ�z]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Data Collector]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Data Collector' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Data Collector'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'1800 �����L���ƾ�z', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�L���ƾ�z�۹藍�Y�귽������', 
		@category_name=N'Data Collector', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ˬd�O�_�������]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ˬd�O�_�������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SELECT 1/COUNT(*) FROM DBMain.dbo.Tradingdate WHERE Tradingdate = CONVERT(date, GETDATE())
', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�p��C�� RI ����]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�p��C�� RI ����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t date = GETDATE()

-- �C����
EXEC Monitor.dbo.�W���d�Ѳ��C����RI���� @t

-- �C��
 EXEC Monitor.dbo.�W���d�Ѳ��C��RI���� @t', 
		@database_name=N'DBMonitor', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�޳N���Ъ�]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�޳N���Ъ�', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.[MarketData_�޳N���Ъ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [HistoryVol To IT]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'HistoryVol To IT', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @tm DATE = dbmain.dbo.tradingdateadd(-1,(SELECT min(tradingdate) FROM dbmain.dbo.Tradingdate where datepart(yy,Tradingdate)=datepart(yy,getdate()) and datepart(mm,Tradingdate)=datepart(mm,getdate())))
Declare @t date =(select max(stadate) from TheoData.dbo.HistoryVol)
DELETE DB39.Trade_DB.dbo.HistoryVol WHERE Stadate <= @t
INSERT DB39.Trade_DB.dbo.HistoryVol
SELECT @t,Seccode,avg(Vol),''22''
  FROM [TheoData].[dbo].[HistoryVol]
 -- WHERE Stadate = @t AND Tag in( ''22'',''66'',''126'')
 WHERE Stadate = @tm AND Tag in( ''126'')
group by Seccode




/*
DECLARE @t DATE = (SELECT MAX(Stadate) FROM TheoData.dbo.HistoryVol)
DELETE DB39.Trade_DB.dbo.HistoryVol WHERE Stadate <= @t
INSERT DB39.Trade_DB.dbo.HistoryVol
SELECT @t,Seccode,avg(Vol),''22''
  FROM [TheoData].[dbo].[HistoryVol]
 -- WHERE Stadate = @t AND Tag in( ''22'',''66'',''126'')
 WHERE Stadate = @t AND Tag in( ''126'')
group by Seccode
*/
', 
		@database_name=N'TheoData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'��������', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160804, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'7be3b4cb-6140-43e7-9c09-4ba9f3256084'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [AS400�������]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:32 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AS400�������', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [��������O���פJ[Deallist_�������_����G��2018]]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'��������O���פJ[Deallist_�������_����G��2018]', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC DailyInsert.[dbo].[Trade_DB_AS400_�������]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'AS400��������O���פJ', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180829, 
		@active_end_date=99991231, 
		@active_start_time=153000, 
		@active_end_time=235959, 
		@schedule_uid=N'cf1ec228-75db-4b58-9254-17557ed3b255'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Cmoney�����s�C��]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Cmoney�����s�C��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailySFB]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailySFB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec [DailyInsert].dbo.[MDoutput_DailySFB] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_DailyOptionData]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_DailyOptionData', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.[dbo].[MarketData_DailyOptionData] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѤU��', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180410, 
		@active_end_date=99991231, 
		@active_start_time=140000, 
		@active_end_time=235959, 
		@schedule_uid=N'cd1b7e84-c608-4730-853f-88b144a3d9b7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѧ��W', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160415, 
		@active_end_date=99991231, 
		@active_start_time=93000, 
		@active_end_time=235959, 
		@schedule_uid=N'0ca8e131-1f80-4ced-8406-859151589d2e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [DBLog]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:33 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBLog', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBLog]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBLog', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DailyInsert_DBLog', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C5�����x�s', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170623, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'a1539559-2d97-489f-b367-db3459543b19'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [DBMain_DailyDefaultPortfolio]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBMain_DailyDefaultPortfolio', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�v�ҼЪ���TraderBE]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�v�ҼЪ���TraderBE', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t=getdate()
exec DailyInsert.dbo.[FrontdeskW_�v�ҼЪ���TraderBE] @t,''1''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_DailyDefaultPortfolio]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_DailyDefaultPortfolio', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.DBMain_DailyDefaultPortfolio ''''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѧ��W0855�A�]�@��', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160803, 
		@active_end_date=99991231, 
		@active_start_time=85500, 
		@active_end_time=235959, 
		@schedule_uid=N'6a3e8f36-27e2-4c23-a138-f41ea026aca5'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Emily_�C�u�׸��]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Emily_�C�u�׸��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�C�u�פJ ��ӥi�o�B�פ�ҡB�D�޾����O�ζO�v', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�D�޾����O�ζO�v�P����B�פ��]    Script Date: 2019/5/15 �W�� 09:23:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�D�޾����O�ζO�v�P����B�פ��', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [Dbmain].[dbo].[�D�޾����O�ζO�v�P����B�פ��]  ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Emily_�C�u�׸��', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180702, 
		@active_end_date=99991231, 
		@active_start_time=173000, 
		@active_end_time=235959, 
		@schedule_uid=N'0a9aff74-01d5-4121-9d03-c7c6ed976b46'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Emily_�C�u�׸��', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20181001, 
		@active_end_date=99991231, 
		@active_start_time=173000, 
		@active_end_time=235959, 
		@schedule_uid=N'1910ef2e-e7e9-48f6-ac66-63d09004cfe1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Emily_�C�u�׸��', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190102, 
		@active_end_date=99991231, 
		@active_start_time=173000, 
		@active_end_time=235959, 
		@schedule_uid=N'f21a0e3e-b0c6-4b90-b07b-ab185c756059'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Emily_�C�u�׸��', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190701, 
		@active_end_date=99991231, 
		@active_start_time=173000, 
		@active_end_time=235959, 
		@schedule_uid=N'151a272b-63c5-4645-b8f1-f81958c82927'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Enid�~����fClosingPrice_add_schedule]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Enid�~����fClosingPrice_add_schedule', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�~����fClosingPrice_add_schedule]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�~����fClosingPrice_add_schedule', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec.�~��ClosingPrice_add_schedule', 
		@database_name=N'Web', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�~����fClosingPrice_add_schedule', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=124, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170714, 
		@active_end_date=99991231, 
		@active_start_time=81500, 
		@active_end_time=235959, 
		@schedule_uid=N'b26de1a1-0431-45ee-9556-16a32dc46959'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [ETFOpenDelta�L��]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ETFOpenDelta�L��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OpenDelta�L��]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OpenDelta�L��', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.[PL_Inventory�l�Ӧ���L��] @t,''J1040071''
--exec DailyInsert.dbo.PL_Inventory_ETFOpenDelta @t,''1''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Ũ����]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Ũ����', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
exec [DailyInsert].[dbo].Credit_BondIndex @t
exec [DailyInsert].[dbo].Credit_BondIndex_AU @t
exec [DailyInsert].[dbo].Credit_BondIndex_BR @t
exec [DailyInsert].[dbo].Credit_BondIndex_CD @t
exec [DailyInsert].[dbo].Credit_BondIndex_CH @t
exec [DailyInsert].[dbo].Credit_BondIndex_DE @t
exec [DailyInsert].[dbo].Credit_BondIndex_FR @t
exec [DailyInsert].[dbo].Credit_BondIndex_GB @t
exec [DailyInsert].[dbo].Credit_BondIndex_GR @t
exec [DailyInsert].[dbo].Credit_BondIndex_ID @t
exec [DailyInsert].[dbo].Credit_BondIndex_IE @t
exec [DailyInsert].[dbo].Credit_BondIndex_IN @t
exec [DailyInsert].[dbo].Credit_BondIndex_IT @t
exec [DailyInsert].[dbo].Credit_BondIndex_JP @t
exec [DailyInsert].[dbo].Credit_BondIndex_KR @t
exec [DailyInsert].[dbo].Credit_BondIndex_PT @t
exec [DailyInsert].[dbo].Credit_BondIndex_RU @t
exec [DailyInsert].[dbo].Credit_BondIndex_SP @t
exec [DailyInsert].[dbo].Credit_BondIndex_US @t


exec [DailyInsert].[dbo].Credit_BondIndex @y
exec [DailyInsert].[dbo].Credit_BondIndex_AU @y
exec [DailyInsert].[dbo].Credit_BondIndex_BR @y
exec [DailyInsert].[dbo].Credit_BondIndex_CD @y
exec [DailyInsert].[dbo].Credit_BondIndex_CH @y
exec [DailyInsert].[dbo].Credit_BondIndex_DE @y
exec [DailyInsert].[dbo].Credit_BondIndex_FR @y
exec [DailyInsert].[dbo].Credit_BondIndex_GB @y
exec [DailyInsert].[dbo].Credit_BondIndex_GR @y
exec [DailyInsert].[dbo].Credit_BondIndex_ID @y
exec [DailyInsert].[dbo].Credit_BondIndex_IE @y
exec [DailyInsert].[dbo].Credit_BondIndex_IN @y
exec [DailyInsert].[dbo].Credit_BondIndex_IT @y
exec [DailyInsert].[dbo].Credit_BondIndex_JP @y
exec [DailyInsert].[dbo].Credit_BondIndex_KR @y
exec [DailyInsert].[dbo].Credit_BondIndex_PT @y
exec [DailyInsert].[dbo].Credit_BondIndex_RU @y
exec [DailyInsert].[dbo].Credit_BondIndex_SP @y
exec [DailyInsert].[dbo].Credit_BondIndex_US @y', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��W��', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161206, 
		@active_end_date=99991231, 
		@active_start_time=100500, 
		@active_end_time=235959, 
		@schedule_uid=N'c16947dd-416e-47f2-8d88-602d217dfba1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Intraday���R��]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Intraday���R��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�L���Y�ɬ����R���All_����Cursor]    Script Date: 2019/5/15 �W�� 09:23:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�L���Y�ɬ����R���All_����Cursor', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec PL.dbo.�L���Y�ɬ����R���All_����Cursor', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [z_�v�����˫���]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'z_�v�����˫���', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)


exec DailyInsert.dbo.z_�v�����˫��� @t

declare @y datetime set @y=(select max(stadate) from pl.dbo.inventory)
exec [DailyInsert].dbo.[MDoutput_DailySFB]  @y', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'1400���L��]�����Ъ�', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170608, 
		@active_end_date=99991231, 
		@active_start_time=140000, 
		@active_end_time=235959, 
		@schedule_uid=N'2b77aca5-dfbe-4d0a-bb59-dbfb0bbc53f3'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�L���C10����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170605, 
		@active_end_date=99991231, 
		@active_start_time=90300, 
		@active_end_time=134359, 
		@schedule_uid=N'94d245cb-94f1-4ae6-bb3d-faf9b3f1afcd'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [IT_�M�L]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'IT_�M�L', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Report �M��', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1.YTA Report�M�L]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1.YTA Report�M�L', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from tblYTA_Report_Done;

Delete from tblYTA_Report_Order;

Delete from tblYTA_Report_Stock;', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'YTA Report �M�L', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20161014, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'ed603a66-c962-442d-9b23-49aa2734b50a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [IT����_Log]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'IT����_Log', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Alan-����]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Alan-����', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--���R����
Insert into [Web].[dbo].[DataDailyCheckLog_01]
SELECT a.ChkType,A.ChkNo,A.ChkName,A.ChkDesc,'''',A.DataPIC,A.CheckDate,A.ChkExecTime,A.ChkPlanTime,
CASE 
WHEN B.Txn_Date=CONVERT(varchar,GETDATE(),112) AND B.CNT>0 THEN ''OK''
ELSE ''����'' END AS ChkStatus,
B.Txn_Date,B.CNT,A.Ret_Memo
FROM (
select '''' as ChkType,'''' as ChkNo,''����ҷ��R����'' AS ChkName ,'''' as ChkDesc,
''Alan'' as DataPIC, CONVERT(varchar,GETDATE(),112) as CheckDate, GETDATE() AS ChkExecTime, ''07:30'' as ChkPlanTime, '''' as ChkStatus,
'''' as Ret_DataDate, '''' as Ret_DataCnt, '''' Ret_Memo
) as A
LEFT JOIN (
select ''����ҷ��R����'' AS Name,[Txn_Date],count(*) AS CNT
FROM [Trade_DB].[dbo].[tblDayTrade]
where [Txn_Date]=CONVERT(varchar,GETDATE(),112)
group by [Txn_Date]
) AS B
ON A.ChkName=b.Name

--���i�����R
insert into [Web].[dbo].[DataDailyCheckLog_01]
SELECT a.ChkType,A.ChkNo,A.ChkName,A.ChkDesc,'''',A.DataPIC,A.CheckDate,A.ChkExecTime,A.ChkPlanTime,
CASE 
WHEN B.Txn_Date=CONVERT(varchar,GETDATE(),112) AND B.CNT>0 THEN ''OK''
ELSE ''����'' END AS ChkStatus,
B.Txn_Date,B.CNT,A.Ret_Memo
FROM (
select '''' as ChkType,'''' as ChkNo,''���i�����R'' AS ChkName ,'''' as ChkDesc,
''Alan'' as DataPIC, CONVERT(varchar,GETDATE(),112) as CheckDate, GETDATE() AS ChkExecTime, ''07:30'' as ChkPlanTime, '''' as ChkStatus,
'''' as Ret_DataDate, '''' as Ret_DataCnt, '''' Ret_Memo
) as A
LEFT JOIN (
select ''���i�����R'' AS Name,[Txn_Date],count(*) AS CNT
FROM [Trade_DB].[dbo].[tblDayTrade]
where [Txn_Date]=CONVERT(varchar,GETDATE(),112)
AND [���i�����R]<>''''
group by [Txn_Date]
) AS B
ON A.ChkName=b.Name

--�ѳs�y��
insert into [Web].[dbo].[DataDailyCheckLog_01]
SELECT a.ChkType,A.ChkNo,A.ChkName+''_''+CONVERT(varchar,B.[TraderName]),A.ChkDesc,'''',A.DataPIC,A.CheckDate,A.ChkExecTime,A.ChkPlanTime,
CASE 
WHEN B.CNT>0 THEN ''OK''
ELSE ''����'' END AS ChkStatus,
B.[TraderName],B.CNT,A.Ret_Memo
FROM (
select '''' as ChkType,'''' as ChkNo,''������y���v�Ҽ�'' AS ChkName ,'''' as ChkDesc,
''Alan'' as DataPIC, CONVERT(varchar,GETDATE(),112) as CheckDate, GETDATE() AS ChkExecTime, ''08:00'' as ChkPlanTime, '''' as ChkStatus,
'''' as Ret_DataDate, '''' as Ret_DataCnt, '''' Ret_Memo
) as A
LEFT JOIN (
select ''������y���v�Ҽ�'' AS Name,
[TraderName],COUNT(*) AS CNT
FROM [Trade_DB].[dbo].[tblWrrmm]
WHERE [PricingVol] IS NOT NULL
GROUP BY [TraderName]
) AS B
ON A.ChkName=b.Name

--�e��w�s
insert into [Web].[dbo].[DataDailyCheckLog_01]
SELECT a.ChkType,A.ChkNo,A.ChkName+''_''+CONVERT(varchar,B.[�N��]),A.ChkDesc,'''',A.DataPIC,A.CheckDate,A.ChkExecTime,A.ChkPlanTime,
CASE 
WHEN B.CNT>0 THEN ''OK''
ELSE ''����'' END AS ChkStatus,
B.[�N��],B.CNT,A.Ret_Memo
FROM (
select '''' as ChkType,'''' as ChkNo,''�e��w�s�ɼ�'' AS ChkName ,'''' as ChkDesc,
''Alan'' as DataPIC, CONVERT(varchar,GETDATE(),112) as CheckDate, GETDATE() AS ChkExecTime, ''08:00'' as ChkPlanTime, '''' as ChkStatus,
'''' as Ret_DataDate, '''' as Ret_DataCnt, '''' Ret_Memo
) as A
LEFT JOIN (
select ''�e��w�s�ɼ�'' AS Name,
[�N��],COUNT(*) AS CNT
FROM [Trade_DB].[dbo].[tblPosExt]
WHERE [�i�ʥΪѼ�]>0
GROUP BY [�N��]
) AS B
ON A.ChkName=b.Name
--

--�������Ũ�w�s����
INSERT INTO [Trade_DB].[dbo].[tblPrevPL_Bond]
SELECT [Date],''Derrick'',[TraderId],[ProductId],[Inv]*1000,0,''0'',[Inv]*1000
FROM [DB39].[Trade_DB].[dbo].[tblSTradeInv]
where [Date] in (select max([Date]) as DD FROM [DB39].[Trade_DB].[dbo].[tblSTradeInv])
AND [TraderId]=''604''', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [albert����]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'albert����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
-- (1) �W���C�馬�L�污	����ҩx���污�����۰��^������	������������e�@�������

INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])

select '''' ChkType,1 ChkNo,''�W���C�馬�L�污'' ChkName,''����ҩx���污�����۰��^������'' ChkDesc,
''������������e�@�������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime, ''08:20:00'' ChkPlanTime, 
case TransDate
when 
( select Tradingdate FROM [DBMain].[dbo].[Tradingdate] where ser = 
  ( select ser-1 FROM [DBMain].[dbo].[Tradingdate] where Tradingdate = (SELECT CONVERT(varchar(10), GETDATE(),111)  ) 
) )
then ''OK'' else ''Fail'' end ChkStatus,
[TransDate] Ret_DataDate, count([TransDate]) Ret_DataCnt, '''' Ret_Memo 
FROM [Web].[dbo].[Web_001A] where TransDate = ( select max(TransDate) from [Web].[dbo].[Web_001A] ) group by TransDate


-- (2) �W�d�C�馬�L�污	�d�R���ߩx���污�����۰��^������	������������e�@�������

INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])

select '''' ChkType,2 ChkNo,''�W�d�C�馬�L�污'' ChkName,''�d�R���ߩx���污�����۰��^������'' ChkDesc,
''������������e�@�������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime, ''08:20:00'' ChkPlanTime, 
case TransDate
when 
( select Tradingdate FROM [DBMain].[dbo].[Tradingdate] where ser = 
  ( select ser-1 FROM [DBMain].[dbo].[Tradingdate] where Tradingdate = (SELECT CONVERT(varchar(10), GETDATE(),111)  ) 
) )
then ''OK'' else ''Fail'' end ChkStatus,
[TransDate] Ret_DataDate, count([TransDate]) Ret_DataCnt, '''' Ret_Memo 
FROM [Web].[dbo].[Web_002A] where TransDate = ( select max(TransDate) from [Web].[dbo].[Web_002A] ) group by TransDate


-- (3) 41 Web �W������i�ɨ��X�Ѽ�	����ҩx������i�ɨ��X�ѼƦ۰��^������	�����������������

INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])
select '''' ChkType,3 ChkNo,''�W������i�ɨ��X�Ѽ�'' ChkName,''����ҩx������i�ɨ��X�ѼƦ۰��^������'' ChkDesc,
''�����������������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime, ''08:20:00'' ChkPlanTime,
case DataDate
when 
(SELECT CONVERT(varchar(10), GETDATE(),112) )
then ''OK'' else ''Fail'' end ChkStatus,
[DataDate] Ret_DataDate, count([DataDate]) Ret_DataCnt,'''' Ret_Memo 
FROM [Web].[dbo].[Web_021] where DataDate = ( select max(DataDate) from [Web].[dbo].[Web_021] ) and MarketType=1  group by DataDate


-- (4) 41 Web �W�d����i�ɨ��X�Ѽ�	����ҩx������i�ɨ��X�ѼƦ۰��^������	�����������������


INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])
select '''' ChkType,4 ChkNo,''�W�d����i�ɨ��X�Ѽ�'' ChkName,''����ҩx������i�ɨ��X�ѼƦ۰��^������'' ChkDesc,
''�����������������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime, ''08:20:00'' ChkPlanTime,
case DataDate
when 
(SELECT CONVERT(varchar(10), GETDATE(),112) )
then ''OK'' else ''Fail'' end ChkStatus,
[DataDate] Ret_DataDate, count([DataDate]) Ret_DataCnt,'''' Ret_Memo 
FROM [Web].[dbo].[Web_021] where DataDate = ( select max(DataDate) from [Web].[dbo].[Web_021] ) and MarketType=2  group by DataDate


-- (5) 41 Web �W���H���B�׺ި�	����� �H���B���`�q�ި�l�B�� �۰��^������	������������e�@�������

INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])
select '''' ChkType,5 ChkNo,''�W���H���B�׺ި�'' ChkName,''����� �H���B���`�q�ި�l�B�� �۰��^������'' ChkDesc,
''������������e�@�������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime, ''08:20:00'' ChkPlanTime,
case DataDate
when 
( select Tradingdate FROM [DBMain].[dbo].[Tradingdate] where ser = 
  ( select ser-1 FROM [DBMain].[dbo].[Tradingdate] where Tradingdate = (SELECT CONVERT(varchar(10), GETDATE(),111)  ) 
) )
then ''OK'' else ''Fail'' end ChkStatus,
[DataDate] Ret_DataDate, count([DataDate]) Ret_DataCnt,'''' Ret_Memo 
FROM [Web].[dbo].[Web_022] where DataDate = ( select max(DataDate) from [Web].[dbo].[Web_022] ) and MarketType=1  group by DataDate



-- (6) 41 Web �W�d�H���B�׺ި�	 (�W�d) �Ĩ�ɨ��X�l�B �۰��^������	������������e�@�������

INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])

select '''' ChkType,6 ChkNo,''�W�d�H���B�׺ި�'' ChkName,''(�W�d) �Ĩ�ɨ��X�l�B �۰��^������'' ChkDesc,
''������������e�@�������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime, ''08:20:00'' ChkPlanTime, 
case DataDate
when 
( select Tradingdate FROM [DBMain].[dbo].[Tradingdate] where ser = 
  ( select ser-1 FROM [DBMain].[dbo].[Tradingdate] where Tradingdate = (SELECT CONVERT(varchar(10), GETDATE(),111)  ) 
) )
then ''OK'' else ''Fail'' end ChkStatus,
[DataDate] Ret_DataDate, count([DataDate]) Ret_DataCnt, '''' Ret_Memo 
FROM [Web].[dbo].[Web_022] where DataDate = ( select max(DataDate) from [Web].[dbo].[Web_022] ) and MarketType=2  group by DataDate


-- (7) 43 Tick ����污����

INSERT INTO [dbo].[DataDailyCheckLog_01]
([ChkType],[ChkNo],[ChkName],[ChkDesc],[VerifyHint],[DataPIC],[CheckDate],[ChkExecTime],[ChkPlanTime],[ChkStatus],[Ret_DataDate],[Ret_DataCnt],[Ret_Memo])
select '''' ChkType,7 ChkNo,''����Ҧ污�ѦҰ��(����)'' ChkName,''����ҩx���污�����۰��^������'' ChkDesc,
''�����������������'' VerifyHint,''Albert'' DataPIC, (SELECT CONVERT(varchar(10), GETDATE(),112) ) CheckDate, 
GETDATE() ChkExecTime,''08:45:00'' ChkPlanTime, 
case In_Time
when (SELECT CONVERT(varchar(10), GETDATE(),112) ) then ''OK'' else ''Fail'' end ChkStatus,
[In_Time] Ret_DataDate, count([In_Time]) Ret_DataCnt,'''' Ret_Memo FROM 
[DB2].[Tick].[dbo].[tbl_Day_MinMax]
where In_Time = ( select max(In_Time) from [DB2].[Tick].[dbo].[tbl_Day_MinMax] ) group by In_Time', 
		@database_name=N'Web', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [HdegeTradingCheck]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'HdegeTradingCheck', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-------------------------------------------------tblDailyStockInfo-------------------------------------------------
INSERT INTO [Web].[dbo].[DataDailyCheckLog_01]
           ([ChkType]
           ,[ChkNo]
           ,[ChkName]
           ,[ChkDesc]
           ,[VerifyHint]
           ,[DataPIC]
           ,[CheckDate]
           ,[ChkExecTime]
           ,[ChkPlanTime]
           ,[ChkStatus]
           ,[Ret_DataDate]
           ,[Ret_DataCnt]
           ,[Ret_Memo])
     VALUES
           (
	        '''',
			0,
            ''tblDailyStockInfo'',
	        '''',
            '''',
            ''Johnny'',			
	    CONVERT(varchar, getdate(),112),
            getdate(),
	    getdate(),
	    (SELECT CASE 
 	    WHEN  (select count(*) from [Trade_DB].[dbo].[tblDailyStockInfo] where DATEDIFF(DAY, [DayDate], getdate()) = 0) <> 0 THEN ''1''
 	    ELSE ''0'' END),
             CONVERT(varchar,(select top 1 [DayDate] from [Trade_DB].[dbo].[tblDailyStockInfo] where DATEDIFF(DAY, [DayDate], getdate()) = 0),112),
	    (select count(*) from [Trade_DB].[dbo].[tblDailyStockInfo] where DATEDIFF(DAY, [DayDate], getdate()) = 0),
            '''')

-------------------------------------------------tblDailyFutures-------------------------------------------------
INSERT INTO [Web].[dbo].[DataDailyCheckLog_01]
           ([ChkType]
           ,[ChkNo]
           ,[ChkName]
           ,[ChkDesc]
           ,[VerifyHint]
           ,[DataPIC]
           ,[CheckDate]
           ,[ChkExecTime]
           ,[ChkPlanTime]
           ,[ChkStatus]
           ,[Ret_DataDate]
           ,[Ret_DataCnt]
           ,[Ret_Memo])
     VALUES
           (
	        '''',
			0,
            ''tblDailyFutures'',
	        '''',
            '''',
            ''Johnny'',			
	   CONVERT(varchar, getdate(),112),
            getdate(),
	    getdate(),
	    (SELECT CASE 
 	    WHEN  (select count(*) from [Trade_DB].[dbo].[tblDailyFutures] where DATEDIFF(DAY, [DayDate], getdate()) = 0) <> 0 THEN ''1''
 	    ELSE ''0'' END),
             CONVERT(varchar,(select top 1 [DayDate] from [Trade_DB].[dbo].[tblDailyFutures] where DATEDIFF(DAY, [DayDate], getdate()) = 0),112),
	    (select count(*) from [Trade_DB].[dbo].[tblDailyFutures] where DATEDIFF(DAY, [DayDate], getdate()) = 0),
            '''')

-------------------------------------------------tblDailyWarrantInfo-------------------------------------------------
INSERT INTO [Web].[dbo].[DataDailyCheckLog_01]
           ([ChkType]
           ,[ChkNo]
           ,[ChkName]
           ,[ChkDesc]
           ,[VerifyHint]
           ,[DataPIC]
           ,[CheckDate]
           ,[ChkExecTime]
           ,[ChkPlanTime]
           ,[ChkStatus]
           ,[Ret_DataDate]
           ,[Ret_DataCnt]
           ,[Ret_Memo])
     VALUES
           (
	        '''',
			0,
            ''tblDailyWarrantInfo'',
	        '''',
            '''',
            ''Johnny'',			
	   CONVERT(varchar, getdate(),112),
            getdate(),
	    getdate(),
	    (SELECT CASE 
 	    WHEN  (select count(*) from [Trade_DB].[dbo].[tblDailyWarrantInfo] where DATEDIFF(DAY, [DayDate], getdate()) = 0) <> 0 THEN ''1''
 	    ELSE ''0'' END),
             CONVERT(varchar,(select top 1 [DayDate] from [Trade_DB].[dbo].[tblDailyWarrantInfo] where DATEDIFF(DAY, [DayDate], getdate()) = 0),112),
	    (select count(*) from [Trade_DB].[dbo].[tblDailyWarrantInfo] where DATEDIFF(DAY, [DayDate], getdate()) = 0),
            '''')

-------------------------------------------------tblPrevPL-------------------------------------------------
INSERT INTO [Web].[dbo].[DataDailyCheckLog_01]
           ([ChkType]
           ,[ChkNo]
           ,[ChkName]
           ,[ChkDesc]
           ,[VerifyHint]
           ,[DataPIC]
           ,[CheckDate]
           ,[ChkExecTime]
           ,[ChkPlanTime]
           ,[ChkStatus]
           ,[Ret_DataDate]
           ,[Ret_DataCnt]
           ,[Ret_Memo])
     VALUES
           (
	        '''',
			0,
            ''tblPrevPL'',
	        '''',
            '''',
            ''Johnny'',			
	  CONVERT(varchar, getdate(),112),
            getdate(),
	    getdate(),
	    (SELECT CASE 
 	    WHEN  (select count(*) from [Trade_DB].[dbo].[tblPrevPL]) <> 0 THEN ''1''
 	    ELSE ''0'' END),
             CONVERT(varchar,(select top 1 [TXN_DT] from [Trade_DB].[dbo].[tblPrevPL]),112),
	    (select count(*) from [Trade_DB].[dbo].[tblPrevPL]),
            '''')

-------------------------------------------------tblUserWarrantUnderlying-------------------------------------------------
INSERT INTO [Web].[dbo].[DataDailyCheckLog_01]
           ([ChkType]
           ,[ChkNo]
           ,[ChkName]
           ,[ChkDesc]
           ,[VerifyHint]
           ,[DataPIC]
           ,[CheckDate]
           ,[ChkExecTime]
           ,[ChkPlanTime]
           ,[ChkStatus]
           ,[Ret_DataDate]
           ,[Ret_DataCnt]
           ,[Ret_Memo])
     VALUES
           (
	        '''',
			0,
            ''tblUserWarrantUnderlying'',
	        '''',
            '''',
            ''Johnny'',			
	   CONVERT(varchar, getdate(),112),
            getdate(),
	    getdate(),
	    (SELECT CASE 
 	    WHEN  (select count(*) from [Trade_DB].[dbo].[tblUserWarrantUnderlying]) <> 0 THEN ''1''
 	    ELSE ''0'' END),
            '''',
	    (select count(*) from [Trade_DB].[dbo].[tblUserWarrantUnderlying]),
            '''')', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����^����-Y]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����^����-Y', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE from [Trade_DB].[dbo].[tblOrderReport_Y]
where convert(varchar,[TxDate],112) = convert(varchar,GETDATE(),112)

INSERT INTO [Trade_DB].[dbo].[tblOrderReport_Y]
SELECT GETDATE() AS TxDate,*
FROM [Trade_DB].[dbo].[tblOrderReport]
ORDER BY [TransactTime]

Delete FROM [Trade_DB].[dbo].[tblOrderReport_Y]
where CONVERT(varchar,[TxDate],112) not in (SELECT CONVERT(varchar,[Tradingdate],112) as DT
FROM [DBMain].[dbo].[Tradingdate]
where substring(CONVERT(varchar,[Tradingdate],112),1,6)=substring(CONVERT(varchar,GETDATE(),112),1,6)
)


', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'0825', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150924, 
		@active_end_date=99991231, 
		@active_start_time=82500, 
		@active_end_time=235959, 
		@schedule_uid=N'9b9db8fc-98f5-4456-b686-784d104b6b29'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'alan', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150911, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959, 
		@schedule_uid=N'132b5bea-e0b6-4e1f-a016-19465292f290'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�U�Ȱ���', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150921, 
		@active_end_date=99991231, 
		@active_start_time=150000, 
		@active_end_time=235959, 
		@schedule_uid=N'dac098ab-07b9-4f9b-aba6-b3f96579b392'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [May3_Intraday_Pre]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:36 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'May3_Intraday_Pre', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_InventoryMay4_Pre]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_InventoryMay4_Pre', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.PL_InventoryMay4_Pre', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Inventory_Pre]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Inventory_Pre', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.[PL_InventoryAlex_Pre]
exec [DailyInsert].[dbo].[PL_Inventory����G�սL��_Pre]
exec [DailyInsert].[dbo].[PL_InventoryDerrick_pre]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [db39Inventory������]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'db39Inventory������', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/****** SSMS �� SelectTopNRows �R�O�����O�X  ******/
delete db39.[Trade_DB].[dbo].[Inventory������]
insert db39.[Trade_DB].[dbo].[Inventory������]
SELECT [TxDate]
      ,[TxTime]
      ,[Portfolio]
      ,[StockID]
      ,[Type]
      ,[B]
      ,[S]
      ,[DealVolume]
  FROM [PL].[dbo].[InventoryMay4_������pre]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_InventoryMay4_�L�a�hVol]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_InventoryMay4_�L�a�hVol', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.PL_InventoryMay4_�L�a�hVol', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyInsert_MDBreakList]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyInsert_MDBreakList', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dailyInsert.[dbo].[DailyInsert_MDBreakList]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Ũ�ETFBD]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Ũ�ETFBD', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec pl.dbo.�Ũ�ETFBD_�Ũ鳡
exec pl.dbo.�Ũ�ETFBD_�l�ӳ�

declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec [DailyInsert].dbo.[MDoutput_DailySFB] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Strategy_�L��TE]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Strategy_�L��TE', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec PL.dbo.KarenMOM�C��}���p_�L����_write', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [InventoryMay4_�ۮaVolGap]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'InventoryMay4_�ۮaVolGap', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.PL_InventoryMay4_�ۮaVolGap', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'0810ForJtin', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190312, 
		@active_end_date=99991231, 
		@active_start_time=81000, 
		@active_end_time=235959, 
		@schedule_uid=N'376e7bd2-64b4-44db-bbdf-e5322d8e70b0'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�L���C40����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=4, 
		@freq_subday_interval=40, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151103, 
		@active_end_date=99991231, 
		@active_start_time=74700, 
		@active_end_time=94700, 
		@schedule_uid=N'60f58fa1-efc8-4cdd-969d-d0fc389ea7ab'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Nancy�C��D�޳���]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:37 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Nancy�C��D�޳���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=29, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SharpeRatio]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SharpeRatio', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec testpa.dbo.�D�޳���_SharpeRatioMTM��ѧV�O20�� @t
exec testpa.dbo.�D�޳���_SharpeRatioMTM��ѧV�O5�� @t
exec testpa.dbo.�D�޳���_SharpeRatio����MTM��ѧV�O20�� @t
exec testpa.dbo.�D�޳���_SharpeRatio����MTM��ѧV�O5�� @t
exec testpa.dbo.�D�޳���_SharpeRatio����MTM��ѧV�O10�� @t

exec pl.dbo.�D�޳���_SharpeRatio����MTM��ѧV�O5�� @t
exec pl.dbo.�D�޳���_SharpeRatio����MTM��ѧV�O10�� @t
exec pl.dbo.�D�޳���_SharpeRatio����MTM��ѧV�O20�� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�o��H�����p��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�o��H�����p��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec testpa.[dbo].[�o��H�����p��_Nancy] @t
exec [TestPA].[dbo].[�o��H�����p��_Nancy_New] @t
exec testpa.[dbo].[�o��H�����p��_Nancy_���Ъ������_����í�w] @t
exec testpa.[dbo].[�o��H�����p��_Nancy_���Ъ������1_����í�w] @t
exec [testpa].[dbo].[�o��H�����p��_Nancy_���Ъ������_���t�j�p] @t
exec [testpa].[dbo].[�o��H�����p��_Nancy_���Ъ������_�����ƶq] @t
exec [testpa].[dbo].[�o��H�����p��_Nancy_���Ъ������_�g��v] @t
exec testpa.dbo.�o��H����_����í�w20�� @t
exec testpa.dbo.�C��o��H�����`�� @t
--exec testpa.dbo.�o��H����_�u�����w�� @t
exec testpa.dbo.�o��H����_�u�����w��_�̷s�@��Data @t
exec testpa.dbo.[�o��H�����p��_����í�w����new] @t
exec testpa.[dbo].[�o��H�����p��_���t�j�p����new] @t
exec testpa.[dbo].[�o��H�����p��_�����ƶq����new] @t
exec testpa.[dbo].[�o��H�����p��_�g��vnew] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�o��H�����p�⤽�|��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�o��H�����p�⤽�|��', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=dbmain.dbo.tradingdateadd(-1,(select max(stadate) from pl.dbo.inventory))

exec testpa.dbo.[�o��H�����p��_���|��] @t
exec testpa.[dbo].[�o��H�����p��_���|��_New] @t
exec testpa.dbo.�C��o��H�����`��_���|�� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�o��H�����p��Remix��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�o��H�����p��Remix��', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [TestPA].[dbo].[�o��H�����p��_Remix��_New] @t

exec testpa.dbo.[�C��o��H�����`��_Remix��] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C��_CB�污��z]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C��_CB�污��z', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete CB.[dbo].[CB�L���������]
where ��� = (select max(���) from cmoney.dbo.[�C�馬�L��T73])

/*
insert CB.[dbo].[CB�L���������]
select distinct *
from db2.[TickBackup].[dbo].[CB�L���������_tmp]
where ��� = (select max(���) from cmoney.dbo.[�C�馬�L��T73])
and dbmain.dbo. �P�_���O(�ӫ~�N��) = ''CB'' 
order by ���
*/
exec DailyInsert.[dbo].[CB_�C���JCB�C��̫�@��IV]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [0050�P����15������ƾ�z]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'0050�P����15������ƾ�z', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t =(select max(���) from cmoney.dbo.[�C�馬�L��T73])
-- exec testpa.dbo.[Davydata20160203] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_�v�ҽL��������ptab]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_�v�ҽL��������ptab', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Z_�v�ҽL��������ptab @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [VaR_MTM_avg]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'VaR_MTM_avg', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.[PL_VaR_MTM_avg] ''''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CBIndex]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CBIndex', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

  exec testpa.dbo.CB_cbindex_Randon1 @t
  exec testpa.dbo.CB_cbindex_Randon2 @t
  exec testpa.dbo.CB_cbindex_Randon3 @t
  exec testpa.dbo.CB_cbindex_Randon4 @t
  exec testpa.dbo.CB_cbindex_Randon5 @t
  exec testpa.dbo.CB_cbindex_Randon6 @t
  exec testpa.dbo.CB_cbindex_Randon7 @t
  exec testpa.dbo.CB_cbindex_Randon8 @t
  exec testpa.dbo.CB_cbindex_Randon9 @t
  exec testpa.dbo.CB_cbindex_Randon10 @t
  exec testpa.dbo.CB_cbindex_Randon11 @t
  exec testpa.dbo.CB_cbindex_Randon12 @t
  exec testpa.dbo.CB_cbindex_Randon13 @t

  exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�� @t
 exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����G @t
exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業�����Gtop100] @t

  exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業��_��g @t
 exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����G_��g @t
  exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業��_��g25�i @t
 exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����G_��g25�i @t
  exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業��_��g35�i @t
 exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����G_��g35�i @t

  exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業��old @t
 exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����Gold @t
exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業�����Gtop100old] @t


exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業��_�]������] @t
exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業�����Gtop100�]������] @t


exec DailyInsert.dbo.CB_CB�����~����q�g�z�� @t
exec [DailyInsert].dbo.[CB_CB�z�׻��PIMPVol] @t

--20181114�Ȯɵ���
exec frontdeskw.dbo.Proc_QD_May_CBIndex_20180206



', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CBIndexUTEtable]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CBIndexUTEtable', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec frontdeskw.dbo.CBIndexIUtable @t

delete FrontDeskW.dbo.CBIndexUTEtable
insert FrontDeskW.dbo.CBIndexUTEtable
select Txdate, TECBIndex_L, TECBU_L, TECBIndex_IL, TECBU_IL, �����qPL, �L���i�X, �������, �z��PL, �|�pPL, [�z��PL(CBIX+S)]
from FrontDeskW.dbo.CBIndexUTE(200000000,100000000,0.25,''2018/11/1'',''2019/1/30'')
--2019/2/1�令4E/0E/0.1
insert FrontDeskW.dbo.CBIndexUTEtable
select Txdate, TECBIndex_L, TECBU_L, TECBIndex_IL, TECBU_IL, �����qPL, �L���i�X, �������, �z��PL, �|�pPL, [�z��PL(CBIX+S)]
from FrontDeskW.dbo.CBIndexUTE(400000000,0,0.1,''2019/2/1'',@t)', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�o��Ъ�_Vol_�z��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�o��Ъ�_Vol_�z��', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec  [DailyInsert].[dbo].[FrontDeskW_�o��Ъ�_Vol_�z��]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ϥθ�����S�v_�e�饫��_Table]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ϥθ�����S�v_�e�饫��_Table', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete pl.dbo.[�ϥθ�����S�v_�e�饫��_Table]
insert pl.dbo.[�ϥθ�����S�v_�e�饫��_Table]
select TxDate, Dept, Portfolio, Acc, NetPL, �����ϥθ��, �ϥθ�����S�v
from pl.dbo.[�ϥθ�����S�v_�e�饫��]((select max(stadate) from pl.dbo.inventory))

declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec frontdeskw.dbo.�U�����ϥθ���P���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CBIndex������_Table]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CBIndex������_Table', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete PL.[dbo].[CBIndex������_Table]
insert PL.[dbo].[CBIndex������_Table]
select *
from PL.[dbo].[CBIndex������]()', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AS400_New]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AS400_New', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime 

set @t = (select max(���) from cmoney.dbo.�C�馬�L��T73)

exec [DailyInsert].dbo.PL_�|�p_400_New @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_RSMA]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_RSMA', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.[Marketdata_RSMA] @t
exec Dailyinsert.dbo.FrontDeskW_ROIC
exec DailyInsert.dbo.FrontDeskW_AltmanZScore
exec DailyInsert.dbo.FrontDeskW_BeneishMScore
exec DailyInsert.dbo.FrontDeskW_SloanRatio', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Frontdeskw_��H���R�W�W��_10_30]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Frontdeskw_��H���R�W�W��_10_30', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.[Frontdeskw_��H���R�W�W��_10_30] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Z��_���쥫�ȻP�l�q���p]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Z��_���쥫�ȻP�l�q���p', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec pro.dbo.�Z��_400���ѳ��쥫�ȻP�l�q @t
exec pro.dbo.�Z��_400���ѳ��쥫�ȻP�l�q2 @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���Base����e��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���Base����e��', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
 exec DailyInsert.dbo.[Pro_���Base����e��] @t
  exec DailyInsert.dbo.[Pro_���Base����e����Ъ�] @t
  exec DailyInsert.dbo.[Pro_���Base����TV�e����Ъ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [������L���ĩ�sheet1Adj]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'������L���ĩ�sheet1Adj', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec pro.dbo.[������L���ĩ�_sheet1Adj] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�W���d�Ѳ��C��DMI]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�W���d�Ѳ��C��DMI', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.[dbo].[Marketdata_�W���d�Ѳ��C��DMI] @t
exec DailyInsert.dbo.Z_�v�����˫���_DMI @t
exec pl.dbo.[AlexP30BD���Ъ�����]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҵo��Ъ�PxVx����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҵo��Ъ�PxVx����', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
 exec DailyInsert.dbo.FrontDeskW_�v�ҵo��Ъ�PxVx���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ұ���q��Tick��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ұ���q��Tick��', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.[dbo].[FrontDeskW_�v�ұ���q��Tick��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C��markupr���B]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C��markupr���B', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.Z_�C��markupr���B @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [KMV]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'KMV', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec credit.dbo.DailyEDFInsert @t

exec DailyInsert.[dbo].[Credit_DailyEDF_���y�k] @t
--exec DailyInsert.[dbo].[Credit_DailyEDF_Multiple] @t

exec DailyInsert.[dbo].[Credit_TermStructure_IRS_GBbootstrap]  @t
exec [DailyInsert].dbo.[CB_CBImpVolByKMV] @t

exec DailyInsert.dbo.[MDoutput_Php_CBBookRet]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LU����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LU����', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.[FrontDeskW_LU���ƨC��W��] @t
exec DailyInsert.dbo.[FrontDeskW_LU����] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�Ҧ�����B����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�Ҧ�����B����', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec FrontDeskW.dbo.�v�Ҧ�����B���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�U����PR��m]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�U����PR��m', 
		@step_id=28, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.[Z_�U����PR] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [18_�C��RPRS_����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'18_�C��RPRS_����', 
		@step_id=29, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t=GETDATE()
exec [DailyInsert].dbo.PL_�C��Ũ鳡RPRS @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C��Ů����J&�������_���Ť��q�ť��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C��Ů����J&�������_���Ť��q�ť��', 
		@step_id=30, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--declare @t date set @t=GETDATE()
--exec [DailyInsert].dbo.[PL_�C��Ů����J_���Ť��q�ť��] @t
--exec [DailyInsert].dbo.[PL_�C��������_���Ť��q�ť��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Nancy�D�޳���', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151120, 
		@active_end_date=99991231, 
		@active_start_time=170000, 
		@active_end_time=235959, 
		@schedule_uid=N'09b0f6b0-699f-45ff-8e9a-69faee5d1348'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�A�]�@��', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161102, 
		@active_end_date=99991231, 
		@active_start_time=180500, 
		@active_end_time=235959, 
		@schedule_uid=N'01215e6d-a50b-4ad4-866a-cd2da52d7cc0'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�b�]�@��', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160512, 
		@active_end_date=99991231, 
		@active_start_time=193000, 
		@active_end_time=235959, 
		@schedule_uid=N'cd92bdd5-f66e-4131-948e-6b3d626505a6'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Nancy�L�eIT����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Nancy�L�eIT����', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB2_Tick_tbl_Day_MinMax]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB2_Tick_tbl_Day_MinMax', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DB2_Tick_tbl_Day_MinMax', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB_tblWrrmm]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB_tblWrrmm', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.[Trade_DB_tblWrrmm]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�e��w�s_������]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�e��w�s_������', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec [DailyInsert].dbo.Trade_DB_tblPrevPL_QuantTrade
--exec [DailyInsert].dbo.Trade_DB_tblPrevPL_FutOptTrade
--exec [DailyInsert].dbo.Trade_DB_tblPrevPL_Bond
--�p�W��2017/5/19����', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB_tblOrderReport_History]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB_tblOrderReport_History', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Trade_DB_tblOrderReport_History', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tbl_Tick_Today_snapshot�M��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tbl_Tick_Today_snapshot�M��', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'truncate table tick.[dbo].[tbl_Tick_Today_snapshot]
truncate table [Tick].[dbo].[tbl_Snap_Today_QV]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyInsert_MDBreakList]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyInsert_MDBreakList', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dailyInsert.[dbo].[DailyInsert_MDBreakList]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_tblWarrMakerParam]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_tblWarrMakerParam', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DBMain_tblWarrMakerParam ''''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѧ��W', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151228, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959, 
		@schedule_uid=N'1fec1318-f96d-4aff-86ef-4e1a4052a77d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Nancy�L�e�]���]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Nancy�L�e�]���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ETFwebtse���ʶR�^�M����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ETFwebtse���ʶR�^�M����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
--exec testpa.dbo.ETFwebtsecheck @t,''0050''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ETF���ʶR�^�M��[�J����W��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ETF���ʶR�^�M��[�J����W��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

--exec testpa.dbo.ETF���ʶR�^�M��[�J����W�� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [������ɸ��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'������ɸ��', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [TestPA].[dbo].[pa_�פJ�C��פJ��Ƽ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�������Ъ���z]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�������Ъ���z', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec testpa.dbo.TradeDB_DDE @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MiniMayReissue��ƹw��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MiniMayReissue��ƹw��', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.PL_MINIMAYReissue�~ @t
exec DailyInsert.[dbo].[PL_MINIMAYOustanding] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [db2.[Tick].[dbo].[tbl_Day_MinMax] �[�J���ƫ��v�ҼЪ�����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'db2.[Tick].[dbo].[tbl_Day_MinMax] �[�J���ƫ��v�ҼЪ�����', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'  declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
  declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
  declare @tt nvarchar(20) set @tt=dbmain.dbo.datetranslator(@t,3)
  delete db2.[Tick].[dbo].[tbl_Day_MinMax] where [In_Time]=@tt and Stockid like ''WTXF%''
  insert db2.[Tick].[dbo].[tbl_Day_MinMax](In_Time, StockId, StockCName, IndustryType, SecuritiesType, FairPrice, UpMaxPrice, DownMinPrice, �D�Q�����B���O, ���`�����Ӫѵ��O, �S�����`�Ҩ���O, �v���ѧO�X, �i������, �e�@��~��i���ƶq, �e�@��~����P�ƶq, �o��l�B�q, ��Ϥ�v, ��~�Ѳ��ѧO�X, ������, ������O�N��, �污��T�u�����O, �i�{�ѷ��R���O, �ŧK���L�U�Ĩ��X���O, �ŧK���L�U�ɨ��X���O, ���X�`������, �W������, �U������, �����)
  select @tt,�Ѳ��N��,�Ѳ��W��,'''','''',���L��,���L��*1.1,���L��*0.9,'''','''','''','''',0,0,0,0,0,'''',1,'''','''','''','''','''',000000,0,0,0
  from marketdata.dbo.dailyquote
  where ���=@y and �Ѳ��N�� like ''WTXF%''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Sñ�۰��_�u]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Sñ�۰��_�u', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dailyInsert.[dbo].[DailyInsert_MDBreakList]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyOptionData]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyOptionData', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.[dbo].[MarketData_DailyOptionData] @t


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѧ��W', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151023, 
		@active_end_date=99991231, 
		@active_start_time=81000, 
		@active_end_time=235959, 
		@schedule_uid=N'8c3b407a-230a-436e-9f6b-ebbc3351a93e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Nancy�L������_2030]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Nancy�L������_2030', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�o��H�����p��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�o��H�����p��', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec testpa.[dbo].[�o��H�����p��_Nancy] @t
exec [TestPA].[dbo].[�o��H�����p��_Nancy_New] @t
exec testpa.[dbo].[�o��H�����p��_Nancy_���Ъ������_����í�w] @t
exec testpa.[dbo].[�o��H�����p��_Nancy_���Ъ������1_����í�w] @t
exec [testpa].[dbo].[�o��H�����p��_Nancy_���Ъ������_���t�j�p] @t
exec [testpa].[dbo].[�o��H�����p��_Nancy_���Ъ������_�����ƶq] @t
exec [testpa].[dbo].[�o��H�����p��_Nancy_���Ъ������_�g��v] @t
exec testpa.dbo.�o��H����_����í�w20�� @t
exec testpa.dbo.�C��o��H�����`�� @t
exec testpa.dbo.�o��H����_�u�����w�� @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҥ���Gamma���R]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҥ���Gamma���R', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec testpa.[dbo].[�v�ҥ���Gamma���R] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�������W���ױi��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�������W���ױi��', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec testpa.[dbo].[�v�ҥ���Gamma���R_Delta�����i��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����Reissue���R]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����Reissue���R', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec testpa.[dbo].[Reissue���R] @t
exec testpa.[dbo].[Reissue���Rnew] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cht_tsftd_PB]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cht_tsftd_PB', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.[dbo].[MDoutput_Cht_Tsftd_PB] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Ũ����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Ũ����', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
exec [DailyInsert].[dbo].Credit_BondIndex @t
exec [DailyInsert].[dbo].Credit_BondIndex_AU @t
exec [DailyInsert].[dbo].Credit_BondIndex_BR @t
exec [DailyInsert].[dbo].Credit_BondIndex_CD @t
exec [DailyInsert].[dbo].Credit_BondIndex_CH @t
exec [DailyInsert].[dbo].Credit_BondIndex_DE @t
exec [DailyInsert].[dbo].Credit_BondIndex_FR @t
exec [DailyInsert].[dbo].Credit_BondIndex_GB @t
exec [DailyInsert].[dbo].Credit_BondIndex_GR @t
exec [DailyInsert].[dbo].Credit_BondIndex_ID @t
exec [DailyInsert].[dbo].Credit_BondIndex_IE @t
exec [DailyInsert].[dbo].Credit_BondIndex_IN @t
exec [DailyInsert].[dbo].Credit_BondIndex_IT @t
exec [DailyInsert].[dbo].Credit_BondIndex_JP @t
exec [DailyInsert].[dbo].Credit_BondIndex_KR @t
exec [DailyInsert].[dbo].Credit_BondIndex_PT @t
exec [DailyInsert].[dbo].Credit_BondIndex_RU @t
exec [DailyInsert].[dbo].Credit_BondIndex_SP @t
exec [DailyInsert].[dbo].Credit_BondIndex_US @t


exec [DailyInsert].[dbo].Credit_BondIndex @y
exec [DailyInsert].[dbo].Credit_BondIndex_AU @y
exec [DailyInsert].[dbo].Credit_BondIndex_BR @y
exec [DailyInsert].[dbo].Credit_BondIndex_CD @y
exec [DailyInsert].[dbo].Credit_BondIndex_CH @y
exec [DailyInsert].[dbo].Credit_BondIndex_DE @y
exec [DailyInsert].[dbo].Credit_BondIndex_FR @y
exec [DailyInsert].[dbo].Credit_BondIndex_GB @y
exec [DailyInsert].[dbo].Credit_BondIndex_GR @y
exec [DailyInsert].[dbo].Credit_BondIndex_ID @y
exec [DailyInsert].[dbo].Credit_BondIndex_IE @y
exec [DailyInsert].[dbo].Credit_BondIndex_IN @y
exec [DailyInsert].[dbo].Credit_BondIndex_IT @y
exec [DailyInsert].[dbo].Credit_BondIndex_JP @y
exec [DailyInsert].[dbo].Credit_BondIndex_KR @y
exec [DailyInsert].[dbo].Credit_BondIndex_PT @y
exec [DailyInsert].[dbo].Credit_BondIndex_RU @y
exec [DailyInsert].[dbo].Credit_BondIndex_SP @y
exec [DailyInsert].[dbo].Credit_BondIndex_US @y
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MDoutput_Data_Bond_SBPostion_table]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MDoutput_Data_Bond_SBPostion_table', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.MDoutput_Data_Bond_SBPostion_table @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailySFB]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailySFB', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec [DailyInsert].dbo.[MDoutput_DailySFB] @t
exec DailyInsert.dbo.MDoutput_DailySFB_S_Table
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�Ҧ������R]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�Ҧ������R', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec [TestPA].[dbo].[�v�Ҧ������R_Nancy] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150911, 
		@active_end_date=99991231, 
		@active_start_time=203000, 
		@active_end_time=235959, 
		@schedule_uid=N'1c5b3302-7ee5-4c5c-87b5-fa00e7a5314a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [OneDo]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'OneDo', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tempdbshrink]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tempdbshrink', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use tempdb
go

dbcc shrinkfile(tempdev, 10000)
go

dbcc shrinkfile(templog, 50)
go', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [run]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'run', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @bb datetime,@ee datetime,@tt datetime
set @bb=''2018/11/9''
set @ee=''2018/11/9''
set @tt=@bb
while @tt<=@ee
  begin
  print @tt

--exec DailyInsert.dbo.[PL_Deallist_Transfer] @tt
--exec [DailyInsert].dbo.[PL_Deallist] @tt

--exec [DailyInsert].dbo.PL_�b�~�w�s @tt
exec [DailyInsert].dbo.[PL_�v�ҨC��Markup] @tt
exec [DailyInsert].dbo.[PL_�v�ҨC��Markup_����] @tt
exec [DailyInsert].[dbo].[PL_���f���t�l�qT] @tt
exec [DailyInsert].[dbo].[PL_WBreakDown_���鳡��] @tt
exec [DailyInsert].[dbo].[PL_�v�ҨC��Slippage_����] @tt
exec [DailyInsert].[dbo].[PL_WBreakDown_���鳡��_����] @tt
exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����] @tt
exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����_����] @tt
--exec [DailyInsert].dbo.PL_Inventory @tt
exec [DailyInsert].[dbo].[PL_InventoryBV�պ�] @tt
exec [DailyInsert].dbo.[PL_�ۮa�v��BidVol] @tt
exec [DailyInsert].dbo.[PL_�v�ҨC��Markup_����PV] @tt
exec [DailyInsert].[dbo].[PL_WBreakDown_���鳡��_����PV] @tt
exec [DailyInsert].[dbo].[PL_MarkupAnalysis_���鳡��] @tt
exec [DailyInsert].[dbo].[PL_MarkupAnalysis] @tt
exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����_����PV] @tt
exec [DailyInsert].[dbo].[PL_WBreakDown_�Q�鳡��PV] @tt
exec [DailyInsert].dbo.PL_DailyPLReport_WPV @tt
exec [DailyInsert].dbo.PL_�v�ҨC��������Q @tt
exec [DailyInsert].dbo.PL_�D�޾����O�� @tt
exec [DailyInsert].[dbo].[PL_DailyPLReport_WBV�պ�] @tt

exec [DailyInsert].dbo.PL_�v�ҨC��VaR @tt
exec [DailyInsert].dbo.[PL_����Book�l�q�t�Z] @tt
exec [DailyInsert].dbo.PL_TGIndex @tt
exec DailyInsert.dbo.PL_�v���`�b�ײv
exec DailyInsert.dbo.PL_�v���`�b�ײv_2016

exec [DailyInsert].dbo.Theodata_�C��IntraVol @tt
exec DailyInsert.dbo.PL_MTM�����l�q @tt
exec DailyInsert.dbo.PL_InventoryBase @tt
exec [DailyInsert].dbo.[Accounting_�v�ҭt�Ůw�s] @tt
exec [TestPA].[dbo].[�|�p�w�s_�t�Ůw�s] @tt
exec [TestPA].[dbo].[�|�p�w�s_�t�Ůw�s_New] @tt
exec [TestPA].[dbo].[�|�p��ذ���_�Ĩ�] @tt

exec DailyInsert.dbo.PL_������_�վ��X  @tt
exec  [TestPA].[dbo].[�|�p_���٨�O��]  @tt
exec [DailyInsert].[dbo].PL_���ĥ���B�����l�q�J��� @tt
exec [DailyInsert].[dbo].PL_���R�ֿn�l�q�C�� @tt
exec testpa.[dbo].[Pa_pa_�U������l�q]
exec DailyInsert.dbo.PL_�D�޳���_�U�����l�q���S�v
exec [DailyInsert].[dbo].PL_PHP_�C��U���l�q���p @tt
exec [DailyInsert].[dbo].PL_����B�J���_MD @tt
exec DailyInsert.dbo.PL_�C��l�q����_Trader�X�pPV @tt
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDown @tt
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol_BookA @tt
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol_BookA_Tax @tt
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol_Book�պ� @tt
exec [DailyInsert].dbo.[PL_WarrantMarkupBreakDownCostQvol_Book�պ�_Tax] @tt
exec DailyInsert.dbo.PL_WarrantMarkupBreakDownCostQvol_BookA_�L�a @tt
exec DailyInsert.[dbo].PL_�v�����I���f���t�l�q @tt
exec DailyInsert.dbo.Pro_�϶��v��BreakDown

  set @tt=DBMain.dbo.tradingdateadd(1,@tt)
  end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'OneDo', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20181112, 
		@active_end_date=99991231, 
		@active_start_time=134000, 
		@active_end_time=235959, 
		@schedule_uid=N'503ecd24-fa30-47df-b9d2-5784c770b7ad'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [PL_�ۮa�v�ҨC��QV]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'PL_�ۮa�v�ҨC��QV', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�ۮa�v�ҨC��QV]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�ۮa�v�ҨC��QV', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)


exec [DailyInsert].[dbo].[PL_�ۮa�v�ҨC��QV] @t

--exec [DailyInsert].dbo.[PL_�ۮa�v��BidVol] @t

exec [DailyInsert].dbo.PL_�ۮa�v�ҨC��BookVol @t

--exec DailyInsert.dbo.[PL_�ۮa�v�ҨC��BookVolAlex_temp] @t

--exec DailyInsert.dbo.PL_�ۮa�v�ҨC��BookVolAlex @t

exec [DailyInsert].[dbo].[PL_�ۮa�v�ҨC��QV_�L�ᥭ��] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday_�����v�ҧ�Vol]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday_�����v�ҧ�Vol', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.[Intraday_�����v�ҧ�Vol] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҵ������]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҵ������', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.Pro_�v�ҵ������ @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150907, 
		@active_end_date=99991231, 
		@active_start_time=154500, 
		@active_end_time=235959, 
		@schedule_uid=N'442a3cd6-3141-4cc5-bc5f-41e1d32876c1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [POSA�w�]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'POSA�w�]', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���ƴ��f�C����]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���ƴ��f�C����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(Txdate) from cmoney.dbo.�W���d���q�򥻸�ƨC��)
exec DailyInsert.dbo.intraday_���ƴ��f�C���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�[�v���Ʀ��Ȧ^��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�[�v���Ʀ��Ȧ^��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(Txdate) from cmoney.dbo.�W���d���q�򥻸�ƨC��)
exec DailyInsert.dbo.FrontDeskW_�[�v���Ʀ��Ȧ^�� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��U��3�I', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190401, 
		@active_end_date=99991231, 
		@active_start_time=150000, 
		@active_end_time=235959, 
		@schedule_uid=N'4bb86683-8b54-4b17-989c-f0aaefb4380b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [QD_Proc]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'QD_Proc', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [QD_Bond_CBASBookPL]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'QD_Bond_CBASBookPL', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec Hubert.dbo.Proc_QD_Bond_CBASBookPL', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [QD_ForeignBD]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'QD_ForeignBD', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
set @t=dbmain.dbo.tradingdateadd(-1,@t)

exec [Hubert].dbo.[Proc_QD_ForeignBD] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [QD_May_CBIndex_20180206]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'QD_May_CBIndex_20180206', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec Hubert.dbo.Proc_QD_May_CBIndex_20180206', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180207, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'71d2beb3-9ce7-4b46-ac23-264ef004c0fb'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Ronald�U��4�I]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Ronald�U��4�I', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C���J�j�L��������]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C���J�j�L��������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec  dailyinsert.dbo.Ronald_�C���J�j�L��������ret  ', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C���J���q��]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C���J���q��', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime
set @t=(select max(���) from   cmoney.dbo.�馬�L���Ʀ� )
delete ronald.[dbo].[���q��] where ���=@t
 insert ronald.[dbo].[���q��]
 select * from (
  select  ���,�Ѳ��N�� ,[������B(�d)]   
 ,   avg([������B(�d)]  ) over (partition by  �Ѳ��N�� order by   ���   rows between   4  preceding and current row) as [5�駡�q]
  ,   avg([������B(�d)]  ) over (partition by  �Ѳ��N�� order by   ���   rows between   21  preceding and current row)   [22�駡�q]
   ,   avg([������B(�d)]  ) over (partition by  �Ѳ��N�� order by   ���   rows between  43   preceding and current row)  [44�駡�q]

 from  cmoney.dbo.�馬�L���Ʀ�   where  len(�Ѳ��N��)=4 and ���>=@t-80) a where ���=@t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C��insert�Ӫ�MA]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C��insert�Ӫ�MA', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec  dailyinsert.dbo.Ronald_�C��insert�Ӫ�MA', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ronald_�C��insert�Ӫ�RS]    Script Date: 2019/5/15 �W�� 09:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ronald_�C��insert�Ӫ�RS', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec  dailyinsert.dbo.Ronald_�C��insert�Ӫ�RS', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'4�I', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170609, 
		@active_end_date=99991231, 
		@active_start_time=160000, 
		@active_end_time=235959, 
		@schedule_uid=N'7c2b550d-7cf2-4fcd-adb0-d012286e340f'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Ronald�L��1]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Ronald�L��1', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C���J�j�L��������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C���J�j�L��������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec  Dailyinsert.dbo.Ronald_�C���J�j�L��������ret  ', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C���JETF_from43]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C���JETF_from43', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime
set @t =(select max(txdate) from db2.Intraday.[dbo].[DailyTick_01min])

exec Ronald_�C���JETF_from43  @t', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB�C��Spread]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB�C��Spread', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime
set @t=(select max(���) from cmoney.[dbo].[�i�ऽ�q�Ŧ��L])

exec dailyinsert.dbo.Ronald_CB�C��Spread @t', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�U��6�I20', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160406, 
		@active_end_date=99991231, 
		@active_start_time=182000, 
		@active_end_time=235959, 
		@schedule_uid=N'521e2cef-b7e7-42c9-b4c3-8cebf54f25f2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [T73 To DailyQuote]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'T73 To DailyQuote', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SELECT 1/COUNT(*) FROM DBMain.dbo.Tradingdate WHERE Tradingdate = CONVERT(DATE, GETDATE())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [T73 To DailyQuote]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'T73 To DailyQuote', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.Marketdata_DailyQuote_T73Insert

exec [DailyInsert].[dbo].[Cmoney_�C�馬�L��T73]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ƥ�InventoryMay4]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ƥ�InventoryMay4', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(Stadate) from pl.dbo.InventoryMay4 )
delete pl.dbo.InventoryMay4_his where Stadate<=Dbmain.dbo.tradingdateadd(-5, @t)
delete pl.dbo.InventoryMay4_his where Stadate=@t
insert  pl.dbo.InventoryMay4_his
SELECT [Stadate] ,[Portfolio],[Trader],[Underlying] ,[StockID] ,[Type] ,[StockName],[B],[S] ,[Volume],[MTM_D],[Book_D],[Tax_D],[MTM_M],[Book_M],[Tax_M],[MTM_Y],[Book_Y]
      ,[Tax_Y],[LastPrice],[TheoPrice],[TheoPriceBV],[Delta],[Gamma],[Theta],[Theta�L�a],[Vega],[DeltaLots],[DeltaLotsChg],[DeltaLotsTNet],[GammaLots]
      ,[TimeValue],[OpendeltaY],[�ۮaMarkup],[�L�aMarkup],[GammaY],[BVega],[Hedge�ٵ|],[Spread],[UPX],[DeltaUp],[DeltaDown],[���O],[�|�p_D],[�|�p_M],[�|�p_Y]
      ,[Reissue],[TimeValue�L�a],[GammaY�L�a],[IssueCost] ,[Base],[DeltaSet],[SPX],[OptGammaLots],[OptSpeedLots],[DeltaUpALL],[DeltaDownALL],[TimeValueBV],[PV]
  FROM [PL].[dbo].[InventoryMay4]
  where  Stadate=@t  and [User]=''J1040001''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160907, 
		@active_end_date=99991231, 
		@active_start_time=142000, 
		@active_end_time=235959, 
		@schedule_uid=N'b0d9c2ea-7f2c-4df2-b5eb-230605a867dd'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�p������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�p������', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ɸ��]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ɸ��', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DBMain.dbo.�@���ʤu�@', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'JustDoIt', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150319, 
		@active_end_date=99991231, 
		@active_start_time=174745, 
		@active_end_time=235959, 
		@schedule_uid=N'9c4ac3b5-de44-49a1-b6c2-dae7a0543acc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�[�v���Ʀ���]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�[�v���Ʀ���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�[�v���Ʀ���]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�[�v���Ʀ���', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.dbo.FrontdeskW_�[�v���Ʀ��� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�L���C10������', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=2, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190109, 
		@active_end_date=99991231, 
		@active_start_time=83000, 
		@active_end_time=134500, 
		@schedule_uid=N'bc2561c4-aa96-4960-ac18-5e544dabfb79'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�u�]�@��]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�u�]�@��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�u�]�@��_1]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�u�]�@��_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @b datetime,@e datetime,@t datetime
set @b=''2019/3/4''
set @e=''2019/4/3''
set @t=@b
while @t<=@e
  begin
  print @t




exec [DailyInsert].[dbo].Cmoney_����Ӷi�X����� @t

exec DailyInsert.dbo.Pro_�P�~�v�ҥ�� @t
exec DailyInsert.dbo.Pro_�P�~�l�q���p @t
exec DailyInsert.dbo.Pro_�P�~�l�q���p_������ @t
exec [DailyInsert].dbo.[Pro_�P�~�l�q�J��] @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdatePL @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdateTV @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o���ɼ�] @t
exec DailyInsert.dbo.[Marketdata_�C��Ѳ��̫�BA]
exec DailyInsert.dbo.[MarketData_�v�Ҧ�����B_���Ъ�] @t
exec [DailyInsert].[dbo].[MarketData_�v�Ҩ�Ӯw�s�i��_�����] @t
exec [DailyInsert].[dbo].[MarketData_�v�Ҩ�Ӯw�s�i��_�����Update] @t

exec [DailyInsert].dbo.FrontDeskW_�C��Reissue���p�� @t
exec DailyInsert.dbo.[FrontDeskW_�C��Reissue���p��_���Ъ�] @t
exec DailyInsert.dbo.[FrontDeskW_�C��Reissue���p��_�����] @t

exec [DailyInsert].dbo.[Pro_�������ӥD�O���G] @t
exec [DailyInsert].dbo.[Pro_�������ӥD�O���G10��30��] @t
exec [DailyInsert].dbo.[Pro_�������ӥD�O���GJohnny] @t
exec [DailyInsert].dbo.[Pro_�v�ҽL���������_���z] @t
exec DailyInsert.dbo.[Pro_��Ӧ��楫���v] @t



  set @t=DBMain.dbo.tradingdateadd(1,@t)
  end

  


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [2]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'2', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/* ���Ѱ_�ӼȤ��]

declare @t1 datetime set @t1=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Pro_�϶��v��BreakDown

delete pl.[dbo].[�����D�޳���_�s���榡Table]
insert pl.[dbo].[�����D�޳���_�s���榡Table]
select *
from pl.[dbo].[�����D�޳���_�s���榡_MD](@t1)


delete pl.[dbo].[���쥫��_Delta_HedgeTable]
insert pl.[dbo].[���쥫��_Delta_HedgeTable]
select *
from pl.[dbo].[���쥫��_Delta_Hedge](@t1)


delete PL.dbo.���I����_�|�p�l�q�`�Btable
insert PL.dbo.���I����_�|�p�l�q�`�Btable
select *
FROM PL.dbo.���I����_�|�p�l�q�`�B(@t1)

delete PL.dbo.���I����_�|�pDeltatable
insert PL.dbo.���I����_�|�pDeltatable
select *
FROM PL.dbo.���I����_�|�pDelta(@t1)



delete PL.dbo.[�l�q����_�v�ҥ���O��table] where TxDate=@t1
insert PL.dbo.[�l�q����_�v�ҥ���O��table] 
select *
from PL.dbo.[�l�q����_�v�ҥ���O��](@t1) order by [Trader]

*/
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�u�]�@��_1', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190405, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'18fce6c0-a278-4656-a43e-688d0c9a9e2b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�u�ݭn���L�����z�׻���]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�u�ݭn���L�����z�׻���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�u�ݭn�ƽL�����z�׻���', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ˬd�O�_�������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ˬd�O�_�������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SELECT 1/COUNT(*) FROM DBMain.dbo.Tradingdate WHERE Tradingdate=CONVERT(date, GETDATE())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday_ETFNAV�C����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday_ETFNAV�C����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t datetime = CONVERT(date, GETDATE())

exec DailyInsert.dbo.Intraday_ETFNAV�C���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�C��x������v���t�i�ʲv]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�C��x������v���t�i�ʲv', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec [DailyInsert].[dbo].[PL_�C��x������v���t�i�ʲv] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB_Delta]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB_Delta', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--DECLARE @t datetime = CONVERT(date, GETDATE())

--exec DailyInsert.dbo.[PL_CB_Delta] @t', 
		@database_name=N'PL', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��������', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160816, 
		@active_end_date=99991231, 
		@active_start_time=165000, 
		@active_end_time=235959, 
		@schedule_uid=N'0231ae11-80b1-4ac0-af36-a5c116e189f1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�~����f����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�~����f����', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�~����f����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�~����f����', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec �~��ClosingPrice_add_�L�״��f
--exec �~��ClosingPrice_add_HG���f
declare @t datetime set @t=(select max(txdate) from pl.dbo.inventory_�l�Ӧ���)
exec web.dbo.�~��������_JT���� @t', 
		@database_name=N'Web', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�~����f����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=124, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170922, 
		@active_end_date=99991231, 
		@active_start_time=43000, 
		@active_end_time=235959, 
		@schedule_uid=N'58f23f40-ad0a-41dd-a10f-7f9a99b60f6b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�۰ʶ]�b]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�۰ʶ]�b', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=49, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�����������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�����������', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATE = GETDATE()
DECLARE @m DATE = DATEADD(DAY, 1, @t)
DECLARE @h INT = DATEPART(hour, GETDATE())


IF @h <= 17
BEGIN

-- ����^��
DELETE Trade_DB.dbo.tblOrderReport
WHERE TransactTime BETWEEN @t AND @m

INSERT Trade_DB.dbo.tblOrderReport
  SELECT NEWID(), [Account], [AvgPx], [Channel], [ChannelType], [CumQty], [Errorcode], [ExecID]
      ,[ExecType], [IsReSend], [LastPx], [LastQty], [LeavesQty], [Market], [OrderID], [OrderQty]
      ,[OrdRejReason], [OrdStatus], [OrdType], [Price], [SerialNo], [Side], [Symbol], [Text]
      ,[TimeInForce], [Trader], [TransactTime], [TwseExCode], [TwseIvacnoFlag], [TwseOrdType] 
  FROM db192.[Trade_DB].[dbo].[tblSTradeExecutionReport]
  WHERE TransactTime BETWEEN @t AND @m


-- 400����
DELETE FROM [Trade_DB].[dbo].[tblExecutionReport400]
WHERE TransactTime BETWEEN @t AND @m

INSERT [Trade_DB].[dbo].[tblExecutionReport400]
--  SELECT * FROM  Trade_db.dbo.tblExecutionReport400_test
     SELECT * FROM  DB192.trade_DB.[dbo].[tblExecutionReport400]
  WHERE TransactTime BETWEEN @t AND @m


-- 400�^��
DELETE FROM [Trade_DB].dbo.tblRequestReport400
WHERE TransactTime BETWEEN @t AND @m

INSERT Trade_DB.dbo.tblRequestReport400
  SELECT * FROM  DB192.Trade_db.dbo.tblRequestReport400
  WHERE TransactTime BETWEEN @t AND @m


-- KGI Report DONE
DELETE Trade_db.dbo.tblKGI_Report_Done_His
WHERE [InTime] BETWEEN @t AND @m

INSERT Trade_db.dbo.tblKGI_Report_Done_His
  SELECT @T, * FROM db192.Trade_DB.dbo.tblKGI_Report_Done NOLOCK

-- KGI Report Order
DELETE Trade_db.dbo.tblKGI_Report_Order_His WHERE [InTime] BETWEEN @t AND @m 

INSERT Trade_db.dbo.tblKGI_Report_Order_His
    SELECT @T, * FROM db192.Trade_DB.dbo.tblKGI_Report_Order NOLOCK




END

  --�~����f�污��
  exec dailyinsert.dbo.Cmoney_�~����f����污�� @t
  exec dailyinsert.dbo.Cmoney_�~����f����污��_�U��


 --400���٨�פJ
  exec [TestPA].[dbo].[�|�p_���٨�_�������_����]  @t

exec [DailyInsert].dbo.PL_�|�p_400_New @t', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestPA_�|�p_�ɨ�_�������Update]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestPA_�|�p_�ɨ�_�������Update', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.TestPA_�|�p_�ɨ�_�������Update ''''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_�v�Ҩ�����⧡����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_�v�Ҩ�����⧡����', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @h dec(18,4) set @h=datepart(hh,getdate())
IF @h <= 17
BEGIN
exec DailyInsert.dbo.Marketdata_�v�Ҩ�����⧡���� @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_DailyQuote]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_DailyQuote', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.Marketdata_DailyQuote @t
exec DailyInsert.dbo.PL_ETF�C��鷸���T��1330 @t
exec DailyInsert.dbo.PL_ETF�����鷸��1300 @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday_tblTickETFDaily��~��]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday_tblTickETFDaily��~��', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @h dec(18,4) set @h=datepart(hh,getdate())
IF @h <= 17
BEGIN
exec DailyInsert.dbo.Intraday_tblTickETFDaily��~�� @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Theodata_HistoryVol]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Theodata_HistoryVol', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec [DailyInsert].[dbo].[Theodata_HistoryVol] @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Deallist_Transfer]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Deallist_Transfer', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.dbo.[PL_Deallist_Transfer] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Deallist]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Deallist', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.[PL_Deallist] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�b�~�w�s]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�b�~�w�s', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec [DailyInsert].dbo.PL_�b�~�w�s @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�L�a�v��Markup����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�L�a�v��Markup����', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����] @t
exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����_����] @t
--exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����_����PV] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Inventory]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Inventory', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.PL_Inventory @t


exec [DailyInsert].[dbo].[PL_InventoryBV�պ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�l�ӳ�RPRS]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�l�ӳ�RPRS', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t =(select max(txdate) from pl.dbo.inventory_�l�Ӧ���)
exec DailyInsert.[dbo].[PL_DailyPLReport_�l�Ӧ���_RPRS]
exec DailyInsert.[dbo].[PL_�l�ӳ�RPRS�l�q] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�Ʃe�U�ײv�l�q]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�Ʃe�U�ײv�l�q', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.PL_�Ʃe�U�ײv�l�q', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�U�����C��l�q(�v�Ұ��~)]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�U�����C��l�q(�v�Ұ��~)', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

DECLARE @h int = DATEPART(hour, GETDATE())
IF @h < 18
BEGIN
  EXEC DailyInsert.dbo.Cmoney_���f����污���w��
  exec dailyinsert.dbo.Cmoney_�~����f����污�� @t
END

exec DailyInsert.dbo.[PL_Deallist_�l�Ӧ���] @t
exec DailyInsert.dbo.[PL_Inventory_�l�Ӧ���_���] @t
exec DailyInsert.dbo.[PL_Inventory_�l�Ӧ���] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_�l�Ӧ���] @t
exec DailyInsert.dbo.[PL_DailyPLReport_�l�Ӧ���_���] @t
exec DailyInsert.dbo.[PL_DailyPLReport_�l�Ӧ���] @t


exec DailyInsert.dbo.[PL_Deallist_����] @t
exec DailyInsert.[dbo].[PL_Inventory_����_���] @t
exec DailyInsert.[dbo].[PL_Inventory_����] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_����] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����_���] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����] @t



exec DailyInsert.dbo.[PL_Deallist_����] @t
exec DailyInsert.[dbo].[PL_Inventory_����_���] @t
exec DailyInsert.[dbo].[PL_Inventory_����] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_����] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����_���] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����] @t
--exec [DailyInsert].dbo.PL_���f����C��VaR @t


exec DailyInsert.dbo.[PL_Deallist_�Ũ�] @t
exec DailyInsert.[dbo].[PL_Inventory_�Ũ�] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_�Ũ�] @t
exec DailyInsert.dbo.[PL_DailyPLReport_�Ũ�] @t
--exec [DailyInsert].dbo.PL_�Ũ鳡�C��VaR @t

exec DailyInsert.dbo.[PL_Deallist_����G��] @t
exec DailyInsert.dbo.[PL_Inventory_����G��] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_����G��] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����G��] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�S�w�~�Ȳz�׷l�q�PBreakDown]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�S�w�~�Ȳz�׷l�q�PBreakDown', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


exec [DailyInsert].[dbo].[PL_DailyPLReport_����305_006205�֭pPL] @t

exec [DailyInsert].dbo.[PL_ETFPortfolio�z�׷l�q] @t

exec DailyInsert.dbo.PL_�l��CBVolTradeBD @t
exec DailyInsert.dbo.PL_�l��CBVolTradeBDNew @t
exec DailyInsert.[dbo].[PL_�l��CBVolTradeBDNew_0.3HisV] @t
/*
--2019/3/7 �p�W��A�]������43�٨S��1��������A�ҥH����L������
--�l��POSA
exec DailyInsert.dbo.FrontDeskW_�[�v���Ʀ��Ȧ^�� @t
*/

-- ���� FF
delete [PL].[dbo].[����FF�z�׷l�q]
insert  [PL].[dbo].[����FF�z�׷l�q]
select * from PL.dbo.[InventoryAlex_FFBookPL](@t)

-- ���� XPM(���R)
exec DailyInsert.dbo.PL_����XPM���RBD���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ӫ~�l�q]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ӫ~�l�q', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.PL_DailyReport_FLN @t
exec DailyInsert.dbo.PL_DailyReport_PGN


--FX_SWAP
--declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
delete pl.dbo.Inventory_FX_SWAP where Txdate=@t
insert  pl.dbo.Inventory_FX_SWAP
select @t as Txdate,�����s�� ,�����  ,[�ͮĤ�(��Τ�)]  ,�����  ,
�ӧ@��H ,�Ъ��겣 ,�Ъ��겣�ײv ,�R�J���O ,�R�J���B  ,��X���O ,��X���B 
,�Ъ��겣�ײv_����  ,�R�J���O_���� ,�R�J���B_���� ,��X���O_���� ,��X���B_����  ,����� 
from OperationDesk.dbo.FX_SWAP_Inventory(@t)

delete pl.dbo.Deallist_FX_SWAP where Txdate=@t
insert pl.dbo.Deallist_FX_SWAP
select ����� as Txdate,
�����s�� ,������A ,[�ͮĤ�(��Τ�)] ,����� ,
�ӧ@��H ,�Ъ��겣 ,�Ъ��겣�ײv ,�R�J���O ,�R�J���B  ,��X���O ,��X���B
,�Ъ��겣�ײv_����  ,�R�J���O_���� ,�R�J���B_���� ,��X���O_���� ,��X���B_����  ,����� 
from OperationDesk.dbo.FX_SWAP_Deallist(@t,@t)', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CBAS�l�q����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CBAS�l�q����', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].[dbo].[DBMain_CBAS_�C��򥻸�ƶפJ_NEWSYS] @t
exec [DailyInsert].[dbo].[PL_CBASDailyPLReportMD_NEWSYS] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MTM_Breakdown1]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MTM_Breakdown1', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

--exec [DailyInsert].dbo.[PL_�ۮa�v��BidVol] @t

--exec [DailyInsert].[dbo].[PL_�v�ҨC��Slippage] @t
exec [DailyInsert].dbo.[PL_�v�ҨC��Markup_����PV] @t
exec [DailyInsert].[dbo].[PL_�v�ҨC��Slippage_����PV] @t
exec [DailyInsert].[dbo].[PL_WBreakDown_���鳡��_����PV] @t
--exec [DailyInsert].[dbo].[PL_MarkupAnalysis_���鳡��] @t
exec [DailyInsert].[dbo].[PL_MarkupAnalysis] @t
exec [DailyInsert].[dbo].[PL_�L�a�v��Markup����_����PV] @t
exec [DailyInsert].[dbo].[PL_WBreakDown_�Q�鳡��PV] @t
exec [DailyInsert].dbo.PL_DailyPLReport_WPV @t
exec [DailyInsert].dbo.PL_�v�ҨC��������Q @t

exec [DailyInsert].dbo.PL_�D�޾����O�� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_DailyPLReport_W]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_DailyPLReport_W', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)


exec [DailyInsert].[dbo].[PL_DailyPLReport_WBV�պ�] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�v�ҨC��VaR]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�v�ҨC��VaR', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec [DailyInsert].dbo.PL_�v�ҨC��VaR @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�|�p��������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�|�p��������', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

--�H�U�����ꨫ����s�g��
exec [DailyInsert].dbo.[Accounting_�v�ҭt�Ůw�s] @t



--�H�U������
exec [TestPA].[dbo].[�|�p�w�s_�t�Ůw�s] @t
--exec [TestPA].[dbo].[�|�p�w�s_�t�Ůw�s_New] @t
exec [TestPA].[dbo].[�|�p��ذ���_�Ĩ�] @t

exec [TestPA].[dbo].[�|�p��ذ���_����] @t
exec [TestPA].[dbo].[�|�p��ذ���_����] @t
exec [TestPA].[dbo].[�|�p��ذ���_�Ũ�] @t
exec [TestPA].[dbo].[�|�p��ذ���_�l�Ӧ���] @t

--exec DailyInsert.[dbo].[PL_�ۮa�o��O���u] @t

--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_�l�Ͱӫ~��] @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_���ĥ���B] @t

exec [DailyInsert].dbo.PL_�|�p_400_New @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_�l�Ӧ���] @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_����] @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_����] @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_�Ũ�] @t

--exec  testpa.[dbo].[pa_�|�p�l�q�C��_���f�M��] @t 

--exec testpa.[dbo].[Pa_pa_�U������l�q] 

--exec [TestPA].[dbo].[TestPA_Daily_�~PL] @t

--exec testpa.[dbo].[TestPa_Pa_DailyReport_Karen] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C������', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.Web_tbl����ռ��ӽ� @t
exec [DailyInsert].dbo.[PL_����ռ���J] @t

exec DailyInsert.dbo.���j��H�٨����ռ� @t

exec Dailyinsert.dbo.pl_db75�ϥθ���l�B @t
exec DailyInsert.dbo.PL_������_���� @t
exec DailyInsert.dbo.PL_������_���� @t
exec DailyInsert.dbo.PL_������_�Ũ� @t
exec DailyInsert.dbo.PL_������_�l�Ӧ��� @t
exec DailyInsert.dbo.PL_������_�l�� @t
exec DailyInsert.dbo.PL_������_����G�� @t

exec DailyInsert.dbo.PL_������_�վ��X  @t

--exec [TestPA].[dbo].[Pa_PL_������]  @t

exec  [TestPA].[dbo].[�|�p_���٨�O��]  @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���f�������_�t��u�ʵ���B]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���f�������_�t��u�ʵ���B', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATE = (SELECT MAX(TxDate) FROM PL.dbo.Inventory_����)
DECLARE @n DATE = CONVERT(DATE, GETDATE())

delete DBmain.dbo.���f�������_�t��u�ʵ���B where tradedate=@t

if @t = @n 
begin

  insert DBmain.dbo.���f�������_�t��u�ʵ���B
  select a.ASorderNo,a.TradeDate,a.Market,a.TraderID
    ,min(case when a.symbol like ''MX%'' then ''MarkFF'' else ''AlexFS'' end) as Tag
    --,min(case when a.symbol like ''MX%'' then ''MarkFF'' when a.market=''4'' and a.symbol like ''TX%'' then ''AlexFF'' else ''AlexFS'' end) as Tag--2016/12/21 �p�W�� ��Q�J���S��FF�F
  from Trade_DB.dbo.tblKGI_Report_Done a
  join dbmain.dbo.[AccountList_temp] b on b.FuAcc00=a.traderID and a.[InTime] between b.Bdate and b.Edate
  join dbmain.[dbo].[DefaultPortfolio_���f���] c on c.acc=a.traderID and a.[InTime] between c.bdate and c.edate and c.Portfolio=''�t��u�ʵ���B''
  group by a.ASorderNo,a.TradeDate,a.Market,a.TraderID

end
else
begin

  insert DBmain.dbo.���f�������_�t��u�ʵ���B
  select a.ASorderNo,a.TradeDate,a.Market,a.TraderID
    ,min(case when a.symbol like ''MX%'' then ''MarkFF'' else ''AlexFS'' end) as Tag
    --,min(case when a.symbol like ''MX%'' then ''MarkFF'' when a.market=''4'' and a.symbol like ''TX%'' then ''AlexFF'' else ''AlexFS'' end) as Tag--2016/12/21 �p�W�� ��Q�J���S��FF�F
  from Trade_DB.dbo.tblKGI_Report_Done_His a
  join dbmain.dbo.[AccountList_temp] b on b.FuAcc00=a.traderID and a.[InTime] between b.Bdate and b.Edate
  join dbmain.[dbo].[DefaultPortfolio_���f���] c on c.acc=a.traderID and a.[InTime] between c.bdate and c.edate and c.Portfolio=''�t��u�ʵ���B''
  where a.TxDate = @t
  group by a.ASorderNo,a.TradeDate,a.Market,a.TraderID

end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�T�w���l�q����(���]�b�ݭn��s)]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�T�w���l�q����(���]�b�ݭn��s)', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC DailyInsert.dbo.MarketData_����G���� @t


exec [DailyInsert].[dbo].PL_���ĥ���B�����l�q�J��� @t
exec [DailyInsert].[dbo].PL_���R�ֿn�l�q�C�� @t
exec testpa.[dbo].[Pa_pa_�U������l�q]

exec DailyInsert.dbo.PL_�D�޳���_�U�����l�q���S�v

exec [DailyInsert].[dbo].PL_PHP_�C��U���l�q���p @t
exec [DailyInsert].[dbo].PL_����B�J���_MD @t


/* ���]�i�H��
DECLARE @tf date = ''2016-05-25''
DECLARE @td date = ''2016-08-02''
DECLARE @ct date 

DECLARE td CURSOR FOR
  SELECT Tradingdate FROM DBMain.dbo.Tradingdate WHERE Tradingdate BETWEEN @tf AND @td
OPEN td
FETCH NEXT FROM td INTO @ct

WHILE @@FETCH_STATUS = 0
BEGIN
  EXEC DailyInsert.dbo.PL_���R�ֿn�l�q�C�� @ct
  FETCH NEXT FROM td INTO @ct
  PRINT @ct
END
CLOSE td
*/', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���I����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���I����', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
DECLARE @h INT = DATEPART(hour, GETDATE())

Declare @tt date set @tt=(select  max(txdate) from pl.dbo.Inventory_���� where acc=''327'')


exec DailyInsert.dbo.[PL_CB_Delta] @t 

 --exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''All''
 --exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''Andy''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''Gary'',''201''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''Gary'',''202''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''YuChien'',''211''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''Francis'',''212''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''YuKai'',''213''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v����G�� @t,''Marshall'',''214''

 
 exec DailyInsert.dbo.PL_���I���޸IĲ���v�l�Ӧ��� @t,''Karen''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v�l�Ӧ��� @t,''Eason''
 
 --exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡 @t,''All''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡 @t,''Jeff''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡 @t,''Cathy''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡_�Ũ��� @t,''�Ũ���''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡_�Ũ��� @t,''���ť��''
 
 --exec DailyInsert.dbo.PL_���I���޸IĲ���v���泡 @t,''Rose''--�{�b���쬰���I����  �L�k�p����v
 --exec DailyInsert.dbo.PL_���I���޸IĲ���v���泡 @t,''Max''
exec DailyInsert.dbo.PL_���I���޸IĲ���v���泡_ADR�M�Q @tt,''Tim''

-- exec DailyInsert.dbo.PL_���I���޸IĲ���v���泡 @t,''Ronald''
 exec DailyInsert.dbo.PL_���I���޸IĲ���v���泡 @t,''Erik''


 exec DailyInsert.dbo.PL_���I���޸IĲ���v�M�Q��� @t

exec DailyInsert.dbo.Monitor_�C��wĵ�q���M�� @t
exec DailyInsert.dbo.MDoutput_�C��wĵ�q���M�� @t

exec [DailyInsert].dbo.PL_����G�եi���B�� @t
exec DailyInsert.dbo.MarketData_����G���� @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BreakDownPV����]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BreakDownPV����', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.PL_�C��l�q����_Trader�X�pPV @t
--exec DailyInsert.dbo.PL_�C��l�q����_Trader�X�pT1PV85 @t
--exec DailyInsert.dbo.PL_�C��l�q����_Trader�X�pPV2 @t

exec [DailyInsert].[dbo].PL_PHP_�C��U���l�q���p @t
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDown @t
--exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCost @t
--exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol @t
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol_BookA @t
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol_BookA_Tax @t
exec [DailyInsert].dbo.PL_WarrantMarkupBreakDownCostQvol_Book�պ� @t
exec [DailyInsert].dbo.[PL_WarrantMarkupBreakDownCostQvol_Book�պ�_Tax] @t

exec DailyInsert.dbo.PL_WarrantMarkupBreakDownCostQvol_BookA_�L�a @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����ADR�t��BD]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����ADR�t��BD', 
		@step_id=28, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=dbmain.dbo.tradingdateadd(-1,(select max(stadate) from pl.dbo.inventory))

--exec DailyInsert.dbo.PL_�C��ADR�鷸���� @t
--exec DailyInsert.dbo.PL_����ADR�t��BD @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�����t�M�QBreakdown]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�����t�M�QBreakdown', 
		@step_id=29, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec DailyInsert.dbo.[PL_DailyPLReport_����325_MarkFF�֭pPL] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����325_AlexFF�֭pPL] @t
exec DailyInsert.dbo.[PL_���f��t�M�QMTH] @t
exec DailyInsert.dbo.[PL_�����t�M�Q_PLBidAsk] @t
exec DailyInsert.dbo.[FrontDeskW_���f��t�M�Q_�j�z���R] @t
exec DailyInsert.dbo.FrontDeskW_���f��t�M�Q���� @t


end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�l�ӹq��SWIM�z�׷l�q]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�l�ӹq��SWIM�z�׷l�q', 
		@step_id=30, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec DailyInsert.dbo.PL_�l�ӹq��SWIM�z�׷l�q
exec DailyInsert.dbo.[PL_�l�ӹq���p�K�z�׷l�q]
end
exec DailyInsert.dbo.PL_WPU30BD @t

exec DailyInsert.dbo.PL_�ͭ۵����z�׷l�qBenchmark


declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
delete [PL].[dbo].[�l�ӹq��SWIMBD���ƻ���Table] where Txdate=@t
insert  [PL].[dbo].[�l�ӹq��SWIMBD���ƻ���Table]
SELECT x.* 
,y.E_O
,case when y.E_H>y.E_O and y.E_H>y.E_C then y.E_H when y.E_O>y.E_C then y.E_O else y.E_C end as [E_H]
,case when y.E_L<y.E_O and y.E_L<y.E_C then y.E_L when y.E_O<y.E_C then y.E_O else y.E_C end as [E_L]
,y.E_C
,y.F_O
,case when y.F_H>y.F_O and y.F_H>y.F_C then y.F_H when y.F_O>y.F_C then y.F_O else y.F_C end as [F_H]
,case when y.F_L<y.F_O and y.F_L<y.F_C then y.F_L when y.F_O<y.F_C then y.F_O else y.F_C end as [F_L]
,y.F_C 
FROM(
select a.TxDate,a.E_Index,a.F_Index,a.E_R,a.F_R,a.����,a.Pos,a.Daily_PL_R,a.Cum_PL_R,a.DailyPL_���B
,b.O
,ceiling(b.H/0.0000001)*0.0000001 as H
,floor(b.L/0.0000001)*0.0000001 as L
,b.C
from pl.[dbo].[�l�ӹq��SWIM�z�׷l�q] a
left join (
     select tb.tradingdate as TxDate
     ,coalesce(
     avg(
     100*(
     (case when b1.�ɶ�=''0901'' then b1.���� end*cast(c2.���L�� as float)/cast(c1.���L�� as float) /a.E_Index-1)
     -(case when b2.�ɶ�=''0901'' then b2.���� end*cast(d2.���L�� as float)/cast(d1.���L�� as float) /a.F_Index-1))
     +a.����
     )
     ,avg(
     100*(
     (c2.�}�L�� /a.E_Index-1)
     -(d2.�}�L�� /a.F_Index-1))
     +a.����
     )
     ,avg(
     100*(
     (c1.�}�L�� /a.E_Index-1)
     -(d1.�}�L�� /a.F_Index-1))
     +a.����
     )
     )
     as O
     ,max(
     100*(
     (b1.����/cast(c1.���L�� as float)*cast(c2.���L�� as float) /a.E_Index-1)
     -(b2.����/cast(d1.���L�� as float)*cast(d2.���L�� as float) /a.F_Index-1))
     +a.����
     )
     as H
     ,min(
     100*(
     (b1.����/cast(c1.���L�� as float)*cast(c2.���L�� as float) /a.E_Index-1)
     -(b2.����/cast(d1.���L�� as float)*cast(d2.���L�� as float) /a.F_Index-1))
     +a.����
     )
     as L
     ,avg(
     100*(
     (c2.���L�� /a.E_Index-1)
     -(d2.���L�� /a.F_Index-1))
     +a.����
     )
     as C

     from pl.[dbo].[�l�ӹq��SWIM�z�׷l�q] a
     join dbmain.dbo.tradingdate ta on ta.tradingdate=a.Txdate
     join dbmain.dbo.tradingdate tb on tb.ser-1=ta.ser
     join cmoney.dbo.�馬�L���Ʀ� c1 on c1.���=tb.tradingdate and c1.�Ѳ��N��=''TWB23''
     join cmoney.dbo.�馬�L���Ʀ� c2 on c2.���=tb.tradingdate and c2.�Ѳ��N��=''TWA23''
     join cmoney.dbo.�馬�L���Ʀ� d1 on d1.���=tb.tradingdate and d1.�Ѳ��N��=''TWB28''
     join cmoney.dbo.�馬�L���Ʀ� d2 on d2.���=tb.tradingdate and d2.�Ѳ��N��=''TWA28''
     left join [Cmoney].[dbo].[����Ƥ����q�έp��] b1 on b1.���=tb.tradingdate and b1.�Ѳ��N��=''TWB23''
     left join [Cmoney].[dbo].[����Ƥ����q�έp��] b2 on b2.���=tb.tradingdate and b2.�Ѳ��N��=''TWB28'' and b2.�ɶ�=b1.�ɶ�
	 where a.Txdate=@y
     group by tb.tradingdate
) b on b.TxDate=a.Txdate
) x
join(
select  b1.���
			, avg(case when b1.�ɶ�=''0900'' then b1.���� end*c2.���L��/c1.���L�� )	as E_O
			,max(b1.����*c2.���L��/c1.���L�� )  as E_H
			,min(b1.����*c2.���L��/c1.���L�� )  as E_L
			,avg(c2.���L��) as E_C

				,avg(case when b2.�ɶ�=''0900'' then b2.���� end*d2.���L��/d1.���L�� )	as F_O

			,max(b2.����*d2.���L��/d1.���L�� )  as F_H
			,min(b2.����*d2.���L��/d1.���L�� )  as F_L
			,avg(d2.���L��) as F_C
from [Cmoney].[dbo].[����Ƥ����q�έp��] b1   
join [Cmoney].[dbo].[����Ƥ����q�έp��] b2 on  b2.�Ѳ��N��=''TWB28'' and b2.�ɶ�=b1.�ɶ� and b1.���=b2.��� --B23 ���� 
    join cmoney.dbo.�馬�L���Ʀ� c1 on c1.���=b1.��� and c1.�Ѳ��N��=''TWB23''
     join cmoney.dbo.�馬�L���Ʀ� c2 on c2.���=b1.��� and c2.�Ѳ��N��=''TWA23'' --�q�l ���S
	      join cmoney.dbo.�馬�L���Ʀ� d1 on d1.���=b1.��� and d1.�Ѳ��N��=''TWB28''
     join cmoney.dbo.�馬�L���Ʀ� d2 on d2.���=b1.��� and d2.�Ѳ��N��=''TWA28'' --���ĳ��S
	 where b1.�Ѳ��N��=''TWB23'' and b1.���=@t --B23 �q�l 
	 
group by b1.���
) y on x.TxDate=y.���
where x.Txdate=@t
order by x.Txdate
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�D�޳�����Table]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�D�޳�����Table', 
		@step_id=31, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


delete pl.[dbo].[�����D�޳���_�s���榡Table]
insert pl.[dbo].[�����D�޳���_�s���榡Table]
select *
from pl.[dbo].[�����D�޳���_�s���榡_MD](@t)


delete pl.[dbo].[���쥫��_Delta_HedgeTable]
insert pl.[dbo].[���쥫��_Delta_HedgeTable]
select *
from pl.[dbo].[���쥫��_Delta_Hedge](@t)


delete PL.dbo.���I����_�|�p�l�q�`�Btable
insert PL.dbo.���I����_�|�p�l�q�`�Btable
select *
FROM PL.dbo.���I����_�|�p�l�q�`�B(@t)

delete PL.dbo.���I����_�|�pDeltatable
insert PL.dbo.���I����_�|�pDeltatable
select *
FROM PL.dbo.���I����_�|�pDelta(@t)

delete pl.dbo.[�l�ӹq��SWIMBDTable]
insert pl.dbo.[�l�ӹq��SWIMBDTable]
select * 
from pl.dbo.[�l�ӹq��SWIMBD]() 
order by Txdate

delete PL.dbo.[�l�q����_�v�ҥ���O��table] where TxDate=@t
insert PL.dbo.[�l�q����_�v�ҥ���O��table] 
select *
from PL.dbo.[�l�q����_�v�ҥ���O��](@t) order by [Trader]

exec PL.[dbo].[�l�ӹq��SWIMBD���_Rolling]

delete pl.dbo.[Gary_BD_�|�����_Rolling_2018_tab]
insert pl.dbo.[Gary_BD_�|�����_Rolling_2018_tab]
exec pl.dbo.[Gary_BD_�|�����_Rolling_2018]

delete pl.[dbo].[Gary_BD_�|�����_Rolling_���S�v_2018_tab]
insert pl.[dbo].[Gary_BD_�|�����_Rolling_���S�v_2018_tab]
exec pl.[dbo].[Gary_BD_�|�����_Rolling_���S�v_2018]

delete pl.[dbo].[CBVolTrade���_Rolling_Table]
insert pl.[dbo].[CBVolTrade���_Rolling_Table]
exec  Pl.dbo.CBVolTrade���_Rolling

delete pl.dbo.WPU30BD_rolling_table
insert pl.dbo.WPU30BD_rolling_table
exec  pl.dbo.WPU30BD_rolling

exec DailyInsert.dbo.CB_CB�l�q�p���Table


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�|�p�l�q��b]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�|�p�l�q��b', 
		@step_id=32, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec PL.dbo.�|�p�l�q��b'''','''',''2''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro_�϶��v��BreakDown]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro_�϶��v��BreakDown', 
		@step_id=33, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Pro_�϶��v��BreakDown', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB_CBImpVol]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB_CBImpVol', 
		@step_id=34, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec [DailyInsert].dbo.[CB_CBImpVol] @t
exec [DailyInsert].[dbo].[CB_CB�L����IV] @t
end
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_MTM�����l�q]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_MTM�����l�q', 
		@step_id=35, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.PL_MTM�����l�q @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v���`�b�ײv]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v���`�b�ײv', 
		@step_id=36, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec [DailyInsert].dbo.[PL_����Book�l�q�t�Z] @t
exec [DailyInsert].dbo.PL_TGIndex @t
exec DailyInsert.dbo.PL_�v���`�b�ײv
exec DailyInsert.dbo.PL_�v���`�b�ײv_2016
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Theodata_�C��IntraVol]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Theodata_�C��IntraVol', 
		@step_id=37, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec [DailyInsert].dbo.Theodata_�C��IntraVol @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_InventoryBase]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_InventoryBase', 
		@step_id=38, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'  declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


exec DailyInsert.dbo.PL_InventoryBase @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ETFBreakDown]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ETFBreakDown', 
		@step_id=39, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
  exec DailyInsert.dbo.PL_ETF�C��Deallist_����R @t
  exec DailyInsert.dbo.[PL_ETF�C��Breakdown_����R] @t


exec DailyInsert.dbo.[PL_ETF�C��DeallistNew] @t
exec DailyInsert.dbo.[PL_ETF�C��DeallistNew7] @t
exec DailyInsert.dbo.[PL_ETF�C��DeallistNew_Sam] @t
exec DailyInsert.dbo.PL_Inventory_ETFOpenDelta @t,''2''
exec DailyInsert.dbo.PL_Inventory_ETFOpenDelta_Sam @t,''2''

exec [DailyInsert].dbo.[PL_ETF�C��Breakdown�Ӷ�_�����鷸��New] @t
exec DailyInsert.dbo.PL_ETF�C��Breakdown_�����鷸��New @t
exec [DailyInsert].dbo.[PL_ETF�C��Breakdown�Ӷ�7_�����鷸��New] @t
exec DailyInsert.dbo.PL_ETF�C��Breakdown7_�����鷸��New @t
exec DailyInsert.[dbo].[PL_ETF�C��Breakdown�Ӷ�_�����鷸��New_Sam] @t
exec DailyInsert.dbo.[PL_ETF�C��Breakdown_�����鷸��New_Sam] @t
end



exec pl.dbo.�Ũ�ETFBD_�Ũ鳡
exec pl.dbo.�Ũ�ETFBD_�l�ӳ�', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���ƫ����t�I�Ʀ���]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���ƫ����t�I�Ʀ���', 
		@step_id=40, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec dailyInsert.dbo.DBMain_�C�鰣�v���I�ƹw�� @t
exec dbmain.dbo.[�������v�ƹw��_���P�зǮt] @t
exec dbmain.dbo.[�������v�ƹw��_���P�зǮt_����] @t
exec dbmain.dbo.[�������v�ƹw��_���P�зǮt_�g����] @t
exec dbmain.dbo.[�������v�ƹw��_���P�зǮt_����_�g����] @t

exec Dbmain.[dbo].[�������v�ƹw��_���P�зǮt0050] @t
exec Dbmain.[dbo].[�������v�ƹw��_���P�зǮtMSCI] @t

exec [DailyInsert].dbo.[DBMain_���ƫ�_���f�I��] @t
exec [DailyInsert].dbo.[DBMain_���ƫ�_�����I��] @t
exec [DailyInsert].dbo.DBMain_���ƫ�_�v���I�Ʀ��� @t

exec [DailyInsert].dbo.DBMain_���ƫ�_�v���I�Ʀ���_�����v�� @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�v�����I���f���t�l�q]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�v�����I���f���t�l�q', 
		@step_id=41, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].PL_�v�����I���f���t�l�q @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [z_�v�����˫���]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'z_�v�����˫���', 
		@step_id=42, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
exec DailyInsert.dbo.z_�v�����˫��� @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�v�ҨC��Markup]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�v�ҨC��Markup', 
		@step_id=43, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.[PL_�v�ҨC��Markup] @t
exec [DailyInsert].dbo.[PL_�v�ҨC��Markup_����] @t

exec [DailyInsert].[dbo].[PL_���f���t�l�qT] @t
exec [DailyInsert].[dbo].[PL_WBreakDown_���鳡��] @t


exec [DailyInsert].[dbo].[PL_�v�ҨC��Slippage_����] @t
exec [DailyInsert].[dbo].[PL_WBreakDown_���鳡��_����] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [trade_DB_400������]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'trade_DB_400������', 
		@step_id=44, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.trade_DB_400������', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�ۮa�v�ҥ[�v����Vol]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�ۮa�v�ҥ[�v����Vol', 
		@step_id=45, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.[FrontDeskW_�ۮa�v�ҥ[�v����Vol] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_��t�M�Q���ѥ��Ȥ�]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_��t�M�Q���ѥ��Ȥ�', 
		@step_id=46, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
DECLARE @h INT = DATEPART(hour, GETDATE())

IF @h >= 17
BEGIN
-- �ݭn ETF���ѩ��Ӫ�
if @t = (select max(���) from cmoney.dbo.ETF���ѩ��Ӫ�)
begin

  exec DailyInsert.dbo.PL_�����t�M�Q�j���pRetDiff @t

end
exec [DailyInsert].dbo.[PL_��t�M�Q���ѥ��Ȥ�] @t

end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����vTrading�l�q]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����vTrading�l�q', 
		@step_id=47, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.PL_����vTrading�l�q @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_WarrantProfileTS_Daily]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_WarrantProfileTS_Daily', 
		@step_id=48, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date =(select max(stadate) from pl.dbo.inventory)
Exec DailyInsert.dbo.DBMain_�v�ҵo��s����s @t



delete dbmain.dbo.WarrantProfileTS_Group where issuedate=@t
if year(@t) >= ''2017''
begin
  insert dbmain.dbo.WarrantProfileTS_Group
  select WarrantKey, ''2016'', WarranTID,Issuedate,Expireddate
  from dbmain.dbo.warrantprofilets
  where Issuedate=@t
end
else
begin
  insert dbmain.dbo.WarrantProfileTS_Group
  select WarrantKey, datepart(yy,issuedate) , WarranTID,Issuedate,Expireddate
  from dbmain.dbo.warrantprofilets
  where Issuedate=@t
end
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C������_���׬O�_������鳣���ݰ���]    Script Date: 2019/5/15 �W�� 09:23:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C������_���׬O�_������鳣���ݰ���', 
		@step_id=49, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--declare @t datetime set @t=convert(varchar(20),getdate(),111)
--declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

declare @h int = DATEPART(hour, GETDATE())
declare @t datetime set @t= (select case when @h<15 then (convert(varchar(20),dateadd(dd,-1,getdate()),111)) else convert(varchar(20),getdate(),111) end)

exec DailyInsert.dbo.Web_tbl����ռ��ӽ� @t

exec [DailyInsert].dbo.[PL_����ռ���J] @t

exec DailyInsert.dbo.���j��H�٨����ռ� ''''

exec Dailyinsert.dbo.pl_db75�ϥθ���l�B @t
exec DailyInsert.dbo.PL_������_���� @t
exec DailyInsert.dbo.PL_������_���� @t
exec DailyInsert.dbo.PL_������_�Ũ� @t
exec DailyInsert.dbo.PL_������_�l�Ӧ��� @t
exec DailyInsert.dbo.PL_������_�l�� @t
exec DailyInsert.dbo.PL_������_����G�� @t

exec DailyInsert.dbo.PL_������_�վ��X  @t

--exec [TestPA].[dbo].[Pa_PL_������]  @t

exec  [TestPA].[dbo].[�|�p_���٨�O��]  @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150713, 
		@active_end_date=99991231, 
		@active_start_time=154000, 
		@active_end_time=235959, 
		@schedule_uid=N'3677a153-df3a-499b-b390-a267d4906762'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#2', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150715, 
		@active_end_date=99991231, 
		@active_start_time=172500, 
		@active_end_time=235959, 
		@schedule_uid=N'd22b28c4-915a-4c37-876b-51fbec73f876'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#3', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170113, 
		@active_end_date=99991231, 
		@active_start_time=223000, 
		@active_end_time=235959, 
		@schedule_uid=N'ad6e7621-317b-4c3d-bab0-da6d6ab6acbb'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�۰ʶ]�b(Night Session)]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�۰ʶ]�b(Night Session)', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ˬd�O�_�������]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ˬd�O�_�������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���f_�C���`�b_��x��J]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���f_�C���`�b_��x��J', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date = convert(date, getdate())
declare @y date set @y =DBMain.dbo.tradingdateadd(-1,@t)
exec [DailyInsert].[dbo].[PL_���f_�C���`�b_��x��J] @y
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�������]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�������', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date = convert(date, getdate())

EXEC DailyInsert.dbo.PL_Deallist_NightSession @t
EXEC [DailyInsert].[dbo].[PL_Deallist_InsertTrade_�L��] @t', 
		@database_name=N'PL', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���f����򥻸�ƨC��]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���f����򥻸�ƨC��', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from Cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec testpa.[dbo].[���f����򥻸�ƨC��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TEJ to 192]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TEJ to 192', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
delete db192.[MarketData].[dbo].[TEJ���Ʀ����ѪѼ�] where �~���=@t
insert db192.[MarketData].[dbo].[TEJ���Ʀ����ѪѼ�]
select * 
from [MarketData].[dbo].[TEJ���Ʀ����ѪѼ�]
where �~���=@t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20161104, 
		@active_end_date=99991231, 
		@active_start_time=83500, 
		@active_end_time=235959, 
		@schedule_uid=N'ac4b6b0b-73f2-4001-bb86-997dd0bb4fde'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�C������Ƨ�s]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�C������Ƨ�s', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Stock Warrant Future', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tradingdate]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblDailyStockInfo]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblDailyStockInfo', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyStockInfo]
GO

INSERT INTO [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyStockInfo]
([DayDate]
      ,[StockId]
      ,[StockName]
      ,[MarketType]
      ,[IsDayTrade]
      ,[IsHasFutureOption]
      ,[IsETF])
SELECT [DayDate]
      ,[StockId]
      ,[StockName]
      ,[MarketType]
      ,[IsDayTrade]
      ,0
      ,0
FROM [Trade_DB].[dbo].[tblDailyStockInfo];
GO

update [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyStockInfo]
set [IsHasFutureOption] = 1
where [StockId] in (select underlyingId from [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyFutures])
GO

update [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyStockInfo] 
set IsETF = 1
where [StockId] in (select [�N��] from [Cmoney].[dbo].[ETF�򥻸��])
GO
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblDailyFutures]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblDailyFutures', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyFutures]
GO

INSERT INTO [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyFutures]
([DayDate]
           ,[FutureId]
           ,[CmoneyId]
           ,[FutureName]
           ,[UnderlyingId]
           ,[UnderlyingName]
           ,[MaturityDay]
           ,[ContractRatio]
		   ,[FutureType])
SELECT [DayDate]
           ,[FutureId]
           ,[CmoneyId]
           ,[FutureName]
           ,[UnderlyingId]
           ,[UnderlyingName]
           ,[MaturityDay]
           ,[ContractRatio]
		   ,0
FROM [Trade_DB].[dbo].[tblDailyFutures]
GO

update [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyFutures]
set [UnderlyingId] = ''TWA00''
where [UnderlyingName] = ''�[�v����'' and [FutureId] like ''TXF%''
GO

update [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyFutures]
set [FutureType] = 1
where [UnderlyingId] in (select [StockId] from [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyStockInfo])
GO

update [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyFutures]
set [FutureType] = 1
where [UnderlyingId] in (select [StockId] from [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyStockInfo] where [IsETF] = 1)', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblDailyWarrantInfo]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblDailyWarrantInfo', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyWarrantInfo]
GO

INSERT INTO [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyWarrantInfo]
([DayDate]
      ,[WarrantId]
      ,[WarrantName]
      ,[StockId]
      ,[StockName]
      ,[CallPut]
      ,[Issuer]
      ,[LastTranDay]
      ,[MaturityDay]
      ,[TradeDays]
      ,[Days]
      ,[StrikePrice]
      ,[ExerciseRatio]	
      ,[Rho]
      ,[VolM]
      ,[MarketType]
      ,[IsSelf])
SELECT [DayDate]
      ,[WarrantId]
      ,[WarrantName]
      ,[StockId]
      ,[StockName]
      ,[CallPut]
      ,[Issuer]
      ,[LastTranDay]
      ,[MaturityDay]
      ,[TradeDays]
      ,[Days]
      ,[StrikePrice]
      ,[ExerciseRatio]
      ,[Rho]
      ,[VolM]
      ,[MarketType]
      ,[IsSelf]
FROM [Trade_DB].[dbo].[tblDailyWarrantInfo3];
GO


DELETE FROM [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyWarrantInfo]
WHERE [StockId] IN (''1101'', ''1313'', ''1453'', ''2408'', ''2707'', ''2801'', ''2812'', ''2850'', ''2887'', ''2888'', ''2911'', ''3376'', ''5203'', ''5388'', ''5706'', ''6285'', ''8163'', ''9908'', ''9925'', ''9926'', ''3452'', ''3615'', ''4174'', ''4198'', ''4739'', ''4933'', ''5438'', ''6125'', ''6173'', ''8048'')
GO


DELETE FROM [DB39].[ProprietaryTrading_DB].[dbo].[tblDailyWarrantInfo]
WHERE [Issuer] = ''%�ثn%''
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'��s���', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=4, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151223, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=81600, 
		@schedule_uid=N'dfaa4c60-aac6-4f03-af5e-78b2755c37a7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�C�g��Χ@�~]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�C�g��Χ@�~', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�M����Ʈw�̤��|�A�ϥΨ쪺���

�åB�����Ʈw���Y�A����

�ƥ���Ʈw�y�z�y��', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�M�����|�Ψ쪺�¸��]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�M�����|�Ψ쪺�¸��', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- Web �M Cmoney ���ƪ�����

--DELETE FROM Web.dbo.�C�馬�L��T73 WHERE ��� <= DBMain.dbo.Tradingdateadd(-7, GETDATE())
DELETE FROM Web.dbo.���f����污�� WHERE ��� <= DBMain.dbo.Tradingdateadd(-7, GETDATE())
DELETE FROM Web.dbo.tblPCStatus WHERE [Date] <= DBMain.dbo.Tradingdateadd(-30, GETDATE())


DECLARE @ed DATE = DBMain.dbo.TradingdateAdd(-30, GETDATE())
  delete we
  from web.dbo.�~����f���L�� we
  left join dbmain.dbo.���~���f�N����Ӫ� re on re.�����N�� = we.[contract] and we.txtime = re.���L��Time
  where txdate <= @ed and re.�污�N�� is null

DELETE FROM Web.dbo.�C����ETF�ײv_���j
WHERE TxDate <= @ed', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [��Ʈw��z Web]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'��Ʈw��z Web', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Web
GO

DECLARE @T DATE = GETDATE()
DECLARE @Y DATE = DBMain.dbo.TradingdateAdd(-7, @T)

DELETE FROM Web.dbo.���f����污�� WHERE ���<=@Y

USE Web
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Web_log'', @logsize)
GO

USE Web
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Web'', @filesize)
GO
', 
		@database_name=N'Web', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Accounting]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Accounting', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Accounting
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Accounting_log'', @logsize)
GO

USE Accounting
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Accounting'', @filesize)
GO
', 
		@database_name=N'Accounting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ATP]    Script Date: 2019/5/15 �W�� 09:23:40 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ATP', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE ATP
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''ATP_log'', @logsize)
GO

USE ATP
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''ATP'', @filesize)
GO', 
		@database_name=N'ATP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE CB
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''CB_log'', @logsize)
GO

USE CB
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''CB'', @filesize)
GO', 
		@database_name=N'CB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Cmoney
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Cmoney_log'', @logsize)
GO

USE Cmoney
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Cmoney'', @filesize)
GO', 
		@database_name=N'Cmoney', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Credit]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Credit', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Credit
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Credit_log'', @logsize)
GO

USE Credit
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Credit'', @filesize)
GO', 
		@database_name=N'Credit', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyInsert]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyInsert', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE DailyInsert
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''DailyInsert_log'', @logsize)
GO

USE DailyInsert
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''DailyInsert'', @filesize)
GO', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE DBMain
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''DBMain_log'', @logsize)
GO

USE DBMain
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''DBMain'', @filesize)
GO', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE FrontDeskW
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''FrontDeskW_log'', @logsize)
GO

USE FrontDeskW
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''FrontDeskW'', @filesize)
GO', 
		@database_name=N'FrontDeskW', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday]    Script Date: 2019/5/15 �W�� 09:23:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Intraday
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Intraday_log'', @logsize)
GO

USE Intraday
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Intraday'', @filesize)
GO', 
		@database_name=N'Intraday', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE MarketData
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''MarketData_log'', @logsize)
GO

USE MarketData
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''MarketData'', @filesize)
GO
', 
		@database_name=N'MarketData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Monitor]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Monitor', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Monitor
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Monitor_log'', @logsize)
GO

USE Monitor
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Monitor'', @filesize)
GO', 
		@database_name=N'Monitor', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Myproject]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Myproject', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE MyProject
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''MyProject_log'', @logsize)
GO

USE MyProject
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''MyProject'', @filesize)
GO', 
		@database_name=N'Myproject', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OperationDesk]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OperationDesk', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE OperationDesk
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''OperationDesk_log'', @logsize)
GO

USE OperationDesk
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''OperationDesk'', @filesize)
GO', 
		@database_name=N'OperationDesk', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE PL
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''PL_log'', @logsize)
GO

USE PL
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''PL'', @filesize)
GO', 
		@database_name=N'PL', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Pro
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Pro_log'', @logsize)
GO

USE Pro
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Pro'', @filesize)
GO
', 
		@database_name=N'Pro', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ronald]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ronald', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Ronald
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Ronald_log'', @logsize)
GO

USE Ronald
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Ronald'', @filesize)
GO', 
		@database_name=N'Ronald', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestDB]    Script Date: 2019/5/15 �W�� 09:23:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestDB', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE TestDB
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''TestDB_log'', @logsize)
GO

USE TestDB
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''TestDB'', @filesize)
GO', 
		@database_name=N'TestDB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestPA]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestPA', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE TestPA
GO

DECLARE @t DATE = GETDATE()
DECLARE @m DATE = DBMain.dbo.TradingdateAdd(-30, @t)

DELETE TestPA.dbo.Pa_PL_�ɨ�_�C��i�ɪѼ�
WHERE StaDate <= @m


-- DBCC
USE TestPa
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''TestPA_log'', @logsize)
GO

USE TestPa
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''TestPA'', @filesize)
GO
', 
		@database_name=N'TestPA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TheoData]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TheoData', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE TheoData
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''TheoData_log'', @logsize)
GO

USE TheoData
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''TheoData'', @filesize)
GO', 
		@database_name=N'TheoData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tick]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tick', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Tick
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Tick_log'', @logsize)
GO

USE Tick
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Tick'', @filesize)
GO', 
		@database_name=N'Tick', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Vix]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Vix', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Vix
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Vix_log'', @logsize)
GO

USE Vix
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Vix'', @filesize)
GO', 
		@database_name=N'Vix', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE Z
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''Z_log'', @logsize)
GO

USE Z
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''Z'', @filesize)
GO', 
		@database_name=N'Z', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IDDataTransfer]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IDDataTransfer', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- DBCC
USE IDDataTransfer
DECLARE @logsize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid<>1 )
DBCC SHRINKFILE(N''IDDataTransfer_log'', @logsize)
GO

USE IDDataTransfer
DECLARE @filesize int = (SELECT (convert(float,fileproperty(name,''SpaceUsed''))) * (8192.0/1048576) + 1000 FROM sysfiles WHERE fileid=1 )
DBCC SHRINKFILE(N''IDDataTransfer'', @filesize)
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [��Ʈw�y�z�y���ƥ�]    Script Date: 2019/5/15 �W�� 09:23:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'��Ʈw�y�z�y���ƥ�', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- �ƥ�
--EXEC xp_cmdshell ''powershell.exe C:\�P�B�ƥ�\��Ʈw�y�z�y���ƥ�.ps1''

-- �P�B
--EXEC xp_cmdshell ''powershell.exe C:\�P�B�ƥ�\�P�B�ƥ�.ps1''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'temp', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180822, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'2052d362-90f6-46ff-b415-8fe03b7ecab4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�g', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160804, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'76ba4b7a-b321-4625-b7f3-161ba90c6531'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�x���������]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�x���������', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�x���������', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_���u�ȵ���}����]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_���u�ȵ���}����', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


exec [DailyInsert].dbo.[FrontDeskW_���u�ȵ���}����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFChoice]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFChoice', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC IDDataTransfer.dbo.Choice default', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFMAStrategy]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFMAStrategy', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC IDDataTransfer.dbo.MAStrategy default', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFMarket]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFMarket', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC IDDataTransfer.dbo.Market default', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrantInfo]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrantInfo', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC IDDataTransfer.dbo.WarrantInfo default', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFValueWarrant]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFValueWarrant', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC IDDataTransfer.dbo.ValueWarrant', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrPrice]    Script Date: 2019/5/15 �W�� 09:23:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrPrice', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--EXEC IDDataTransfer.dbo.WarrPrice default
--2018/7/26 ����
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFTopWarrants]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFTopWarrants', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.TopWarrants @t', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrantsRateInfo]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrantsRateInfo', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.WarrantsRateInfo @t', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrantsStrategy]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrantsStrategy', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.WarrantsStrategy @t
', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrantsStrategy_Data]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrantsStrategy_Data', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.WarrantsStrategy_Data @t
', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFHotInfo]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFHotInfo', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.HotInfo @t', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFMarketWarrantsRateInfo]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFMarketWarrantsRateInfo', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.MarketWarrantsRateInfo @t
', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFCandlestickChartData]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFCandlestickChartData', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.CandlestickChartData @t', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFLastDayRate]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFLastDayRate', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.LastDayRate @t', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyCloseByWarrant]    Script Date: 2019/5/15 �W�� 09:23:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyCloseByWarrant', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC IDDataTransfer.dbo.DailyCloseByWarrant', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SBLLIMIT]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SBLLIMIT', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
delete [IDDataTransfer].dbo.SBLLimit
insert [IDDataTransfer].dbo.SBLLimit
select * from Monitor.dbo.�s�X�ɨ�O�Ҫ����B
where @t between Bdate and Edate', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrantInfo2]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrantInfo2', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC IDDataTransfer.dbo.WarrantInfo2 @t', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFDailyELN_Data]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFDailyELN_Data', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.FrontDeskW_�v�ҥ������RELN_new  @t

exec DailyInsert.dbo.FrontDeskW_�v�ҥ������RELN_new_US  @t

exec IDDataTransfer.dbo.DailyELN_Data @t
', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IFWarrantWeek]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IFWarrantWeek', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
EXEC IDDataTransfer.dbo.WarrantWeek', 
		@database_name=N'IDDataTransfer', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW1800~2100', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170224, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, 
		@schedule_uid=N'78cba2a8-98fb-4ad4-87df-3c59e30c1a62'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [����L�e]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'����L�e', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Traddingdate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Traddingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�o��O���u]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�o��O���u', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime
 set @t = (select max(���) from  cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.[dbo].[PL_�ۮa�o��O���u] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [W1�g��]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'W1�g��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @today datetime, @y datetime
set @today = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
set @y = dbmain.[dbo].[tradingdateadd](-1,@today)

exec [TestPA].[dbo].[W1_�U�a�o��] @y,''5''    
exec [TestPA].[dbo].[W1_�U�a�o��] @y,''10''
exec [TestPA].[dbo].[W1_�U�a�o��] @y,''15''', 
		@database_name=N'TestPA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [W3�g��]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'W3�g��', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @today1 datetime
set @today1 = (select max(���) from cmoney.dbo.�v�ҵ�����)
exec [TestPA].[dbo].[W3_��ӨC��] @today1 ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'����L�e', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150813, 
		@active_end_date=99991231, 
		@active_start_time=75500, 
		@active_end_time=235959, 
		@schedule_uid=N'ff5c68df-977d-43cc-ac2a-ae5283fe7d24'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [����L�e00]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'����L�e00', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Traddingdate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Traddingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�L�e��IT]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�L�e��IT', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec testpa.[dbo].[���f�򥻸����IT] ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'����L�e00', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151110, 
		@active_end_date=99991231, 
		@active_start_time=81500, 
		@active_end_time=235959, 
		@schedule_uid=N'fbc36c4e-b146-49ef-98ed-f0e5780e9939'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [����L��_�D�޳���]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'����L��_�D�޳���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Traddingdate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Traddingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�D�޳�����ӥ����v]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�D�޳�����ӥ����v', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec TestPA.[dbo].[Pa_�D�޳���_��ӥ����v����3] @t
--exec TestPA.[dbo].[Pa_�D�޳���_��ӥ����v����4] @t
exec DailyInsert.[dbo].[MarketData_��ӧN���v���ɼ�] @t
exec DailyInsert.[dbo].[MarketData_��Ӽ����v���ɼ�] @t


exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdatePL @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdateTV @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o���ɼ�] @t
', 
		@database_name=N'TestPA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontdeskW_�v�ҼЪ���TraderBE]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontdeskW_�v�ҼЪ���TraderBE', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t=getdate()
exec DailyInsert.dbo.[FrontdeskW_�v�ҼЪ���TraderBE] @t,''0''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�L��D�޳���', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151228, 
		@active_end_date=99991231, 
		@active_start_time=191000, 
		@active_end_time=235959, 
		@schedule_uid=N'65bf33c2-4de3-4a6c-9393-2e564a268aa9'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [����L��00]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'����L��00', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [traddingdate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'traddingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C����٨���ӶפJ]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C����٨���ӶפJ', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [TestPA].[dbo].[�|�p_���٨�_�������_����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_�v�ҼЪ����v���򥻸���ܧ�]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_�v�ҼЪ����v���򥻸���ܧ�', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATE = GETDATE()

EXEC DailyInsert.[dbo].[DBMain_�v�ҼЪ����v���򥻸���ܧ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�L��1710', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151228, 
		@active_end_date=99991231, 
		@active_start_time=171000, 
		@active_end_time=235959, 
		@schedule_uid=N'b5501f9e-3f0c-4ef8-87ce-247f3965a712'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�L��2100', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160712, 
		@active_end_date=99991231, 
		@active_start_time=210000, 
		@active_end_time=235959, 
		@schedule_uid=N'9e17746f-085a-457e-89a1-09f083ab37c4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [���~���f0600]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'���~���f0600', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���~���f0600]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���~���f0600', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATEtime set @t =convert (nvarchar(12),dateadd(d, -1, getdate()),112)
--select convert (nvarchar(12),dateadd(d, -1, getdate()),112))

EXEC DailyInsert.dbo.Cmoney_�~����f����污��_���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'���~���f0600', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190129, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'1700f800-27b2-49ba-be29-656934c395ae'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [��~�l�q�C��]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'��~�l�q�C��]', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���~���f����]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���~���f����', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime = (SELECT CONVERT(varchar(100), GETDATE(), 111))

exec DailyInsert.dbo.Cmoney_�~����f����污��_�C�� @t,''0''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����Bfunding_����]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����Bfunding_����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime = (SELECT CONVERT(varchar(100), GETDATE(), 111))
exec [DailyInsert].[dbo].[PL_����Bfunding_D_����table] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�l�q]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�l�q', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime = (SELECT CONVERT(varchar(100), GETDATE(), 111))
exec DailyInsert.dbo.PL_DailyPLReport_��~ @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѧ��W9�I�]', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190430, 
		@active_end_date=99991231, 
		@active_start_time=90000, 
		@active_end_time=235959, 
		@schedule_uid=N'5c0bbcf1-551d-40e3-942d-12d308a95595'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [���������]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'���������]', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB Index ����]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB Index ����', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�C�馬�L��T73)

exec Dailyinsert.[dbo].[Z_�]�����ƿ��] @t
exec DailyInsert.dbo.[Z_�]�����ƿ��addPUGBAll] @t
exec DailyInsert.dbo.Z_�]�����ƿ��add�V�� @t
exec DailyInsert.dbo.Z_�]�����ƿ��add�V��Karen @t

exec DailyInsert.dbo.Z_EVEBITDA���q���� @t
 exec [DailyInsert].dbo.[Z_EVEBITDA���q���ȵ��G] @t
--exec DailyInsert.dbo.[PL_Deallist_�l�Ӧ���] @t
--exec DailyInsert.dbo.[PL_Inventory_�l�Ӧ���] @t
--exec DailyInsert.dbo.[PL_Inventory_�l�Ӧ���_���] @t
--exec DailyInsert.dbo.[PL_�D�޾����O��_�l�Ӧ���] @t
--exec DailyInsert.dbo.[PL_DailyPLReport_�l�Ӧ���] @t
--exec DailyInsert.dbo.[PL_DailyPLReport_�l�Ӧ���_���] @t
exec [DailyInsert].dbo.[PL_ETFPortfolio�z�׷l�q] @t
exec  [DailyInsert].[dbo].[CB_CBDelta�C��] @t


 -- exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�� @t
 --exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����G @t
--exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業�����Gtop100] @t


-- exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業��old @t
--exec DailyInsert.dbo.FrontDeskW_CBIndex�W�g����q�z��²�業�����Gold @t
--exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業�����Gtop100old] @t


exec DailyInsert.[dbo].[CB_CB�Ѳ�����l�q] @t
exec [DailyInsert].dbo.[CB_CB�Ѳ�����l�q_���] @t
exec [DailyInsert].[dbo].[CB_�϶����B���_�@�뫬] @t

exec [DailyInsert].dbo.FrontDeskW_AH_RS���f�C30����
exec Dailyinsert.dbo.Proc_QD_May_CBIndex_20180206', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [WSim�V��30���v��]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'WSim�V��30���v��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @�~�u nvarchar(50) set @�~�u=(select max(�~�u) from z.[dbo].[�]�����ƿ��] where Tag=''�j�L_Q'')


exec DailyInsert.dbo.Z_WPU30_WSim�V��30���v��_���ޭɨ� @�~�u
exec DailyInsert.dbo.Z_WPU30_WSim�V��30���v��_���ޭɨ�_��ڪ��p @�~�u
exec DailyInsert.dbo.Z_WPU30_WSim�V��30���v��_���ޭɨ�_6M�B���@�� @�~�u
exec DailyInsert.dbo.Z_WPU30_WSim�V��GB30���v��_���ޭɨ� @�~�u

exec DailyInsert.dbo.Z_WPU30_WSim�V��30���v��_S�i�X @�~�u
exec DailyInsert.dbo.Z_WPU30_WSim�V��30���v��_��ڪ��p @�~�u

exec DailyInsert.dbo.Z_WPU30_WSim�V��30���v��_��ڪ��p_6M�B���@�� @�~�u', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�T�{������inventory', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161103, 
		@active_end_date=99991231, 
		@active_start_time=171000, 
		@active_end_time=235959, 
		@schedule_uid=N'fc5aa89d-16f8-49fb-ab0e-f1c9c20617b4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [����ADR_TestPA�Q��]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'����ADR_TestPA�Q��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�q����ADR�ԥX�ӡA���L�����]�|�p�b�����l�q', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���~�Q�� TestPA]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���~�Q�� TestPA', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [TestPA].[dbo].[�|�p��ذ���_����] @t
exec [TestPA].[dbo].[�|�p��ذ���_����] @t
exec [TestPA].[dbo].[�|�p��ذ���_�l�Ӧ���] @t

--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_���ĥ���B] @t

exec [TestPA].[dbo].[pa_�|�p�l�q�C��_����] @t
exec [TestPA].[dbo].[pa_�|�p�l�q�C��_����] @t
exec [TestPA].[dbo].[pa_�|�p�l�q�C��_�l�Ӧ���] @t

--exec [TestPA].[dbo].[TestPA_Daily_�~PL] @t

exec  [TestPA].[dbo].[�|�p_���٨�O��]  @t

--exec [TestPA].[dbo].[Pa_PL_������]  @t

exec testpa.[dbo].[Pa_pa_�U������l�q]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѤU��2:30', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20181112, 
		@active_end_date=99991231, 
		@active_start_time=143000, 
		@active_end_time=235959, 
		@schedule_uid=N'92aef2c3-8a8e-4974-8f5b-d750b626c016'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [����ADR�l�q]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'����ADR�l�q', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�פJ�ײv���]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�פJ�ײv���', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t =(select max(Stadate) from pl.dbo.Inventory)
--(select max(DR_Date) from [DB75].[IntraWeb].[dbo].[DailyRate])
delete Cmoney.dbo.�x�s�Ȧ�C��ײv where ���=@t

insert Cmoney.dbo.�x�s�Ȧ�C��ײv
select * from [DB75].[IntraWeb].[dbo].[DailyRate]
 where DR_Date=@t
 order by DR_currency

/*
select ���,�N��,1/��s�x���ײv from Cmoney.[dbo].[�D�n�q�f�ײv��]
where ���=@t
order by �N��
*/', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����Ʃe�U�����Jinserttrade]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����Ʃe�U�����Jinserttrade', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date=(select Max(Txdate) from pl.dbo.���ĥ���B�����l�q�J���)
exec  dailyinsert.dbo.PL_���f�������_����Ʃe�U @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����ADR�l�q]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����ADR�l�q', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].[dbo].[Cmoney_�~����f����污��_�l�Ӧ���] @t

exec DailyInsert.dbo.[PL_Deallist_����_ADR] @t
exec DailyInsert.dbo.PL_�C��ADR�鷸���� @t
exec DailyInsert.dbo.PL_�C��ADR�鷸���� @t
exec DailyInsert.[dbo].[PL_Inventory_����_ADR] @t
exec DailyInsert.[dbo].[PL_Inventory_����_���_ADR] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_����] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����_ADR] @t
exec DailyInsert.dbo.[PL_DailyPLReport_����_���_ADR] @t

exec DailyInsert.dbo.PL_����ADR�t��BD @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [������ѷl�q]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'������ѷl�q', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


 exec DailyInsert.[dbo].[PL_Deallist_����_US] @t
 exec DailyInsert.[dbo].[PL_Inventory_����_US] @t
 exec DailyInsert.[dbo].[PL_Inventory_����_���_US] @t

 exec DailyInsert.dbo.[PL_�D�޾����O��_����] @t

exec DailyInsert.[dbo].[PL_DailyPLReport_����_US] @t
 exec DailyInsert.[dbo].[PL_DailyPLReport_����_���_US] @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�l�Ӯ��~��ETF�l�q]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�l�Ӯ��~��ETF�l�q', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.[PL_Deallist_�l�Ӧ���_US] @t
exec DailyInsert.dbo.PL_�C��ADR�鷸���� @t
exec DailyInsert.dbo.PL_�C��ADR�鷸���� @t
exec DailyInsert.[dbo].[PL_Inventory_�l�Ӧ���_US] @t
exec DailyInsert.[dbo].[PL_Inventory_�l�Ӧ���_���_US] @t
exec DailyInsert.dbo.[PL_�D�޾����O��_�l�Ӧ���] @t
exec DailyInsert.dbo.[PL_DailyPLReport_�l�Ӧ���_US] @t
exec DailyInsert.dbo.[PL_DailyPLReport_�l�Ӧ���_���_US] @t



delete db192.pl.dbo.DailyPLReport_�l�Ӧ���
insert db192.pl.dbo.DailyPLReport_�l�Ӧ���
select *
from pl.dbo.DailyPLReport_�l�Ӧ���
where Txdate=@t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����B��������������]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����B��������������]', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.[PL_InventoryAlex_Pre]
exec DailyInsert.dbo.PL_InventoryMay4_Pre


exec DailyInsert.dbo.PL_�Ʃe�U�ײv�l�q
--exec [TestPA].[dbo].[�|�p��ذ���_����] @t
--exec [TestPA].[dbo].[�|�p��ذ���_����] @t
--exec [TestPA].[dbo].[�|�p��ذ���_�l�Ӧ���] @t

--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_���ĥ���B] @t

--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_����] @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_����] @t
--exec [TestPA].[dbo].[pa_�|�p�l�q�C��_�l�Ӧ���] @t

--exec [TestPA].[dbo].[TestPA_Daily_�~PL] @t

declare @b datetime,@e datetime,@tt datetime
set @b=@t
set @e=convert(nvarchar(10),getdate(),111)
set @tt=@b
while @tt<@e
  begin
  --print(@tt)
exec Dailyinsert.dbo.pl_db75�ϥθ���l�B @tt
exec DailyInsert.dbo.PL_������_���� @tt
exec DailyInsert.dbo.PL_������_���� @tt
exec DailyInsert.dbo.PL_������_�l�Ӧ��� @tt
exec DailyInsert.dbo.PL_������_�վ��X  @tt
  set @tt=dateadd(dd,1,@tt)
  end
----exec [TestPA].[dbo].[Pa_PL_������]  @t
--exec  [TestPA].[dbo].[�|�p_���٨�O��]  @t

exec [DailyInsert].[dbo].PL_���ĥ���B�����l�q�J��� @t
exec [DailyInsert].[dbo].PL_���R�ֿn�l�q�C�� @t
--exec testpa.[dbo].[Pa_pa_�U������l�q]

exec DailyInsert.dbo.PL_�D�޳���_�U�����l�q���S�v
exec [DailyInsert].[dbo].PL_PHP_�C��U���l�q���p @t
exec [DailyInsert].[dbo].PL_����B�J���_MD @t

exec DailyInsert.dbo.PL_����ADR�t��BD_�����ײv�l�q @t
exec DailyInsert.dbo.PL_����ADR�t��BD_�����ײv�l�q_New @t

delete pl.[dbo].[�����D�޳���_�s���榡Table]
insert pl.[dbo].[�����D�޳���_�s���榡Table]
select *
from pl.[dbo].[�����D�޳���_�s���榡_MD](@t)', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���I���޸IĲ���v���泡_ADR�M�Q]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���I���޸IĲ���v���泡_ADR�M�Q', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Declare @t date set @t=(select  max(txdate) from pl.dbo.Inventory_���� where acc=''327'')
exec DailyInsert.dbo.PL_���I���޸IĲ���v���泡_ADR�M�Q @t,''Tim''

 exec DailyInsert.[dbo].[PL_���I���޸IĲ���v���泡_US] @t,''Ronald''

exec [DailyInsert].dbo.[Monitor_�C��wĵ�q���M��] @t
exec DailyInsert.dbo.MDoutput_�C��wĵ�q���M�� @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [��~�Q�v�פJ]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'��~�Q�v�פJ', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime = (select max(stadate) from pl.dbo.inventory)
exec DailyInsert.[dbo].[Credit_TermStructure_IRS_GBbootstrap]  @t
exec DailyInsert.dbo.[MDoutput_Php_CBBookRet]

--�~����KMV
exec DailyInsert.dbo.[Theodata_HistoryVol_�~��] @t
exec DailyInsert.[dbo].[Credit_DailyEDF_���y�k] @t
exec DailyInsert.[dbo].[Credit_DailyEDF_���y�k_vol2Y] @t

--Data_Bond_SBPosition.php
exec DailyInsert.[dbo].[MDoutput_Data_Bond_SBPostion_table] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��W��10:05', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170816, 
		@active_end_date=99991231, 
		@active_start_time=100500, 
		@active_end_time=235959, 
		@schedule_uid=N'9bf073f7-4ff2-46ec-9dac-369acfe045b7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��W��8:40', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170817, 
		@active_end_date=99991231, 
		@active_start_time=84000, 
		@active_end_time=235959, 
		@schedule_uid=N'4e667ae3-5b50-475c-a6ce-75c5e1b27188'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�o��H�������|���w��]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:46 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�o��H�������|���w��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�o��H�����p�⤽�|��]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�o��H�����p�⤽�|��', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec testpa.dbo.[�o��H�����p��_���|��] @t
exec testpa.[dbo].[�o��H�����p��_���|��_New] @t
exec testpa.dbo.�C��o��H�����`��_���|�� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѤW��11:02', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170509, 
		@active_end_date=99991231, 
		@active_start_time=110200, 
		@active_end_time=235959, 
		@schedule_uid=N'e43c3494-13ca-45a7-b8c4-c64829cae7ed'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�g��ư���]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�g��ư���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�g�����Ъ��[���all]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�g�����Ъ��[���all', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from [Cmoney].[dbo].[����Ӷi�X�g����])
exec FrontDeskW.dbo.�g�����Ъ��[���all @t
exec FrontDeskW.dbo.�g�����Ъ��[���Call @t
exec FrontDeskW.dbo.�g�����Ъ��[���Put @t

exec FrontDeskW.[dbo].[�g�����Ъ��[����b�R����B]
exec FrontDeskW.[dbo].[�g�����Ъ��[����b�R����BCall]
exec FrontDeskW.[dbo].[�g�����Ъ��[����b�R����BPut]
exec FrontDeskW.dbo.[�g�����Ъ��[��������]
exec FrontDeskW.dbo.[�g�����Ъ��[��������Call]
exec FrontDeskW.dbo.[�g�����Ъ��[��������Put]
exec FrontDeskW.[dbo].[�g�����Ъ��[����ѻ����]
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����Ӷi�X�g����new]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����Ӷi�X�g����new', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t =(select max(���) from Cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.[dbo].[Cmoney_����Ӷi�X�g����new] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�P�@', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=3, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160108, 
		@active_end_date=99991231, 
		@active_start_time=110000, 
		@active_end_time=235959, 
		@schedule_uid=N'3dc010b8-41ff-4707-8c50-6cdca4cfa91b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�Ũ�Q�v����]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�Ũ�Q�v����', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney_��s�x���Q�v�洫�污]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney_��s�x���Q�v�洫�污', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.dbo.Cmoney_��s�x���Q�v�洫�污 @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѥ���12:30', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160107, 
		@active_end_date=99991231, 
		@active_start_time=3000, 
		@active_end_time=235959, 
		@schedule_uid=N'e03883ab-b275-4432-a388-5bfe34cf58ad'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�Ũ鳡���]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�Ũ鳡���', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Ũ鳡����(��Τ�)_�ɤ���]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Ũ鳡����(��Τ�)_�ɤ���', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t = GETDATE()
declare @�����ɳ̤j��� date set @�����ɳ̤j���=(select  max(��Ƥ��) from pl.dbo.[�Ũ鳡����(��Τ�)])

if @�����ɳ̤j��� = DATEADD(day, -1, @t)
begin 
delete pl.dbo.[�Ũ鳡����(��Τ�)] where ��Ƥ��=@t
insert pl.dbo.[�Ũ鳡����(��Τ�)]
select @t, [����渹], [�Ǹ�], [������], [��Τ��], [�Ũ�N��], [�Ũ�W��], [������N��], [�R��O], [������B], [������], [��Ϊ��B], [�Q�v], [����γ~], [����ت�], [�鷽], [�����Q�v], [��������], [����{], [�s�����], [����O], [��ǹ��O], [��������ײv], [����鰣����(�x��)], [������Ϊ��B(�x��)], [����饫��(�x��)], [����{(�x��)], [����{�קI�l�q], [����{(�x��)1], [DV01]
from pl.dbo.[�Ũ鳡����(��Τ�)]
where ��Ƥ��=@�����ɳ̤j���

end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Ũ鳡����_Daily_�ɤ���]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Ũ鳡����_Daily_�ɤ���', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t = GETDATE()

if dbmain.dbo.tradingdateadd(0,@t) <> @t
begin 

	delete pl.dbo.[�Ũ鳡����_Daily] where ��Ƥ��=@t
	insert pl.dbo.[�Ũ鳡����_Daily]
		select @t, [����渹], [�Ǹ�], [������], [��Τ��], [�Ũ�N��], [�Ũ�W��], [������N��], [�R��O], [������B], [������], [��Ϊ��B], [�Q�v], [����γ~], [����ت�], [�鷽], [�����Q�v], [��������], [����{], [�s�����], [����O], [��ǹ��O], [��������ײv], [����鰣����(�x��)], [������Ϊ��B(�x��)], [����饫��(�x��)], [����{(�x��)], [����{�קI�l�q], [����{(�x��)1], [DV01]
		from pl.dbo.[�Ũ鳡����_Daily]
		where ��Ƥ��=dbmain.dbo.tradingdateadd(-1,@t)

end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C��Ů����J&�������_���Ť��q�ť��_�ɤ���]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C��Ů����J&�������_���Ť��q�ť��_�ɤ���', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t=GETDATE()
if dbmain.dbo.tradingdateadd(0,@t) <> @t
begin 
  exec [DailyInsert].dbo.[PL_�C��Ů����J_���Ť��q�ť��] @t
  exec [DailyInsert].dbo.[PL_�C��������_���Ť��q�ť��] @t
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW8000����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180213, 
		@active_end_date=99991231, 
		@active_start_time=200000, 
		@active_end_time=235959, 
		@schedule_uid=N'e3964da1-6d64-4349-a96d-868851c71c70'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�s���y���ѼƦs43]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�s���y���ѼƦs43', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATE = CONVERT(DATE, GETDATE())
SELECT
    1/COUNT(*)
FROM DBMain.dbo.Tradingdate
WHERE Tradingdate = @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB2_Tick_tbl_WrrMMPlcPrms_QV]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB2_Tick_tbl_WrrMMPlcPrms_QV', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.DB2_Tick_tbl_WrrMMPlcPrms_QV @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��1900', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170626, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'b5b7ae7c-f942-4206-9919-3e44cbf67562'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�Ъ��L�����R]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�Ъ��L�����R', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [��J����Ъ��L�����R]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'��J����Ъ��L�����R', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.��J����Ъ��L�����R
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��ߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150513, 
		@active_end_date=99991231, 
		@active_start_time=203000, 
		@active_end_time=235959, 
		@schedule_uid=N'6a40801f-f0d3-498d-975f-f4bfe209deca'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L���Y�ɷl�q_final]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L���Y�ɷl�q_final', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CBAS�l�q���p]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CBAS�l�q���p', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATETIME = (SELECT MAX(���) FROM cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

--�Q�v�פJ
exec [DailyInsert].[dbo].[DBMain_Rate_Swap_rate] @t
--�Q�v���u
exec DailyInsert.dbo.Credit_TermStructure_IRS @t
--���� CBAS�򥻸����J
exec [DailyInsert].[dbo].[DBMain_CBAS_�C��򥻸�ƶפJ] @t
--���⤵��s�@�@ASW �I����
exec [DailyInsert].dbo.DBMain_CBAS_�I���� @t

exec [DailyInsert].[dbo].DBMain_CBASUSRDEPTID @t
-- ASW PL����
exec [DailyInsert].dbo.PL_CBAS_ASW_PL @t
--ASO PL����
exec [DailyInsert].dbo.PL_CBAS_ASO_PL @t

exec [DailyInsert].dbo.PL_CBAS_ASW_PL_YR @t

exec [DailyInsert].[dbo].PL_CBASDailiPLReportMD @t

exec [DailyInsert].[dbo].MDoutput_ASW_DAILY @t

exec [DailyInsert].dbo.[PL_CBAS�C��ֿnPL] @t
exec [DailyInsert].dbo.[PL_CBAS�C��ֿnPL����] @t

exec DailyInsert.dbo.Monitor_CBAS�C��ϥ��B�� @t,''���ĥ���B''
exec DailyInsert.dbo.Monitor_CBAS�C��ϥ��B�� @t,''�Ũ�@��''
exec DailyInsert.dbo.Monitor_CBAS�C��ϥ��B�� @t,''�Ũ�G��''





------20180705 ALIBABA ����CBAS
	--	exec [DailyInsert].[dbo].[DBMain_CBAS_�C��򥻸�ƶפJ_����_alibaba ] @t
	--	exec [DailyInsert].dbo.DBMain_CBAS_�I����_����_alibaba  @t
	--	exec [DailyInsert].dbo.PL_CBAS_ASW_PL_����_alibaba  @t
	--	exec [DailyInsert].dbo.PL_CBAS_ASO_PL_����_alibaba  @t
	--	exec [DailyInsert].dbo.PL_CBAS_ASW_PL_YR_����_alibaba  @t
	--	exec [DailyInsert].[dbo].PL_CBASDailiPLReportMD_����_alibaba  @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Inventory_�L��]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Inventory_�L��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATETIME = (SELECT MAX(���) FROM cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
DECLARE @hubert CHAR(8) = ''J1040040''

EXEC DailyInsert.[dbo].[PL_InventoryMay4] @hubert 
EXEC DailyInsert.[dbo].[PL_Inventory�l�Ӧ���L��] @t, @hubert 
EXEC DailyInsert.[dbo].[PL_InventoryAlex] @t,@hubert 
EXEC DailyInsert.[dbo].[PL_InventoryRonald] @t, @hubert 
EXEC DailyInsert.[dbo].[PL_InventoryDerrick] @t, @hubert 
EXEC DailyInsert.[dbo].[PL_Inventory����G�սL��] @t, @hubert', 
		@database_name=N'TestPA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�L���Y�ɷl�q_fianl]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�L���Y�ɷl�q_fianl', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].[dbo].[PL_�L���Y�ɷl�q_final]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PHP_�C��U���l�q���p_3�I]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PHP_�C��U���l�q���p_3�I', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from Cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec [DailyInsert].[dbo].PL_PHP_�C��U���l�q���p_1500 @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'1520', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180611, 
		@active_end_date=99991231, 
		@active_start_time=155000, 
		@active_end_time=235959, 
		@schedule_uid=N'edb9c7b0-6eea-40ed-a548-c2d540932580'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L���v���[��_3min����@��]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L���v���[��_3min����@��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_InventoryRonald]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_InventoryRonald', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @david nvarchar(20) = ''J1040001''
declare @t datetime = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

EXEC DailyInsert.[dbo].[PL_InventoryRonald] @t, @david', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����May4]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����May4', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.PL_InventoryMay4 ''J1040071''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [[PL_InventoryMay4]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'[PL_InventoryMay4]', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @david CHAR(8) = ''J1040001''

EXEC DailyInsert.[dbo].[PL_InventoryMay4] @david', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Inventory�l�Ӧ���L��]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Inventory�l�Ӧ���L��', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @david CHAR(8) = ''J1040001''
declare @t datetime = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

EXEC DailyInsert.[dbo].[PL_Inventory�l�Ӧ���L��] @t, @david', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_InventoryDerrick]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_InventoryDerrick', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @david CHAR(8) = ''J1040001''
declare @t datetime = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

EXEC DailyInsert.[dbo].[PL_InventoryDerrick] @t, @david', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_InventoryAlex]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_InventoryAlex', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @david CHAR(8) = ''J1040001''
declare @t datetime = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

EXEC DailyInsert.[dbo].[PL_InventoryAlex] @t,@david', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Inventory����G�սL��]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Inventory����G�սL��', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @david CHAR(8) = ''J1040001''
declare @t datetime = (select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

EXEC DailyInsert.[dbo].[PL_Inventory����G�սL��] @t, @david', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�L���Y�ɷl�q]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�L���Y�ɷl�q', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC DailyInsert.dbo.PL_�L���Y�ɷl�q

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Strategy�L�����p]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Strategy�L�����p', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec PL.dbo.Gary�C��Զ}���p_�L���� ''2018/1/1''
--exec PL.dbo.Alex�C��Զ}���p_�L���� ''2018/1/1''
--exec PL.dbo.KarenMOM�C��}���p_�L����_write', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Greek&PL]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Greek&PL', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete [OperationDesk].[dbo].[Greek&PL]
insert [OperationDesk].[dbo].[Greek&PL]
select * from OperationDesk.dbo.����|ĳ()

--41�����192����
delete db192.pl.[dbo].[InventoryMay4_MainTraderNew]
insert db192.pl.[dbo].[InventoryMay4_MainTraderNew]
select *
 FROM PL.dbo.[InventoryMay4_MainTraderNew](''J1040001'')

delete db192.PL.dbo.[�ײv�l�q_�L��]
insert db192.PL.dbo.[�ײv�l�q_�L��]
select *
from PL.dbo.[�ײv�l�q_�L��]()', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�Sñ�۰��_�u]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�Sñ�۰��_�u', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dailyInsert.[dbo].[DailyInsert_MDBreakList]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�s�U��]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�s�U��', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert intraday.dbo.�L��May3����
select Stadate
,datepart(hour,getdate()) as [Hour]
,datepart(minute,getdate()) as [Min]
,datepart(SECOND,getdate()) as [Sec]
,Underlying,MTM_D,�|�p_D,Tax_D,Delta,AbsDelta,Gamma,[D/G],Theta,�Ѳ�HR,GammaRatio,ThetaRatio,TimeValue,GammaY,OpendeltaY,�L�aMarkup as �L�a�hVol,Hedge�L�a,Hedge��L,Hedge�ٵ|,Spread,BVega as PVega,NPX,PX,[NPX+1],[NPX-1],Uplimit,Downlimit,DeltaLots,DeltaLotsChg,DeltaLotsTNet,GammaLots,Reissue
from PL.dbo.[InventoryMay4_MainUnderlyingNew](''J1040071'') 
where Trader not in (''Karen'',''Tony'') 
and (TimeValue<>0 or delta<>0 or Tax_D<>0)


delete MDoutput.dbo.[�L���Y�ɭ��I�ȹwĵ_table]
insert MDoutput.dbo.[�L���Y�ɭ��I�ȹwĵ_table]
select * 
from MDoutput.dbo.[�L���Y�ɭ��I�ȹwĵ]()

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѤW��_3Min�@��', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=4, 
		@freq_subday_interval=3, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170417, 
		@active_end_date=99991231, 
		@active_start_time=84300, 
		@active_end_time=140000, 
		@schedule_uid=N'55eddfe0-e8f5-49da-b125-08d1767d7d21'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L�e����]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L�e����', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:47 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_�v�ҼЪ����v���򥻸���ܧ�]    Script Date: 2019/5/15 �W�� 09:23:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_�v�ҼЪ����v���򥻸���ܧ�', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATE = GETDATE()
SET @t = DBMain.dbo.TradingdateAdd(-1, @t)

EXEC DailyInsert.[dbo].[DBMain_�v�ҼЪ����v���򥻸���ܧ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�Ұ򥻸�ƪ��Y�ť��άQ�Ѹ�]    Script Date: 2019/5/15 �W�� 09:23:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�Ұ򥻸�ƪ��Y�ť��άQ�Ѹ�', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date set @t=getdate()
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)

declare @n int
set @n=(select count(*) from cmoney.dbo.�v�Ұ򥻸�ƪ��C�� where ���=@t)

if @n=0 
	begin
	insert cmoney.dbo.�v�Ұ򥻸�ƪ��C��
	select @t, �~��, �N��, �W��, �Ъ��N��, �Ъ��W��, �o����, �o��~��, �W�����, �̫�����, ������, �o�����, [�v�Q��(%)], �̷s�i����, ��l�i����, �i��������O, [��l�����~�{��(%)], �̷s������, ��l������, [�y�q�ƶq(�d)], [�o��ƶq(�d)], [�W�B�o��ƶq(�d)], [���P�v�Ҽƶq(�d)], �o��ɼЪ��ѻ�, �o��ɼЪ��ѻ����O, [�s�����(��)], [��l���v�i�ʲv(%)], [�Q�v(%)], [�o��i�ʲv(%)], �i���覡, ���O, �W�U�����O, [�@���ҡ�������], [�{�ʡ��{��], �̷s�������, ��l�������, �o��ɰ]�Ȭ����O��, �o��ɰ]�ȶO�Φ~�Q�v, �y�ʶq���Ѫ�, �����覡, �o����c�N��, �o����c�W��, �o����c�Τ@�s��, ����Ҩ�s�X, �Ъ��Ҩ�i�o���`�Ѽ�, �W���Ѧһ�, ����覡, �o��ײv, �Ƶ�, ��������
	from cmoney.dbo.�v�Ұ򥻸�ƪ��C�� where ���=@y
	end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB39����]    Script Date: 2019/5/15 �W�� 09:23:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB39����', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete db39.[Trade_DB].[dbo].[tradingdate]
insert db39.[Trade_DB].[dbo].[tradingdate]
select *
from dbmain.dbo.tradingdate


delete db39.[Trade_DB].[dbo].[tradingdate2]
insert db39.[Trade_DB].[dbo].[tradingdate2]
select 
rank() over(order by x.Tradingdate)
,x.Tradingdate
from (
	select tradingdate
	from dbmain.dbo.tradingdate
	union 
	select tradingdate
	from dbmain.dbo.Tradingdate�K�`�L�~���p�����
) x', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [����o���v�ҳ]�wTrader�PHV]    Script Date: 2019/5/15 �W�� 09:23:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'����o���v�ҳ]�wTrader�PHV', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DailyInsert.dbo.����o���v�ҳ]�wTrader�PHV', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_WarrantProfileTS_Daily]    Script Date: 2019/5/15 �W�� 09:23:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_WarrantProfileTS_Daily', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t date = getdate()
Exec DailyInsert.dbo.DBMain_�v�ҵo��s����s @t
exec [DailyInsert].dbo.DBMain_WarrantProfileTS_Daily


delete dbmain.dbo.WarrantProfileTS_Group where issuedate=@t
if year(@t) >= ''2017''
begin
  insert dbmain.dbo.WarrantProfileTS_Group
  select WarrantKey, ''2016'', WarranTID,Issuedate,Expireddate
  from dbmain.dbo.warrantprofilets
  where Issuedate=@t
end
else
begin
  insert dbmain.dbo.WarrantProfileTS_Group
  select WarrantKey, datepart(yy,issuedate) , WarranTID,Issuedate,Expireddate
  from dbmain.dbo.warrantprofilets
  where Issuedate=@t
end
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [WarrantData]    Script Date: 2019/5/15 �W�� 09:23:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'WarrantData', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.Cmoney_�v�Ұ򥻸�ƪ��C��Update������ ''''

exec [DailyInsert].dbo.[DBMain_WarrantData] @t
exec [DailyInsert].dbo.DBMain_WarrantDataAll @t

', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�ۮa�v�ҨC��BookVol]    Script Date: 2019/5/15 �W�� 09:23:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�ۮa�v�ҨC��BookVol', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.PL_�ۮa�v�ҨC��BookVol @t

exec [DailyInsert].[dbo].[PL_�ۮa�v�ҨC��QV��BookVol_update] @t

exec DailyInsert.dbo.[PL_�ۮa�v�ҨC��BookVolAlex_temp] @t

exec DailyInsert.dbo.PL_�ۮa�v�ҨC��BookVolAlex @t

exec [DailyInsert].[dbo].[PL_�ۮa�v�ҨC��BookVol�պ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�L�a�v�ҨC��BookVol]    Script Date: 2019/5/15 �W�� 09:23:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�L�a�v�ҨC��BookVol', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.[PL_�L�a�v�ҨC��BookVol] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_�C��ӪѴ��f��������]    Script Date: 2019/5/15 �W�� 09:23:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_�C��ӪѴ��f��������', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec [DailyInsert].dbo.Marketdata_�C��ӪѴ��f�������� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB_tblDailyStockInfo�BtblDailyWarrantInfo�BtblPrevPL�BtblUserWarrantUnderlying]    Script Date: 2019/5/15 �W�� 09:23:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB_tblDailyStockInfo�BtblDailyWarrantInfo�BtblPrevPL�BtblUserWarrantUnderlying', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Trade_DB_tblDailyStockInfo
exec DailyInsert.dbo.Trade_DB_tblDailyWarrantInfo

exec DailyInsert.dbo.Trade_DB_tblDailyWarrantInfo3

--exec [DailyInsert].dbo.Trade_DB_tblPrevPL
exec DailyInsert.dbo.Trade_DB_tblUserWarrantUnderlying


--exec [DailyInsert].dbo.Trade_DB_Deputy_tblPrevPL
--exec DailyInsert.dbo.Trade_DB_Deputy_tblUserWarrantUnderlying

--exec DailyInsert.dbo.Trade_DB_tblWarrantDefaultBuySellSetting
exec DailyInsert.dbo.Trade_DB_tblAutoHedgeSetting', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB_tblWMParamsJJ]    Script Date: 2019/5/15 �W�� 09:23:49 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB_tblWMParamsJJ', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Trade_DB_tblWMParamsJJ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblWrrmm]    Script Date: 2019/5/15 �W�� 09:23:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblWrrmm', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.[Trade_DB_tblWrrmm]
--exec [DailyInsert].dbo.[Trade_DB_Deputy_tblWrrmm]

--�p�W��2017/6/30�_�R��
--Nancy��2017/8/1�_�Ұ�', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblWrnOptPrms]    Script Date: 2019/5/15 �W�� 09:23:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblWrnOptPrms', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec [DailyInsert].dbo.[Trade_DB_tblWrnOptPrms]

--�p�W��2017/6/30�_�R��', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblWrnExt]    Script Date: 2019/5/15 �W�� 09:23:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblWrnExt', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec [DailyInsert].dbo.[Trade_DB_tblWrnExt]

--�p�W��2017/6/30�_�R��', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblPosExt]    Script Date: 2019/5/15 �W�� 09:23:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblPosExt', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec [DailyInsert].dbo.[Trade_DB_tblPosExt]
--exec [DailyInsert].dbo.[Trade_DB_Deputy_tblPosExt]


--�p�W��2017/6/30�_�R��', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblWarrantInvLimit]    Script Date: 2019/5/15 �W�� 09:23:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblWarrantInvLimit', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(Stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.Trade_DB_tblWarrantInvLimit @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblAutoHedgeRiskCheck]    Script Date: 2019/5/15 �W�� 09:23:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblAutoHedgeRiskCheck', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.[dbo].[Trade_DB_tblAutoHedgeRiskCheck]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblIndexWarrantParameter]    Script Date: 2019/5/15 �W�� 09:23:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblIndexWarrantParameter', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].[dbo].[Trade_DB_tblIndexWarrantParameter]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBMain_DailyDefaultPortfolio]    Script Date: 2019/5/15 �W�� 09:23:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBMain_DailyDefaultPortfolio', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.DBMain_DailyDefaultPortfolio ''''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBmain_�x�s�Ҩ鸳�ʸg�z�HUpdate]    Script Date: 2019/5/15 �W�� 09:23:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBmain_�x�s�Ҩ鸳�ʸg�z�HUpdate', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DBmain_�x�s�Ҩ鸳�ʸg�z�HUpdate', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB2_Tick_tbl_Tick_LastUpDate]    Script Date: 2019/5/15 �W�� 09:23:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB2_Tick_tbl_Tick_LastUpDate', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec DailyInsert.dbo.DB2_Tick_tbl_Tick_LastUpDate', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB2_Tick_tbl_SSW_IA_STKID]    Script Date: 2019/5/15 �W�� 09:23:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB2_Tick_tbl_SSW_IA_STKID', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DB2_Tick_tbl_SSW_IA_STKID', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�W���d���q�򥻸�ƨC��]    Script Date: 2019/5/15 �W�� 09:23:51 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�W���d���q�򥻸�ƨC��', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

delete cmoney.dbo.�W���d���q�򥻸�ƨC�� where TxDate=@t
insert cmoney.dbo.�W���d���q�򥻸�ƨC��
select @t,*
from cmoney.dbo.�W���d���q�򥻸��

Declare @Yesterday date set @Yesterday=(select max(���) from Cmoney.dbo.�馬�L���Ʀ�)
DELETE  dbmain.dbo.�[�v���Ʀ�����_�� WHERE Txdatetime=@Yesterday 
INSERT INTO dbmain.dbo.�[�v���Ʀ�����_��
SELECT  A.��� ,A.�Ѳ��N�� ,A.�Ѳ��W��,A.[���Ȥ�(%)]  
FROM [Cmoney].[dbo].[�馬�L�٭���Ʀ�] A 
LEFT JOIN (SELECT TxDate,�~��,  [�Ѳ��N��] ,[�W���W�d] FROM [Cmoney].[dbo].�W���d���q�򥻸�ƨC��  ) B ON RTRIM(B.�Ѳ��N��)=RTRIM(A.�Ѳ��N��) AND B.Txdate = @Yesterday
WHERE ���=@Yesterday   AND A.[���Ȥ�(%)] IS NOT NULL AND B.�W���W�d=1', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB_CBData]    Script Date: 2019/5/15 �W�� 09:23:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB_CBData', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.[CB_CBData] @t

exec dailyinsert.[dbo].[CB_TradeDB]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�����v�ҵ��P�����BMarketdata_�����v�ҼW�B����]    Script Date: 2019/5/15 �W�� 09:23:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�����v�ҵ��P�����BMarketdata_�����v�ҼW�B����', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.MarketData_�����v�ҵ��P���� @t
exec dailyinsert.[dbo].[Marketdata_�����v�ҼW�B����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tblDailyStockInfoUpdateGarch]    Script Date: 2019/5/15 �W�� 09:23:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tblDailyStockInfoUpdateGarch', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Trade_DB_tblDailyStockInfoUpdateGarch', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB39_IT���]    Script Date: 2019/5/15 �W�� 09:23:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB39_IT���', 
		@step_id=28, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec DailyInsert.dbo.DB39_IT���', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB39_���x���]    Script Date: 2019/5/15 �W�� 09:23:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB39_���x���', 
		@step_id=29, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--exec DailyInsert.dbo.DB39_���x���', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���f����򥻸�ƨC��]    Script Date: 2019/5/15 �W�� 09:23:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���f����򥻸�ƨC��', 
		@step_id=30, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from Cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec testpa.[dbo].[���f����򥻸�ƨC��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�L�e��J�v��ĵ��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�L�e��J�v��ĵ��', 
		@step_id=31, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.�L�e��J�v��ĵ��', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB2_Intraday_SQLtoMongo]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB2_Intraday_SQLtoMongo', 
		@step_id=32, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)


exec DailyInsert.[dbo].[DB2_Intraday_SQLtoMongoFutN] @t
exec DailyInsert.[dbo].[DB2_Intraday_SQLtoMongoOptN] @t

insert db2.[Tick].[dbo].[SN]
SELECT left(������,4) as StockID
FROM MarketData.[dbo].[TEJ���Ʀ����ѪѼ�] a
left join db2.[Tick].[dbo].[SN] b on b.�Ѳ��N��=left(������,4)
where �~���=(select max(�~���) from MarketData.[dbo].[TEJ���Ʀ����ѪѼ�]) and b.�Ѳ��N�� is null
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro_Pretty30MDList]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro_Pretty30MDList', 
		@step_id=33, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Pro_Pretty30MDList', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҥ������R]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҥ������R', 
		@step_id=34, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.FrontDeskW_�v�ҥ������R', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB192_BloombergDataSet_COMMDTY_TABLE_FF]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB192_BloombergDataSet_COMMDTY_TABLE_FF', 
		@step_id=35, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DB192_BloombergDataSet_COMMDTY_TABLE_FF ''''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB192����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB192����', 
		@step_id=36, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

delete db192.cmoney.dbo.�v�Ұ򥻸�ƪ��C��
insert db192.cmoney.dbo.�v�Ұ򥻸�ƪ��C��
select *
from cmoney.dbo.�v�Ұ򥻸�ƪ��C��
where ���=@t

delete db192.cmoney.dbo.��ꪬ�p
insert db192.cmoney.dbo.��ꪬ�p
select *
from cmoney.dbo.��ꪬ�p
where �}�l�R����=@t

delete db192.cmoney.dbo.�ѧQ�F����
insert db192.cmoney.dbo.�ѧQ�F����
select *
from cmoney.dbo.�ѧQ�F����
where ������=@t or ���v��=@t

delete db192.cmoney.dbo.���f�Ӫѫ����վ�
insert db192.cmoney.dbo.���f�Ӫѫ����վ�
select *
from cmoney.dbo.���f�Ӫѫ����վ�
where �����վ���=@t

delete db192.marketdata.[dbo].[DailyQuote��ʳ]�w]
insert db192.marketdata.[dbo].[DailyQuote��ʳ]�w]
select *
from marketdata.[dbo].[DailyQuote��ʳ]�w]
where ���=@t

declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)

delete db192.vix.[dbo].[��x������v�i�ʲv����(���L��)]
insert db192.vix.[dbo].[��x������v�i�ʲv����(���L��)]
select *
from vix.[dbo].[��x������v�i�ʲv����(���L��)]
where ���=@y

delete db192.[Cmoney].[dbo].[�����v�污��]
insert db192.[Cmoney].[dbo].[�����v�污��]
select *
from [Cmoney].[dbo].[�����v�污��]
where ���=@y

delete db192.marketdata.[dbo].[�C��ӪѴ��f��������]
insert db192.marketdata.[dbo].[�C��ӪѴ��f��������]
select *
from marketdata.[dbo].[�C��ӪѴ��f��������]
where ���>=@y

delete db192.marketdata.dbo.dailyquote
insert db192.marketdata.dbo.dailyquote
select *
from marketdata.dbo.dailyquote
where ���=@y

delete db192.cmoney.dbo.���f����污��
insert db192.cmoney.dbo.���f����污��
select *
from cmoney.dbo.���f����污��
where ���=@y

delete db192.cmoney.dbo.���Ѥ馬�L���Ʀ�
insert db192.cmoney.dbo.���Ѥ馬�L���Ʀ�
select *
from cmoney.dbo.���Ѥ馬�L���Ʀ�
where ���=@y

delete db192.Intraday.dbo.tblTickETFDaily
insert db192.Intraday.dbo.tblTickETFDaily
select *
from Intraday.dbo.tblTickETFDaily
where Txdate=@y

delete db192.pl.dbo.DailyPLReport_�l�Ӧ���
insert db192.pl.dbo.DailyPLReport_�l�Ӧ���
select *
from pl.dbo.DailyPLReport_�l�Ӧ���
where Txdate=@y

delete db192.pl.dbo.ETF�����鷸��1300
insert db192.pl.dbo.ETF�����鷸��1300
select *
from pl.dbo.ETF�����鷸��1300
where Txdate=@y

delete db192.dbmain.dbo.tradingdate
insert db192.dbmain.dbo.tradingdate
select *
from dbmain.dbo.tradingdate

delete db192.dbmain.dbo.[EmployeeID]
insert db192.dbmain.dbo.[EmployeeID]
select *
from dbmain.dbo.[EmployeeID]

delete db192.dbmain.dbo.[AccountList_Temp]
insert db192.dbmain.dbo.[AccountList_Temp]
select *
from dbmain.dbo.[AccountList_Temp]

delete db192.dbmain.dbo.[DefaultPortfolio_�l�Ӧ���]
insert db192.dbmain.dbo.[DefaultPortfolio_�l�Ӧ���]
select *
from dbmain.dbo.[DefaultPortfolio_�l�Ӧ���]

delete db192.pl.[dbo].[ETF����ū�^IPO��]
insert db192.pl.[dbo].[ETF����ū�^IPO��]
select *
from pl.[dbo].[ETF����ū�^IPO��]

delete db192.dbmain.[dbo].[���~���f�N����Ӫ�]
insert db192.dbmain.[dbo].[���~���f�N����Ӫ�]
select *
from dbmain.[dbo].[���~���f�N����Ӫ�]

delete db192.dbmain.[dbo].[���f_�^������Ӫ�]
insert db192.dbmain.[dbo].[���f_�^������Ӫ�]
select *
from dbmain.[dbo].[���f_�^������Ӫ�]

delete db192.dbmain.[dbo].[����v_�^������Ӫ�]
insert db192.dbmain.[dbo].[����v_�^������Ӫ�]
select *
from dbmain.[dbo].[����v_�^������Ӫ�]

delete db192.dbmain.[dbo].���f�����
insert db192.dbmain.[dbo].���f�����
select *
from dbmain.[dbo].���f�����

delete db192.dbmain.[dbo].[ETF�b�쭼�ƻP���O]
insert db192.dbmain.[dbo].[ETF�b�쭼�ƻP���O]
select *
from dbmain.[dbo].[ETF�b�쭼�ƻP���O]

delete db192.dbmain.[dbo].���y�ѥ��𥫮ɶ��@����
insert db192.dbmain.[dbo].���y�ѥ��𥫮ɶ��@����
select *
from dbmain.[dbo].���y�ѥ��𥫮ɶ��@����

delete db192.Ronald.dbo.Dummy
insert db192.Ronald.dbo.Dummy
select *
from Ronald.dbo.Dummy

delete db192.cmoney.[dbo].[����v����򥻸��]
insert db192.cmoney.[dbo].[����v����򥻸��]
select *
from cmoney.[dbo].[����v����򥻸��]


delete db192.dbmain.dbo.ADR���Ѥ�v
insert db192.dbmain.dbo.ADR���Ѥ�v
select *
from dbmain.dbo.ADR���Ѥ�v


delete db192.cmoney.dbo.�i�ऽ�q�Ű򥻸��
insert db192.cmoney.dbo.�i�ऽ�q�Ű򥻸��
select *
from cmoney.dbo.�i�ऽ�q�Ű򥻸��
where �~��=(select max(�~��) from cmoney.dbo.�i�ऽ�q�Ű򥻸��)

delete db192.[CB].[dbo].[CB_fit_bookprice]
insert db192.[CB].[dbo].[CB_fit_bookprice]
select *
from [CB].[dbo].[CB_fit_bookprice]

delete db192.marketdata.[dbo].[�~����f�b�Ȧ��L��]
insert db192.marketdata.[dbo].[�~����f�b�Ȧ��L��]
select *
from marketdata.[dbo].[�~����f�b�Ȧ��L��]
where ���=@t

delete db192.[Cmoney].[dbo].[���f����򥻸��]
insert db192.[Cmoney].[dbo].[���f����򥻸��]
select *
from [Cmoney].[dbo].[���f����򥻸��]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB192����part2]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB192����part2', 
		@step_id=37, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)

delete db192.intraday.[dbo].[���ѥ����v��IV�ʱ�]
insert db192.intraday.[dbo].[���ѥ����v��IV�ʱ�]
select *
from intraday.[dbo].[���ѥ����v��IV�ʱ�]
where [TxDate]=@t

delete db192.dbmain.dbo.DailyDefaultPortfolio
insert db192.dbmain.dbo.DailyDefaultPortfolio
select *
from dbmain.dbo.DailyDefaultPortfolio
where [TxDate]=@t

delete db192.dbmain.[dbo].[WarrantProfileTS]
insert db192.dbmain.[dbo].[WarrantProfileTS]
select *
from dbmain.[dbo].[WarrantProfileTS]

delete db192.DBMain.[dbo].[WarrantTraderTS]
insert db192.DBMain.[dbo].[WarrantTraderTS]
select *
from DBMain.[dbo].[WarrantTraderTS]

delete db192.dbmain.dbo.WarrantProfileTS_Daily 
insert db192.dbmain.dbo.WarrantProfileTS_Daily 
select *
from dbmain.dbo.WarrantProfileTS_Daily 
where TxDate=@t

delete db192.dbmain.dbo.���ƫ�_�v���I�Ʀ���
insert db192.dbmain.dbo.���ƫ�_�v���I�Ʀ���
select *
from dbmain.dbo.���ƫ�_�v���I�Ʀ���

delete db192.PL.[dbo].[�v�ҼЪ��쩳�n�ƻ����]
insert db192.PL.[dbo].[�v�ҼЪ��쩳�n�ƻ����]
select *
from PL.[dbo].[�v�ҼЪ��쩳�n�ƻ����]

delete db192.dbmain.[dbo].[StructureProfilesTS]
insert db192.dbmain.[dbo].[StructureProfilesTS]
select *
from dbmain.[dbo].[StructureProfilesTS]

delete db192.dbmain.[dbo].[�v�үS�����I�Ъ�]
insert db192.dbmain.[dbo].[�v�үS�����I�Ъ�]
select *
from dbmain.[dbo].[�v�үS�����I�Ъ�]


delete db192.dbmain.[dbo].[Strategy�W���ഫ]
insert db192.dbmain.[dbo].[Strategy�W���ഫ]
select *
from dbmain.[dbo].[Strategy�W���ഫ]

delete db192.pl.dbo.�l�ӳ�RPRS�l�q
insert db192.pl.dbo.�l�ӳ�RPRS�l�q
select *
from pl.dbo.�l�ӳ�RPRS�l�q
where [TxDate]=@y

delete db192.theodata.dbo.HistoryVol
insert db192.theodata.dbo.HistoryVol
select *
from theodata.dbo.HistoryVol
where Stadate=''2016/5/5'' and tag=''252''

delete db192.cmoney.dbo.�W���d���q�򥻸�ƨC��
insert db192.cmoney.dbo.�W���d���q�򥻸�ƨC��
select *
from cmoney.dbo.�W���d���q�򥻸�ƨC��
where TxDate=@t

delete db192.CB.[dbo].[���īH��]
insert db192.CB.[dbo].[���īH��]
select *
from CB.[dbo].[���īH��]
where �H���֩w�ɶ�=(select max(�H���֩w�ɶ�) from CB.[dbo].[���īH��] ) and ��Ƥ��=(select max(��Ƥ��) from CB.[dbo].[���īH��] where ��Ƥ��<=@t)

delete db192.dbmain.dbo.TCRI
insert db192.dbmain.dbo.TCRI
select *
from dbmain.dbo.TCRI
where �~��=(select max(�~��) from dbmain.dbo.TCRI)

delete db192.pl.[dbo].[���f�������_��~]
insert db192.pl.[dbo].[���f�������_��~]
select *
from pl.[dbo].[���f�������_��~]

delete db192.pl.dbo.�Ũ鳡����
insert db192.pl.dbo.�Ũ鳡����
select *
from pl.dbo.�Ũ鳡����
where ��Ƥ��=@y 

delete db192.Cmoney.dbo.�Ũ�o��򥻸�ƪ�
insert db192.Cmoney.dbo.�Ũ�o��򥻸�ƪ�
select *
from Cmoney.dbo.�Ũ�o��򥻸�ƪ�
where left(DBmain.[dbo].[DateTranslator](@y,3),6)=�~��

delete db192.Cmoney.dbo.[��Ũ�ާQ�v�P�ʤ������(���ަ���)]
insert db192.Cmoney.dbo.[��Ũ�ާQ�v�P�ʤ������(���ަ���)]
select *
from Cmoney.dbo.[��Ũ�ާQ�v�P�ʤ������(���ަ���)]
where ���=@y

delete db192.testpa.dbo.�]�ȳ��Q�v
insert db192.testpa.dbo.�]�ȳ��Q�v
select *
from testpa.dbo.�]�ȳ��Q�v
where @y between BDate and EDate

delete db192.[Trade_DB].[dbo].[�Ũ�q��ĳ��_����污����]
insert db192.[Trade_DB].[dbo].[�Ũ�q��ĳ��_����污����]
select *
from web.[dbo].[�Ũ�q��ĳ��_����污����]
 where  txdate=@t and  txtime=(select top(1) txtime from web.dbo.[�Ũ�q��ĳ��_����污����]  where txdate=@t order by txdate desc,txtime desc)

 delete db192.pl.dbo.DailyPLReport_���Ť��q�ť��
insert db192.pl.dbo.DailyPLReport_���Ť��q�ť��
select *
from pl.dbo.DailyPLReport_���Ť��q�ť��
where �����=@y

 delete db192.pl.dbo.DailyPLReport_���Ť��q�ť��_�������
insert db192.pl.dbo.DailyPLReport_���Ť��q�ť��_�������
select *
from pl.dbo.DailyPLReport_���Ť��q�ť��_�������
where �����=@y

 delete db192.dbmain.[dbo].[�Ũ鳡�l�q���ؤ���]
insert db192.dbmain.[dbo].[�Ũ鳡�l�q���ؤ���]
select *
from dbmain.[dbo].[�Ũ鳡�l�q���ؤ���]

 delete db192.pl.dbo.[400�{�Ѯw�s��wkstkx]
insert db192.pl.dbo.[400�{�Ѯw�s��wkstkx]
select *
from pl.dbo.[400�{�Ѯw�s��wkstkx]
where �w�s���=@y
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�Ѧ��W#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150410, 
		@active_end_date=99991231, 
		@active_start_time=74500, 
		@active_end_time=235959, 
		@schedule_uid=N'49a2735e-b840-42c6-aa71-a04ee0f45eda'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L���ˬd�^��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L���ˬd�^��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Monitor_�v�ҫe���k�ݭ����ˬd]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Monitor_�v�ҫe���k�ݭ����ˬd', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Monitor_�v�ҫe���k�ݭ����ˬd', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Monitor_���f�����ˬd]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Monitor_���f�����ˬd', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Monitor_���f�����ˬd', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�U��4�I', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160915, 
		@active_end_date=99991231, 
		@active_start_time=160000, 
		@active_end_time=235959, 
		@schedule_uid=N'434a5914-df35-4091-8708-a39fb22f19ca'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�U��5�I�b', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160915, 
		@active_end_date=99991231, 
		@active_start_time=173000, 
		@active_end_time=235959, 
		@schedule_uid=N'e4b01fbf-e542-4bc4-a0f2-7515555d9f0f'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L������]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L������', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MDoutput_Php]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MDoutput_Php', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.[MDoutput_Php_KMVDefaultRateList]
exec DailyInsert.dbo.[MDoutput_Php_KMVDeptAvg]

exec DailyInsert.dbo.[MDoutput_Php_CreditSnapshot]
exec DailyInsert.[dbo].[Credit_�C�uCreditSnapShot] ''''

exec DailyInsert.dbo.[MDoutput_Php_CBBookRet]
exec DailyInsert.dbo.[MDoutput_Php_MPC]
exec DailyInsert.dbo.[MDoutput_Php_DV01Rate]

exec DailyInsert.dbo.MDOutput_CBOpen
exec DailyInsert.dbo.MDOutput_Php_CBTradableAmt', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_DailyQuote]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_DailyQuote', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Marketdata_DailyQuote @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Theodata_HistoryVol]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Theodata_HistoryVol', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].[dbo].[Theodata_HistoryVol] @t
exec DailyInsert.dbo.Theodata_�C�餽��BookVol @t

exec [DailyInsert].dbo.[Theodata_HistoryVol_OneDay] @t
exec DailyInsert.dbo.Theodata_HistoryVol_NDay @t
exec DailyInsert.dbo.Trade_DB_HistoricalVol @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�L�a�v��Delta���Im���]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�L�a�v��Delta���Im���', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.PL_�L�a�v��Delta���Im��� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�v�ҼЪ����I���x����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�v�ҼЪ����I���x����', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.[FrontDeskW_�v�ҼЪ����I���x����] @t
exec [DailyInsert].dbo.[FrontDeskW_�v�ҼЪ����I���x����2] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney_�ӪѨ�Ӥ��I�i�X����Update]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney_�ӪѨ�Ӥ��I�i�X����Update', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Cmoney_�ӪѨ�Ӥ��I�i�X����Update @t
--exec [DailyInsert].[dbo].Cmoney_����Ӷi�X����� @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�C���v�ҼЪ��i�o��Ѽ�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�C���v�ҼЪ��i�o��Ѽ�', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


exec [DailyInsert].dbo.FrontDeskW_�C���v�ҼЪ��i�o��Ѽ� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�v�Ҩ�Ӯw�s�i��_�����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�v�Ҩ�Ӯw�s�i��_�����', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].[dbo].[MarketData_�v�Ҩ�Ӯw�s�i��_�����] @t
exec [DailyInsert].[dbo].[MarketData_�v�Ҩ�Ӯw�s�i��_�����Update] @t


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�C��Reissue���p��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�C��Reissue���p��', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


exec [DailyInsert].dbo.FrontDeskW_�C��Reissue���p�� @t
exec DailyInsert.dbo.[FrontDeskW_�C��Reissue���p��_���Ъ�] @t
exec DailyInsert.dbo.[FrontDeskW_�C��Reissue���p��_�����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro����', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=21, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Pro_�P�~�v�ҥ�� @t
exec DailyInsert.dbo.Pro_�v�ҵ������ @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info @t

exec DailyInsert.dbo.Pro_�P�~�l�q���p @t
exec DailyInsert.dbo.Pro_�P�~�l�q���p_������ @t

exec [DailyInsert].dbo.[Pro_�P�~�l�q�J��] @t

exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdatePL @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdateTV @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o���ɼ�] @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�s��o���ɼ�] @t
  exec DailyInsert.[dbo].[Pro_�v�ҵo���Info_OSadd���R���ȥ����v] @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o��i��] @t

exec DailyInsert.dbo.[Pro_�ۮa�������] @t
exec [DailyInsert].dbo.[Pro_�i��ŵ������] @t

exec [DailyInsert].dbo.[Pro_�������ӥD�O���G] @t
exec [DailyInsert].dbo.[Pro_�������ӥD�O���G10��30��] @t
exec [DailyInsert].dbo.[Pro_�������ӥD�O���GJohnny] @t

exec [DailyInsert].dbo.[Pro_�v�ҽL���������_���z] @t

exec DailyInsert.dbo.Pro_�v�ҷl�qBreakDown

exec DailyInsert.dbo.Pro_CBVolTradeDeallist @t

exec DailyInsert.dbo.[Pro_�Ъ�OS���ȥ����v] @t
exec DailyInsert.dbo.[Pro_��Ӧ��楫���v] @t

exec [DailyInsert].[dbo].[Pro_�v�ҵo��ӨC��TimeValue] @t
exec [DailyInsert].[dbo].[Pro_�v�ҵo��ӨC����p���Q] @t
exec [DailyInsert].[dbo].[Pro_�v�ҵo��ӨC����p���Q_Underlying] @t




', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_�v�ҦU������]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_�v�ҦU������', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)




exec DailyInsert.dbo.Z_�v�ҦU������_20180501 @t

exec DailyInsert.dbo.Z_�v�ҦU������_0615 @t

exec DailyInsert.dbo.Z_��ӫ��v�Ҧ�����BRatio @t

exec DailyInsert.dbo.Z_��ӫ��v��TimeValueRatio @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_����v�Ұ�Vol�P�CVol���Table]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_����v�Ұ�Vol�P�CVol���Table', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.PL_����v�Ұ�Vol�P�CVol���Table', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�v��OS�Ѽ�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�v��OS�Ѽ�', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.MarketData_�v��OS�Ѽ� @t


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_�j���p������Ret]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_�j���p������Ret', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec dailyinsert.dbo.Z_KMeanResult�� @t
exec DailyInsert.dbo.[Marketdata_�j���p������Ret] @t
exec DailyInsert.dbo.[Marketdata_�j���p������Ret����] @t
exec DailyInsert.dbo.[Marketdata_�j���p������RetEW] @t
exec DailyInsert.dbo.[marketdata_�j���p�g����S�v] @t
exec DailyInsert.dbo.[Marketdata_TopBot50�g����S�v] @t
exec DailyInsert.[dbo].[Marketdata_KMean11������RetTEJ�Ӷ�] @t 
exec DailyInsert.[dbo].[Marketdata_KMean11������RetTEJ]  @t
exec DailyInsert.[dbo].[Marketdata_KMean28��10RetTEJ]  @t
exec DailyInsert.dbo.[Marketdata_�j���p������RetTEJ] @t
exec DailyInsert.dbo.[Marketdata_�j���p������RetTEJ����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�v�Ҧ�����B_���Ъ�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�v�Ҧ�����B_���Ъ�', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.[MarketData_�v�Ҧ�����B_���Ъ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�P�~�l�q���p]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�P�~�l�q���p', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

  exec [DailyInsert].[dbo].[PL_�P�~�l�q���p] @t

  exec [DailyInsert].[dbo].[PL_IssuerVolGap] @t

  exec [DailyInsert].dbo.PL_�P�~�l�q���p_�Ҽ{���楫������Step1 @t
  exec [DailyInsert].dbo.PL_�P�~�l�q���p_�Ҽ{���楫������Step2 @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB_cbindex]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB_cbindex', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.CB_cbindex @t', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CB_CB�z�׻�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CB_CB�z�׻�', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].[dbo].[CB_CB�z�׻�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_��ӫȷ����c]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_��ӫȷ����c', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].[Marketdata_�v�Ҷi�X���B����] @t
exec DailyInsert.dbo.Marketdata_��ӫȷ����c @t
exec DailyInsert.dbo.Marketdata_��Ӥj��R�i���B @t

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB39����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB39����', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.DB39_tblOtherWarrantImpVol
--exec DailyInsert.dbo.DB39_tblKGIInv
--2017/3/7 Dennis��IT�w���ݭn', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_���I�i�X�v�ҼЪ�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_���I�i�X�v�ҼЪ�', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

  exec [DailyInsert].dbo.MarketData_���I�i�X�v�ҼЪ� @t', 
		@database_name=N'MarketData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�ۮa�v�ҨC��QV_�s����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�ۮa�v�ҨC��QV_�s����', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].[dbo].[PL_�ۮa�v�ҨC��QV] @t,1', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�C�饫���v�Ұ�]]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�C�饫���v�Ұ�]', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].[DailyInsert_�C�饫���v�Ұ�]] @t
exec DailyInsert.[dbo].[DailyInsert_�C�饫���v�Ұ�]Value] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData���f�����z]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData���f�����z', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].[MarketData_DailyQuoteFutAll] @t,''TX''
exec DailyInsert.[dbo].[MarketData_DailyQuoteFutAll] @t,''NYF''
exec DailyInsert.[dbo].[MarketData_DailyQuoteTX_05Sec] @t,5
exec DailyInsert.[dbo].[MarketData_DailyQuoteNYF_05Sec] @t,5', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_���f_����_0050_Daily]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_���f_����_0050_Daily', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Marketdata_���f_����_0050_Daily @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_���ĥ���B�����l�q�J���]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_���ĥ���B�����l�q�J���', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�馬�L���Ʀ�)

exec [DailyInsert].[dbo].PL_���ĥ���B�����l�q�J��� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�L�a�v��Index]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�L�a�v��Index', 
		@step_id=28, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.FrontDeskW_�L�a�v��Index @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_CB_DeltaRonald]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_CB_DeltaRonald', 
		@step_id=29, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'  declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.[dbo].[PL_CB_DeltaRonald] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�O������vImpVol]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�O������vImpVol', 
		@step_id=30, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'  declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.MarketData_�O������vImpVol @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�v��Index]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�v��Index', 
		@step_id=31, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec [DailyInsert].dbo.FrontDeskW_�v��Index @t,5
exec [DailyInsert].dbo.FrontDeskW_�v��Index @t,10
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DailyQuoteTest]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DailyQuoteTest', 
		@step_id=32, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

delete marketdata.[dbo].[DailyQuoteTest] where TxDate=@t
  insert marketdata.[dbo].[DailyQuoteTest]
  select @t,[�Ѳ��N��],[���L��] from cmoney.[dbo].[�馬�L���Ʀ�] where [���]=@t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�����t�M�Q�j���pTERSim]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�����t�M�Q�j���pTERSim', 
		@step_id=33, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.PL_�����t�M�Q�j���pTERSim @t
exec DailyInsert.dbo.PL_�����t�M�Q�j���pTERSim2 @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҼЪ��{�����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҼЪ��{�����', 
		@step_id=34, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
EXEC DailyInsert.dbo.PL_�v�ҼЪ��{�����', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҼЪ��P���f���q15Min�C��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҼЪ��P���f���q15Min�C��', 
		@step_id=35, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.[FrontDeskW_�v�ҼЪ��P���f���q15Min�C��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_CBAS�C��ֿnPL]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_CBAS�C��ֿnPL', 
		@step_id=36, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


  exec [DailyInsert].dbo.[PL_CBAS�C��ֿnPL] @t
  exec [DailyInsert].dbo.[PL_CBAS�C��ֿnPL����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_B_IMP_Vol]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_B_IMP_Vol', 
		@step_id=37, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.FrontDeskW_B_IMP_Vol @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�L�a�v�ҥi�f��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�L�a�v�ҥi�f��', 
		@step_id=38, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].[FrontDeskW_�L�a�v�ҥi�f��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_�]�����ƿ��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_�]�����ƿ��', 
		@step_id=39, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Z_�]�����ƿ�� @t
exec DailyInsert.dbo.[Z_�]�����ƿ��addPUGBAll] @t
exec DailyInsert.dbo.Z_�]�����ƿ��add�V�� @t
exec DailyInsert.dbo.Z_�]�����ƿ��add�V��Karen @t
exec DailyInsert.dbo.Z_�]�����ƿ��_d1w @t

exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業��_�]������] @t
exec DailyInsert.[dbo].[FrontDeskW_CBIndex�W�g����q�z��²�業�����Gtop100�]������] @t

exec DailyInsert.dbo.Z_EVEBITDA���q���� @t
 exec [DailyInsert].dbo.[Z_EVEBITDA���q���ȵ��G] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_���ĥ���B�ϥθ����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_���ĥ���B�ϥθ����', 
		@step_id=40, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Z_���ĥ���B�ϥθ���� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro_�v�ҵo���Info�Q��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro_�v�ҵo���Info�Q��', 
		@step_id=41, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=dbmain.dbo.tradingdateadd(-1,(select max(stadate) from pl.dbo.inventory))



  exec dailyinsert.[dbo].[Pro_�v�ҵo���Info] @t
  exec dailyinsert.[dbo].[Pro_�v�ҵo���Info_UpdatePL] @t
  exec dailyinsert.[dbo].[Pro_�v�ҵo���Info_UpdateTV] @t
  exec dailyinsert.[dbo].[Pro_�v�ҵo���Info_Update�o���ɼ�] @t

exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�s��o���ɼ�] @t
  exec DailyInsert.[dbo].[Pro_�v�ҵo���Info_OSadd���R���ȥ����v] @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o��i��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_�W���d���q���������S�v�d�ߪ�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_�W���d���q���������S�v�d�ߪ�', 
		@step_id=42, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec Dailyinsert.dbo.Credit_TermStructure_GB @t
exec DailyInsert.dbo.Z_�W���d���q���������S�v�d�ߪ�
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_StockChain_hour]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_StockChain_hour', 
		@step_id=43, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.Z_StockChain_hour ''3'',@t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_���u�ȵ���}����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_���u�ȵ���}����', 
		@step_id=44, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)


exec [DailyInsert].dbo.[FrontDeskW_���u�ȵ���}����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�U�u�Ъ��w��Table]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�U�u�Ъ��w��Table', 
		@step_id=45, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.FrontDeskW_�U�u�Ъ��w��Table', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [intraday_���ƴ��f�C����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'intraday_���ƴ��f�C����', 
		@step_id=46, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.intraday_���ƴ��f�C���� @t
exec DailyInsert.[dbo].[Intraday_���x�����C����] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_�[�v���Ʀ��Ȧ^��(�l��POSA)]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_�[�v���Ʀ��Ȧ^��(�l��POSA)', 
		@step_id=47, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--�l��POSA
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.dbo.FrontDeskW_�[�v���Ʀ��Ȧ^��New @t


exec DailyInsert.dbo.FrontDeskW_�[�v���Ʀ��Ȧ^�� @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney_�馬�L�٭���Ʀ�Update]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney_�馬�L�٭���Ʀ�Update', 
		@step_id=48, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Cmoney_�馬�L�٭���Ʀ�Update', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Z_MOMLOP_POSOSC]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Z_MOMLOP_POSOSC', 
		@step_id=49, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.Z_MOMLOP_POSOSC

declare @t datetime set @t=(select max(Stadate) from pl.dbo.inventory)
exec [DailyInsert].[dbo].[Z_������B����]
exec [DailyInsert].[dbo].[Z_MOMLOP_list] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Index�^���t�C]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Index�^���t�C', 
		@step_id=50, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].[pro_�W���d�Ѳ�Ret] @t
exec DailyInsert.[dbo].[pro_�W���d�Ѳ�Ret_New] @t

exec [DailyInsert].[dbo].[MDoutput_FPB_List]
exec [DailyInsert].[dbo].[MDoutput_NCAV_List]

exec [DailyInsert].[dbo].[MDoutput_Index_Ret]

exec z.dbo.ROIC�����t�C ''ROIC''
exec z.dbo.ROIC�����t�C ''ROIC_with_FScore''
exec z.dbo.ROIC�����t�C ''ROIC_with_PB''
exec z.[dbo].[NNWC �����t�C] ''NN''
exec z.[dbo].[NNWC �����t�C] ''NNF''
exec z.[dbo].[NNWC �����t�C] ''NNEmax''
exec z.[dbo].[NNWC �����t�C] ''NNEmaxF''
exec z.[dbo].[NNWC �����t�C] ''NNEmin''
exec z.[dbo].[NNWC �����t�C] ''NNEminF''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���İӫ~�O�l�q���Ӫ�]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���İӫ~�O�l�q���Ӫ�', 
		@step_id=51, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=dbmain.dbo.tradingdateadd(-1,(select max(stadate) from pl.dbo.inventory))
declare @b datetime set @b=DATEADD(MONTH,DATEDIFF(MONTH,0,@t),0)--���

exec OperationDesk.[dbo].[���İӫ~�O�l�q���Ӫ�����_���b��] @t
exec OperationDesk.[dbo].[���İӫ~�O�l�q���Ӫ�����] @b,@t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [���x�|�p�P���xMD�t��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'���x�|�p�P���xMD�t��', 
		@step_id=52, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec Monitor.dbo.���x�|�p�P���xMD�t��', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [StockADL]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'StockADL', 
		@step_id=53, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC MarketData.dbo.StockADL
', 
		@database_name=N'MarketData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_PB_ValueRatio]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_PB_ValueRatio', 
		@step_id=54, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(Stadate) from pl.dbo.inventory)
exec DailyInsert.dbo.[FrontDeskW_PB_ValueRatio] @t

exec DailyInsert.dbo.[FrontDeskW_PB_ValueRatio_F] @t

exec DailyInsert.dbo.[FrontDeskW_PB_PE_Ratio] @t

exec DailyInsert.dbo.[FrontDeskW_PB_stocks] @t

exec DailyInsert.dbo.[FrontDeskW_PB_stocks_new] @t', 
		@database_name=N'DailyInsert', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150416, 
		@active_end_date=99991231, 
		@active_start_time=200000, 
		@active_end_time=235959, 
		@schedule_uid=N'714c1c42-0d16-4fb2-b558-d5492f0b908b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L������_AS400]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L������_AS400', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_DailyQuote_T73Insert]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_DailyQuote_T73Insert', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.Marketdata_DailyQuote_T73Insert', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Deallist_Transfer]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Deallist_Transfer', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.dbo.[PL_Deallist_Transfer] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_Deallist]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_Deallist', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.[PL_Deallist] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AS400����]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AS400����', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.[Trade_DB_tblAS400wkwprc] ''''
exec [DailyInsert].dbo.[Trade_DB_tblAS400wkwipo] ''''
exec [DailyInsert].dbo.[Trade_DB_tblAS400wkctlp] ''''
exec [DailyInsert].dbo.[Trade_DB_tblAS400wkctld] ''''
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�馬�L#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150722, 
		@active_end_date=99991231, 
		@active_start_time=140500, 
		@active_end_time=235959, 
		@schedule_uid=N'231f6130-3276-41ff-8567-f0443da93f87'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L������_�HTick�w��]    Script Date: 2019/5/15 �W�� 09:23:53 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L������_�HTick�w��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�����������]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�����������', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/* ���ѨåΦ۰ʶ]�b�ۦP�����O�мg

DECLARE @t DATE = GETDATE()
DECLARE @m DATE = DATEADD(DAY, 1, @t)

DELETE Trade_DB.dbo.tblOrderReport
WHERE TransactTime BETWEEN @t AND @m
INSERT Trade_DB.dbo.tblOrderReport
  SELECT NEWID(), [Account], [AvgPx], [Channel], [ChannelType], [CumQty], [Errorcode], [ExecID]
      ,[ExecType], [IsReSend], [LastPx], [LastQty], [LeavesQty], [Market], [OrderID], [OrderQty]
      ,[OrdRejReason], [OrdStatus], [OrdType], [Price], [SerialNo], [Side], [Symbol], [Text]
      ,[TimeInForce], [Trader], [TransactTime], [TwseExCode], [TwseIvacnoFlag], [TwseOrdType] 
  FROM [Trade_DB].[dbo].[tblOrderReport_socket]
  WHERE TransactTime BETWEEN @t AND @m


DELETE FROM [Trade_DB].[dbo].[tblExecutionReport400]
WHERE TransactTime BETWEEN @t AND @m
INSERT [Trade_DB].[dbo].[tblExecutionReport400]
  SELECT * FROM Trade_db.dbo.tblExecutionReport400_test
  WHERE TransactTime BETWEEN @t AND @m

*/



DECLARE @t DATE = GETDATE()
DECLARE @m DATE = DATEADD(DAY, 1, @t)
DECLARE @h INT = DATEPART(hour, GETDATE())


IF @h <= 17
BEGIN

-- ����^��
DELETE Trade_DB.dbo.tblOrderReport
WHERE TransactTime BETWEEN @t AND @m

INSERT Trade_DB.dbo.tblOrderReport
  SELECT NEWID(), [Account], [AvgPx], [Channel], [ChannelType], [CumQty], [Errorcode], [ExecID]
      ,[ExecType], [IsReSend], [LastPx], [LastQty], [LeavesQty], [Market], [OrderID], [OrderQty]
      ,[OrdRejReason], [OrdStatus], [OrdType], [Price], [SerialNo], [Side], [Symbol], [Text]
      ,[TimeInForce], [Trader], [TransactTime], [TwseExCode], [TwseIvacnoFlag], [TwseOrdType] 
  FROM db192.[Trade_DB].[dbo].[tblSTradeExecutionReport]
  WHERE TransactTime BETWEEN @t AND @m


-- 400����
DELETE FROM [Trade_DB].[dbo].[tblExecutionReport400]
WHERE TransactTime BETWEEN @t AND @m

INSERT [Trade_DB].[dbo].[tblExecutionReport400]
  --SELECT * FROM Trade_db.dbo.tblExecutionReport400_test
     SELECT * FROM db192.Trade_db.dbo.tblExecutionReport400
  WHERE TransactTime BETWEEN @t AND @m


-- 400�^��
DELETE FROM [Trade_DB].dbo.tblRequestReport400
WHERE TransactTime BETWEEN @t AND @m

INSERT Trade_DB.dbo.tblRequestReport400
  SELECT * FROM DB192.Trade_db.dbo.tblRequestReport400
  WHERE TransactTime BETWEEN @t AND @m


-- KGI Report DONE
DELETE Trade_db.dbo.tblKGI_Report_Done_His
WHERE [InTime] BETWEEN @t AND @m

INSERT Trade_db.dbo.tblKGI_Report_Done_His
  SELECT @T, * FROM db192.Trade_DB.dbo.tblKGI_Report_Done NOLOCK

-- KGI Report Order
DELETE Trade_db.dbo.tblKGI_Report_Order_His WHERE [InTime] BETWEEN @t AND @m 

INSERT Trade_db.dbo.tblKGI_Report_Order_His
    SELECT @T, * FROM db192.Trade_DB.dbo.tblKGI_Report_Order NOLOCK




END
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FrontDeskW_tblIssueQuery_7_1]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FrontDeskW_tblIssueQuery_7_1', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec DailyInsert.dbo.FrontDeskW_tblIssueQuery_7_1 @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_�C��ۮa�v�ҳ̫�BA]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_�C��ۮa�v�ҳ̫�BA', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.[Marketdata_�C��ۮa�v�ҳ̫�BA]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday_DailyOrder]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday_DailyOrder', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.Intraday_DailyOrder @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday_WarrantMMOrderAll]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday_WarrantMMOrderAll', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].dbo.Intraday_WarrantMMOrderAll @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_MarkupAnalysis_���鳡��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_MarkupAnalysis_���鳡��', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�馬�L���Ʀ�)




exec [DailyInsert].[dbo].[PL_MarkupAnalysis_���鳡��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_�ۮa�v��BidVol]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_�ۮa�v��BidVol', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�馬�L���Ʀ�)

exec [DailyInsert].dbo.[PL_�ۮa�v��BidVol] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Intraday_���`�ˮ�]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Intraday_���`�ˮ�', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�馬�L���Ʀ�)

exec DailyInsert.dbo.Intraday_���d�ɶ����`�ˮ� @t
exec DailyInsert.dbo.Intraday_���j�ɶ����`�ˮ� @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�馬�L#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150608, 
		@active_end_date=99991231, 
		@active_start_time=134000, 
		@active_end_time=235959, 
		@schedule_uid=N'fe31f260-fe84-4e91-9a41-6eb847f58477'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L������_���L��~��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L������_���L��~��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [GaryTE]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'GaryTE', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec PL.dbo.GaryTE ''2018/1/26''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C��U�Ȧ��L', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180507, 
		@active_end_date=99991231, 
		@active_start_time=134800, 
		@active_end_time=235959, 
		@schedule_uid=N'54e19c45-5ffe-4876-ac01-9b00ae564200'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L������_�Ũ鳡]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L������_�Ũ鳡', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Vic 20190424 �s�W', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [������_���Ť��q��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'������_���Ť��q��', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t as datetime 
set @t=(select MAX(���) from Cmoney.dbo.�馬�L���Ʀ�)

exec [DailyInsert].[dbo].[PL_��Ũ�����] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [������_CBAS]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'������_CBAS', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
--NEWSYS
exec [DailyInsert].[dbo].[DBMain_CBAS_�C��򥻸�ƶפJ_NEWSYS] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_���Ť��q��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_���Ť��q��', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select MAX(���) from Cmoney.dbo.�馬�L���Ʀ�)

--�������
exec DailyInsert.dbo.PL_������_�Ũ� @t

--�D�޾����O��
exec DailyInsert.dbo.PL_�D�޾����O��_���Ť��q�� @t

--�Ů����J & �������
exec [DailyInsert].dbo.[PL_�C��Ů����J_���Ť��q�ť��] @t
exec [DailyInsert].dbo.[PL_�C��������_���Ť��q�ť��] @t

--�[�J�קI�l�q
exec [DailyInsert].[dbo].[PL_�C��Ũ鳡�ײv�l�q_����] @t
exec [DailyInsert].[dbo].[PL_�C��Ũ鳡�ײv�l�q]

exec [DailyInsert].[dbo].[PL_�C��Ũ鳡RPRS] @t

exec DailyInsert.[dbo].[PL_���Ť��q�ų����ɲz�קQ�v] @t
exec DailyInsert.dbo.[PL_DailyPLReport_���Ť��q�ť��]
exec DailyInsert.dbo.[PL_DailyPLReport_���Ť��q�ť��_�������]

exec DailyInsert.[dbo].[PL_���Ť��q�ŷl�qBD] @t
exec DailyInsert.[dbo].[PL_���ť���l�q] @t
exec DailyInsert.[dbo].[PL_���ť���l�q_�D�ƨ�] @t

exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡_�Ũ��� @t,''�Ũ���''
exec DailyInsert.dbo.PL_���I���޸IĲ���v�Ũ鳡_�Ũ��� @t,''���ť��''
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�l�ӳ�_RPRS�l�q]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�l�ӳ�_RPRS�l�q', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec DailyInsert.[dbo].[PL_DailyPLReport_�l�Ӧ���_RPRS]
exec DailyInsert.[dbo].[PL_�l�ӳ�RPRS�l�q] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_CBAS]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_CBAS', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)
exec [DailyInsert].[dbo].[PL_CBASDailyPLReportMD_NEWSYS] @t
--�Q�v�פJ
exec [DailyInsert].[dbo].[DBMain_Rate_Swap_rate] @t
--�Q�v���u
exec DailyInsert.dbo.Credit_TermStructure_IRS @t
--���� CBAS�򥻸����J
exec [DailyInsert].[dbo].[DBMain_CBAS_�C��򥻸�ƶפJ] @t
--���⤵��s�@�@ASW �I����
exec [DailyInsert].dbo.DBMain_CBAS_�I���� @t

exec [DailyInsert].[dbo].DBMain_CBASUSRDEPTID @t
-- ASW PL����
exec [DailyInsert].dbo.PL_CBAS_ASW_PL @t
--ASO PL����
exec [DailyInsert].dbo.PL_CBAS_ASO_PL @t
exec [DailyInsert].dbo.PL_CBAS_ASW_PL_YR @t
exec [DailyInsert].[dbo].PL_CBASDailiPLReportMD @t
exec [DailyInsert].[dbo].MDoutput_ASW_DAILY @t
exec [DailyInsert].dbo.[PL_CBAS�C��ֿnPL] @t
exec [DailyInsert].dbo.[PL_CBAS�C��ֿnPL����] @t
exec DailyInsert.dbo.Monitor_CBAS�C��ϥ��B�� @t,''���ĥ���B''
exec DailyInsert.dbo.Monitor_CBAS�C��ϥ��B�� @t,''�Ũ�@��''
exec DailyInsert.dbo.Monitor_CBAS�C��ϥ��B�� @t,''�Ũ�G��''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PL_FXSWAP_IRS]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PL_FXSWAP_IRS', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

--FX Swap
exec DailyInsert.dbo.[PL_DailyPLReport_FX_SWAP] @t

--IRS
--exec [DailyInsert].[dbo].[Credit_IRSRate_Bootstrap] @t
--exec [DailyInsert].[dbo].[PL_DailyPLReport_IRS] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�T�w���l�q����]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�T�w���l�q����', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

EXEC [DailyInsert].[dbo].PL_PHP_�C��U���l�q���p @t
EXEC [DailyInsert].[dbo].PL_����B�J���_MD @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [KMV]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'KMV', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t = (select MAX(Stadate) from pl.dbo.inventory)

exec DailyInsert.[dbo].[Credit_DailyEDF_���y�k] @t
exec DailyInsert.dbo.[MDoutput_Php_KMVDefaultRateList]
exec DailyInsert.dbo.[MDoutput_Php_KMVDeptAvg] ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'0800', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190425, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959, 
		@schedule_uid=N'914402cb-3e2c-4fc7-b879-6e1bc9754284'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'1830', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190424, 
		@active_end_date=99991231, 
		@active_start_time=183000, 
		@active_end_time=235959, 
		@schedule_uid=N'822b95f9-6010-4a37-9d30-9cf0df4b9458'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'1950', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190424, 
		@active_end_date=99991231, 
		@active_start_time=195000, 
		@active_end_time=235959, 
		@schedule_uid=N'27715a67-1bbf-4abe-b9be-4c1738eef9f5'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�L������IT�B�����w��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�L������IT�B�����w��', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Theodata_HistoryVol]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Theodata_HistoryVol', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec [DailyInsert].[dbo].[Theodata_HistoryVol] @t
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Theodata_�C�餽��BookVol]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Theodata_�C�餽��BookVol', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.Theodata_�C�餽��BookVol @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cmoney_����Ӷi�X�����]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cmoney_����Ӷi�X�����', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from Cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec [DailyInsert].[dbo].Cmoney_����Ӷi�X����� @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [.Pro_�P�~�v��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'.Pro_�P�~�v��', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.Pro_�P�~�v�ҥ�� @t
exec DailyInsert.dbo.Pro_�v�ҵ������ @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info @t

exec DailyInsert.dbo.Pro_�P�~�l�q���p @t
exec DailyInsert.dbo.Pro_�P�~�l�q���p_������ @t

exec [DailyInsert].dbo.[Pro_�P�~�l�q�J��] @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdatePL @t
exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdateTV @t
exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o���ɼ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_�C��Ѳ��̫�BA]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_�C��Ѳ��̫�BA', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DailyInsert.dbo.[Marketdata_�C��Ѳ��̫�BA]', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarketData_�v�Ҧ�����B_���Ъ�]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarketData_�v�Ҧ�����B_���Ъ�', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.[MarketData_�v�Ҧ�����B_���Ъ�] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TestDB_�j�L�d�R�����ѨC�饫��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TestDB_�j�L�d�R�����ѨC�饫��', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec dailyinsert.[dbo].[TestDB_�j�L�d�R�����ѨC�饫��] @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Marketdata_DailyQuote]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Marketdata_DailyQuote', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.Marketdata_DailyQuote @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [StockChain]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'StockChain', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

exec DailyInsert.dbo.Z_StockChain ''5'',@t
exec DailyInsert.dbo.Z_StockChain ''10'',@t
exec DailyInsert.dbo.Z_StockChain ''20'',@t
exec DailyInsert.dbo.Z_StockChain ''60'',@t
exec DailyInsert.dbo.Z_StockChain ''120'',@t

--exec DailyInsert.dbo.Z_StockChain_hour ''3'',@t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Pro�w��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Pro�w��', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

--exec DailyInsert.dbo.Pro_�P�~�v�ҥ�� @t
--exec DailyInsert.dbo.Pro_�v�ҵ������ @t
--exec DailyInsert.dbo.Pro_�v�ҵo���Info @t

--exec DailyInsert.dbo.Pro_�P�~�l�q���p @t
--exec DailyInsert.dbo.Pro_�P�~�l�q���p_������ @t

--exec [DailyInsert].dbo.[Pro_�P�~�l�q�J��] @t
--exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdatePL @t
--exec DailyInsert.dbo.Pro_�v�ҵo���Info_UpdateTV @t
--exec [DailyInsert].dbo.[Pro_�v�ҵo���Info_Update�o���ɼ�] @t

exec DailyInsert.dbo.[Pro_�ۮa�������] @t
exec [DailyInsert].dbo.[Pro_�i��ŵ������] @t

exec [DailyInsert].dbo.[Pro_�������ӥD�O���G] @t
exec [DailyInsert].dbo.[Pro_�������ӥD�O���G10��30��] @t
exec [DailyInsert].dbo.[Pro_�������ӥD�O���GJohnny] @t

exec [DailyInsert].dbo.[Pro_�v�ҽL���������_���z] @t


exec DailyInsert.dbo.Pro_�v�ҷl�qBreakDown

exec DailyInsert.dbo.Pro_CBVolTradeDeallist @t

exec DailyInsert.dbo.[Pro_�Ъ�OS���ȥ����v] @t
exec DailyInsert.dbo.[Pro_��Ӧ��楫���v] @t


exec DailyInsert.dbo.DB39_tblOtherWarrantImpVol
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tbl_Tick_Seccode]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tbl_Tick_Seccode', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DailyInsert].dbo.TestDB_tbl_Tick_Seccode', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�ѱߤW#1', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150512, 
		@active_end_date=99991231, 
		@active_start_time=163000, 
		@active_end_time=235959, 
		@schedule_uid=N'224bc9fc-563b-4531-a53a-01040003b3a3'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�v�ҥN�z(Arielle)]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�v�ҥN�z(Arielle)', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�v�ҥN�z(Arielle)', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҥN�z(A)]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҥN�z(A)', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from  [dbo].[Deputy_tblUserWarrantUnderlying]

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6239'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''4919'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1590'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3035'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1305'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1565'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1905'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2409'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2474'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1536'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2727'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2352'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3152'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2317'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3227'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3406'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3081'', GETDATE())
GO
INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3691'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1605'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1707'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2023'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2103'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2303'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2330'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2498'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2882'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3293'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3545'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3673'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''4966'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6176'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6214'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6269'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6414'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6451'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6116'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3078'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2345'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6488'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''00632R'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2328'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''5871'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''8234'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''5317'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3264'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''8406'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''00631L'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2485'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''5392'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6153'', GETDATE())
GO
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3211'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''5425'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''5483'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3037'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2603'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2313'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3289'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2382'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2456'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''5478'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''6285'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''0050'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''00635U'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''00637L'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''00648R'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1215'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1310'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1522'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1527'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1560'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1589'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1815'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2455'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2618'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2888'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2891'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3023'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3231'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3324'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3596'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3532'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3611'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3702'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''4426'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''4938'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''8936'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''3374'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''00642U'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''00672L'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1476'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1704'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''8358'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''6230'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''1216'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2353'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''2515'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''arielle'', ''8404'', GETDATE())
GO
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''6187'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2337'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3552'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''4943'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3260'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3008'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''6456'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2454'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2383'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2049'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''8299'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2458'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''4958'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2448'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3189'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''6452'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''4947'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2344'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3380'', GETDATE())
GO


INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2233'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2360'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''1710'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''6238'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2340'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''1802'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2392'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2451'', GETDATE())
GO
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------
INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''0050'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2888'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3374'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2313'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''3037'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''1215'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''6285'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''5425'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''8404'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''2891'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''tony'', ''4426'', GETDATE())
GO
-----------------------------------------------------------------------------
INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3023'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1476'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2353'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1310'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1216'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3532'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2456'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''2382'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3596'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''1815'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''6230'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''3289'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''00642U'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''4938'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''00637L'', GETDATE())
GO

INSERT INTO [dbo].[Deputy_tblUserWarrantUnderlying]
           ([UserId]
           ,[UnderlyingCode]
           ,[ModiTime])
     VALUES
           (''sam'', ''00648R'', GETDATE())
GO

delete from [Trade_DB].[dbo].[Deputy_tblUserWarrantUnderlying]
where [UnderlyingCode] not in (select [UnderlyingCode] FROM [Trade_DB].[dbo].[tblUserWarrantUnderlying])
GO', 
		@database_name=N'Trade_DB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�v�ҥN�z(����)', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161017, 
		@active_end_date=99991231, 
		@active_start_time=80700, 
		@active_end_time=235959, 
		@schedule_uid=N'f01e61ea-f3e4-429f-99f6-30dbe3a5a240'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�v�ҵo��פJ]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�v�ҵo��פJ', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�v�ҵo���ƶפJ', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MD', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�ˬd�O�_�������]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�ˬd�O�_�������', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҼW�B�פJ]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҼW�B�פJ', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @T DATE = GETDATE()

EXEC OperationDesk.dbo.�v�ҼW�B���ӶפJ @T', 
		@database_name=N'OperationDesk', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [�v�ҵ��P�פJ]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'�v�ҵ��P�פJ', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
exec OperationDesk.dbo.�v�ҵ��P���ӶפJ @t', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [��s�v�Ҹ��]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'��s�v�Ҹ��', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t DATE = CONVERT(date, GETDATE())

Exec DailyInsert.dbo.DBMain_�v�ҵo��s����s @t

EXEC DailyInsert.dbo.DBMain_�v�ҵo��פJ @t, default

Exec DailyInsert.dbo.DBMain_�v�ҵo�歫�]�����s @t', 
		@database_name=N'DBMain', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�U�Ȥ��I��W', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161111, 
		@active_end_date=99991231, 
		@active_start_time=183000, 
		@active_end_time=235959, 
		@schedule_uid=N'd1f30a45-2f6e-474e-9f1e-567dc897b118'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�C�����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161108, 
		@active_end_date=99991231, 
		@active_start_time=140000, 
		@active_end_time=235959, 
		@schedule_uid=N'db6e14df-ac1a-44f6-a93c-7d501e6f70fc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [�v�����I�ƴ�(43)]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'�v�����I�ƴ�(43)', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�v�����I�ƴ�(43)', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'IT', 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tradingdate]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*)
from DBMain.dbo.tradingdate
where datepart(yy,Tradingdate)=datepart(yy,getdate())
and datepart(mm,Tradingdate)=datepart(mm,getdate())
and datepart(dd,Tradingdate)=datepart(dd,getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB(43)]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB(43)', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--tblDailyFutures(���n)
delete from [DB2].[Trade_DB].[dbo].[tblDailyFutures];
go
insert into [DB2].[Trade_DB].[dbo].[tblDailyFutures] ([DayDate]
      ,[FutureId]
      ,[CmoneyId]
      ,[FutureName]
      ,[UnderlyingId]
      ,[UnderlyingName]
      ,[MaturityDay]
      ,[ContractRatio]
	  ,[UnderlyingType])
select [DayDate]
      ,[FutureId]
      ,[CmoneyId]
      ,[FutureName]
      ,[UnderlyingId]
      ,[UnderlyingName]
      ,[MaturityDay]
      ,[ContractRatio]
	  ,0 from [Trade_DB].[dbo].[tblDailyFutures];
go
update [DB2].[Trade_DB].[dbo].[tblDailyFutures]
set [UnderlyingType] = 1
where [UnderlyingId] in (select [�N��] from [Cmoney].[dbo].[ETF�򥻸��])
go
update [DB2].[Trade_DB].[dbo].[tblDailyFutures]
set [UnderlyingType] = 2
where [UnderlyingId] in (select [�Ѳ��N��] from [Cmoney].[dbo].[�W���d���q�򥻸��])
go


--tblDailyStockInfo(���n)
delete from [DB2].[Trade_DB].[dbo].[tblDailyStockInfo];
go
insert into [DB2].[Trade_DB].[dbo].[tblDailyStockInfo] ([DayDate]
      ,[StockId]
      ,[StockName]
      ,[PrevOpen]
      ,[PrevHigh]
      ,[PrevLow]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[MarketType]
      ,[IsDayTrade]
      ,[HedgePrediction]
      ,[HedgeFrequency]
      ,[OtherWarrant]
	  ,[UnderlyingType])
select [DayDate]
      ,[StockId]
      ,[StockName]
      ,[PrevOpen]
      ,[PrevHigh]
      ,[PrevLow]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[MarketType]
      ,[IsDayTrade]
      ,[HedgePrediction]
      ,[HedgeFrequency]
      ,[OtherWarrant]
	  ,0 from [Trade_DB].[dbo].[tblDailyStockInfo];
go

update [DB2].[Trade_DB].[dbo].[tblDailyStockInfo]
set [UnderlyingType] = 1
where [StockId] in (select distinct [�N��] from [Cmoney].[dbo].[ETF�򥻸��])
go

update [DB2].[Trade_DB].[dbo].[tblDailyStockInfo]
set [UnderlyingType] = 2
where [StockId] in (select distinct [�Ѳ��N��] from [Cmoney].[dbo].[�W���d���q�򥻸��])
go

--tblDailyWarrantInfo(���n)
delete from [DB2].[Trade_DB].[dbo].[tblDailyWarrantInfo];
go
insert into [DB2].[Trade_DB].[dbo].[tblDailyWarrantInfo] ([DayDate]
      ,[WarrantId]
      ,[WarrantName]
      ,[StockId]
      ,[StockName]
      ,[CallPut]
      ,[Issuer]
      ,[LastTranDay]
      ,[MaturityDay]
      ,[TradeDays]
      ,[Days]
      ,[StrikePrice]
      ,[Rho]
      ,[IV]
      ,[VolH]
      ,[VolQ]
      ,[Vol30D]
      ,[ExerciseRatio]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[IsSelf]
      ,[VolM]
      ,[MarketType]
	  ,[VolDown]
      ,[�ۦ���]
      ,[�U�ժŶ�]
      ,[í�w��]
      ,[�`��]
      ,[mHR]
	  ,[UnderlyingType])
select [DayDate]
      ,[WarrantId]
      ,[WarrantName]
      ,[StockId]
      ,[StockName]
      ,[CallPut]
      ,[Issuer]
      ,[LastTranDay]
      ,[MaturityDay]
      ,[TradeDays]
      ,[Days]
      ,[StrikePrice]
      ,[Rho]
      ,[IV]
      ,[VolH]
      ,[VolQ]
      ,[Vol30D]
      ,[ExerciseRatio]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[IsSelf]
      ,[VolM]
      ,[MarketType]
      ,[VolDown]
      ,[�ۦ���]
      ,[�U�ժŶ�]
      ,[í�w��]
      ,[�`��]
      ,[mHR]
	  ,0 from [Trade_DB].[dbo].[tblDailyWarrantInfo];
go
update [DB2].[Trade_DB].[dbo].[tblDailyFutures]
set [UnderlyingType] = 1
where [UnderlyingId] in (select distinct [�N��] from [Cmoney].[dbo].[ETF�򥻸��])
go

update [DB2].[Trade_DB].[dbo].[tblDailyFutures]
set [UnderlyingType] = 2
where [UnderlyingId] in (select distinct [�Ѳ��N��] from [Cmoney].[dbo].[�W���d���q�򥻸��])
go


--tblPrevPL(���n)
delete from [DB2].[Trade_DB].[dbo].[tblPrevPL];
go
insert into [DB2].[Trade_DB].[dbo].[tblPrevPL] ([Date]
      ,[UserId]
      ,[PortfolioId]
      ,[TraderId]
      ,[Type]
      ,[Property]
      ,[ProductId]
      ,[Pos]
      ,[Inv]
      ,[Amt])
select [TXN_DT]
      ,[USER_ID]
	  ,[STOCK_ID]
	  ,[TRADE_ID]
	  ,0
	  ,0
	  ,[STOCK_ID]
	  ,[PL_POS]
      ,[PL_QTY]
      ,[PL_AMT]
       from [Trade_DB].[dbo].[tblPrevPL];
go
--update tblPrevPL ProductType(���n)
update [DB2].[Trade_DB].[dbo].[tblPrevPL]
set [Type] = 1
where [ProductId] in (select [WarrantId] from [DB2].[Trade_DB].[dbo].[tblDailyWarrantInfo])
go
update [DB2].[Trade_DB].[dbo].[tblPrevPL]
set [Type] = 2
where [ProductId] in (select [FutureId] from [DB2].[Trade_DB].[dbo].[tblDailyFutures])
go
update [DB2].[Trade_DB].[dbo].[tblPrevPL]
set [PortfolioId] = (select top 1 [StockId] from [DB2].[Trade_DB].[dbo].[tblDailyWarrantInfo] where [WarrantId] = [ProductId])
where [Type] = 1
go
update [DB2].[Trade_DB].[dbo].[tblPrevPL]
set [PortfolioId] = (select top 1 [UnderlyingId] from [DB2].[Trade_DB].[dbo].[tblDailyFutures] where [FutureId] = [ProductId])
where [Type] = 2
go
--tblPortfolio(���n)
delete from [DB2].[Trade_DB].[dbo].[tblPortfolio];
go
INSERT INTO [DB2].[Trade_DB].[dbo].[tblPortfolio]
([UserId],[PortfolioId],[UserId_Deputy])
SELECT [UserId],[UnderlyingCode],[UserId] 
FROM [Trade_DB].[dbo].[tblUserWarrantUnderlying]
go
--tblUserHedgeFuture(���n)
delete from [DB2].[Trade_DB].[dbo].[tblUserHedgeFuture];
go
INSERT INTO [DB2].[Trade_DB].[dbo].[tblUserHedgeFuture]
([UserId],[PortfolioId],[HedgeFutureId],[UserId_Deputy])
SELECT [UserId],[UnderlyingCode],[FutureId],[Deputy] 
FROM (select U.[UserId], U.[UnderlyingCode], F.[FutureId], U.[UserId] as [Deputy] from [Trade_DB].[dbo].[tblUserWarrantUnderlying] U
inner join 	[Trade_DB].[dbo].[tblDailyFutures] F on U.[UnderlyingCode] = F.[UnderlyingId]) Temp
go
--tblUserHedgeStock(���n)
delete from [DB2].[Trade_DB].[dbo].[tblUserHedgeStock];
go
INSERT INTO [DB2].[Trade_DB].[dbo].[tblUserHedgeStock]
([UserId],[PortfolioId],[HedgeStockId],[UserId_Deputy])
SELECT U.[UserId], U.[UnderlyingCode], U.[UnderlyingCode],U.[UserId] as [Deputy]
FROM [Trade_DB].[dbo].[tblUserWarrantUnderlying] U
go
--tblUserHedgeWarrant(���n)
delete from [DB2].[Trade_DB].[dbo].[tblUserHedgeWarrant];
go
INSERT INTO [DB2].[Trade_DB].[dbo].[tblUserHedgeWarrant]
([UserId],[PortfolioId],[HedgeWarrantId],[UserId_Deputy])
SELECT Temp.[UserId], Temp.[UnderlyingCode], Temp.[WarrantId] ,Temp.[Deputy]
FROM (select U.[UserId], U.[UnderlyingCode], W.[WarrantId], U.[UserId] as [Deputy] from [Trade_DB].[dbo].[tblUserWarrantUnderlying] U
inner join 	[Trade_DB].[dbo].[tblDailyWarrantInfo] W on U.[UnderlyingCode] = W.[StockId] and W.[IsSelf] = 0) Temp
go
--tblUserSelfWarrant(���n)
delete from [DB2].[Trade_DB].[dbo].[tblUserSelfWarrant];
go
INSERT INTO [DB2].[Trade_DB].[dbo].[tblUserSelfWarrant]
([UserId],[PortfolioId],[SelfWarrantId],[UserId_Deputy])
SELECT Temp.[UserId], Temp.[UnderlyingCode], Temp.[WarrantId] ,Temp.[Deputy]
FROM (select U.[UserId], U.[UnderlyingCode], W.[WarrantId], U.[UserId] as [Deputy] from [Trade_DB].[dbo].[tblUserWarrantUnderlying] U
inner join 	[Trade_DB].[dbo].[tblDailyWarrantInfo] W on U.[UnderlyingCode] = W.[StockId] and W.[IsSelf] = 1) Temp
go
--tblUserWarrantUnderlyingOrderSetting(���n)
delete from [DB2].[Trade_DB].[dbo].[tblUserWarrantUnderlyingOrderSetting];
go
insert into [DB2].[Trade_DB].[dbo].[tblUserWarrantUnderlyingOrderSetting] ([UserId]
      ,[UnderlyingId]
      ,[OrderIndex])
select [UserId]
      ,[UnderlyingId]
      ,[OrderIndex] from [Trade_DB].[dbo].[tblUserWarrantUnderlyingOrderSetting];
go
--tblWarrantDefaultBuySellSetting(���n)
delete from [DB2].[Trade_DB].[dbo].[tblWarrantDefaultBuySellSetting];
go
insert into [DB2].[Trade_DB].[dbo].[tblWarrantDefaultBuySellSetting] ([UserId]
      ,[WarrantId]
      ,[IsCanSell]
      ,[IsCanBuy])
select [UserId]
      ,[WarrantId]
      ,[IsCanSell]
      ,[IsCanBuy] from [Trade_DB].[dbo].[tblWarrantDefaultBuySellSetting];
go
--tblWarrantFilterRule(���n)
delete from [DB2].[Trade_DB].[dbo].[tblWarrantFilterRule];
go
insert into [DB2].[Trade_DB].[dbo].[tblWarrantFilterRule] ([PKey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[Value]
      ,[ModiTime])
select [PKey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[Value]
      ,[ModiTime] from [Trade_DB].[dbo].[tblWarrantFilterRule];
go
--tblWarrantDefaultFilterRule(���n)
delete from [DB2].[Trade_DB].[dbo].[tblWarrantDefaultFilterRule];
go
insert into [DB2].[Trade_DB].[dbo].[tblWarrantDefaultFilterRule] ([PKey]
      ,[UserId]
      ,[RuleName]
      ,[IsDefaultRule])
select [PKey]
      ,[UserId]
      ,[RuleName]
      ,[IsDefaultRule] from [Trade_DB].[dbo].[tblWarrantDefaultFilterRule];
go
--tblWarrantFilterRuleOrder(���n)
delete from [DB2].[Trade_DB].[dbo].[tblWarrantFilterRuleOrder];
go
insert into [DB2].[Trade_DB].[dbo].[tblWarrantFilterRuleOrder] ([WarrantFilterRulePkey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[OrderIndex]
      ,[OrderByAsc]
      ,[TakePercent]
      ,[TakeCount])
select [WarrantFilterRulePkey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[OrderIndex]
      ,[OrderByAsc]
      ,[TakePercent]
      ,[TakeCount] from [Trade_DB].[dbo].[tblWarrantFilterRuleOrder];
go
--tblQuickHedgeSetting(���n)
delete from [DB2].[Trade_DB].[dbo].[tblQuickHedgeSetting];
go
insert into [DB2].[Trade_DB].[dbo].[tblQuickHedgeSetting] ([UserId]
      ,[UnderlyingId]
      ,[AutoHedgeType]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockOrderPriceType]
      ,[StockOrderPriceTick]
      ,[WarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantOrderPriceType]
      ,[WarrantOrderPriceTick]
      ,[FutureOrderMaxQty]
      ,[FutureOrderPriceType]
      ,[FutureOrderPriceTick])
select [UserId]
      ,[UnderlyingId]
      ,[AutoHedgeType]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockOrderPriceType]
      ,[StockOrderPriceTick]
      ,[WarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantOrderPriceType]
      ,[WarrantOrderPriceTick]
      ,[FutureOrderMaxQty]
      ,[FutureOrderPriceType]
      ,[FutureOrderPriceTick] from [Trade_DB].[dbo].[tblQuickHedgeSetting];
go
--tblQuickOrderDefaultSetting(���n)
delete from [DB2].[Trade_DB].[dbo].[tblQuickOrderDefaultSetting];
go
insert into [DB2].[Trade_DB].[dbo].[tblQuickOrderDefaultSetting] ([UserId]
      ,[UnderlyingId]
      ,[WarrantBuyQty]
      ,[WarrantSellQty]
      ,[WarrantBuyTick]
      ,[WarrantSellTick]
      ,[StockBuyQty]
      ,[StockSellQty]
      ,[StockBuyTick]
      ,[StockSellTick]
      ,[StockMaxOrderQty]
      ,[WarrantBuyPriceType]
      ,[WarrantSellPriceType]
      ,[StockBuyPriceType]
      ,[StockSellPriceType])
select [UserId]
      ,[UnderlyingId]
      ,[WarrantBuyQty]
      ,[WarrantSellQty]
      ,[WarrantBuyTick]
      ,[WarrantSellTick]
      ,[StockBuyQty]
      ,[StockSellQty]
      ,[StockBuyTick]
      ,[StockSellTick]
      ,[StockMaxOrderQty]
      ,[WarrantBuyPriceType]
      ,[WarrantSellPriceType]
      ,[StockBuyPriceType]
      ,[StockSellPriceType] from [Trade_DB].[dbo].[tblQuickOrderDefaultSetting];
go
--tblAutoHedgeRiskCheck(���n)
delete from [DB2].[Trade_DB].[dbo].[tblAutoHedgeRiskCheck];
go
insert into [DB2].[Trade_DB].[dbo].[tblAutoHedgeRiskCheck] ([UnderlyingId]
      ,[MaxOrderMoney]
      ,[CumMaxOrderMoney]
      ,[CumFireAutoHedgeCount1]
      ,[CumFireAutoHedgeCount2])
select [UnderlyingId]
      ,[MaxOrderMoney]
      ,[CumMaxOrderMoney]
      ,[CumFireAutoHedgeCount1]
      ,[CumFireAutoHedgeCount2] from [Trade_DB].[dbo].[tblAutoHedgeRiskCheck];
go
--tblAutoHedgeSetting(���n)
delete from [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting];
go
insert into [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting] ([UserId]
      ,[UnderlyingId]
      ,[IsEnable]
      ,[StockPriceDiffer]
      ,[FireDeltaHMoney]
      ,[FireDG]
      ,[HedgeDeltaHMoney]
      ,[HedgeDG]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsAutoHedgeCycle]
      ,[IsClearOtherWarrant]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent])
select [UserId]
      ,[UnderlyingId]
      ,[IsEnable]
      ,[StockPriceDiffer]
      ,[FireDeltaHMoney]
      ,[FireDG]
      ,[HedgeDeltaHMoney]
      ,[HedgeDG]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsAutoHedgeCycle]
      ,[IsClearOtherWarrant]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent] from [Trade_DB].[dbo].[tblAutoHedgeSetting];
go
--tblAutoHedgeSetting_WarrantDeal(���n)
delete from [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting_WarrantDeal];
go
insert into [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting_WarrantDeal] ( [UserId]
      ,[UnderlyingId]
      ,[FireDeltaHMoney]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsClearOtherWarrant]
      ,[IsEnable]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent]
      ,[IsAutoHedgeCycle]
      ,[FireDG])
select  [UserId]
      ,[UnderlyingId]
      ,[FireDeltaHMoney]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsClearOtherWarrant]
      ,[IsEnable]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent]
      ,[IsAutoHedgeCycle]
      ,[FireDG] from [Trade_DB].[dbo].[tblAutoHedgeSetting_WarrantDeal];
go
--tblAutoHedgeSetting���x�Ѽ�(���n)
delete from [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
insert into [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�] ([Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt])
select [Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt] from [Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
--tblAutoHedgeSetting���x�Ѽ�(���n)
delete from [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
insert into [DB2].[Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�] ([Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt])
select [Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt] from [Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
--tblAutoHedgeSetting���x�Ѽ�(���n)
delete from [DB2].[Trade_DB].[dbo].[tblWarrantInvLimit];
go
insert into [DB2].[Trade_DB].[dbo].[tblWarrantInvLimit] ([WarrnatId]
      ,[LimitInv])
select [WarrnatId]
      ,[LimitInv] from [Trade_DB].[dbo].[tblWarrantInvLimit];
go
--tblOrderReport(���n)
delete from  [DB2].[Trade_DB].[dbo].[tblOrderReport]
go
--tblWrrmm(�D���n�ۮa�y���ʱ��D���n)
delete from [DB2].[Trade_DB].[dbo].[tblWrrmm];
go
insert into [DB2].[Trade_DB].[dbo].[tblWrrmm] ([Wrrmm]
      ,[Vol�U��]
      ,[Vol�W��]
      ,[WarrantID]
      ,[Trader]
      ,[TraderName]
      ,[PricingVol]
      ,[BookVol]
      ,[StartDate])
select [Wrrmm]
      ,[Vol�U��]
      ,[Vol�W��]
      ,[WarrantID]
      ,[Trader]
      ,[TraderName]
      ,[PricingVol]
      ,[BookVol]
      ,[StartDate] from [Trade_DB].[dbo].[tblWrrmm];
go
--tblInvLimit(���n)
delete from [DB2].[Trade_DB].[dbo].[tblInvLimit]
go

INSERT INTO [DB2].[Trade_DB].[dbo].[tblInvLimit]
([UserId],[PortfolioId],[ProductId],[InvLimit])
SELECT [UserId],[PortfolioId],[HedgeStockId],99999
FROM [DB2].[Trade_DB].[dbo].[tblUserHedgeStock]
go

update [DB2].[Trade_DB].[dbo].[tblInvLimit]
set [InvLimit] = 3600
where [ProductId] = ''2408''
go

INSERT INTO [DB2].[Trade_DB].[dbo].[tblInvLimit]
([UserId],[PortfolioId],[ProductId],[InvLimit])
SELECT [UserId],[PortfolioId],[HedgeFutureId],99999
FROM [DB2].[Trade_DB].[dbo].[tblUserHedgeFuture]
go

INSERT INTO [DB2].[Trade_DB].[dbo].[tblInvLimit]
([UserId],[PortfolioId],[ProductId],[InvLimit])
SELECT [UserId],[PortfolioId],[HedgeWarrantId],[LimitInv]
FROM (SELECT HW.[UserId], HW.[PortfolioId], HW.[HedgeWarrantId], IL.[LimitInv] FROM [DB2].[Trade_DB].[dbo].[tblUserHedgeWarrant] HW
inner join [Trade_DB].[dbo].[tblWarrantInvLimit] IL ON HW.[HedgeWarrantId] = IL.[WarrnatId]) Temp
go', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trade_DB_Test(43)]    Script Date: 2019/5/15 �W�� 09:23:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trade_DB_Test(43)', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*--tblDailyFutures(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblDailyFutures];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblDailyFutures] ([DayDate]
      ,[FutureId]
      ,[CmoneyId]
      ,[FutureName]
      ,[UnderlyingId]
      ,[UnderlyingName]
      ,[MaturityDay]
      ,[ContractRatio])
select [DayDate]
      ,[FutureId]
      ,[CmoneyId]
      ,[FutureName]
      ,[UnderlyingId]
      ,[UnderlyingName]
      ,[MaturityDay]
      ,[ContractRatio] from [Trade_DB].[dbo].[tblDailyFutures];
go
--tblDailyStockInfo(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblDailyStockInfo];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblDailyStockInfo] ([DayDate]
      ,[StockId]
      ,[StockName]
      ,[PrevOpen]
      ,[PrevHigh]
      ,[PrevLow]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[MarketType]
      ,[IsDayTrade]
      ,[HedgePrediction]
      ,[HedgeFrequency]
      ,[OtherWarrant])
select [DayDate]
      ,[StockId]
      ,[StockName]
      ,[PrevOpen]
      ,[PrevHigh]
      ,[PrevLow]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[MarketType]
      ,[IsDayTrade]
      ,[HedgePrediction]
      ,[HedgeFrequency]
      ,[OtherWarrant] from [Trade_DB].[dbo].[tblDailyStockInfo];
go
--tblDailyWarrantInfo(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblDailyWarrantInfo];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblDailyWarrantInfo] ([DayDate]
      ,[WarrantId]
      ,[WarrantName]
      ,[StockId]
      ,[StockName]
      ,[CallPut]
      ,[Issuer]
      ,[LastTranDay]
      ,[MaturityDay]
      ,[TradeDays]
      ,[Days]
      ,[StrikePrice]
      ,[Rho]
      ,[IV]
      ,[VolH]
      ,[VolQ]
      ,[Vol30D]
      ,[ExerciseRatio]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[IsSelf]
      ,[VolM]
      ,[MarketType]
	  ,[VolDown]
      ,[�ۦ���]
      ,[�U�ժŶ�]
      ,[í�w��]
      ,[�`��]
      ,[mHR])
select [DayDate]
      ,[WarrantId]
      ,[WarrantName]
      ,[StockId]
      ,[StockName]
      ,[CallPut]
      ,[Issuer]
      ,[LastTranDay]
      ,[MaturityDay]
      ,[TradeDays]
      ,[Days]
      ,[StrikePrice]
      ,[Rho]
      ,[IV]
      ,[VolH]
      ,[VolQ]
      ,[Vol30D]
      ,[ExerciseRatio]
      ,[PrevClose]
      ,[PrevAsk]
      ,[PrevAskQty]
      ,[PrevBid]
      ,[PrevBidQty]
      ,[IsSelf]
      ,[VolM]
      ,[MarketType]
      ,[VolDown]
      ,[�ۦ���]
      ,[�U�ժŶ�]
      ,[í�w��]
      ,[�`��]
      ,[mHR] from [Trade_DB].[dbo].[tblDailyWarrantInfo];
go
--tblPrevPL(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblPrevPL];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblPrevPL] ([TXN_DT]
      ,[USER_ID]
      ,[TRADE_ID]
      ,[STOCK_ID]
      ,[PL_QTY]
      ,[PL_AMT]
      ,[STOCK_TYPE]
      ,[PL_POS])
select [TXN_DT]
      ,[USER_ID]
      ,[TRADE_ID]
      ,[STOCK_ID]
      ,[PL_QTY]
      ,[PL_AMT]
      ,[STOCK_TYPE]
      ,[PL_POS] from [Trade_DB].[dbo].[tblPrevPL];
go
--update tblPrevPL ProductType(���n)
update [DB2].[Trade_DB_Test].[dbo].[tblPrevPL]
set [STOCK_TYPE] = 1
where [STOCK_ID] in (select [WarrantId] from [DB2].[Trade_DB_Test].[dbo].[tblDailyWarrantInfo])
go
update [DB2].[Trade_DB_Test].[dbo].[tblPrevPL]
set [STOCK_TYPE] = 2
where [STOCK_ID] in (select [FutureId] from [DB2].[Trade_DB_Test].[dbo].[tblDailyFutures])
go
--tblUserWarrantUnderlying(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblUserWarrantUnderlying];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblUserWarrantUnderlying] ([UserId]
      ,[UnderlyingCode]
      ,[ModiTime])
select [UserId]
      ,[UnderlyingCode]
      ,[ModiTime] from [Trade_DB].[dbo].[tblUserWarrantUnderlying];
go
--tblUserWarrantUnderlyingOrderSetting(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblUserWarrantUnderlyingOrderSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblUserWarrantUnderlyingOrderSetting] ([UserId]
      ,[UnderlyingId]
      ,[OrderIndex])
select [UserId]
      ,[UnderlyingId]
      ,[OrderIndex] from [Trade_DB].[dbo].[tblUserWarrantUnderlyingOrderSetting];
go
--tblWarrantDefaultBuySellSetting(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblWarrantDefaultBuySellSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblWarrantDefaultBuySellSetting] ([UserId]
      ,[WarrantId]
      ,[IsCanSell]
      ,[IsCanBuy])
select [UserId]
      ,[WarrantId]
      ,[IsCanSell]
      ,[IsCanBuy] from [Trade_DB].[dbo].[tblWarrantDefaultBuySellSetting];
go
--tblWarrantFilterRule(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblWarrantFilterRule];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblWarrantFilterRule] ([PKey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[Value]
      ,[ModiTime])
select [PKey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[Value]
      ,[ModiTime] from [Trade_DB].[dbo].[tblWarrantFilterRule];
go
--tblWarrantDefaultFilterRule(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblWarrantDefaultFilterRule];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblWarrantDefaultFilterRule] ([PKey]
      ,[UserId]
      ,[RuleName]
      ,[IsDefaultRule])
select [PKey]
      ,[UserId]
      ,[RuleName]
      ,[IsDefaultRule] from [Trade_DB].[dbo].[tblWarrantDefaultFilterRule];
go
--tblWarrantFilterRuleOrder(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblWarrantFilterRuleOrder];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblWarrantFilterRuleOrder] ([WarrantFilterRulePkey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[OrderIndex]
      ,[OrderByAsc]
      ,[TakePercent]
      ,[TakeCount])
select [WarrantFilterRulePkey]
      ,[UserId]
      ,[RuleName]
      ,[RuleTag]
      ,[OrderIndex]
      ,[OrderByAsc]
      ,[TakePercent]
      ,[TakeCount] from [Trade_DB].[dbo].[tblWarrantFilterRuleOrder];
go
--tblQuickHedgeSetting(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblQuickHedgeSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblQuickHedgeSetting] ([UserId]
      ,[UnderlyingId]
      ,[AutoHedgeType]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockOrderPriceType]
      ,[StockOrderPriceTick]
      ,[WarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantOrderPriceType]
      ,[WarrantOrderPriceTick]
      ,[FutureOrderMaxQty]
      ,[FutureOrderPriceType]
      ,[FutureOrderPriceTick])
select [UserId]
      ,[UnderlyingId]
      ,[AutoHedgeType]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockOrderPriceType]
      ,[StockOrderPriceTick]
      ,[WarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantOrderPriceType]
      ,[WarrantOrderPriceTick]
      ,[FutureOrderMaxQty]
      ,[FutureOrderPriceType]
      ,[FutureOrderPriceTick] from [Trade_DB].[dbo].[tblQuickHedgeSetting];
go
--tblQuickOrderDefaultSetting(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblQuickOrderDefaultSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblQuickOrderDefaultSetting] ([UserId]
      ,[UnderlyingId]
      ,[WarrantBuyQty]
      ,[WarrantSellQty]
      ,[WarrantBuyTick]
      ,[WarrantSellTick]
      ,[StockBuyQty]
      ,[StockSellQty]
      ,[StockBuyTick]
      ,[StockSellTick]
      ,[StockMaxOrderQty]
      ,[WarrantBuyPriceType]
      ,[WarrantSellPriceType]
      ,[StockBuyPriceType]
      ,[StockSellPriceType])
select [UserId]
      ,[UnderlyingId]
      ,[WarrantBuyQty]
      ,[WarrantSellQty]
      ,[WarrantBuyTick]
      ,[WarrantSellTick]
      ,[StockBuyQty]
      ,[StockSellQty]
      ,[StockBuyTick]
      ,[StockSellTick]
      ,[StockMaxOrderQty]
      ,[WarrantBuyPriceType]
      ,[WarrantSellPriceType]
      ,[StockBuyPriceType]
      ,[StockSellPriceType] from [Trade_DB].[dbo].[tblQuickOrderDefaultSetting];
go
--tblAutoHedgeRiskCheck(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeRiskCheck];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeRiskCheck] ([UnderlyingId]
      ,[MaxOrderMoney]
      ,[CumMaxOrderMoney]
      ,[CumFireAutoHedgeCount1]
      ,[CumFireAutoHedgeCount2])
select [UnderlyingId]
      ,[MaxOrderMoney]
      ,[CumMaxOrderMoney]
      ,[CumFireAutoHedgeCount1]
      ,[CumFireAutoHedgeCount2] from [Trade_DB].[dbo].[tblAutoHedgeRiskCheck];
go
--tblAutoHedgeSetting(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting] ([UserId]
      ,[UnderlyingId]
      ,[IsEnable]
      ,[StockPriceDiffer]
      ,[FireDeltaHMoney]
      ,[FireDG]
      ,[HedgeDeltaHMoney]
      ,[HedgeDG]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsAutoHedgeCycle]
      ,[IsClearOtherWarrant]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent])
select [UserId]
      ,[UnderlyingId]
      ,[IsEnable]
      ,[StockPriceDiffer]
      ,[FireDeltaHMoney]
      ,[FireDG]
      ,[HedgeDeltaHMoney]
      ,[HedgeDG]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsAutoHedgeCycle]
      ,[IsClearOtherWarrant]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent] from [Trade_DB].[dbo].[tblAutoHedgeSetting];
go
--tblAutoHedgeSetting_WarrantDeal(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting_WarrantDeal];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting_WarrantDeal] ( [UserId]
      ,[UnderlyingId]
      ,[FireDeltaHMoney]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsClearOtherWarrant]
      ,[IsEnable]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent]
      ,[IsAutoHedgeCycle]
      ,[FireDG])
select  [UserId]
      ,[UnderlyingId]
      ,[FireDeltaHMoney]
      ,[StockHedgePercent]
      ,[WarrantHedgePercent]
      ,[FutureHedgePercent]
      ,[StockOrderMaxQty]
      ,[StockBuyOrderPriceType]
      ,[StockBuyOrderPriceTick]
      ,[StockSellOrderPriceType]
      ,[StockSellOrderPriceTick]
      ,[OverWarrantFilterRule]
      ,[UnderWarrantFilterRule]
      ,[WarrantOrderMaxQty]
      ,[WarrantBuyOrderPriceType]
      ,[WarrantBuyOrderPriceTick]
      ,[WarrantSellOrderPriceType]
      ,[WarrantSellOrderPriceTick]
      ,[OverWarrantHedgeActionType]
      ,[UnderWarrantHedgeActionType]
      ,[FutureOrderMaxQty]
      ,[FutureOrderBuyPriceType]
      ,[FutureOrderBuyPriceTick]
      ,[FutureOrderSellPriceType]
      ,[FutureOrderSellPriceTick]
      ,[IsClearOtherWarrant]
      ,[IsEnable]
      ,[IsUseFutureHedge]
      ,[UseFutureLimitPercent]
      ,[IsAutoHedgeCycle]
      ,[FireDG] from [Trade_DB].[dbo].[tblAutoHedgeSetting_WarrantDeal];
go
--tblAutoHedgeSetting���x�Ѽ�(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting���x�Ѽ�] ([Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt])
select [Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt] from [Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
--tblAutoHedgeSetting���x�Ѽ�(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblAutoHedgeSetting���x�Ѽ�] ([Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt])
select [Trader]
      ,[UnderlyingID]
      ,[UpLimit]
      ,[�@�i���B]
      ,[�̧C���B]
      ,[TriggerAmt] from [Trade_DB].[dbo].[tblAutoHedgeSetting���x�Ѽ�];
go
--tblAutoHedgeSetting���x�Ѽ�(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblWarrantInvLimit];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblWarrantInvLimit] ([WarrnatId]
      ,[LimitInv])
select [WarrnatId]
      ,[LimitInv] from [Trade_DB].[dbo].[tblWarrantInvLimit];
go
--tblOrderReport(���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblOrderReport]
go
--tblWrrmm(�D���n�ۮa�y���ʱ��D���n)
delete from [DB2].[Trade_DB_Test].[dbo].[tblWrrmm];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblWrrmm] ([Wrrmm]
      ,[Vol�U��]
      ,[Vol�W��]
      ,[WarrantID]
      ,[Trader]
      ,[TraderName]
      ,[PricingVol]
      ,[BookVol]
      ,[StartDate])
select [Wrrmm]
      ,[Vol�U��]
      ,[Vol�W��]
      ,[WarrantID]
      ,[Trader]
      ,[TraderName]
      ,[PricingVol]
      ,[BookVol]
      ,[StartDate] from [Trade_DB].[dbo].[tblWrrmm];
go
--tblHedgeSystemFormSetting(�D���n�����]�w)
delete from [DB2].[Trade_DB_Test].[dbo].[tblHedgeSystemFormSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblHedgeSystemFormSetting] ([UserId]
      ,[FormId]
      ,[X]
      ,[Y]
      ,[Width]
      ,[Height])
select [UserId]
      ,[FormId]
      ,[X]
      ,[Y]
      ,[Width]
      ,[Height] from [Trade_DB].[dbo].[tblHedgeSystemFormSetting];
go
--tblHedgeSystemFormSetting(�D���n���]�w)
delete from [DB2].[Trade_DB_Test].[dbo].[tblHedgeSystemGridColumnSetting];
go
insert into [DB2].[Trade_DB_Test].[dbo].[tblHedgeSystemGridColumnSetting] ([UserId]
      ,[GridId]
      ,[ColumnId]
      ,[DataPropertyName]
      ,[ColumnHeaderText]
      ,[Index]
      ,[Width]
      ,[CellFormat]
      ,[CellForeColor]
      ,[CellBackColor])
select [UserId]
      ,[GridId]
      ,[ColumnId]
      ,[DataPropertyName]
      ,[ColumnHeaderText]
      ,[Index]
      ,[Width]
      ,[CellFormat]
      ,[CellForeColor]
      ,[CellBackColor] from [Trade_DB].[dbo].[tblHedgeSystemGridColumnSetting];
go*/', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'�ƴ�����', 
		@enabled=0, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151228, 
		@active_end_date=99991231, 
		@active_start_time=80700, 
		@active_end_time=235959, 
		@schedule_uid=N'cfd0c44b-451c-4107-9448-d82a2961f574'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


