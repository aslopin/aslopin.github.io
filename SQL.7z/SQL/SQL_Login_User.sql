ALTER USER DataUtility
WITH Login = DataUtility