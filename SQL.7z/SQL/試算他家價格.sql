declare @rng decimal(20,6) set @rng=0.2 declare @sec nvarchar(50) set @sec='3474'
declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

declare @TTM decimal(20,6) set @TTM=10/252.

select 
Theodata.dbo.optvlu(c.[SLast]*(1+@rng),c.strike,c.barrier,c.[T�����]-1/252.,isnull(b.M1VolAvg,0.8),c.r,c.warrantid,c.Exer)
as �z�׻�
,b.M1VolAvg as QV
,c.WLast as �Q��
,c.WarrantID,c.WarrantName
,c.strike,c.expireddate,c.Exer
from pro.[dbo].[�v�ҵ������] c
left join dbmain.dbo.tradingdate tr on tr.Tradingdate=c.Availabledate
left join dbmain.dbo.tradingdate tr10 on tr.ser+10=tr10.ser
join intraday.dbo.�����v�ҧ�Vol b on b.�N��=c.WarrantID and b.���=tr10.Tradingdate
where c.TxDate=@t and c.UnderlyingID=@sec and c.T�����>=@TTM and right(c.WarrantID,1)<>'P'
and c.IssuerID<>'8150'

