declare @t datetime set @t='2015/8/18'

declare @MM table(ser int identity,TxDate datetime,TxTime nvarchar(50),TradeSN nvarchar(50),Portfolio nvarchar(50),StockID nvarchar(50),BuySell nvarchar(50)
,Volume decimal(20,6),MMPL decimal(20,6),BCum decimal(20,6),SCum decimal(20,6),BMCum decimal(20,6),SMCum decimal(20,6)
,PCTile decimal(20,6),Lead decimal(20,6),Lag decimal(20,6),FIRST_Time nvarchar(50),LAST_VALUE nvarchar(50))
insert @MM
select a.TxDate,a.TxTime,a.TradeSN,a.Portfolio,a.StockID,a.BuySell,a.Volume,a.MMPL
,SUM(case when a.BuySell='B' then 1 else 0 end*a.Volume) OVER(PARTITION BY a.Portfolio,a.StockID ORDER BY a.TxDate,a.TxTime) 
 AS BCum
,SUM(case when a.BuySell='B' then 0 else 1 end*a.Volume) OVER(PARTITION BY a.Portfolio,a.StockID ORDER BY a.TxDate,a.TxTime) 
 AS SCum
,SUM(case when a.BuySell='B' then 1 else 0 end*a.MMPL) OVER(PARTITION BY a.Portfolio,a.StockID ORDER BY a.TxDate,a.TxTime) 
 AS BMCum
,SUM(case when a.BuySell='B' then 0 else 1 end*a.MMPL) OVER(PARTITION BY a.Portfolio,a.StockID ORDER BY a.TxDate,a.TxTime) 
 AS SMCum
,PERCENT_RANK( ) OVER (ORDER BY a.TxDate,a.TxTime) AS PCTile

,LEAD(a.MMPL, 1,0) OVER (ORDER BY a.TxDate,a.TxTime) AS NextMMPL
,Lag(a.MMPL, 1,0) OVER (ORDER BY a.TxDate,a.TxTime) AS NextMMPL
,FIRST_VALUE(a.TxTime) OVER (PARTITION BY a.Portfolio,a.StockID ORDER BY a.TxDate desc,a.TxTime desc) AS FIRST_Time
,LAST_VALUE(a.TxTime) OVER (PARTITION BY a.Portfolio,a.StockID ORDER BY a.TxDate) AS LAST_VALUE

from pl.[dbo].[�v�ҨC��Markup] a
where a.[TxDate]<=@t
and a.account='8888885'
--and a.Stockid='034506'
order by a.Portfolio,a.StockID,a.TxDate,a.TxTime,a.TradeSN

select * from @MM

select aa.Portfolio,aa.StockID
,aa.BMCum
+coalesce(bb.SMCumB+(bb.SMCumE-bb.SMCumB)*(aa.BCum-bb.SCumB)/(bb.SCumE-bb.SCumB)
         ,cc.SMCumB,0)
 as �w�^��Markup
,aa.SMCum
-coalesce(bb.SMCumB+(bb.SMCumE-bb.SMCumB)*(aa.BCum-bb.SCumB)/(bb.SCumE-bb.SCumB)
         ,cc.SMCumB,0)
 as ���^��Markup
,aa.BCum,aa.SCum
,aa.BMCum,aa.SMCum
--,bb.*
from (
select a.Portfolio,a.StockID,a.BCum,a.SCum,a.BMCum,a.SMCum
from @MM a
join (select Portfolio,StockID,max(ser) as ser from @MM group by Portfolio,StockID) b on b.Portfolio=a.Portfolio and b.StockID=a.StockID and b.Ser=a.Ser
) aa
left join (
select a.Portfolio,a.StockID,isnull(b.SCum,0) as SCumB,a.SCum as SCumE,isnull(b.SMCum,0) as SMCumB,a.SMCum as SMCumE
from @MM a
left join @MM b on b.portfolio=a.portfolio and b.Stockid=a.stockid and b.ser+1=a.ser
) bb on aa.Portfolio=bb.portfolio and aa.Stockid=bb.StockID and aa.BCum>bb.SCumB and aa.BCum<=bb.SCumE
left join (
select a.Portfolio,a.StockID,a.SCum as SCumB,b.SCum as SCumE,a.SMCum as SMCumB,b.SMCum as SMCumE
from @MM a
join @MM b on b.portfolio=a.portfolio and b.Stockid=a.stockid and b.ser=a.ser+1
) cc on aa.Portfolio=cc.portfolio and aa.Stockid=cc.StockID and aa.BCum=cc.SCumB and aa.BCum=cc.SCumE



--select * from @MM
