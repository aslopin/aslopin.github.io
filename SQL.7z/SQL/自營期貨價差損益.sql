select txdate,StockID
,volume-isnull(lag(volume) over(partition by Acc,StockID order by txdate),0)
 as DealVolume
,LastPrice,Theoprice
,(volume-isnull(lag(volume) over(partition by Acc,StockID order by txdate),0))*200*(Theoprice-LastPrice)
 as ��tPL
from pl.dbo.Inventory_����G��
where trader='Andy' and Stockid like 'TX%'-- and volume<>0
order by txdate,StockID

