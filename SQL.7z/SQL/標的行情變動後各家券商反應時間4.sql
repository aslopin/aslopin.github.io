declare @sec nvarchar(50) set @sec='2454'

declare @t datetime set @t=(select max(���) from DB.cmoney.dbo.�v�Ұ򥻸�ƪ��C��)

--select distinct(a.sec),a.Wsec
--from EDBK2.Intraday.dbo.�v�ҽL�����R�Q��_9600 a
--where a.stadate=@y
--and a.sec=@sec
--order by a.sec desc,a.Wsec desc
/*
select distinct(a.sec),a.Wsec
from EDBK2.Intraday.dbo.�v�ҽL�����R�Q��_9800 a
where a.stadate=@y
and a.sec=@sec
order by a.sec desc,a.Wsec desc
*/
create table #PX(Tsec nvarchar(50),Bid decimal(20,6),Ask decimal(20,6))
insert #PX
select [Tick_Time]
,case when [B1_Price]<>'' then [B1_Price] end
,case when [A1_Price]<>'' then [A1_Price] end
from Tick.[dbo].[tbl_Tick_Today_New]
where [StockId]=@sec



declare inputTsec cursor
for 
select lag(Tsec) over(order by Tsec),Tsec,lead(Tsec) over(order by Tsec)
from #PX
order by Tsec

--select b.Tsec as PXb,a.Tsec as PXm,c.Tsec as PXe
--from @PX a
--join @PX b on b.ser+1=a.ser
--and (a.bid<>b.bid or a.ask<>b.ask)
--join @PX c on a.ser+1=c.ser
--order by a.ser


open inputTsec

declare @b nvarchar(50)
declare @m nvarchar(50)
declare @e nvarchar(50)
fetch inputTsec into @b,@m,@e



while (@@fetch_status=0)
  begin
--�I��

select @y,@sec,@m,min(a.Tsec),a.Wsec
,monitor.dbo.TimeSecToDecimal(min(a.Tsec))-monitor.dbo.TimeSecToDecimal(@m) as �Z������
,'9600' from EDBK2.Intraday.dbo.�v�ҽL�����R�Q��_9600 a
where a.stadate=@y
and a.sec=@sec
and a.Tsec>@m
and a.Tsec<@e
group by a.Wsec



  fetch inputTsec into @b,@m,@e
  end

close inputTsec
deallocate inputTsec




drop table #PX




