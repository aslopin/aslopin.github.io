


--一般的指令

--#############################################################
--python 寫CODE DB輸出   PS:特別留意的地方，在輸出python的data時需要用"pandas的 Dataframe格式"
--#########################以下################################


declare @py nvarchar(max);

set @py = N'import pandas as pd
name = ["ABC", "TUV", "XYZ", "PQR"] 
degree = ["BBA", "MBA", "BSC", "MSC"] 
score = [98, 90, 88, 95] 	
dict = {"name": name, "degree": degree, "score": score} 
df = pd.DataFrame(dict) 
'; 



exec sp_execute_external_script 
    @language = N'Python',
    @script = @py,
    @output_data_1_name =N'df'
	with Result sets(([name] nvarchar(10),[degree] nvarchar(10),[score] float))    --沒有這段就沒有欄名 可以自己變更



--#########################以上################################
--python 寫CODE DB輸出   PS:特別留意的地方，在輸出python的data時需要用"pandas的 Dataframe格式"
--#############################################################



--#############################################################
--python 寫CODE write to csv 
--#########################以下################################




---寫成csv


declare @py nvarchar(max);

set @py = N'import pandas as pd
name = ["ABC", "TUV", "XYZ", "PQR"] 
degree = ["BBA", "MBA", "BSC", "MSC"] 
score = [98, 90, 88, 95] 	
dict = {"name": name, "degree": degree, "score": score} 
df = pd.DataFrame(dict) 
df.to_csv(r"D:\SQL_In_and_Out\test.csv") 
'; 

---此處要特別注意 轉出csv的資料夾 是否有開啟DB192的權限 開啟資料夾權限方式 詳見資料夾權限檔案

exec sp_execute_external_script 
    @language = N'Python',
    @script = @py,
    @output_data_1_name =N'df'


	
--#########################以上################################
--python 寫CODE write to csv 
--#############################################################


--#############################################################
--python 寫CODE read csv 
--#########################以下################################





declare @py nvarchar(max);

set @py = N'import pandas as pd
stop_loss_data=pd.read_csv(r"D:\SQL_In_and_Out\stop_loss.csv")

'; 


exec sp_execute_external_script 
    @language = N'Python',
    @script = @py,
    @output_data_1_name =N'stop_loss_data'
	with Result sets(([Txdate] nvarchar(10),[Portfoilo] nvarchar(20),[Dept] nvarchar(20),[Trader] nvarchar(20),[Acc] nvarchar(20),[策略] nvarchar(20),[市值] float,[單日損益標準差] float 
	,[月停損機率] float,[年停損機率] float,[月停損] float,[年停損] float,[月PL] float,[年PL] float)) 


	
--#########################以上################################
--python 寫CODE read csv 
--#############################################################








--#############################################################
--python 寫CODE insert DB
--#########################以下################################



declare @py nvarchar(max);

set @py = N'from pandas.io.json import json_normalize

rdd = {"documents": [{"id": "1", "score": 0.97},{"id": "2","score": 0.87},{"id": "3", "score": 0.78}],"errors": []}
print(type(rdd))

df = json_normalize(rdd, "documents")
print(df)
print(type(df))
'; 


INSERT INTO vix.dbo.myTable   
exec sp_execute_external_script 
    @language = N'Python',
    @script = @py,
    @output_data_1_name =N'df'


--select * from vix.dbo.myTable

--#########################以上################################
--python 寫CODE insert DB
--#############################################################





--#############################################################
--python 寫CODE 抓取DB資料做計算 不用額外在下ODBC
--#########################以下################################


declare @py nvarchar(max);

set @py = N'
import pandas as pd
data = pd.DataFrame(myTable[["aggregate","value"]]) 
data["value"]=data["value"]*10
print(data)'; 


--@input_data_1 可以叫出DB資料
-- 然後在 py裡面呼叫該變數 記得看 @input_data_1_name 所對應的變數名稱
--之後輸出 資料 要用 @output_data_1_name

EXECUTE sp_execute_external_script @language = N'Python'
, @script =@py
, @input_data_1 = N'select "aggregate", "value" from vix.dbo.myTable'   --欄名是py 裡面要稱呼 ex:  myTable[["aggregate","value"]] 此處的myTable 為下方 @input_data_1_name 令名的變數名稱
, @input_data_1_name = N'myTable'           --此名稱要特別留意 是在py裡面要呼叫的變數名稱 
, @output_data_1_name =N'data'				--此處為呼叫py的變數 
with Result sets(([aggregate] nvarchar(10),[value] float))



--#########################以上################################
--python 寫CODE 抓取DB資料做計算  不用額外在下ODBC
--#############################################################




--預存程序部分



--#############################################################
--預存程序 包python
--#########################以下################################


CREATE PROCEDURE MyPyNorm (
      @param1 INT
    , @param2 INT
    , @param3 INT
    )
AS
EXECUTE sp_execute_external_script @language = N'Python'
    , @script = N'
import numpy
import pandas
OutputDataSet = pandas.DataFrame(numpy.random.normal(size=mynumbers, loc=mymean, scale=mysd));
'
    , @input_data_1 = N'   ;'
    , @params = N' @mynumbers int, @mymean int, @mysd int'
    , @mynumbers = @param1
    , @mymean = @param2
    , @mysd = @param3
WITH RESULT SETS(([Density] FLOAT NOT NULL));


--請特別留意這裡不是用一般的exec 是用 EXECUTE
EXECUTE Vix.dbo.MyPyNorm @param1 = 100,@param2 = 50, @param3 = 3


	
	
--#########################以上################################
--預存程序 包python
--#############################################################


