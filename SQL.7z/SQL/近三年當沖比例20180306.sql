select avg(���) as ���
from (
	select x.YY,x.MM,x.DD,avg(���) as ���
	from (
		select x.YY,x.MM,x.DD,x.TransactTime,x.Symbol
		,case when case when avg(x.B)>avg(x.S) then avg(x.B) else avg(x.S) end*avg(x.Price)<>0 then 
		 (case when avg(x.B)<avg(x.S) then avg(x.B) else avg(x.S) end*avg(x.Price))
		/(case when avg(x.B)>avg(x.S) then avg(x.B) else avg(x.S) end*avg(x.Price))
		else 0 end
		 as ���
		from (
			select datepart(yy,TransactTime) as YY,datepart(mm,TransactTime) as MM,datepart(dd,TransactTime) as DD,*
			,sum(case when Side='0' then OrderQty else 0 end) over(partition by datepart(yy,TransactTime),datepart(mm,TransactTime),datepart(dd,TransactTime),symbol order by TransactTime)
			 as B
			,sum(case when Side='1' then OrderQty else 0 end) over(partition by datepart(yy,TransactTime),datepart(mm,TransactTime),datepart(dd,TransactTime),symbol order by TransactTime)
			 as S
			from Trade_DB.[dbo].[tblExecutionReport400]
			where account='8888888'
		) x
		join (
			select datepart(yy,x.TransactTime) as YY,datepart(mm,x.TransactTime) as MM,datepart(dd,x.TransactTime) as DD,SymBol
			,max(x.TransactTime) as TransactTime
			from (
				select *
				,sum(case when Side='0' then OrderQty else 0 end) over(partition by datepart(yy,TransactTime),datepart(mm,TransactTime),datepart(dd,TransactTime),symbol order by TransactTime)
				 as B
				,sum(case when Side='1' then OrderQty else 0 end) over(partition by datepart(yy,TransactTime),datepart(mm,TransactTime),datepart(dd,TransactTime),symbol order by TransactTime)
				 as S
				from Trade_DB.[dbo].[tblExecutionReport400]
				where account='8888888'
			) x
			group by datepart(yy,x.TransactTime),datepart(mm,x.TransactTime),datepart(dd,x.TransactTime),SymBol
		) y on y.YY=x.YY and y.MM=x.MM and y.DD=x.DD and y.SymBol=x.SymBol and y.TransactTime=x.TransactTime
		group by x.YY,x.MM,x.DD,x.TransactTime,x.Symbol
	) x
	group by x.YY,x.MM,x.DD
) x