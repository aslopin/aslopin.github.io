select a.Stadate,a.S,a.W,a.�`Lots-b.����� as �D�O,b.�����-a.���� as ����� ,a.����
from 
--6�ѳ̤p(����)
(
select  a.stadate,a.WarrantID+'_'+warrantname as W ,S,min( ����) ���� , avg(�`Lots) as �`Lots
from (
  select x.stadate,y.Lots  as ���� ,-x.volume/1000  as  �`Lots,y.WarrantID,y.WarrantName,y.S
  from pl.[dbo].[Inventory] x 
  join dbmain.dbo.WarrantProfileTS w on w.WarrantKey=x.portfolio and w.WarrantID=x.StockID
  join dbmain.dbo.Tradingdate t on t.Tradingdate=x.Stadate
  join (
    select  ser,a.stadate,WarrantID,WarrantName   , b.stockid+'_'+StockName as S
    , -[Volume]/1000 as Lots
    from  pl.[dbo].[Inventory] a
    join dbmain.dbo.Tradingdate t on t.Tradingdate=a.Stadate
    join dbmain.dbo.WarrantProfileTS b on b.WarrantID=a.StockID    -- and b.stockid in (  )
  ) y on y.ser-t.ser<6  and  y.ser-t.ser>=0 and w.warrantid=y.warrantid and w.warrantname=y.warrantname
) a
group by a.stadate,a.WarrantID,a.warrantname,s
) a
left join
--2�ѳ̤p(�����)
(
select  a.stadate,a.WarrantID+'_'+warrantname as W ,S,min( �����) �����
from (
  select x.stadate,y.Lots  as ����� ,-x.volume/1000  as  �`Lots,y.WarrantID,y.WarrantName,y.S
  from pl.[dbo].[Inventory] x 
  join dbmain.dbo.WarrantProfileTS w on w.WarrantKey=x.portfolio and w.WarrantID=x.StockID
  join dbmain.dbo.Tradingdate t on t.Tradingdate=x.Stadate
  join (
    select  ser,a.stadate,WarrantID,WarrantName   , b.stockid+'_'+StockName as S
    , -[Volume]/1000 as Lots
    from  pl.[dbo].[Inventory] a
    join dbmain.dbo.Tradingdate t on t.Tradingdate=a.Stadate
    join dbmain.dbo.WarrantProfileTS b on b.WarrantID=a.StockID    -- and b.stockid in (  )
  ) y on y.ser-t.ser<2  and  y.ser-t.ser>=0 and w.warrantid=y.warrantid and w.warrantname=y.warrantname
) a
group by a.stadate,a.WarrantID,a.warrantname,s
) b on b.Stadate=a.stadate and b.W=a.W

