declare @t datetime set @t='2017/5/25'--(select max(txdate) from frontdeskw.[dbo].[CBIndex�W�g����q�z��²�業�����Gtop100])
declare @b1 datetime set @b1=dateadd(yy,-1,@t)
declare @b2 datetime set @b2=dateadd(yy,-2,@t)

select a.Tag
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY>0 then 1. else 0 end)
/sum(1.)
 as P
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY>0 then a.IndexT/a.IndexY-b.IndexT/b.IndexY else 0 end)
/sum(1.)
 as U
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY<0 then a.IndexT/a.IndexY-b.IndexT/b.IndexY else 0 end)
/sum(1.)
 as D 
from (
	select b.YY,a.TxDate,a.Tag,a.CBindex²�榨��q as IndexT,lag(a.CBindex²�榨��q) over(partition by a.Tag order by a.TxDate) as IndexY
	from frontdeskw.[dbo].[CBIndex�W�릨��q�z��²�業�����Gtop100] a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.TxDate
) a
left join (
	select b.YY,a.TxDate,a.CBindex²�榨��q as IndexT,lag(a.CBindex²�榨��q) over(order by a.TxDate) as IndexY
	from frontdeskw.[dbo].[CBIndex�W�g����q�z��²�業�����Gtop100] a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.TxDate
) b on b.Txdate=a.txdate 
--where a.Txdate>='2016/5/18'-- and a.Tag like 'Pb%'
where a.Txdate>='2010/1/1'-- and a.Tag like 'Pb%'
group by a.Tag
order by a.Tag

select a.Tag
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY>0 then 1. else 0 end)
/sum(1.)
 as P
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY>0 then a.IndexT/a.IndexY-b.IndexT/b.IndexY else 0 end)
/sum(1.)
 as U
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY<0 then a.IndexT/a.IndexY-b.IndexT/b.IndexY else 0 end)
/sum(1.)
 as D 
from (
	select b.YY,a.TxDate,a.Tag,a.CBindex²�榨��q as IndexT,lag(a.CBindex²�榨��q) over(partition by a.Tag order by a.TxDate) as IndexY
	from frontdeskw.[dbo].[CBIndex�W�릨��q�z��²�業�����Gtop100] a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.TxDate
) a
left join (
	select b.YY,a.TxDate,a.CBindex²�榨��q as IndexT,lag(a.CBindex²�榨��q) over(order by a.TxDate) as IndexY
	from frontdeskw.[dbo].[CBIndex�W�g����q�z��²�業�����Gtop100] a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.TxDate
) b on b.Txdate=a.txdate 
--where a.Txdate>='2016/5/18'-- and a.Tag like 'Pb%'
where a.Txdate>=@b1-- and a.Tag like 'Pb%'
group by a.Tag
order by a.Tag

select a.Tag
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY>0 then 1. else 0 end)
/sum(1.)
 as P
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY>0 then a.IndexT/a.IndexY-b.IndexT/b.IndexY else 0 end)
/sum(1.)
 as U
,sum(case when a.IndexT/a.IndexY-b.IndexT/b.IndexY<0 then a.IndexT/a.IndexY-b.IndexT/b.IndexY else 0 end)
/sum(1.)
 as D 
from (
	select b.YY,a.TxDate,a.Tag,a.CBindex²�榨��q as IndexT,lag(a.CBindex²�榨��q) over(partition by a.Tag order by a.TxDate) as IndexY
	from frontdeskw.[dbo].[CBIndex�W�릨��q�z��²�業�����Gtop100] a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.TxDate
) a
left join (
	select b.YY,a.TxDate,a.CBindex²�榨��q as IndexT,lag(a.CBindex²�榨��q) over(order by a.TxDate) as IndexY
	from frontdeskw.[dbo].[CBIndex�W�g����q�z��²�業�����Gtop100] a
	join (
		select datepart(yy,tradingdate) as YY,datepart(wk,tradingdate) as WK,max(Tradingdate) as Tradingdate
		from dbmain.dbo.tradingdate 
		group by datepart(yy,tradingdate),datepart(wk,tradingdate)
	) b on b.Tradingdate=a.TxDate
) b on b.Txdate=a.txdate 
--where a.Txdate>='2016/5/18'-- and a.Tag like 'Pb%'
where a.Txdate>=@b2-- and a.Tag like 'Pb%'
group by a.Tag
order by a.Tag