declare @t datetime set @t=(select max(���) from cmoney.dbo.�v�Ұ򥻸�ƪ��C��)
declare @t1 datetime set @t1=dbmain.dbo.tradingdateadd(1,@t)

declare @y datetime
set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @yy nvarchar(50) set @yy=dbmain.dbo.datetranslator(@y,3)
declare @r decimal(20,6) set @r=0.01
declare @ser decimal(20,4) set @ser=(select ser from dbmain.dbo.tradingdate where tradingdate=@t)

declare @QVy table(WarrantID nvarchar(50),qv decimal(20,6))
insert @QVy
select Wrr_ID,QV/100.
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
where TX_Date=@yy

create table #Last(�Ѳ��N�� nvarchar(50),���L�� decimal(20,4))
insert #Last
select StockID,Price from db2.Tick.dbo.View_TickLast

create table #hvtab(warrantid nvarchar(50),warrantname nvarchar(50)
,stockid nvarchar(50),hv decimal(20,6),qv decimal(20,6)
,strike decimal(20,4),barrier decimal(20,4),exer decimal(20,4),ed datetime,r decimal(20,4),T decimal(20,4))
insert #hvtab
select a.warrantid,a.warrantname,a.Stockid,hv.HV,qv.qv
,[CurrentStrikePrice],[BarrierPrice],[AdjustedExerciseRate],expireddate,@r
,t.ser-@ser+1
--,dbmain.dbo.tradingdatediff(@t,expireddate)
from dbmain.[dbo].[WarrantProfileTS] a
left join dbmain.dbo.tradingdate t on t.Tradingdate=a.expireddate
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hv on hv.StockID=a.stockID
and @t between hv.bdate and hv.edate
left join @QVy qv on qv.WarrantID=a.warrantid
where @t between issuedate and expireddate

insert #hvtab
select a.�N��,a.�W��,a.�Ъ��N��,hv.HV,hv.HV
,a.�̷s�i����,a.�̷s�������,a.�̷s������,a.������,@r
,t.ser-@ser+1
--,dbmain.dbo.tradingdatediff(@t,������)
from cmoney.dbo.�v�Ұ򥻸�ƪ��C�� a
left join dbmain.dbo.tradingdate t on t.Tradingdate=a.������
left join dbmain.dbo.[WarrantHedgeVolTS_BE]() hv on hv.StockID=a.�Ъ��N��
and @t between hv.bdate and hv.edate
left join dbmain.[dbo].[WarrantProfileTS] w on @t between w.issuedate and w.expireddate
and w.WarrantID=a.�N��
where a.���=@t
and a.[�@���ҡ�������]='false'
and w.WarrantID is null

declare @yb datetime set @yb=(select min(tradingdate) from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) )

create table #������pre(TxDate datetime,Portfolio nvarchar(50),Trader nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50),B decimal(20,3),S decimal(20,3),DealVolume decimal(20,3),Cost decimal(20,3),Tax decimal(20,3),Fee decimal(20,3))
insert #������pre
select @t as TxDate,b.Portfolio,b.Trader,a.Symbol,a.TwseOrdType
,case when a.side='0' then 1 else 0 end*a.LastQty*1000
,case when a.side='0' then 0 else -1 end*a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000
,case when a.side='0' then 1 else -1 end*a.LastQty*1000*a.LastPx
,case when a.side='0' then 0 else 1 end*a.LastQty*1000*a.LastPx*case when dbmain.dbo.�P�_���O(a.Symbol) in ('warrant','ETF') then 0.001 else 0.003 end
,0
from [Trade_DB].[dbo].[tblOrderReport](nolock) a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.Symbol
left join testDB.dbo.�N���ഫ c on @t between c.BDate and c.EDate and c.[�N���ഫTo]=a.Symbol
where a.TransactTime between @t and @t1
and a.LastQty<>0
and a.OrdStatus in ('1','2')

create table #���e�U(TxDate datetime,TxTime nvarchar(50),Portfolio nvarchar(50),Trader nvarchar(50),StockID nvarchar(50),[Type] nvarchar(50),[BS] nvarchar(50),Volume decimal(20,3),Price decimal(20,3))
insert #���e�U
select @t as TxDate
,right('0'+cast(datepart(hour,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(minute,a.TransactTime) as nvarchar(50)),2)
+right('0'+cast(datepart(second,a.TransactTime) as nvarchar(50)),2)
+'00'
,b.Portfolio,b.Trader,a.Symbol,a.TwseOrdType
,case when a.side='0' then 'B' else 'S' end
,a.LeavesQty*1000
,a.Price

from [Trade_DB].[dbo].[tblOrderReport](nolock) a
left join dbmain.dbo.DailyDefaultPortfolio b on b.TxDate=@t
and b.StockID=a.Symbol
left join testDB.dbo.�N���ഫ c on @t between c.BDate and c.EDate and c.[�N���ഫTo]=a.Symbol
where a.TransactTime between @t and @t1
--and a.OrdStatus in ('1','0')

select a.* 
,Theodata.dbo.optvlu(qu.���L��,hv.strike,hv.barrier,hv.T/252.,hv.qv,hv.r,a.StockID,hv.Exer)
 as �z�ץ���
,Theodata.dbo.optvlu(qu.���L��,hv.strike,hv.barrier,hv.T/252.,hv.hv,hv.r,a.StockID,hv.Exer)
 as �z�׻�
,hv.qv
from #���e�U a
left join dbmain.[dbo].[WarrantProfileTS] b on @t between b.AvailableDate and b.lasttradedate and b.warrantid=a.StockID
left join #last qu on qu.�Ѳ��N��=b.StockID 
left join #hvtab hv on a.stockid=hv.warrantid
order by a.TxTime desc

select left(TxTime,4),count(*)
from #���e�U
group by left(TxTime,4)
order by left(TxTime,4)

select left(TxTime,3),count(*)
from #���e�U
group by left(TxTime,3)
order by left(TxTime,3)

select StockID,sum(B) as B,sum(S) as S
from #������pre
group by StockID
order by StockID

select *,cost/DealVolume
from #������pre
order by StockID


drop table #Last
drop table #������pre
drop table #���e�U
drop table #hvtab
--select * from [Trade_DB].[dbo].[tblOrderReport] order by TransactTime desc
--select * from [Trade_DB].[dbo].[tblOrderReport] where Symbol='034509' order by TransactTime desc
--select * from DB2.[Trade_DB].[dbo].[tblOrderReport] where Symbol='034509' and LastQty<>0 and OrdStatus in ('1','2')order by TransactTime desc
--select * from [Trade_DB].[dbo].[tblOrderReport] where Symbol='034509' and LastQty<>0 and OrdStatus in ('1','2') order by TransactTime desc
