declare @t datetime set @t='2017/3/31'

declare @StockID_Vol table(
Tag nvarchar(50),StockID nvarchar(50), Vol dec(20,5)
)



insert @StockID_Vol
select '22_66_126',case when seccode='4733' then '3708' else seccode end,avg(vol)
from theodata.dbo.HistoryVol
where stadate=@t and tag in ('22','66','126')
group by case when seccode='4733' then '3708' else seccode end

select sum(isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, d.Vol, a.r, a.WarrantID, a.Exer)
))
,sum(isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, e.Vol, a.r, a.WarrantID, a.Exer)
))
from pro.dbo.�v�ҵ������ a
left join dbmain.dbo.WarrantProfileTS_Daily b on b.txdate=a.txdate and b.WarrantID=a.WarrantID and b.Availabledate=a.Availabledate
left join pl.dbo.Inventory c on c.stadate=a.txdate and c.portfolio=b.WarrantKey and c.StockID=b.WarrantID
left join pl.[dbo].[�ۮa�v�ҨC��BookVol�պ�] d on d.TxDate=a.txdate and d.IssueDate=b.issuedate and d.WarrantID=b.WarrantID and d.Tag='22_66_126�s����'
left join @StockID_Vol e on e.StockID=b.StockID
where a.Txdate=@t
and a.IssuerID='8150'

select b.StockID
,sum(isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, d.Vol, a.r, a.WarrantID, a.Exer)
))
,sum(isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, e.Vol, a.r, a.WarrantID, a.Exer)
))
from pro.dbo.�v�ҵ������ a
left join dbmain.dbo.WarrantProfileTS_Daily b on b.txdate=a.txdate and b.WarrantID=a.WarrantID and b.Availabledate=a.Availabledate
left join pl.dbo.Inventory c on c.stadate=a.txdate and c.portfolio=b.WarrantKey and c.StockID=b.WarrantID
left join pl.[dbo].[�ۮa�v�ҨC��BookVol�պ�] d on d.TxDate=a.txdate and d.IssueDate=b.issuedate and d.WarrantID=b.WarrantID and d.Tag='22_66_126�s����'
left join @StockID_Vol e on e.StockID=b.StockID
where a.Txdate=@t
and a.IssuerID='8150'
group by b.StockID
order by sum(isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, d.Vol, a.r, a.WarrantID, a.Exer)
))
-sum(isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, e.Vol, a.r, a.WarrantID, a.Exer)
))

select b.StockID,a.WarrantID,a.WarrantName
,isnull(c.volume,0)
,isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, d.Vol, a.r, a.WarrantID, a.Exer)
)
,isnull(c.volume,0)
*
(TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, a.PricingVol, a.r, a.WarrantID, a.Exer)
-TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, e.Vol, a.r, a.WarrantID, a.Exer)
)
,d.Vol
,TheoData.dbo.OptVlu(a.SLast, a.Strike, a.Barrier, a.T�����, e.Vol, a.r, a.WarrantID, a.Exer)
,e.Vol
from pro.dbo.�v�ҵ������ a
left join dbmain.dbo.WarrantProfileTS_Daily b on b.txdate=a.txdate and b.WarrantID=a.WarrantID and b.Availabledate=a.Availabledate
left join pl.dbo.Inventory c on c.stadate=a.txdate and c.portfolio=b.WarrantKey and c.StockID=b.WarrantID
left join pl.[dbo].[�ۮa�v�ҨC��BookVol�պ�] d on d.TxDate=a.txdate and d.IssueDate=b.issuedate and d.WarrantID=b.WarrantID and d.Tag='22_66_126�s����'
left join @StockID_Vol e on e.StockID=b.StockID
where a.Txdate=@t
and a.IssuerID='8150'
order by b.StockID,b.WarrantID


select c.UnderlyingID+'_'+e.�Ѳ��W�� as �Ъ�,d.��ӦW��,case when right(c.WarrantID,1)='P' then 'P' else 'C' end as CP
,case when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<-0.3 then '01.-30%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<-0.25 then '02.-25%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<-0.20 then '03.-20%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<-0.15 then '04.-15%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<-0.10 then '05.-10%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<-0.05 then '06.-5%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<0.05 then '07. 5%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<0.10 then '08. 10%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<0.15 then '09. 15%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<0.20 then '10. 20%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<0.25 then '11. 25%�H�U'
      when case when right(c.WarrantID,1)='P' then 1-c.SLast/c.Strike else c.SLast/c.Strike-1 end<0.30 then '12. 30%�H�U'
	  else '13. 30%�H�W' end as Moneyness
, c.WarrantID,c.WarrantName,isnull(a.Volume*c.WLast,0) as MV

from pl.dbo.Inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.txdate=a.Stadate and b.WarrantKey=a.Portfolio and b.WarrantID<>a.StockID
join pro.dbo.�v�ҵ������ c on c.TxDate=a.Stadate and c.UnderlyingID=b.StockID and c.WarrantID=a.StockID and c.IssuerID<>'8150'
join dbmain.dbo.��ӥN���� d on d.��ӥN��=c.IssuerID
left join cmoney.dbo.�馬�L���Ʀ� e on e.���=a.Stadate and e.�Ѳ��N��=b.StockID
where a.Stadate=@t and a.Volume<>0


