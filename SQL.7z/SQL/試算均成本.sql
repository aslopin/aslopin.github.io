set nocount on
declare @b datetime set @b='2022/1/1'
declare @acc nvarchar(50) set @acc='8021'

select x.TxDate,x.Acc,x.StockID
,x.Volume
,x.LastPrice as ����
,abs(y.SAmtCum)/abs(y.SvolumeCum)/x.��������
-(y.TradingCost)/abs(y.SvolumeCum)/x.��������
+(sum(isnull(y.Bvolume*x.��������*x.LastPrice-y.BAmt,0)) over(partition by x.Acc,x.StockID order by x.TxDate))/abs(y.SvolumeCum)/x.��������
as �վ�᧡����

,case when y.Bvolume<>0 then abs(y.BAmt)/abs(y.Bvolume)/x.�������� end as �R����
,case when y.Svolume<>0 then abs(y.SAmt)/abs(y.Svolume)/x.�������� end as �槡��
,(y.Tax+y.Fee)/abs(y.SvolumeCum)/x.�������� as ���������

from (
	select TxDate,Acc,StockID
	,sum(Volume) as Volume
	,sum(Cost) as Cost
	,sum(Tax) as Tax
	,sum(Fee) as Fee
	,avg(LastPrice) as LastPrice
	,avg(��������) as ��������
	from (
		select TxDate,Portfolio,Acc,Trader,StockID,[Type],Volume,Cost,Tax,Fee,LastPrice,��������
		from pl.[dbo].[Inventory_�Ũ�_���~_KGI]
		where TxDate>=@b and acc=@acc-- and volume<>0
		union all
		select TxDate,Portfolio,Acc,Trader,StockID,[Type],Volume,Cost,Tax,Fee,LastPrice,��������
		from pl.[dbo].[Inventory_�Ũ�_���~_CSC]
		where TxDate>=@b and acc=@acc-- and volume<>0
	) x
	group by TxDate,Acc,StockID
) x
left join (
	select x.Acc,x.StockID,y.TxDate
	,z.Bvolume,z.BAmt,z.Svolume,z.SAmt,z.Tax,z.Fee
	,sum(z.Bvolume) over(partition by x.Acc,x.StockID order by y.TxDate) as BvolumeCum
	,sum(z.BAmt) over(partition by x.Acc,x.StockID order by y.TxDate) as BAmtCum
	,sum(z.Svolume) over(partition by x.Acc,x.StockID order by y.TxDate) as SvolumeCum
	,sum(z.SAmt) over(partition by x.Acc,x.StockID order by y.TxDate) as SAmtCum
	,sum(z.Tax+z.Fee) over(partition by x.Acc,x.StockID order by y.TxDate) as TradingCost
	from (
		select x.Acc,x.StockID
		from (
			select [Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
			from pl.[dbo].[Deallist_�Ũ�_���~_KGI]
			where acc=@acc-- and volume<>0
			union all
			select [Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
			from pl.[dbo].[Deallist_�Ũ�_���~_CSC]
			where acc=@acc-- and volume<>0
		) x
		group by x.Acc,x.StockID
	) x
	cross join (select dateadd(dd,ser-1,'2020/1/1') as TxDate from dbmain.dbo.tradingdate) y
	left join (
		select x.TxDate,x.Acc,x.StockID,x.Bvolume,x.BAmt,x.Svolume,x.SAmt,x.Tax,x.Fee
		from (
			select x.TxDate,x.Acc,x.StockID
			,sum(x.Bvolume) as Bvolume
			,sum(case when x.Bvolume>0 then x.DealAmt else 0 end) as BAmt
			,sum(x.Svolume) as Svolume
			,sum(case when x.Bvolume<=0 then x.DealAmt else 0 end) as SAmt
			,sum(x.[Tax]) as [Tax],sum(x.[Fee]) as [Fee]
			from (
				select [Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
				from pl.[dbo].[Deallist_�Ũ�_���~_KGI]
				where acc=@acc-- and volume<>0
				union all
				select [Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
				from pl.[dbo].[Deallist_�Ũ�_���~_CSC]
				where acc=@acc-- and volume<>0
			) x
			group by x.TxDate,x.Acc,x.StockID
		) x
	) z on x.Acc=z.acc and x.StockID=z.StockID and y.TxDate=z.Txdate
) y on y.TxDate=x.TxDate and y.Acc=x.Acc and y.StockID=x.StockID
where x.StockID like 'TN202203'-- and x.Volume<>0
order by x.Acc,x.StockID,x.TxDate


