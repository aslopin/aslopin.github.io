declare @temp table(庫存日期 datetime,acc nvarchar(50),MV decimal(20,4))
insert @temp
select a.庫存日期,a.交易員代碼,sum(a.MV) as MV
from (
	select a.庫存日期,a.交易員代碼,a.股票代號
	,a.今日庫存成本+a.今日未實現損益
	+isnull(-1*b.今日券賣庫存成本+b.今日未實現損益,0)
	as MV
	from pl.dbo.[400現股庫存檔wkstkx] a
	left join pl.[dbo].[400券賣庫存損益檔wklnkx] b on b.[庫存日期]=a.庫存日期 and b.交易員代碼=a.交易員代碼 and b.股票代號=a.股票代號
	where a.庫存日期 between '20190101' and '20230630'
	--and a.交易員代碼='711'
) a
where a.MV>=0 and a.交易員代碼 not like '[015]__'
group by a.庫存日期,a.交易員代碼

select a.Y,coalesce(nc.策略,nb.Portfolio,a.acc) as 策略
,sum(isnull(c.MV,0)) as MV
from (select format(庫存日期,'yyyy') as Y,acc from @temp group by format(庫存日期,'yyyy'),acc) a
join dbmain.dbo.Tradingdate b on format(b.Tradingdate,'yyyy')=a.Y
left join @temp c on c.庫存日期=b.Tradingdate and c.acc=a.acc
left join DBMain.dbo.AccountList_Temp nb on nb.Acc00=a.acc and b.Tradingdate between nb.BDate and nb.EDate
left join dbmain.dbo.Strategy名稱轉換 nc on nc.Strategy=nb.Portfolio 
and nc.Dept=(case when nb.ID='策略交易' then '策交部' when nb.ID='期貨交易' then '期交部' when nb.ID='債券交易' then '債券部' when nb.ID='計量交易' then '計量部'   when nb.ID='權證交易' then '衍商部'  when nb.ID='自營交易' then '自營二組' else nb.ID end )
and b.Tradingdate between nc.BDate and nc.EDate
group by a.Y,coalesce(nc.策略,nb.Portfolio,a.acc)
having sum(isnull(c.MV,0))<>0
order by a.Y,coalesce(nc.策略,nb.Portfolio,a.acc)

select format(x.txdate,'yyyy') as Y,x.策略,x.acc
,sum(x.delta) as delta
,sum(x.delta_L) as delta_L
,sum(x.Credit_Delta) as Credit_Delta
,sum(x.累計資金) as 累計資金
from (
	SELECT txdate,acc,delta,delta_L,Credit_Delta,累計資金,coalesce(c.策略,b.Portfolio,a.acc) as 策略--,b.id
	FROM [OperationDesk].[dbo].[Delta_LS] a
	left join DBMain.dbo.AccountList_Temp b on b.Acc00=a.acc and a.txdate between b.BDate and b.EDate
	left join dbmain.dbo.Strategy名稱轉換 c on c.Strategy=b.Portfolio 
	and c.Dept=(case when b.ID='策略交易' then '策交部' when b.ID='期貨交易' then '期交部' when b.ID='債券交易' then '債券部' when b.ID='計量交易' then '計量部'   when b.ID='權證交易' then '衍商部'  when b.ID='自營交易' then '自營二組' else b.ID end )
	and a.txdate between c.BDate and c.EDate
	where txdate between '2019/1/1' and '2023/6/30'
) x
group by format(x.txdate,'yyyy'),x.策略,x.acc
order by format(x.txdate,'yyyy'),x.策略,x.acc

select format(tradingdate,'yyyy') as Y,count(*)
from dbmain.dbo.tradingdate
where tradingdate between '2019/1/1' and '2023/6/30'
group by format(tradingdate,'yyyy')
order by format(tradingdate,'yyyy')



select cast(年度 as nvarchar(50))+cast(月份 as nvarchar(50))
,sum(case when left(層二,1) in ('2','4','6','8','0') and 層一='3投資收益' then 損益 else 0 end)/1000000. as 已實現
,sum(case when left(層二,1) in ('1','3','5','7','9') and 層一='3投資收益' then 損益 else 0 end)/1000000. as 未實現
,sum(case when 層一='3投資收益' then 損益 else 0 end)/1000000. as 合計
from hubert.[dbo].[Cognos]
where cast(年度 as nvarchar(50))+cast(月份 as nvarchar(50)) <='202306'
group by cast(年度 as nvarchar(50))+cast(月份 as nvarchar(50))
order by cast(年度 as nvarchar(50))+cast(月份 as nvarchar(50))

select cast(年度 as nvarchar(50)) as 年度
,sum(case when 層一 like '[1234]%' then 損益 else 0 end)/1000000. as 操作損益
,sum(case when 層一 like '[5]%' then 損益 else 0 end)/1000000. as 費用
,sum(case when 層一 like '[12345]%' then 損益 else 0 end)/1000000. as 合計
from hubert.[dbo].[Cognos]
where cast(年度 as nvarchar(50))+cast(月份 as nvarchar(50)) <='202306'
and 層一 like '[12345]%'
and 部門 like '%金融交易處%'     
group by cast(年度 as nvarchar(50))
order by cast(年度 as nvarchar(50))

select distinct(層一)
from hubert.[dbo].[Cognos]
where 年度>='2019'
order by 層一

select distinct(部門)
from hubert.[dbo].[Cognos]