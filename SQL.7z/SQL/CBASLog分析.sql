/*
SELECT len(FIRM_EMPL_NO1),len(FIRM_EMPL_NO2),[MOD_SEQ], [LOG_DATE], [MOD_STATUS], [LOG_EMPL_NO], [TRD_NO], [SEQ], [TRD_DATE], [STTL_DATE], [FIRM_DATE], [CUST_NO], [TRD_TYPE], [BS_TYPE], [BOND_NO], [VAL], [PRICE], [TRD_AMT], [INT_AMT_I], [INT_TAX_I], [INT_AMT_II], [INT_TAX_II], [COMPENSATION_AMT], [RESCIS_PENAL_AMT], [STTL_AMT], [ACT_DUE_STTL_DATE], [RATE_I], [CBAS_INT_TYPE_I], [INT_PAY_TIMES_I], [INT_CALC_TIMES_I], [INT_TYPE_I], [ODD_PERIOD_I], [PAY_INT_TYPE_I], [RATE_II], [CBAS_INT_TYPE_II], [INT_PAY_TIMES_II], [INT_CALC_TIMES_II], [INT_TYPE_II], [ODD_PERIOD_II], [PAY_INT_TYPE_II], [OPT_ACT_DUE_STTL_DATE], [BOPT_TYPE], [CBAS_BOPT_MODE], [PREM], [PERF_LEAST_UNIT], [STTL_DAYS], [RESCIS_PENAL_DATE], [RESCIS_PENAL_RATIO], [BAT_NO], [REM_VAL], [RECEIPT_NO], [TRD_STATUS], [DEPT_NO_IN], [DEALER_NO], [SUB_ACCT_NO], [COMPENSATION_RATIO], [CONF_EMPL_NO], [BANK_NO], [BANK_ACCT_NO], [TDCC_NO], [BANK_SEQ_NO], [TDCC_SEQ_NO], [CB_EXEC_PRICE], [OPOS_TRD_NO], [RETURN_PRICE], [PREM_COST], [CANCEL_FLAG], [KEYIN_NO], [AGENT_TYPE], [PRICE_EVENT], [RELATION_SHIP], [FIRM_EMPL_NO1], [FIRM_EMPL_NO2], [SIGN_DATE], [MODIFY_PROGRAM_ID], [ADD_EMPL_NO], [ADD_TIME], [CHG_EMPL_NO], [CHG_TIME]
FROM [BOND_TAISHIN_CBAS].[dbo].[CBAS_TRD_LOG]
where [TRD_DATE] ='2022/3/24' and TRD_NO='22W0062299' --and (FIRM_EMPL_NO2 is not null or FIRM_EMPL_NO2<>'')
order by [MOD_SEQ]

SELECT [MOD_SEQ], [LOG_DATE], [MOD_STATUS], [LOG_EMPL_NO], [TRD_NO], [SEQ], [TRD_DATE], [STTL_DATE], [FIRM_DATE], [CUST_NO], [TRD_TYPE], [BS_TYPE], [BOND_NO], [VAL], [PRICE], [TRD_AMT], [INT_AMT_I], [INT_TAX_I], [INT_AMT_II], [INT_TAX_II], [COMPENSATION_AMT], [RESCIS_PENAL_AMT], [STTL_AMT], [ACT_DUE_STTL_DATE], [RATE_I], [CBAS_INT_TYPE_I], [INT_PAY_TIMES_I], [INT_CALC_TIMES_I], [INT_TYPE_I], [ODD_PERIOD_I], [PAY_INT_TYPE_I], [RATE_II], [CBAS_INT_TYPE_II], [INT_PAY_TIMES_II], [INT_CALC_TIMES_II], [INT_TYPE_II], [ODD_PERIOD_II], [PAY_INT_TYPE_II], [OPT_ACT_DUE_STTL_DATE], [BOPT_TYPE], [CBAS_BOPT_MODE], [PREM], [PERF_LEAST_UNIT], [STTL_DAYS], [RESCIS_PENAL_DATE], [RESCIS_PENAL_RATIO], [BAT_NO], [REM_VAL], [RECEIPT_NO], [TRD_STATUS], [DEPT_NO_IN], [DEALER_NO], [SUB_ACCT_NO], [COMPENSATION_RATIO], [CONF_EMPL_NO], [BANK_NO], [BANK_ACCT_NO], [TDCC_NO], [BANK_SEQ_NO], [TDCC_SEQ_NO], [CB_EXEC_PRICE], [OPOS_TRD_NO], [RETURN_PRICE], [PREM_COST], [CANCEL_FLAG], [KEYIN_NO], [AGENT_TYPE], [PRICE_EVENT], [RELATION_SHIP], [FIRM_EMPL_NO1], [FIRM_EMPL_NO2], [SIGN_DATE], [MODIFY_PROGRAM_ID], [ADD_EMPL_NO], [ADD_TIME], [CHG_EMPL_NO], [CHG_TIME]
FROM [BOND_TAISHIN_CBAS].[dbo].[CBAS_TRD_LOG]
where [TRD_DATE] between '2020/3/1' and '2022/6/30'
order by [MOD_SEQ]

SELECT [MOD_SEQ], [LOG_DATE], [MOD_STATUS], [LOG_EMPL_NO], [TRD_NO], [SEQ], [OPT_TRD_DATE], [OPT_EFFECTIVE_DATE], [FIRM_DATE], [CUST_NO], [BOND_NO], [TRD_TYPE], [BS_TYPE], [VAL], [RETURN_PRICE], [DISCOUNT_RATE], [CHARGE_FEE_RATIO], [CHARGE_FEE], [EXEC_PRICE], [OPT_ACT_DUE_STTL_DATE], [ACT_DUE_STTL_DATE], [STTL_DATE], [STTL_DATE_1], [CB_MKT_PRICE], [PREM_QUOTE], [PREM], [PERF_LEAST_UNIT], [BOPT_TYPE], [CBAS_BOPT_MODE], [STTL_TYPE], [RESCIS_PENAL_DATE], [RESCIS_PENAL_RATIO], [HONOR_FEE_RATIO], [TRD_AMT], [RESCIS_PENAL_AMT], [HONOR_FEE], [PREM_REFUND], [INT_AMT], [INT_TAX], [STTL_AMT], [REPORT_TRD_VAL], [REPORT_PRICE], [REPORT_TRD_AMT], [REPORT_FEE], [REPORT_TAX], [REPORT_STTL_AMT], [STTL_AMT_1], [REM_VAL], [RECEIPT_NO], [TRD_STATUS], [DEPT_NO_IN], [DEALER_NO], [SUB_ACCT_NO], [CONF_EMPL_NO], [STTL_DAYS], [BANK_NO], [BANK_ACCT_NO], [TDCC_NO], [BANK_SEQ_NO], [TDCC_SEQ_NO], [CB_EXEC_PRICE], [OPOS_TRD_NO], [RETURN_DATE], [KEYIN_NO], [AGENT_TYPE], [PRICE_EVENT], [RELATION_SHIP], [FIRM_EMPL_NO1], [FIRM_EMPL_NO2], [SIGN_DATE], [MODIFY_PROGRAM_ID], [ADD_EMPL_NO], [ADD_TIME], [CHG_EMPL_NO], [CHG_TIME]
FROM [BOND_TAISHIN_CBAS].[dbo].[CBAS_OPT_TRD_LOG]
where [OPT_TRD_DATE] between '2020/3/1' and '2022/6/30'
order by [MOD_SEQ]
*/

select a.TRD_DATE,cast(a.LOG_DATE as datetime) as LOG_DATE,a.TRD_NO,a.中台確認數,a.後台確認數
from (
	SELECT [TRD_DATE],[TRD_NO],cast(datepart(yy,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(mm,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(dd,LOG_DATE) as nvarchar(50)) as LOG_DATE
	,sum(case when len(FIRM_EMPL_NO1)=3 then 1. else 0 end) as 中台確認數
	,sum(case when len(FIRM_EMPL_NO2)=3 then 1. else 0 end) as 後台確認數
	FROM [BOND_TAISHIN_CBAS].[dbo].[CBAS_TRD_LOG]
	where [TRD_DATE] between '2020/3/1' and '2022/6/30'
	and [MOD_STATUS]='2'
	group by [TRD_DATE],[TRD_NO],cast(datepart(yy,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(mm,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(dd,LOG_DATE) as nvarchar(50))
	having sum(case when len(FIRM_EMPL_NO1)=3 then 1. else 0 end)>2
	or sum(case when len(FIRM_EMPL_NO2)=3 then 1. else 0 end)>2
) a
where a.TRD_DATE=cast(a.LOG_DATE as datetime)

select a.OPT_TRD_DATE,cast(a.LOG_DATE as datetime) as LOG_DATE,a.TRD_NO,a.中台確認數,a.後台確認數
from (
	SELECT OPT_TRD_DATE,[TRD_NO],cast(datepart(yy,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(mm,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(dd,LOG_DATE) as nvarchar(50)) as LOG_DATE
	,sum(case when len(FIRM_EMPL_NO1)=3 then 1. else 0 end) as 中台確認數
	,sum(case when len(FIRM_EMPL_NO2)=3 then 1. else 0 end) as 後台確認數
	FROM [BOND_TAISHIN_CBAS].[dbo].CBAS_OPT_TRD_LOG
	where OPT_TRD_DATE between '2020/3/1' and '2022/6/30'
	and [MOD_STATUS]='2'
	group by OPT_TRD_DATE,[TRD_NO],cast(datepart(yy,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(mm,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(dd,LOG_DATE) as nvarchar(50))
	having sum(case when len(FIRM_EMPL_NO1)=3 then 1. else 0 end)>2
	or sum(case when len(FIRM_EMPL_NO2)=3 then 1. else 0 end)>2
) a
where a.OPT_TRD_DATE=cast(a.LOG_DATE as datetime)

select a.TRD_DATE,cast(a.LOG_DATE as datetime) as LOG_DATE,a.TRD_NO,a.中台確認數,a.後台確認數
from (
	SELECT [TRD_DATE],[TRD_NO],cast(datepart(yy,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(mm,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(dd,LOG_DATE) as nvarchar(50)) as LOG_DATE
	,sum(case when len(FIRM_EMPL_NO1)=3 then 1. else 0 end) as 中台確認數
	,sum(case when len(FIRM_EMPL_NO2)=3 then 1. else 0 end) as 後台確認數
	FROM [BOND_TAISHIN_CBAS].[dbo].[CBAS_TRD_LOG]
	where [TRD_DATE] between '2020/3/1' and '2022/6/30'
	and [MOD_STATUS]='2'
	group by [TRD_DATE],[TRD_NO],cast(datepart(yy,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(mm,LOG_DATE) as nvarchar(50))+'/'+cast(datepart(dd,LOG_DATE) as nvarchar(50))
	--having sum(case when len(FIRM_EMPL_NO1)=3 then 1. else 0 end)>2
	--or sum(case when len(FIRM_EMPL_NO2)=3 then 1. else 0 end)>2
) a
where a.TRD_DATE=cast(a.LOG_DATE as datetime)