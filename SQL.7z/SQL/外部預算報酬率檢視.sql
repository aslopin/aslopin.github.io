﻿declare @t datetime set @t='2024/2/2'
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @月份 nvarchar(50) set @月份=format(@t,'MM')


declare @ELNPGN table(部門 varchar(50),中台損益 decimal(20,4),會計損益 decimal(20,4),會計減中台 decimal(20,4))
if datepart(mm,@t)=datepart(mm,@y)
	begin
	insert @ELNPGN
	exec MDOutput.[dbo].[ELNPGN本月差異數] @y
	end


declare @會計差異數 table(年月 nvarchar(50),部門 nvarchar(50),PL decimal(20,4))
insert @會計差異數
select format(@t,'MM') as 年月,x.部門,x.PL+isnull(y.會計減中台/1000000.,0) as PL
--按2023/5/27小銘與May電話中協議，以差異項一半來計算會被扣回來的數字
from (
	select x.年月,x.部門
	,sum(x.PL) over(partition by x.部門 order by x.年月)/1000000. as PL
	,rank() over(partition by x.部門 order by x.年月 desc) as rnk
	from (
		select 年月,部門,sum(case when 策略 in ('ETF申贖差異','匯率損益','其他') then 0.5 else 1 end*會計差異數) as PL
		from MDoutput.dbo.主管報表_會計差異數 
		where left(年月,4) = format(@t,'yyyy') and 策略 in ('ETF申贖差異','匯率損益','其他','主管機關費用','ELN/PGN差異') 
		group by 年月,部門
	) x
) x
left join @ELNPGN y on y.部門=x.部門
where x.rnk=1

insert @會計差異數 select 年月,'金融交易處',sum(PL) from @會計差異數 group by 年月



declare @一隻腳 table(年月 nvarchar(50),部門 nvarchar(50),PL decimal(20,4),[建立日期] datetime)
insert @一隻腳
select format(x.TxDate,'MM') as 年月,x.Dept,sum(x.PL)/1000000. as PL,max(x.[建立日期]) as [建立日期]
from (
	select x.TxDate,x.TxTime,x.Dept,x.Strategy,x.Acc,x.PL,x.[建立日期]
	from (
		select x.TxDate,x.TxTime,x.Dept,x.Strategy,x.Acc,x.PL,x.[建立日期]
		,rank() over(partition by x.TxDate,x.Dept,x.Strategy,x.Acc order by x.[建立日期] desc) as Rnk
		from (
			SELECT a.TxDate,a.TxTime,a.Dept,a.Strategy,a.Acc,a.[建立日期],sum(a.PL) as PL
			FROM [PL].[dbo].[海外期貨假日損益_中台_His] a
			join (select max(TxDate) as TxDate from [PL].[dbo].[海外期貨假日損益_中台_His]  where  Txdate<=@t group by datepart(yy,TxDate),datepart(mm,TxDate)) b on b.TxDate=a.TxDate
			where datepart(yy,a.TxDate)=datepart(yy,@t)
			group by a.TxDate,a.TxTime,a.Dept,a.Strategy,a.Acc,a.[建立日期]
		) x
	) x
	where x.Rnk=1 and x.Strategy like '%結算時間點為1330%'
) x
group by x.Dept,format(x.TxDate,'MM')


insert @一隻腳 select 年月,'金融交易處',sum(PL),max(建立日期) from @一隻腳 group by 年月

declare @每月預計費用 table(部門 nvarchar(50),PL decimal(20,6))
if year(@t)>=2024
	begin
	--May2024/2/26設的
	insert @每月預計費用
	select '衍商'	,-3.5
	union all select '計交'	,-2.7
	union all select '債券'	,-2.8
	----小名2024/1/4自己設的
	--insert @每月預計費用
	--select '衍商'	,-2.6
	--union all select '計交'	,-2.8
	--union all select '債券'	,-3.1
	end
	else
	begin
	--MR說的
	insert @每月預計費用
	select '衍商'	,-2.8
	union all select '計交'	,-2
	union all select '債券'	,-3
	union all select '自營'	,-1.2
	end



--select * from @會計差異數
--select * from @一隻腳
declare @月份maxcognos nvarchar(50) 
create table #cognos(部門 nvarchar(50),層一 nvarchar(50),PL decimal(20,6),月份 nvarchar(50))
if @月份='01' and year(@t)>=2024
	begin
	insert #cognos
	select a.部門,a.層一,0 as PL,'00' as 月份
	from hubert.dbo.Cognos a
	where a.年度=datepart(yy,@t)-1 and a.月份='01' and a.部門 not in ('自營')
	group by a.部門,a.層一,a.月份

	set @月份maxcognos='00'
	end
/*
else if @月份='02' and year(@t)>=2024
	begin
	insert #cognos
	select case when Dept ='全處' then '金融交易處' when Dept ='自三' then '自營' when Dept ='計量' then '計交' else Dept end as 部門
	,'3投資收益' as 層一
	,累計到本月全年損益*1000000. as PL
	,right(left(日期,7),2) as 月份
	from  [MDoutput].dbo.Cht_tsftd_CIOReport_End
	where 交易類別='合計' and Dept not like '%OCI%' and right(left(日期,7),2)='01' and left(日期,4)=year(@t)
	union all
	select 部門,'5營業費用' as 層一,PL*1000000,'01' as 月份
	from @每月預計費用
	union all
	select '金融交易處' as 部門,'5營業費用' as 層一,sum(PL*1000000),'01' as 月份
	from @每月預計費用

	set @月份maxcognos='01'
	end
*/
else
	begin
	insert #cognos
	select a.部門,a.層一,sum(a.損益) as PL,a.月份
	from hubert.dbo.Cognos a
	where a.年度=datepart(yy,@t)
	group by a.部門,a.層一,a.月份

	set @月份maxcognos=isnull((select max(月份) from #cognos),'00')
	end

--create table #CIO(ser decimal(20,7),日期 datetime,部門 nvarchar(50),交易類別 nvarchar(50),本日損益 decimal(20,6),本月損益 decimal(20,6),累計到本月全年損益 decimal(20,6),累計到前月全年損益 decimal(20,6),FYF decimal(20,6),更新時間 datetime)
create table #PreCIO(日期 datetime,部門 nvarchar(50),交易類別 nvarchar(50),Desk nvarchar(50),本日損益 decimal(20,6),部位 decimal(20,6),更新時間 datetime)
insert #PreCIO
exec [PL].[dbo].[投資長報表] '交易類別_D'

--select * from #PreCIO order by 日期 desc

create table #CIO(日期 datetime,部門 nvarchar(50),交易類別 nvarchar(50),Desk nvarchar(50),本日損益 decimal(20,6),部位 decimal(20,6),更新時間 datetime)
insert #CIO
select * from #PreCIO where 日期<=@t and year(日期)=year(@t)


create table #temp(部門 nvarchar(50),月份 nvarchar(50),PLCIO decimal(20,6))
insert #temp
select 部門,format(日期,'MM') as 月份,sum(本日損益) as PLCIO
from #CIO
where datepart(yy,日期)=datepart(yy,@t) and 交易類別 not in ('OCI')-- and 交易類別='合計'
group by 部門,format(日期,'MM')
union all
select '金融交易處' as 部門,format(日期,'MM') as 月份,sum(本日損益) as PLCIO
from #CIO
where datepart(yy,日期)=datepart(yy,@t) and 交易類別 not in ('OCI')-- and 交易類別='合計'
group by format(日期,'MM')

declare @tempCognos table(部門 nvarchar(50),PL decimal(20,6),PL當月 decimal(20,6),月份 nvarchar(50))
insert @tempCognos
select case when Dept ='全處' then '金融交易處' when Dept ='自三' then '自營' when Dept ='計量' then '計交' else Dept end as 部門
,累計到本月全年損益 as PL
,0 as PL當月
,right(left(日期,7),2) as 月份
from  [MDoutput].dbo.Cht_tsftd_CIOReport_End
where 交易類別='合計' and Dept not like '%OCI%' and right(left(日期,7),2)>@月份maxcognos and left(日期,4)=year(@t)
order by 日期 desc ,ser 

--select * from @tempCognos

declare @月份maxcognostemp nvarchar(50)
set @月份maxcognostemp =isnull((select max(月份) from @tempCognos),@月份maxcognos)

if @月份maxcognostemp<>@月份maxcognos
	begin
	insert @會計差異數
	select @月份maxcognostemp,部門,PL from @會計差異數
	end

--select * from #cognos
	
		
		select 部門,sum(PL)/1000000. as PL,0. as PL當月,b.月份 
		from #cognos a
		cross join (select format(tradingdate,'MM') as 月份 from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and tradingdate<=@t and format(tradingdate,'MM')>@月份maxcognostemp group by format(tradingdate,'MM')) b
		where 層一 like '[1234]%' 
		group by 部門,b.月份
--		union all
		select 部門,PL,PL當月,月份 from @tempCognos
		union all
		select x.部門,sum(x.PL) over(partition by x.部門 order by x.月份),x.PL,x.月份
		from (select 部門,sum(PL)/1000000. as PL,月份 from #cognos where 層一 like '[1234]%' group by 部門,月份) x


		select 部門,sum(PL)/1000000. as PL,0. as PL當月,b.月份 
		from #cognos a
		cross join (select format(tradingdate,'MM') as 月份 from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and tradingdate<=@t and format(tradingdate,'MM')>(select max(月份) from #cognos) group by format(tradingdate,'MM')) b
		where 層一 like '5%' 
		group by 部門,b.月份
		--select 部門,sum(PL)/1000000. as PL,sum(case when 月份=@月份 then PL else 0 end)/1000000. as PL當月,@月份 as 月份 from #cognos where 層一 like '5%' group by 部門
--		union all
		select x.部門,sum(x.PL) over(partition by x.部門 order by x.月份),x.PL,x.月份
		from (select 部門,sum(PL)/1000000. as PL,月份 from #cognos where 層一 like '5%' group by 部門,月份) x


	select a1.月份,a1.部門--,c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) as PL
--2023/6/16May來電討論，一隻腳於月底時再呈現
	--,case when a1.月份>@月份maxcognos then b.PLCIO+isnull(e.PL,0)+case when datepart(hour,f.建立日期)>=17 then isnull(f.PL,0) else 0 end
	--                                  else a1.PL end
	-- as 總收入
	, b.PLCIO,isnull(e.PL,0),
										case when datepart(dd,@t)>=29  then 
										(case when (cast(getdate() as date)<>@t) or (cast(getdate() as date)=@t and datepart(HH,getdate())>=15) then isnull(f.PL,0) else 0 end )
										when datepart(dd,@t)=1 and datepart(mm,@t)=cast(a1.月份 as int)+1 then isnull(f.PL,0)
										else 0 end

	,case when a1.月份>@月份maxcognos then b.PLCIO+isnull(e.PL,0)+
										case when datepart(dd,@t)>=29  then 
										(case when (cast(getdate() as date)<>@t) or (cast(getdate() as date)=@t and datepart(HH,getdate())>=15) then isnull(f.PL,0) else 0 end )
										when datepart(dd,@t)=1 and datepart(mm,@t)=cast(a1.月份 as int)+1 then isnull(f.PL,0)
										else 0 end
	                                  else a1.PL end
	 as 總收入
	 ,a2.PL
	,case when a1.月份>@月份maxcognos then a2.PL+c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) else a2.PL end as 營業費用
	--,case when a1.月份>@月份maxcognos then b.PLCIO+isnull(e.PL,0)+case when datepart(hour,f.建立日期)>=17 then isnull(f.PL,0) else 0 end
	--                                  else a1.PL end
	--+case when a1.月份>@月份maxcognos then a2.PL+c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) else a2.PL end as 稅前純益
	,case when a1.月份>@月份maxcognos then b.PLCIO+isnull(e.PL,0)+
					case when datepart(dd,@t)>=29 then 
										(case when (cast(getdate() as date)<>@t) or (cast(getdate() as date)=@t and datepart(HH,getdate())>=15) then isnull(f.PL,0) else 0 end )
					                    when datepart(dd,@t)=1 and datepart(mm,@t)=cast(a1.月份 as int)+1 then isnull(f.PL,0)
										else 0 end
	else a1.PL end
	+case when a1.月份>@月份maxcognos then a2.PL+c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) else a2.PL end as 稅前純益

	--,case when a1.月份>@月份maxcognos then b.PLCIO-a1.PL+isnull(e.PL,0)+isnull(f.PL,0) else a1.PL當月 end as 總收入_當月
	--,case when a1.月份>@月份maxcognos then c.PL else a2.PL當月 end as 營業費用_當月
	--,case when a1.月份>@月份maxcognos then b.PLCIO-a1.PL+isnull(e.PL,0)+isnull(f.PL,0) else a1.PL當月 end
	--+case when a1.月份>@月份maxcognos then c.PL else a2.PL當月 end as 稅前純益_當月

	,d.[總收入(當月)] as [總收入(預算當月)]
	,d.[營業費用(當月)] as [營業費用(預算當月)]
	,d.[稅前純益(當月)] as [稅前純益(預算當月)]
	,d.總收入 as [總收入(預算)]
	,d.營業費用 as [營業費用(預算)]
	,d.稅前純益 as [稅前純益(預算)]
	,g.總收入 as [總收入(年預算)]
	,g.營業費用 as [營業費用(年預算)]
	,g.稅前純益 as [稅前純益(年預算)]
	from (

		select 部門,sum(PL)/1000000. as PL,0. as PL當月,b.月份 
		from #cognos a
		cross join (select format(tradingdate,'MM') as 月份 from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and tradingdate<=@t and format(tradingdate,'MM')>@月份maxcognostemp group by format(tradingdate,'MM')) b
		where 層一 like '[1234]%' 
		group by 部門,b.月份
		union all
		select 部門,PL,PL當月,月份 from @tempCognos
		union all
		select x.部門,sum(x.PL) over(partition by x.部門 order by x.月份),x.PL,x.月份
		from (select 部門,sum(PL)/1000000. as PL,月份 from #cognos where 層一 like '[1234]%' group by 部門,月份) x
	) a1
	left join (
	--+--累積營業費用--+--
		select 部門,sum(PL)/1000000. as PL,0. as PL當月,b.月份 
		from #cognos a
		cross join (select format(tradingdate,'MM') as 月份 from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and tradingdate<=@t and format(tradingdate,'MM')>(select max(月份) from #cognos) group by format(tradingdate,'MM')) b
		where 層一 like '5%' 
		group by 部門,b.月份
		--select 部門,sum(PL)/1000000. as PL,sum(case when 月份=@月份 then PL else 0 end)/1000000. as PL當月,@月份 as 月份 from #cognos where 層一 like '5%' group by 部門
		union all
		select x.部門,sum(x.PL) over(partition by x.部門 order by x.月份),x.PL,x.月份
		from (select 部門,sum(PL)/1000000. as PL,月份 from #cognos where 層一 like '5%' group by 部門,月份) x
	) a2 on a2.部門=a1.部門 and a2.月份=a1.月份
	left join (
	--+--V1損益--+--
		select x.部門,x.月份,sum(x.PLCIO) over(partition by x.部門 order by x.月份) as PLCIO
		from #temp x
	) b on left(b.部門,1)=left(a1.部門,1) and b.月份=a1.月份
	left join (
	--+-每月費用--+--
		select 部門,PL
		from @每月預計費用
		union all
		select '金融交易處' as 部門,sum(PL) as PL
		from @每月預計費用
	) c on left(c.部門,1)=left(a1.部門,1)
	left join (
		select 年月
		,單位 as 部門
		, [總收入]/1000000. as [總收入(當月)]
		, [營業費用]/1000000.*-1 as [營業費用(當月)]
		, [稅前純益]/1000000. as [稅前純益(當月)]
		, sum([總收入]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [總收入]
		, sum([營業費用]) over(partition by 單位,left(年月,4) order by 年月)/1000000.*-1 as [營業費用]
		, sum([稅前純益]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [稅前純益]
		from pl.dbo.每月外部預算
		where left(年月,4)=datepart(yy,@t) 
	) d on left(d.部門,1)=left(a1.部門,1) and d.年月=cast(datepart(yy,@t) as nvarchar(50))+a1.月份
	left join @會計差異數 e on left(e.部門,1)=left(a1.部門,1) and e.年月=a1.月份
	left join @一隻腳 f on left(f.部門,1)=left(a1.部門,1) and f.年月=a1.月份
	left join (
		select 年月
		,單位 as 部門
		, [總收入]/1000000. as [總收入(當月)]
		, [營業費用]/1000000.*-1 as [營業費用(當月)]
		, [稅前純益]/1000000. as [稅前純益(當月)]
		, sum([總收入]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [總收入]
		, sum([營業費用]) over(partition by 單位,left(年月,4) order by 年月)/1000000.*-1 as [營業費用]
		, sum([稅前純益]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [稅前純益]
		from pl.dbo.每月外部預算
		where left(年月,4)=datepart(yy,@t) 
	) g on left(g.部門,1)=left(a1.部門,1) and g.年月=cast(datepart(yy,@t) as nvarchar(50))+'12'
	order by a1.月份 desc,a1.部門


select a.月份,a.部門
,a.總收入,a.營業費用,a.稅前純益
,a.總收入-isnull(lag(a.總收入) over(partition by a.部門 order by a.月份),0) as 總收入_當月
,a.營業費用-isnull(lag(a.營業費用) over(partition by a.部門 order by a.月份),0) as 營業費用_當月
,a.稅前純益-isnull(lag(a.稅前純益) over(partition by a.部門 order by a.月份),0) as 稅前純益_當月
,a.[總收入(預算當月)]
,a.[營業費用(預算當月)]
,a.[稅前純益(預算當月)]
,a.[總收入(預算)]
,a.[營業費用(預算)]
,a.[稅前純益(預算)]

,case when a.[總收入(預算當月)]>0 then (a.總收入-isnull(lag(a.總收入) over(partition by a.部門 order by a.月份),0))/a.[總收入(預算當月)]
      when a.[總收入(預算當月)]<0 then 2-(a.總收入-isnull(lag(a.總收入) over(partition by a.部門 order by a.月份),0))/(a.[總收入(預算當月)]) 
	  else 0 end
 as [總收入(達成率當月)]
,(a.營業費用-isnull(lag(a.營業費用) over(partition by a.部門 order by a.月份),0))/a.[營業費用(預算當月)]
 as [營業費用(達成率當月)]
,case when a.[稅前純益(預算當月)]>0 then (a.稅前純益-isnull(lag(a.稅前純益) over(partition by a.部門 order by a.月份),0))/a.[稅前純益(預算當月)]
      when a.[稅前純益(預算當月)]<0 then 2-(a.稅前純益-isnull(lag(a.稅前純益) over(partition by a.部門 order by a.月份),0))/(a.[稅前純益(預算當月)]) 
	  else 0 end
 as [稅前純益(達成率當月)]

,case when a.[總收入(預算)]>0 then a.總收入/a.[總收入(預算)]
      when a.[總收入(預算)]<0 then 2-a.總收入/a.[總收入(預算)]
	  else 0 end
as [總收入(達成率)]
,a.營業費用/a.[營業費用(預算)]
as [營業費用(達成率)]
,case when a.[稅前純益(預算)]>0 then a.稅前純益/a.[稅前純益(預算)]
      when a.[稅前純益(預算)]<0 then 2-a.稅前純益/a.[稅前純益(預算)]
	  else 0 end
as [稅前純益(達成率)]
,@t
,getdate()
,[總收入(年預算)] as [總收入(年預算)]
,[營業費用(年預算)] as [營業費用(年預算)]
,[稅前純益(年預算)] as [稅前純益(年預算)]
--2023/5/29 1400經與may討論後，預算為負者，達成率需另行調整
--2023/6/15 Ken來信表達，預算為負者，達成率應修正調整方式
from (
	select a1.月份,a1.部門--,c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) as PL
--2023/6/16May來電討論，一隻腳於月底時再呈現
	--,case when a1.月份>@月份maxcognos then b.PLCIO+isnull(e.PL,0)+case when datepart(hour,f.建立日期)>=17 then isnull(f.PL,0) else 0 end
	--                                  else a1.PL end
	-- as 總收入
	,case when a1.月份>@月份maxcognostemp then b.PLCIO+isnull(e.PL,0)+
										case when datepart(dd,@t)>=29  then 
										(case when (cast(getdate() as date)<>@t) or (cast(getdate() as date)=@t and datepart(HH,getdate())>=15) then isnull(f.PL,0) else 0 end )
										when datepart(dd,@t)=1 and datepart(mm,@t)=cast(a1.月份 as int)+1 then isnull(f.PL,0)
										else 0 end
	                                  else a1.PL end
	 as 總收入
	,case when a1.月份>@月份maxcognostemp then a2.PL+c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) else a2.PL end as 營業費用
	--,case when a1.月份>@月份maxcognos then b.PLCIO+isnull(e.PL,0)+case when datepart(hour,f.建立日期)>=17 then isnull(f.PL,0) else 0 end
	--                                  else a1.PL end
	--+case when a1.月份>@月份maxcognos then a2.PL+c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) else a2.PL end as 稅前純益
	,case when a1.月份>@月份maxcognostemp then b.PLCIO+isnull(e.PL,0)+
					case when datepart(dd,@t)>=29 then 
										(case when (cast(getdate() as date)<>@t) or (cast(getdate() as date)=@t and datepart(HH,getdate())>=15) then isnull(f.PL,0) else 0 end )
					                    when datepart(dd,@t)=1 and datepart(mm,@t)=cast(a1.月份 as int)+1 then isnull(f.PL,0)
										else 0 end
	else a1.PL end
	+case when a1.月份>@月份maxcognostemp then a2.PL+c.PL*(cast(a1.月份 as decimal(20,4))-cast(@月份maxcognos as decimal(20,4))) else a2.PL end as 稅前純益

	--,case when a1.月份>@月份maxcognos then b.PLCIO-a1.PL+isnull(e.PL,0)+isnull(f.PL,0) else a1.PL當月 end as 總收入_當月
	--,case when a1.月份>@月份maxcognos then c.PL else a2.PL當月 end as 營業費用_當月
	--,case when a1.月份>@月份maxcognos then b.PLCIO-a1.PL+isnull(e.PL,0)+isnull(f.PL,0) else a1.PL當月 end
	--+case when a1.月份>@月份maxcognos then c.PL else a2.PL當月 end as 稅前純益_當月

	,d.[總收入(當月)] as [總收入(預算當月)]
	,d.[營業費用(當月)] as [營業費用(預算當月)]
	,d.[稅前純益(當月)] as [稅前純益(預算當月)]
	,d.總收入 as [總收入(預算)]
	,d.營業費用 as [營業費用(預算)]
	,d.稅前純益 as [稅前純益(預算)]
	,g.總收入 as [總收入(年預算)]
	,g.營業費用 as [營業費用(年預算)]
	,g.稅前純益 as [稅前純益(年預算)]
	from (
	
		select 部門,sum(PL)/1000000. as PL,0. as PL當月,b.月份 
		from #cognos a
		cross join (select format(tradingdate,'MM') as 月份 from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and tradingdate<=@t and format(tradingdate,'MM')>@月份maxcognostemp group by format(tradingdate,'MM')) b
		where 層一 like '[1234]%' 
		group by 部門,b.月份
		union all
		select 部門,PL,PL當月,月份 from @tempCognos
		union all
		select x.部門,sum(x.PL) over(partition by x.部門 order by x.月份),x.PL,x.月份
		from (select 部門,sum(PL)/1000000. as PL,月份 from #cognos where 層一 like '[1234]%' group by 部門,月份) x
	) a1
	left join (
	--+--累積營業費用--+--
		select 部門,sum(PL)/1000000. as PL,0. as PL當月,b.月份 
		from #cognos a
		cross join (select format(tradingdate,'MM') as 月份 from dbmain.dbo.tradingdate where datepart(yy,tradingdate)=datepart(yy,@t) and tradingdate<=@t and format(tradingdate,'MM')>(select max(月份) from #cognos) group by format(tradingdate,'MM')) b
		where 層一 like '5%' 
		group by 部門,b.月份
		--select 部門,sum(PL)/1000000. as PL,sum(case when 月份=@月份 then PL else 0 end)/1000000. as PL當月,@月份 as 月份 from #cognos where 層一 like '5%' group by 部門
		union all
		select x.部門,sum(x.PL) over(partition by x.部門 order by x.月份),x.PL,x.月份
		from (select 部門,sum(PL)/1000000. as PL,月份 from #cognos where 層一 like '5%' group by 部門,月份) x
	) a2 on a2.部門=a1.部門 and a2.月份=a1.月份
	left join (
	--+--V1損益--+--
		select x.部門,x.月份,sum(x.PLCIO) over(partition by x.部門 order by x.月份) as PLCIO
		from #temp x
	) b on left(b.部門,1)=left(a1.部門,1) and b.月份=a1.月份
	left join (
	--+-每月費用--+--
		select 部門,PL
		from @每月預計費用
		union all
		select '金融交易處' as 部門,sum(PL) as PL
		from @每月預計費用
	) c on left(c.部門,1)=left(a1.部門,1)
	left join (
		select 年月
		,單位 as 部門
		, [總收入]/1000000. as [總收入(當月)]
		, [營業費用]/1000000.*-1 as [營業費用(當月)]
		, [稅前純益]/1000000. as [稅前純益(當月)]
		, sum([總收入]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [總收入]
		, sum([營業費用]) over(partition by 單位,left(年月,4) order by 年月)/1000000.*-1 as [營業費用]
		, sum([稅前純益]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [稅前純益]
		from pl.dbo.每月外部預算
		where left(年月,4)=datepart(yy,@t) 
	) d on left(d.部門,1)=left(a1.部門,1) and d.年月=cast(datepart(yy,@t) as nvarchar(50))+a1.月份
	left join @會計差異數 e on left(e.部門,1)=left(a1.部門,1) and e.年月=a1.月份
	left join @一隻腳 f on left(f.部門,1)=left(a1.部門,1) and f.年月=a1.月份
	left join (
		select 年月
		,單位 as 部門
		, [總收入]/1000000. as [總收入(當月)]
		, [營業費用]/1000000.*-1 as [營業費用(當月)]
		, [稅前純益]/1000000. as [稅前純益(當月)]
		, sum([總收入]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [總收入]
		, sum([營業費用]) over(partition by 單位,left(年月,4) order by 年月)/1000000.*-1 as [營業費用]
		, sum([稅前純益]) over(partition by 單位,left(年月,4) order by 年月)/1000000. as [稅前純益]
		from pl.dbo.每月外部預算
		where left(年月,4)=datepart(yy,@t) 
	) g on left(g.部門,1)=left(a1.部門,1) and g.年月=cast(datepart(yy,@t) as nvarchar(50))+'12'
) a
where a.月份>'00'
order by a.月份 desc, case when a.部門='金融交易處' then 0 when a.部門='衍商' then 1 when a.部門='計交' then 2 when a.部門='債券' then 3 when a.部門='自營' then 4  end


--insert mdoutput.[dbo].[外部預算達成率更新時間] select getdate(),'E'

select a.*
,case when left(a.月份,2)='01' then a.[總收入(年預算)] else b.[總收入]/1000000. end as [總收入FYF]
,case when left(a.月份,2)='01' then a.[營業費用(年預算)] else b.[營業費用]/1000000. end as [營業費用FYF]
,case when left(a.月份,2)='01' then a.[稅前純益(年預算)] else b.[稅前純益]/1000000. end as [稅前純益FYF]
,case when left(a.月份,2)='01' then a.[總收入(年預算)] else b.[總收入]/1000000. end/a.[總收入(年預算)] as [總收入FYF%]
,case when left(a.月份,2)='01' then a.[營業費用(年預算)] else b.[營業費用]/1000000. end/a.[營業費用(年預算)] as [營業費用FYF%]
,case when left(a.月份,2)='01' then a.[稅前純益(年預算)] else b.[稅前純益]/1000000. end/a.[稅前純益(年預算)] as [稅前純益FYF%]
--Ronald2023/11/9早上11點說RR不用算當月賺的
,(case when left(a.月份,2)='01' then a.[總收入(年預算)] else b.[總收入]/1000000. end-a.總收入+a.總收入_當月)/(12-cast(left(a.月份,2) as decimal(20,6))+1) as [總收入RR]
,(case when left(a.月份,2)='01' then a.[營業費用(年預算)] else b.[營業費用]/1000000. end-a.營業費用+a.營業費用_當月)/(12-cast(left(a.月份,2) as decimal(20,6))+1) as [營業費用RR]
,(case when left(a.月份,2)='01' then a.[稅前純益(年預算)] else b.[稅前純益]/1000000. end-a.稅前純益+a.稅前純益_當月)/(12-cast(left(a.月份,2) as decimal(20,6))+1) as [稅前純益RR]
from (
	select *
	from
	(
	select 月份,部門,總收入,營業費用,稅前純益
	,總收入_當月,營業費用_當月 ,稅前純益_當月
	,[總收入(預算當月)] ,[營業費用(預算當月)],[稅前純益(預算當月)]
	,[總收入(預算)],[營業費用(預算)],[稅前純益(預算)]
	,[總收入(達成率當月)] ,[營業費用(達成率當月)],[稅前純益(達成率當月)]
	,[總收入(達成率)] ,[營業費用(達成率)],[稅前純益(達成率)],[總收入(年預算)],[營業費用(年預算)],[稅前純益(年預算)]
	from mdoutput.dbo.外部預算達成率table where txdate=@t and 月份<=@月份maxcognos
	union
	select right(dbmain.dbo.datetranslator(Txdate,3),4) as 月份
	--case when Txdate=@t then left(right(dbmain.dbo.datetranslator(Txdate,3),4),2) else  right(dbmain.dbo.datetranslator(Txdate,3),4) end as 月份
	,部門,總收入,營業費用,稅前純益
	,總收入_當月,營業費用_當月 ,稅前純益_當月
	,[總收入(預算當月)] ,[營業費用(預算當月)],[稅前純益(預算當月)]
	,[總收入(預算)],[營業費用(預算)],[稅前純益(預算)]
	,[總收入(達成率當月)] ,[營業費用(達成率當月)],[稅前純益(達成率當月)]
	,[總收入(達成率)] ,[營業費用(達成率)],[稅前純益(達成率)],[總收入(年預算)],[營業費用(年預算)],[稅前純益(年預算)]
	from mdoutput.dbo.外部預算達成率table
	where Txdate>=dbmain.dbo.tradingdateadd(-6,@t) 
	and  Txdate<=@t and datepart(yy,@t)=datepart(yy,Txdate) and 月份>@月份maxcognos
	and left(right(dbmain.dbo.datetranslator(Txdate,3),4),2)=月份
	) x
) a
left join MDoutput.[dbo].[外部預算達成率FYF] b on b.年度=datepart(yy,@t) and b.月份=left(a.月份,2) and b.部門=a.部門
order by a.月份, case when a.部門='金融交易處' then 0 when a.部門='衍商' then 1 when a.部門='計交' then 2 when a.部門='債券' then 3 when a.部門='自營' then 4  end




drop table #temp
drop table #cognos
drop table #PreCIO
drop table #CIO
