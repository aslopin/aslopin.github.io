USE PL;
GO

SELECT name
FROM sys.objects
WHERE type = 'P';

SELECT DISTINCT OBJECT_NAME(id) AS StoredProcName
FROM syscomments 
WHERE TEXT LIKE '%TheoData.dbo.HistoryVol%'

SELECT DISTINCT OBJECT_NAME(id) AS StoredProcName
FROM syscomments 
WHERE TEXT LIKE '%������_List%'

SELECT login_name, login_time
FROM sys.dm_exec_sessions
WHERE login_name = 'it'
order by login_time desc

SELECT *
FROM sys.dm_exec_sessions s
INNER JOIN sys.dm_exec_connections c ON s.session_id = c.session_id
CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) AS t
WHERE s.login_name = 'it'

SELECT *
FROM sys.dm_exec_sessions s
INNER JOIN sys.dm_exec_connections c ON s.session_id = c.session_id
CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) AS t
WHERE s.login_name = 'sa'
order by s.login_time desc

SELECT c.session_id, s.login_name, r.start_time, t.text
FROM sys.dm_exec_connections AS c
JOIN sys.dm_exec_sessions AS s ON c.session_id = s.session_id
JOIN sys.dm_exec_requests AS r ON c.connection_id = r.connection_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t
WHERE s.login_name = 'sa'

SELECT c.session_id, r.start_time, t.text,*
FROM sys.dm_exec_connections AS c
JOIN sys.dm_exec_requests AS r ON c.connection_id = r.connection_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t

SELECT *
FROM sys.dm_exec_connections AS c
order by c.session_id

SELECT *
FROM sys.dm_exec_connections AS c
CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) AS t

SELECT *
FROM sys.dm_exec_requests AS r

SELECT *
FROM sys.dm_exec_requests AS r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t

SELECT *
FROM sys.dm_exec_requests AS r
CROSS APPLY sys.dm_exec_sql_text(r.plan_handle) AS t

select *
from sys.dm_exec_sessions s
order by s.login_time

select *
from sys.dm_exec_sessions s
JOIN sys.dm_exec_requests AS r ON r.session_id = r.session_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t
order by s.last_request_start_time desc

SELECT c.session_id, c.connect_time, c.protocol_type, c.client_net_address, c.local_net_address, s.login_name, s.host_name, s.program_name
FROM sys.dm_exec_connections c
JOIN sys.dm_exec_sessions s ON c.session_id = s.session_id
ORDER BY c.connect_time DESC
