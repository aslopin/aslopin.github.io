select In_Time as �污�Ǹ�,max(Out_Time) as �ɶ�
,sum(case when cast(case when B1_Qty<>'' then B1_Qty end as decimal(20,4))>=100
            or cast(case when B1_Qty<>'' then B1_Qty end as decimal(20,4))*cast(case when B1_price<>'' then B1_price end as decimal(20,4))>100000
			 then 1. else 0 end)
 as �j���ɼ�
,sum(1.)
 as �`�ɼ�
from Tick.[dbo].[tbl_Tick_Today_snapshot](Nolock) a
join dbmain.dbo.WarrantProfileTS b on b.WarrantID=a.StockId
where In_Time>='62' and In_Time not like '_' or In_Time like '___' 
group by In_Time
order by max(Out_Time)

select a.*
from Tick.[dbo].[tbl_Tick_Today_snapshot](Nolock) a
join dbmain.dbo.WarrantProfileTS b on b.WarrantID=a.StockId
where In_Time='125'
order by cast(case when B1_Qty<>'' then B1_Qty end as decimal(20,4))


select a.*
from Tick.[dbo].[tbl_Tick_Today_snapshot](Nolock) a
join dbmain.dbo.WarrantProfileTS b on b.WarrantID=a.StockId
where a.StockID='035103'
order by Out_Time