declare @t date = '2020/1/10'--(select max(TxDate) from pl.dbo.����B�J���_MD)  
declare @hy datetime =DBMain.dbo.tradingdateadd(-4,@t)
declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
declare @hy2 datetime =DBMain.dbo.tradingdateadd(-2,@hy)



declare @bondfloor TABLE ( bond_no nvarchar(50),DEALER_NO nvarchar(50) ,bondfloor decimal(20,4) )
insert @bondfloor
select e.bond_no,e.DEALER_NO,avg(e.bondfloor)
 from (
select a.BOND_NO,a.DEALER_NO,CASE WHEN rem_val<>0 then  isnull(bond_floor_mkt_price*100/rem_val,0) else 0 end as bondfloor from (
select  DEALER_NO,bond_no,sum(rem_val) as rem_val , sum(bond_floor_mkt_price) as bond_floor_mkt_price  from dbmain.[dbo].[CBAS_ASW_DAILY_NEWSYS] where work_date=@y /*and bond_no='32895' and DEALER_NO in ('697','605')*/ and rem_val<>0  
group by DEALER_NO,bond_no) as a 
union all
select a.BOND_NO,a.DEALER_NO,CASE WHEN rem_val<>0 then  isnull(bond_floor_mkt_price*100/rem_val,0) else 0 end as bondfloor from (
select  DEALER_NO,bond_no,sum(rem_val) as rem_val , sum(bond_floor_mkt_price) as bond_floor_mkt_price  from dbmain.[dbo].[CBAS_ASO_DAILY_NEWSYS] where work_date=@y /*and bond_no='32895' and DEALER_NO in ('697','605')*/ and rem_val<>0  
group by DEALER_NO,bond_no) as a ) as  e
group by e.bond_no,e.DEALER_NO


select xx.Acc,xx.CBID,xx.PRINCIPAL,yy.Predict_Price,bf.bondfloor
,case when yy.Predict_Price < bf.bondfloor then (yy.Predict_Price - bf.bondfloor) * xx.PRINCIPAL else 0 end as PL
from pl.dbo.CBASDailyPLReportMD_NEWSYS xx
left join (
	select  c.���,a.�N��,a.Beta ,c.���L��,(1+b.TW_Ret*a.Beta)*c.���L�� as Predict_Price
	from (
		SELECT x.�N��--,(Avg(x.TW_RET * x.CB_RET) - (Avg(x.TW_RET) * Avg(x.CB_RET))) / (StDevP(x.TW_RET) * StDevP(x.CB_RET)) as Pearsons1
		,case when (SQRT(SUM(x.TW_RET * x.TW_RET) - (SUM(x.TW_RET) * SUM (x.TW_RET)) / COUNT(*) ) * SQRT(SUM(x.CB_RET * x.CB_RET)  - (SUM(x.CB_RET) * SUM(x.CB_RET)) / COUNT(*)))<>0 then
		((SUM(x.TW_RET * x.CB_RET) - (SUM(x.TW_RET) * SUM(x.CB_RET)) / COUNT(*))) / (SQRT(SUM(x.TW_RET * x.TW_RET) - (SUM(x.TW_RET) * SUM (x.TW_RET)) / COUNT(*) ) * SQRT(SUM(x.CB_RET * x.CB_RET)  - (SUM(x.CB_RET) * SUM(x.CB_RET)) / COUNT(*)) ) end AS Beta
		from (
			select a.���,a.�N��,a.�W��,a.���L��,a.���L��/lag(a.���L��) over (partition by a.�N�� order by a.���)-1 as CB_RET
			,b.�Ѳ��N��,b.���L��/lag(b.���L��) over (partition by a.�N�� order by a.���)-1 as TW_RET 
			from cmoney.dbo.�i�ऽ�q�Ŧ��L a
			left join cmoney.dbo.�馬�L���Ʀ� b on a.��� = b.��� and b.�Ѳ��N��  = 'TWA02'
			where a.��� between @hy2 and @y  --and a.�N�� <> '15302'
		) x 
	    group by x.�N��
	    having(count(*) > 1 and sum(x.CB_RET) <> 0)
   ) a
   join cmoney.dbo.�i�ऽ�q�Ŧ��L c on c.�N�� = a.�N�� and c.��� = @y
) yy on xx.TxDate = yy.��� and xx.CBID = yy.�N��
left join @bondfloor bf on bf.bond_no = xx.CBID and bf.DEALER_NO =  xx.acc
 where xx.ID like '%BI%' and xx.Txdate = @y
