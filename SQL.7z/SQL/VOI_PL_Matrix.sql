declare @t datetime set @t='2018/7/12'
declare @b datetime set @b=dbmain.dbo.tradingdateadd(-5,@t)

create table #VOI(TxDate datetime,StockID nvarchar(50),BTime nvarchar(50),ETime nvarchar(50)
                  ,BTime01 nvarchar(50),BTime02 nvarchar(50),BTime03 nvarchar(50),BTime04 nvarchar(50)
                  ,DeltaVBt decimal(20,6),DeltaVAt decimal(20,6),VOI decimal(20,6),B1_Price decimal(20,6),A1_Price decimal(20,6))
insert #VOI
select TxDate,StockID,BTime,ETime
,DBMain.dbo.[TimeAdd](BTime,60)
,DBMain.dbo.[TimeAdd](BTime,120)
,DBMain.dbo.[TimeAdd](BTime,180)
,DBMain.dbo.[TimeAdd](BTime,240)
,case when B1_Price<lag(B1_Price) over(partition by TxDate,StockID order by BTime) then 0
		when B1_Price=lag(B1_Price) over(partition by TxDate,StockID order by BTime) then B1_Qty-lag(B1_Qty) over(partition by TxDate,StockID order by BTime)
		when B1_Price>lag(B1_Price) over(partition by TxDate,StockID order by BTime) then B1_Qty
		end
as DeltaVBt

,case when A1_Price<lag(A1_Price) over(partition by TxDate,StockID order by BTime) then A1_Qty
		when A1_Price=lag(A1_Price) over(partition by TxDate,StockID order by BTime) then A1_Qty-lag(A1_Qty) over(partition by TxDate,StockID order by BTime)
		when A1_Price>lag(A1_Price) over(partition by TxDate,StockID order by BTime) then 0
		end
as DeltaVAt
       
,case when B1_Price<lag(B1_Price) over(partition by TxDate,StockID order by BTime) then 0
		when B1_Price=lag(B1_Price) over(partition by TxDate,StockID order by BTime) then B1_Qty-lag(B1_Qty) over(partition by TxDate,StockID order by BTime)
		when B1_Price>lag(B1_Price) over(partition by TxDate,StockID order by BTime) then B1_Qty
		end
-case when A1_Price<lag(A1_Price) over(partition by TxDate,StockID order by BTime) then A1_Qty
		when A1_Price=lag(A1_Price) over(partition by TxDate,StockID order by BTime) then A1_Qty-lag(A1_Qty) over(partition by TxDate,StockID order by BTime)
		when A1_Price>lag(A1_Price) over(partition by TxDate,StockID order by BTime) then 0
		end
as VOI
,B1_Price,A1_Price
from db2.[Intraday].[dbo].[DailyTick_Underlying]
where TxDate=@t 
--and [Stockid]='2454'
--order by BTime

delete db2.intraday.[dbo].[VOI_PL_Matrix] where TxDate=@t
insert db2.intraday.[dbo].[VOI_PL_Matrix]
select @t as TxDate,a.StockID,'>5Std' as Tag
,sum(case when a.VOI>5*Std then c01.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret01
,sum(case when a.VOI>5*Std then c02.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret02
,sum(case when a.VOI>5*Std then c03.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret03
,sum(case when a.VOI>5*Std then c04.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret04
from #VOI a
left join (
	select StockID,avg(VOIstd) as Std
	from db2.intraday.[dbo].[VOIDaily]
	where TxDate>=@b and txdate<@t
	group by StockID
) b on b.StockID=a.StockID
left join #VOI c01 on c01.StockID=a.StockID and a.BTime01 between c01.Btime and c01.etime
left join #VOI c02 on c02.StockID=a.StockID and a.BTime02 between c02.Btime and c02.etime
left join #VOI c03 on c03.StockID=a.StockID and a.BTime03 between c03.Btime and c03.etime
left join #VOI c04 on c04.StockID=a.StockID and a.BTime04 between c04.Btime and c04.etime
where a.BTime between '09000000' and '13250000'  and a.VOI>5*Std
group by a.StockID

insert db2.intraday.[dbo].[VOI_PL_Matrix]
select @t as TxDate,a.StockID,'>6Std' as Tag
,sum(case when a.VOI>6*Std then c01.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret01
,sum(case when a.VOI>6*Std then c02.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret02
,sum(case when a.VOI>6*Std then c03.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret03
,sum(case when a.VOI>6*Std then c04.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret04
from #VOI a
left join (
	select StockID,avg(VOIstd) as Std
	from db2.intraday.[dbo].[VOIDaily]
	where TxDate>=@b and txdate<@t
	group by StockID
) b on b.StockID=a.StockID
left join #VOI c01 on c01.StockID=a.StockID and a.BTime01 between c01.Btime and c01.etime
left join #VOI c02 on c02.StockID=a.StockID and a.BTime02 between c02.Btime and c02.etime
left join #VOI c03 on c03.StockID=a.StockID and a.BTime03 between c03.Btime and c03.etime
left join #VOI c04 on c04.StockID=a.StockID and a.BTime04 between c04.Btime and c04.etime
where a.BTime between '09000000' and '13250000'  and a.VOI>6*Std
group by a.StockID

insert db2.intraday.[dbo].[VOI_PL_Matrix]
select @t as TxDate,a.StockID,'>7Std' as Tag
,sum(case when a.VOI>7*Std then c01.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret01
,sum(case when a.VOI>7*Std then c02.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret02
,sum(case when a.VOI>7*Std then c03.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret03
,sum(case when a.VOI>7*Std then c04.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret04
from #VOI a
left join (
	select StockID,avg(VOIstd) as Std
	from db2.intraday.[dbo].[VOIDaily]
	where TxDate>=@b and txdate<@t
	group by StockID
) b on b.StockID=a.StockID
left join #VOI c01 on c01.StockID=a.StockID and a.BTime01 between c01.Btime and c01.etime
left join #VOI c02 on c02.StockID=a.StockID and a.BTime02 between c02.Btime and c02.etime
left join #VOI c03 on c03.StockID=a.StockID and a.BTime03 between c03.Btime and c03.etime
left join #VOI c04 on c04.StockID=a.StockID and a.BTime04 between c04.Btime and c04.etime
where a.BTime between '09000000' and '13250000'  and a.VOI>7*Std
group by a.StockID

insert db2.intraday.[dbo].[VOI_PL_Matrix]
select @t as TxDate,a.StockID,'>8Std' as Tag
,sum(case when a.VOI>8*Std then c01.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret01
,sum(case when a.VOI>8*Std then c02.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret02
,sum(case when a.VOI>8*Std then c03.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret03
,sum(case when a.VOI>8*Std then c04.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret04
from #VOI a
left join (
	select StockID,avg(VOIstd) as Std
	from db2.intraday.[dbo].[VOIDaily]
	where TxDate>=@b and txdate<@t
	group by StockID
) b on b.StockID=a.StockID
left join #VOI c01 on c01.StockID=a.StockID and a.BTime01 between c01.Btime and c01.etime
left join #VOI c02 on c02.StockID=a.StockID and a.BTime02 between c02.Btime and c02.etime
left join #VOI c03 on c03.StockID=a.StockID and a.BTime03 between c03.Btime and c03.etime
left join #VOI c04 on c04.StockID=a.StockID and a.BTime04 between c04.Btime and c04.etime
where a.BTime between '09000000' and '13250000'  and a.VOI>8*Std
group by a.StockID

insert db2.intraday.[dbo].[VOI_PL_Matrix]
select @t as TxDate,a.StockID,'>9Std' as Tag
,sum(case when a.VOI>9*Std then c01.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret01
,sum(case when a.VOI>9*Std then c02.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret02
,sum(case when a.VOI>9*Std then c03.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret03
,sum(case when a.VOI>9*Std then c04.B1_Price/a.A1_Price-1-0.002 else 0 end) as Ret04
from #VOI a
left join (
	select StockID,avg(VOIstd) as Std
	from db2.intraday.[dbo].[VOIDaily]
	where TxDate>=@b and txdate<@t
	group by StockID
) b on b.StockID=a.StockID
left join #VOI c01 on c01.StockID=a.StockID and a.BTime01 between c01.Btime and c01.etime
left join #VOI c02 on c02.StockID=a.StockID and a.BTime02 between c02.Btime and c02.etime
left join #VOI c03 on c03.StockID=a.StockID and a.BTime03 between c03.Btime and c03.etime
left join #VOI c04 on c04.StockID=a.StockID and a.BTime04 between c04.Btime and c04.etime
where a.BTime between '09000000' and '13250000'  and a.VOI>9*Std
group by a.StockID

drop table #VOI

