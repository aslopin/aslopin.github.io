USE [msdb]
GO

/****** Object:  Job [BAK tempdb]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK tempdb', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [shrinktempdb]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'shrinktempdb', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use tempdb
go

dbcc shrinkfile(tempdev, 10000)
go

dbcc shrinkfile(templog, 100)
go', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'shrinktempdb', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181123, 
		@active_end_date=99991231, 
		@active_start_time=2000, 
		@active_end_time=235959, 
		@schedule_uid=N'7ddbbd4b-ca90-4ace-a64b-b62ebe006d2e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [BAK_Cmoney]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK_Cmoney', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_Cmoney]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_Cmoney', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
BACKUP DATABASE [Cmoney] TO  DISK = N''E:\MSSQLBAK\Cmoney.bak'' WITH NOFORMAT, INIT,  
NAME = N''Cmoney'', SKIP, REWIND, NOUNLOAD,  STATS = 10
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BAK_Cmoney', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181124, 
		@active_end_date=99991231, 
		@active_start_time=2100, 
		@active_end_time=235959, 
		@schedule_uid=N'1bd9568d-93c5-4a8c-8035-18ff7a5b60cb'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [BAK_Intraday]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK_Intraday', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_Intraday]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_Intraday', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BACKUP DATABASE [Intraday] TO  DISK = N''E:\MSSQLBAK\Intraday.bak'' WITH NOFORMAT, INIT,  
NAME = N''Intraday'', SKIP, REWIND, NOUNLOAD,  STATS = 10
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BAK_Intraday', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181124, 
		@active_end_date=99991231, 
		@active_start_time=2200, 
		@active_end_time=235959, 
		@schedule_uid=N'f7600138-3b8a-4cc8-9fb9-065b492b6c6a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [BAK_other]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK_other', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tradingdate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_msdb]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_msdb', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use msdb
BACKUP DATABASE [msdb] TO  DISK = N''E:\MSSQLBAK\msdb.bak'' WITH NOFORMAT, INIT,  
NAME = N''msdb'', SKIP, REWIND, NOUNLOAD,  STATS = 10', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_other]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_other', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
BACKUP DATABASE [Accounting] TO  DISK = N''E:\MSSQLBAK\Accounting.bak'' WITH NOFORMAT, INIT,  
NAME = N''Accounting'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [ATP] TO  DISK = N''E:\MSSQLBAK\ATP.bak'' WITH NOFORMAT, INIT,  
NAME = N''ATP'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [CB] TO  DISK = N''E:\MSSQLBAK\CB.bak'' WITH NOFORMAT, INIT,  
NAME = N''CB'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Credit] TO  DISK = N''E:\MSSQLBAK\Credit.bak'' WITH NOFORMAT, INIT,  
NAME = N''Credit'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [DailyInsert] TO  DISK = N''E:\MSSQLBAK\DailyInsert.bak'' WITH NOFORMAT, INIT,  
NAME = N''DailyInsert'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [DBMain] TO  DISK = N''E:\MSSQLBAK\DBMain.bak'' WITH NOFORMAT, INIT,  
NAME = N''DBMain'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [DBMonitor] TO  DISK = N''E:\MSSQLBAK\DBMonitor.bak'' WITH NOFORMAT, INIT,  
NAME = N''DBMonitor'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [FrontDeskW] TO  DISK = N''E:\MSSQLBAK\FrontDeskW.bak'' WITH NOFORMAT, INIT,  
NAME = N''FrontDeskW'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Hubert] TO  DISK = N''E:\MSSQLBAK\Hubert.bak'' WITH NOFORMAT, INIT,  
NAME = N''Hubert'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [IDDataTransfer] TO  DISK = N''E:\MSSQLBAK\IDDataTransfer.bak'' WITH NOFORMAT, INIT,  
NAME = N''IDDataTransfer'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [LoginDefault] TO  DISK = N''E:\MSSQLBAK\LoginDefault.bak'' WITH NOFORMAT, INIT,  
NAME = N''LoginDefault'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [MarketData] TO  DISK = N''E:\MSSQLBAK\MarketData.bak'' WITH NOFORMAT, INIT,  
NAME = N''MarketData'', SKIP, REWIND, NOUNLOAD,  STATS = 10
 
BACKUP DATABASE [MDoutput] TO  DISK = N''E:\MSSQLBAK\MDoutput.bak'' WITH NOFORMAT, INIT,  
NAME = N''MDoutput'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Monitor] TO  DISK = N''E:\MSSQLBAK\Monitor.bak'' WITH NOFORMAT, INIT,  
NAME = N''Monitor'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Myproject] TO  DISK = N''E:\MSSQLBAK\Myproject.bak'' WITH NOFORMAT, INIT,  
NAME = N''Myproject'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [OperationDesk] TO  DISK = N''E:\MSSQLBAK\OperationDesk.bak'' WITH NOFORMAT, INIT,  
NAME = N''OperationDesk'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [OTC] TO  DISK = N''E:\MSSQLBAK\OTC.bak'' WITH NOFORMAT, INIT,  
NAME = N''OTC'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [TestDB] TO  DISK = N''E:\MSSQLBAK\TestDB.bak'' WITH NOFORMAT, INIT,  
NAME = N''TestDB'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [TestErik] TO  DISK = N''E:\MSSQLBAK\TestErik.bak'' WITH NOFORMAT, INIT,  
NAME = N''TestErik'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [TestSherlock] TO  DISK = N''E:\MSSQLBAK\TestSherlock.bak'' WITH NOFORMAT, INIT,  
NAME = N''TestSherlock'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Ronald] TO  DISK = N''E:\MSSQLBAK\Ronald.bak'' WITH NOFORMAT, INIT,  
NAME = N''Ronald'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [TheoData] TO  DISK = N''E:\MSSQLBAK\TheoData.bak'' WITH NOFORMAT, INIT,  
NAME = N''TheoData'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Tick] TO  DISK = N''E:\MSSQLBAK\Tick.bak'' WITH NOFORMAT, INIT,  
NAME = N''Tick'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Vix] TO  DISK = N''E:\MSSQLBAK\Vix.bak'' WITH NOFORMAT, INIT,  
NAME = N''Vix'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Web] TO  DISK = N''E:\MSSQLBAK\Web.bak'' WITH NOFORMAT, INIT,  
NAME = N''Web'', SKIP, REWIND, NOUNLOAD,  STATS = 10

BACKUP DATABASE [Ray] TO  DISK = N''E:\MSSQLBAK\Ray.bak'' WITH NOFORMAT, INIT,  
NAME = N''Ray'', SKIP, REWIND, NOUNLOAD,  STATS = 10', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BAK_other', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181124, 
		@active_end_date=99991231, 
		@active_start_time=2300, 
		@active_end_time=235959, 
		@schedule_uid=N'a55ebcd1-0105-4f2f-8c46-0186a0a7fea7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [BAK_PL]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK_PL', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_PL]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_PL', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BACKUP DATABASE [PL] TO  DISK = N''E:\MSSQLBAK\PL.bak'' WITH NOFORMAT, INIT,  
NAME = N''PL'', SKIP, REWIND, NOUNLOAD,  STATS = 10

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BAK_PL', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181124, 
		@active_end_date=99991231, 
		@active_start_time=2400, 
		@active_end_time=235959, 
		@schedule_uid=N'bf7fd64e-8e51-42b3-a628-5b6b261debfe'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [BAK_Pro_Z]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK_Pro_Z', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [tradingdate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'tradingdate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_Pro_Z]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_Pro_Z', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BACKUP DATABASE [Pro] TO  DISK = N''E:\MSSQLBAK\Pro.bak'' WITH NOFORMAT, INIT,  
NAME = N''Pro'', SKIP, REWIND, NOUNLOAD,  STATS = 10
 
BACKUP DATABASE [Z] TO  DISK = N''E:\MSSQLBAK\Z.bak'' WITH NOFORMAT, INIT,  
NAME = N''Z'', SKIP, REWIND, NOUNLOAD,  STATS = 10
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BAK_Pro_Z', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181124, 
		@active_end_date=99991231, 
		@active_start_time=2500, 
		@active_end_time=235959, 
		@schedule_uid=N'961a6f19-2b5a-475c-9588-4c565b02bcee'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [BAK_TestPA_TradeDB]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BAK_TestPA_TradeDB', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'�S���i�Ϊ��y�z�C', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'tsftd', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TradingDate]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TradingDate', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1/count(*) from dbmain.dbo.tradingdate where tradingdate = convert(date, getdate())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BAK_TestPA_TradeDB]    Script Date: 2019/5/15 �W�� 09:17:06 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BAK_TestPA_TradeDB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
BACKUP DATABASE [TestPA] TO  DISK = N''E:\MSSQLBAK\TestPA.bak'' WITH NOFORMAT, INIT,  
NAME = N''TestPA'', SKIP, REWIND, NOUNLOAD,  STATS = 10

 
BACKUP DATABASE [Trade_DB] TO  DISK = N''E:\MSSQLBAK\Trade_DB.bak'' WITH NOFORMAT, INIT,  
NAME = N''Trade_DB'', SKIP, REWIND, NOUNLOAD,  STATS = 10
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BAK_TestPA_TradeDB', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20181124, 
		@active_end_date=99991231, 
		@active_start_time=2600, 
		@active_end_time=235959, 
		@schedule_uid=N'6f8c067c-3f97-4291-92d6-961a8ae0f53f'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


