declare @day int set @day=-5

CREATE TABLE #temp_deal(
	[Txdate] [datetime] NULL,
	[Txtime] [nvarchar](20) NULL,
	[Portfolio] [nvarchar](20) NULL,
	[Acc] [nvarchar](20) NULL,
	[Trader] [nvarchar](20) NULL,
	[StockID] [nvarchar](20) NULL,
	[Type] [nvarchar](20) NULL,
	[Bvolume] [decimal](20, 5) NULL,
	[SVolume] [decimal](20, 5) NULL,
	[DealVolume] [decimal](20, 5) NULL,
	[DealAmt] [decimal](20, 5) NULL,
	[Tag] [nvarchar](50) NULL,
	[Tax] [decimal](20, 5) NULL,
	[Fee] [decimal](20, 5) NULL
)
insert #temp_deal
select a.[Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
from PL.[dbo].[Deallist_�l�Ӧ���_����] a
join cb.dbo.cbdata b on b.TxDate=a.TxDate and b.�i��ťN�X=a.StockID
where a.TxDate>='2023/1/1'

insert #temp_deal
select a.[Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
from PL.[dbo].[Deallist_�Ũ�_����] a
join cb.dbo.cbdata b on b.TxDate=a.TxDate and b.�i��ťN�X=a.StockID
where a.TxDate>='2023/1/1'

select format(a.TxDate,'yyyyMM') as YM,a.Trader,a.Portfolio,sum(a.�l�q) as �l�q
from(
	select *,iif(abs(Bvolume)>abs(Svolume),abs(Svolume),abs(Bvolume))*(�槡��-�R����) as �l�q 
	from (
		select *,d.�R�i��O/d.Bvolume as �R���� 
		from (
			 select c.txdate,c.Portfolio,c.Acc,c.Trader,c.StockID,c.[type],c.Svolume,c.Dealamt,c.�槡��,sum(Bvolume) Bvolume ,sum(�R�i��O) �R�i��O 
			 from (
				   select a.*,b.txdate as �R�i��,b.Bvolume,b.Dealamt as �R�i��O 
				   from (
						select txdate,Portfolio,Acc,Trader,StockID,[type],sum(Svolume) Svolume,sum(Dealamt) Dealamt,avg(Dealamt/Svolume) �槡��,DBMain.dbo.tradingdateadd(@day,txdate) as Edate  
						from #temp_deal    
						where Svolume<>0 and tag<>'CB TO Stock'    
						group by txdate,Portfolio,Acc,Trader,StockID,[type]    
				   ) as a     
				   left join (    
						select txdate,Portfolio,Acc,Trader,StockID,[type],sum(Bvolume) Bvolume,sum(Dealamt) Dealamt  
						from #temp_deal    
						where Bvolume<>0  and tag<>'CB TO Stock'    
						group by txdate,Portfolio,Acc,Trader,StockID,[type]    
				   ) as b on b.txdate between a.Edate and a.txdate  and a.Portfolio=b.Portfolio  and a.Acc=b.Acc and a.Trader=b.Trader and a.StockID=b.StockID and a.[type]=b.[type]     
				   where b.txdate is not null
			) as c    
			group by c.txdate,c.Portfolio,c.Acc,c.Trader,c.StockID,c.[type],c.Svolume,c.Dealamt,c.�槡��   
		) as d   
	) as e 
) a
group by format(a.TxDate,'yyyyMM'),a.Trader,a.Portfolio
order by format(a.TxDate,'yyyyMM'),a.Trader,a.Portfolio

select format(a.TxDate,'yyyyMM') as YM,a.Trader,a.Portfolio,a.StockID,sum(a.�l�q) as �l�q
from(
	select *,iif(abs(Bvolume)>abs(Svolume),abs(Svolume),abs(Bvolume))*(�槡��-�R����) as �l�q 
	from (
		select *,d.�R�i��O/d.Bvolume as �R���� 
		from (
			 select c.txdate,c.Portfolio,c.Acc,c.Trader,c.StockID,c.[type],c.Svolume,c.Dealamt,c.�槡��,sum(Bvolume) Bvolume ,sum(�R�i��O) �R�i��O 
			 from (
				   select a.*,b.txdate as �R�i��,b.Bvolume,b.Dealamt as �R�i��O 
				   from (
						select txdate,Portfolio,Acc,Trader,StockID,[type],sum(Svolume) Svolume,sum(Dealamt) Dealamt,avg(Dealamt/Svolume) �槡��,DBMain.dbo.tradingdateadd(@day,txdate) as Edate  
						from #temp_deal    
						where Svolume<>0 and tag<>'CB TO Stock'    
						group by txdate,Portfolio,Acc,Trader,StockID,[type]    
				   ) as a     
				   left join (    
						select txdate,Portfolio,Acc,Trader,StockID,[type],sum(Bvolume) Bvolume,sum(Dealamt) Dealamt  
						from #temp_deal    
						where Bvolume<>0  and tag<>'CB TO Stock'    
						group by txdate,Portfolio,Acc,Trader,StockID,[type]    
				   ) as b on b.txdate between a.Edate and a.txdate  and a.Portfolio=b.Portfolio  and a.Acc=b.Acc and a.Trader=b.Trader and a.StockID=b.StockID and a.[type]=b.[type]     
				   where b.txdate is not null
			) as c    
			group by c.txdate,c.Portfolio,c.Acc,c.Trader,c.StockID,c.[type],c.Svolume,c.Dealamt,c.�槡��   
		) as d   
	) as e 
) a
group by format(a.TxDate,'yyyyMM'),a.Trader,a.Portfolio,a.StockID
order by format(a.TxDate,'yyyyMM'),a.Trader,a.Portfolio,sum(a.�l�q)

select *,iif(abs(Bvolume)>abs(Svolume),abs(Svolume),abs(Bvolume))*(�槡��-�R����) as �l�q 
from (
    select *,d.�R�i��O/d.Bvolume as �R���� 
	from (
	     select c.txdate,c.Portfolio,c.Acc,c.Trader,c.StockID,c.[type],c.Svolume,c.Dealamt,c.�槡��,sum(Bvolume) Bvolume ,sum(�R�i��O) �R�i��O 
		 from (
		       select a.*,b.txdate as �R�i��,b.Bvolume,b.Dealamt as �R�i��O 
			   from (
			        select txdate,Portfolio,Acc,Trader,StockID,[type],sum(Svolume) Svolume,sum(Dealamt) Dealamt,avg(Dealamt/Svolume) �槡��,DBMain.dbo.tradingdateadd(@day,txdate) as Edate  
					from #temp_deal    
					where Svolume<>0 and tag<>'CB TO Stock'    
					group by txdate,Portfolio,Acc,Trader,StockID,[type]    
			   ) as a     
			   left join (    
			        select txdate,Portfolio,Acc,Trader,StockID,[type],sum(Bvolume) Bvolume,sum(Dealamt) Dealamt  
					from #temp_deal    
					where Bvolume<>0  and tag<>'CB TO Stock'    
					group by txdate,Portfolio,Acc,Trader,StockID,[type]    
			   ) as b on b.txdate between a.Edate and a.txdate  and a.Portfolio=b.Portfolio  and a.Acc=b.Acc and a.Trader=b.Trader and a.StockID=b.StockID and a.[type]=b.[type]     
			   where b.txdate is not null
	    ) as c    
		group by c.txdate,c.Portfolio,c.Acc,c.Trader,c.StockID,c.[type],c.Svolume,c.Dealamt,c.�槡��   
	) as d   
) as e 



drop TABLE #temp_deal



/*
select a.[Txdate], [Txtime], [Portfolio], [Acc], [Trader], [StockID], [Type], [Bvolume], [SVolume], [DealVolume], [DealAmt], [Tag], [Tax], [Fee]
from PL.[dbo].[Deallist_�l�Ӧ���_����] a
join cb.dbo.cbdata b on b.TxDate=a.TxDate and b.�i��ťN�X=a.StockID
where a.TxDate>='2023/1/1' and a.StockID='35913'
order by a.[Txdate], [Txtime]


SELECT [Txdate]
      ,[CBID]
      ,[CBName]
      ,[�W�g�i��]
      ,[�W�g����Moneyness]
      ,[���T(%)]
      ,[�v��]
  FROM [FrontDeskW].[dbo].[CBIndex�W�g����q�z��²�業��_MN50]
  where CBID='35913'
  order by [Txdate] desc
*/