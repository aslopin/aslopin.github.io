select Txdate as 日期,b.股票代號+'_'+b.股票名稱 as [ETF],a.會計_Delta as [ETF市值],b.標的代號,b.標的名稱,b.[權重(%)],a.會計_Delta*b.[權重(%)]/100. as 標的市值
from pl.dbo.DailyPLReport_衍商自營_日曆日 a
join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/7/20'
where txdate='2022/7/21' and acc in ('711','713','351','715') and volume<>0 and stockid not like '%R%' and stockid not like '%L%'  and stockid not like '%U%'  and (標的名稱 like '%地%' or 標的名稱 like '%房%')


select Txdate as 日期,b.股票代號+'_'+b.股票名稱 as [ETF],a.會計_Delta as [ETF市值],b.標的代號,b.標的名稱,b.[權重(%)],a.會計_Delta*b.[權重(%)]/100. as 標的市值
from pl.dbo.DailyPLReport_衍商自營_日曆日 a
join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/7/20' and b.標的代號 like '%CH'
join cmoney.[dbo].[陸股公司基本資料Temp] c on c.代號=left(b.標的代號,6) and c.[證監會行業一級分類名稱] like '%房地%'
where txdate='2022/7/21' and acc in ('711','713','351','715') and volume<>0 

select Txdate as 日期,b.股票代號+'_'+b.股票名稱 as [ETF],a.會計_Delta as [ETF市值],b.標的代號,b.標的名稱,b.[權重(%)],a.會計_Delta*b.[權重(%)]/100. as 標的市值
from pl.dbo.DailyPLReport_衍商自營_日曆日 a
join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/7/20' and b.標的代號 like '%HK'
join cmoney.[dbo].[港股上市公司基本資料] c on c.[年度]='2022' and c.[名稱]=b.標的名稱 and (c.[產業名稱] like '%地產%')
where txdate='2022/7/21' and acc in ('711','713','351','715') and volume<>0 
order by b.股票代號,b.標的代號

select Txdate,stockid,volume, 會計_Delta,b.*
from pl.dbo.DailyPLReport_債券_日曆日 a
left join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/7/20'
where txdate='2022/7/21' and volume<>0 and stockid not like '%R%' and stockid not like '%L%'  and stockid not like '%U%'  and (標的名稱 like '%地%' or 標的名稱 like '%房%')


select Txdate,stockid,volume, 會計_Delta,b.*
from pl.dbo.DailyPLReport_債券_日曆日 a
left join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/7/20'
join cmoney.[dbo].[陸股公司基本資料Temp] c on c.代號=left(b.標的代號,6) and c.[證監會行業一級分類名稱] like '%房地%'
where txdate='2022/7/21' and volume<>0




select Txdate as 日期,b.股票代號+'_'+b.股票名稱 as [ETF],a.會計_Delta as [ETF市值],b.標的代號,b.標的名稱,b.[權重(%)],a.會計_Delta*b.[權重(%)]/100. as 標的市值
from pl.dbo.DailyPLReport_衍商自營_日曆日 a
join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/8/8'
where txdate='2022/8/9' and acc in ('711','713','351','715') and volume<>0 and stockid not like '%R%' and stockid not like '%L%'  and stockid not like '%U%'  and (標的名稱 like '%地%' or 標的名稱 like '%房%')
order by b.股票代號,b.標的代號

select Txdate as 日期,b.股票代號+'_'+b.股票名稱 as [ETF],a.會計_Delta as [ETF市值],b.標的代號,b.標的名稱,b.[權重(%)],a.會計_Delta*b.[權重(%)]/100. as 標的市值
from pl.dbo.DailyPLReport_衍商自營_日曆日 a
join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/8/8' and b.標的代號 like '%CH'
join cmoney.[dbo].[陸股公司基本資料Temp] c on c.代號=left(b.標的代號,6) and c.[證監會行業一級分類名稱] like '%房地%'
where txdate='2022/8/9' and acc in ('711','713','351','715') and volume<>0 
order by b.股票代號,b.標的代號

select Txdate as 日期,b.股票代號+'_'+b.股票名稱 as [ETF],a.會計_Delta as [ETF市值],b.標的代號,b.標的名稱,b.[權重(%)],a.會計_Delta*b.[權重(%)]/100. as 標的市值
from pl.dbo.DailyPLReport_衍商自營_日曆日 a
join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/8/8' and b.標的代號 like '%HK'
join cmoney.[dbo].[港股上市公司基本資料] c on c.[年度]='2022' and c.[名稱]=b.標的名稱 and (c.[產業名稱] like '%地產%')
where txdate='2022/8/9' and acc in ('711','713','351','715') and volume<>0 
order by b.股票代號,b.標的代號

select Txdate,stockid,volume, 會計_Delta,b.*
from pl.dbo.DailyPLReport_債券_日曆日 a
left join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/8/8'
where txdate='2022/8/9' and volume<>0 and stockid not like '%R%' and stockid not like '%L%'  and stockid not like '%U%'  and (標的名稱 like '%地%' or 標的名稱 like '%房%')


select Txdate,stockid,volume, 會計_Delta,b.*
from pl.dbo.DailyPLReport_債券_日曆日 a
left join cmoney.dbo.ETF持股明細表 b on b.股票代號=a.StockID and 日期='2022/8/8'
join cmoney.[dbo].[陸股公司基本資料Temp] c on c.代號=left(b.標的代號,6) and c.[證監會行業一級分類名稱] like '%房地%'
where txdate='2022/8/9' and volume<>0
