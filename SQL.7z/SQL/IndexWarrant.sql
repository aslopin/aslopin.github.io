
declare @Inventory table(TxDate datetime,Portfolio nvarchar(50),StockID nvarchar(50),Cost decimal(20,6),Volume decimal(20,6),Tax decimal(20,6),Fee decimal(20,6),TheoP decimal(20,6))
insert @Inventory
select a.Stadate as TxDate,a.Portfolio,a.StockID
,a.Cost,a.Volume,a.Tax,a.Fee
,theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����, c.PricingVol, c.r, a.StockID, c.Exer)
 as TheoP
from pl.dbo.inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.stadate and b.WarrantKey=a.portfolio and b.StockID='TWA00'
join pro.dbo.�v�ҵ������ c on c.Txdate=a.Stadate and c.WarrantID=a.StockID
left join cmoney.dbo.���f����污�� d on d.���=a.Stadate and d.�N��='TX201707'
where a.Stadate>='2017/6/3'

insert @Inventory
select a.Stadate as TxDate,a.Portfolio,a.StockID
,a.Cost,a.Volume*a.Delta,a.Tax,a.Fee
,a.LastPrice
from pl.dbo.inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.stadate and b.WarrantKey=a.portfolio and b.StockID='TWA00'
where a.Stadate>='2017/6/3'
and a.stockid not like '[0]_____'

select a.StockID,a.Volume
*(theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, 0, c.PricingVol, c.r, a.StockID, c.Exer)
 -theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����, c.PricingVol, c.r, a.StockID, c.Exer)
 )
 as PL
 ,theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, 0, c.PricingVol, c.r, a.StockID, c.Exer)
 ,theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����, c.PricingVol, c.r, a.StockID, c.Exer)
 ,d.�����, c.Strike, c.Barrier, 0, c.PricingVol, c.r, a.StockID, c.Exer
from pl.dbo.inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.stadate and b.WarrantKey=a.portfolio and b.StockID='TWA00'
join pro.dbo.�v�ҵ������ c on c.Txdate=a.Stadate and c.WarrantID=a.StockID
left join cmoney.dbo.���f����污�� d on d.���=a.Stadate and d.�N��='TX201707'
where a.Stadate='2017/6/9'
and a.Volume<>0
group by a.StockID

select sum(a.Volume
*(theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, 0, c.PricingVol, c.r, a.StockID, c.Exer)
 -theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����, c.PricingVol, c.r, a.StockID, c.Exer)
 ))
 as PL
from pl.dbo.inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.stadate and b.WarrantKey=a.portfolio and b.StockID='TWA00'
join pro.dbo.�v�ҵ������ c on c.Txdate=a.Stadate and c.WarrantID=a.StockID
left join cmoney.dbo.���f����污�� d on d.���=a.Stadate and d.�N��='TX201707'
where a.Stadate='2017/6/9'
and a.Volume<>0

select sum(a.Volume
*(theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����-1/252., c.PricingVol, c.r, a.StockID, c.Exer)
 -theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����, c.PricingVol, c.r, a.StockID, c.Exer)
 ))
 as PL
from pl.dbo.inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.stadate and b.WarrantKey=a.portfolio and b.StockID='TWA00'
join pro.dbo.�v�ҵ������ c on c.Txdate=a.Stadate and c.WarrantID=a.StockID
left join cmoney.dbo.���f����污�� d on d.���=a.Stadate and d.�N��='TX201707'
where a.Stadate='2017/6/5'
and a.Volume<>0


select a.Txdate
,sum(
 (isnull(a.TheoP,0)*isnull(a.Volume,0)-isnull(a.Cost,0))
-(isnull(a2.TheoP,0)*isnull(a2.Volume,0)-isnull(a2.Cost,0))
 )
+sum(
 -1*(isnull(a.tax,0)-isnull(a2.tax,0))
 )
+sum(
 -1*(isnull(a.fee,0)-isnull(a2.fee,0))
 )
 as NetPL
,sum(
 (isnull(a.TheoP,0)*isnull(a.Volume,0)-isnull(a.Cost,0))
-(isnull(a2.TheoP,0)*isnull(a2.Volume,0)-isnull(a2.Cost,0))
 )
 as PL
,sum(
 -1*(isnull(a.tax,0)-isnull(a2.tax,0))
 )
 as Tax
,sum(
 -1*(isnull(a.fee,0)-isnull(a2.fee,0))
 )
 as Fee
from @Inventory a
join dbmain.dbo.tradingdate tr on tr.tradingdate=a.txdate
join dbmain.dbo.tradingdate tr2 on tr2.Ser+1=tr.ser
left join @Inventory a2 on a2.TxDate=tr2.Tradingdate and a2.portfolio=a.portfolio and a2.StockID=a.StockID
where a.txdate>='2017/6/5'
group by a.txdate
order by a.txdate

select a.Txdate,a.Portfolio,a.StockID
,(isnull(a.TheoP,0)*isnull(a.Volume,0)-isnull(a.Cost,0))
-(isnull(a2.TheoP,0)*isnull(a2.Volume,0)-isnull(a2.Cost,0))
 as PL
,-1*(isnull(a.tax,0)-isnull(a2.tax,0))
 as Tax
,-1*(isnull(a.fee,0)-isnull(a2.fee,0))
 as Fee
from @Inventory a
join dbmain.dbo.tradingdate tr on tr.tradingdate=a.txdate
join dbmain.dbo.tradingdate tr2 on tr2.Ser+1=tr.ser
left join @Inventory a2 on a2.TxDate=tr2.Tradingdate and a2.portfolio=a.portfolio and a2.StockID=a.StockID
where a.txdate>='2017/6/5'
order by a.Txdate,a.StockID



select a.Stadate as TxDate,a.Portfolio,a.StockID
,a.Cost,a.Volume,a.Tax,a.Fee
,theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, c.T�����, c.PricingVol, c.r, a.StockID, c.Exer)
 as TheoP
,theodata.dbo.optvlu(d.�����, c.Strike, c.Barrier, 0, c.PricingVol, c.r, a.StockID, c.Exer)
 as ���[����
from pl.dbo.inventory a
join dbmain.dbo.WarrantProfileTS_Daily b on b.Txdate=a.stadate and b.WarrantKey=a.portfolio and b.StockID='TWA00'
join pro.dbo.�v�ҵ������ c on c.Txdate=a.Stadate and c.WarrantID=a.StockID
left join cmoney.dbo.���f����污�� d on d.���=a.Stadate and d.�N��='TX201707'
where a.Stadate='2017/6/9'
and a.Volume<>0
