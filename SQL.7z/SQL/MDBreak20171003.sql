USE [master]
GO

/****** Object:  DdlTrigger [tr_connection_limit_MD]    Script Date: 2017/10/3 �W�� 08:47:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




















alter TRIGGER [tr_connection_limit_MD]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'MD' 

     begin
		 if @ip in (select IP from DailyInsert.[dbo].[MDBreakList]) and @ap like '%Office%'
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Microsoft SQL Server Management Studio%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.151','172.24.26.128','172.24.26.159')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Office%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.151','172.24.26.128','172.24.26.159')
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 end
	 end


  















GO

ENABLE TRIGGER [tr_connection_limit_MD] ON ALL SERVER
GO


