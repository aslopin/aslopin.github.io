declare @TxDate datetime
declare @TimeTag nvarchar(50)

declare @TSM decimal(20,4)
declare @NQ decimal(20,4)
declare @TXF decimal(20,4)

declare @preTSM decimal(20,4)
declare @preNQ decimal(20,4)
declare @preTXF decimal(20,4)

declare @temp table(TxDate datetime,TimeTag nvarchar(50),TSM decimal(20,4),NQ decimal(20,4),TXF decimal(20,4))

declare input cursor
for 

SELECT a.[TxDate]
      ,a.[TimeTag]
      ,a.[Close] as TSM
      ,b.[Close] as NQ
      ,isnull(c.[Close],d.[last]) as TXF
--	  ,rank() over(order by a.[TxDate],a.[TimeTag]) as Cnt
  FROM [Intraday].[dbo].[RayIntraday] a
  left join [Intraday].[dbo].[RayIntraday] b on b.TxDate=a.TxDate and b.TimeTag=a.TimeTag and b.Stock='NQ'
  left join [Intraday].[dbo].[RayIntraday] c on c.TxDate=a.TxDate and c.TimeTag=a.TimeTag and c.Stock='TXF1'
  left join [Intraday].[dbo].[BloombergIntraday�����] d on d.TxDate=a.TxDate and d.TimeTag=a.TimeTag and d.Stock='TXF'
  where a.Stock='TSM'
  order by a.[TxDate],a.[TimeTag]

open input

fetch input into @TxDate,@TimeTag,@TSM,@NQ,@TXF
while (@@fetch_status=0)
  begin
  if @TSM is not null 
    begin set @preTSM=@TSM end
  else
    begin set @TSM=@preTSM end

  if @NQ is not null 
    begin set @preNQ=@NQ end
  else
    begin set @NQ=@preNQ end

  if @TXF is not null 
    begin set @preTXF=@TXF end
  else
    begin set @TXF=@preTXF end
  
  insert @temp select @TxDate,@TimeTag,@TSM,@NQ,@TXF
  fetch input into @TxDate,@TimeTag,@TSM,@NQ,@TXF
  end

close input
deallocate input

select *
from @temp
where TimeTag like '___[05]'
order by TxDate,TimeTag
