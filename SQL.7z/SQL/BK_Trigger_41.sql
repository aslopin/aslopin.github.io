USE [master]
GO

/****** Object:  DdlTrigger [tr_connection_limit]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE TRIGGER [tr_connection_limit]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS
--BEGIN
/*
IF ORIGINAL_LOGIN()= 'Patrick'
--��?test�b����M�U����IP�n?
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.103')
     ROLLBACK;
*/
IF ORIGINAL_LOGIN()= 'sa'
--��?test�b����M�U����IP�n?
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.116','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.42','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.151','172.24.26.39')
     ROLLBACK;
/*
IF ORIGINAL_LOGIN()= 'MD'
--��?test�b����M�U����IP�n?
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.103')
     ROLLBACK;

IF ORIGINAL_LOGIN()= 'patrick'
--��?test�b����M�U����IP�n?
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.102')
     ROLLBACK;
	 */
/*
--����test????��?��
IF ORIGINAL_LOGIN()= 'test'
--��?test�b����M�U����IP�n?
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
IN('172.24.26.102')
     ROLLBACK;
END;
*/

GO

DISABLE TRIGGER [tr_connection_limit] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_cmoney]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




























CREATE TRIGGER [tr_connection_limit_cmoney]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'cmoney' 

     begin
		 if @ap not like '%Office%' AND @ap not like '%Microsoft SQL Server%' AND @ap not like '%Apache HTTP Server%' AND @ap not like '%SSIS%'
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end
	 end


  






















GO

DISABLE TRIGGER [tr_connection_limit_cmoney] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_it]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




























CREATE TRIGGER [tr_connection_limit_it]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN() in ( 'it','ray','thhan') 

     begin
		 if @ap not like '%Office%' AND @ap not like '%Microsoft SQL Server%' AND @ap not like '%Apache HTTP Server%' AND @ap not like '%SSIS%'
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end
	 end


  






















GO

DISABLE TRIGGER [tr_connection_limit_it] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_Jay]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
























CREATE TRIGGER [tr_connection_limit_Jay]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'jay' 

     begin
		 if @ap like '%Microsoft SQL Server Management Studio%' AND @ip not IN('172.24.26.102','172.24.26.122','172.24.26.41','172.24.26.38','172.24.26.39')
			 begin
			 set @file='JayBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end

	 end


  


















GO

DISABLE TRIGGER [tr_connection_limit_Jay] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_MD]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








































CREATE TRIGGER [tr_connection_limit_MD]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'MD' 

     begin
		 if @ip in (select IP from DailyInsert.[dbo].[MDBreakList]) and @ap like '%Office%'
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Microsoft SQL Server Management Studio%' AND @ip not IN('172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.128','172.24.26.169','172.24.26.192','172.24.26.167','172.24.26.42')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%.Net SqlClient Data Provider%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Python%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.128','172.24.26.195','172.24.26.109','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%RStudio%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.128','172.24.26.195','172.24.26.109','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Office%' AND @ip not IN('172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.151','172.24.26.128','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 end

		 if @ap not like '%Office%' AND @ap not like '%Microsoft SQL Server%' AND @ap not like '%Apache HTTP Server%' AND @ap not like '%SSIS%'
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end
	 end


  


































GO

DISABLE TRIGGER [tr_connection_limit_MD] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_MDExcel]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








































CREATE TRIGGER [tr_connection_limit_MDExcel]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'MDExcel' 

     begin
		 if @ip in (select IP from DailyInsert.[dbo].[MDBreakList]) and @ap like '%Office%'
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 if @ap like '%Microsoft SQL Server Management Studio%' AND @ip not IN('172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.128','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 if @ap like '%.Net SqlClient Data Provider%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 if @ap like '%Python%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.128','172.24.26.195','172.24.26.109','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 if @ap like '%RStudio%' AND @ip not IN('172.24.26.102','172.24.26.101','172.24.26.106','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.42','172.24.26.43','172.24.26.46','172.24.26.151','172.24.26.128','172.24.26.195','172.24.26.109','172.24.26.169','172.24.26.192','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 else
			 begin
			 set @file='LoginMonitor'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end

	 end


  


































GO

DISABLE TRIGGER [tr_connection_limit_MDExcel] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_MDread]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


































CREATE TRIGGER [tr_connection_limit_MDread]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'MDread' 

     begin
		 if @ip in (select IP from DailyInsert.[dbo].[MDBreakList]) and @ap like '%Office%'
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end
		 if @ap like '%Microsoft SQL Server Management Studio%' AND @ip not IN('172.24.26.169','172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.128','172.24.26.159','172.24.26.167')
			 begin
			 set @file='UseSQLBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 ROLLBACK;
			 end

	 end


  




























GO

DISABLE TRIGGER [tr_connection_limit_MDread] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_sa]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE TRIGGER [tr_connection_limit_sa]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS
IF ORIGINAL_LOGIN()= 'sa'
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
not IN('172.24.26.102','172.24.26.106','172.24.26.121',
       -- '172.24.26.42',  '172.24.26.45', '172.24.26.46','172.24.26.129','172.24.26.170',
       '172.24.26.101','172.24.26.100','172.24.26.43','172.24.26.105', '172.24.26.46',
       '172.24.26.41')
     ROLLBACK;
	




GO

DISABLE TRIGGER [tr_connection_limit_sa] ON ALL SERVER
GO

/****** Object:  DdlTrigger [tr_connection_limit_tsftd]    Script Date: 2019/5/14 �U�� 05:54:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO











CREATE TRIGGER [tr_connection_limit_tsftd]
ON ALL SERVER WITH EXECUTE AS 'tsftd'
FOR LOGON
AS
IF ORIGINAL_LOGIN()= 'tsftd'
AND
(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)'))
not IN('172.24.26.102','172.24.26.106','172.24.26.121','172.24.26.129','172.24.26.131',
       -- '172.24.26.42',  '172.24.26.45', '172.24.26.46','172.24.26.129','172.24.26.105','172.24.26.170',
       '172.24.26.101','172.24.26.100','172.24.26.43','172.24.26.105', '172.24.26.46', '172.24.26.42', '172.24.26.136', '172.24.26.135',
       '172.24.26.41')
     ROLLBACK;
	










GO

DISABLE TRIGGER [tr_connection_limit_tsftd] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_cmoney] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_it] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_Jay] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_MD] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_MDExcel] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_MDread] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_sa] ON ALL SERVER
GO

ENABLE TRIGGER [tr_connection_limit_tsftd] ON ALL SERVER
GO


