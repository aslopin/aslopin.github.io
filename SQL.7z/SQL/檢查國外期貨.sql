


select * from db2.Tick.[dbo].[tbl_Tick_Today_snapshot_FF] order by Tick_Time
select Symbol,max(InTime) from db2.Tick.[dbo].[tbl_Tick_Today_New_FF] group by Symbol order by max(InTime)

select * from db2.Tick.[dbo].[tbl_Tick_Today_snapshot_FF] order by StockID

select *
from db192.pl.[dbo].[InventoryMay4_�Q�w�s_�l�Ӧ���]
where Stockid='VX202103'

select *
from pl.[dbo].[DailyPLReport_�l�Ӧ���_����]
where TxDate='2021/1/27' and Stockid='VX202103' and acc='5609'


select *
from pl.[dbo].[DailyPLReport_�l�Ӧ���_����]
where TxDate='2021/1/27' and Stockid='VX202103'

select *
from pl.[dbo].[DailyPLReport_�l�Ӧ���_����]
where TxDate='2021/1/27' and Stockid like 'TX%' and volume<>0
