  select a.年月,a.會計科目,a.科目代號,-1*a.累進金額 as 同業,b.金額 as MIS,-1*a.累進金額-b.金額 as [同業-MIS]
  from pl.[dbo].[同業交換報表_收支概況表] a
  left join (
		SELECT 年月,left(科目代號,6) as 科目代號,sum(Amount) as 金額
		FROM [Accounting].[dbo].[MIS]
		where 年月 in ('202208','202209','202210') and Dept='金交處合計' and Tag='本年'
		and left(科目代號,6) in ('521200','528000','533060','533130','533230')
		group by 年月,left(科目代號,6)
  ) b on b.科目代號=a.科目代號 and b.年月=a.年月
  where a.年月='202210' and a.科目代號 in ('521200','528000','533060','533130','533230') and a.券商名稱 ='台新證券'
  order by a.科目代號

  select a.年月,a.會計科目,a.科目代號,a.累進金額 as 同業,b.金額 as MIS,a.累進金額-b.金額 as [同業-MIS]
  from pl.[dbo].[同業交換報表_收支概況表] a
  left join (
		SELECT 年月,left(科目代號,6) as 科目代號,sum(Amount) as 金額
		FROM [Accounting].[dbo].[MIS]
		where 年月 in ('202208','202209','202210') and Dept='金交處合計' and Tag='本年'
		and left(科目代號,6) in ('421300','602491')
		group by 年月,left(科目代號,6)
  ) b on b.科目代號=a.科目代號 and b.年月=a.年月
  where a.年月='202210' and a.科目代號 in ('421300','602491') and a.券商名稱 ='台新證券'
  order by a.科目代號



select * 
from (
     select a.科目代號,a.會計科目,b.乘數, sum(b.乘數*a.本月金額) as 同業--sum(b.乘數*a.本月金額) 
     from  [PL].[dbo].[同業交換報表_收支概況表] a
     left join dbmain.[dbo].[交換報表科目對應] b on b.[科目代號]=a.科目代號
     where a.年月 between '202201' and '202209' and a.券商名稱='台新證券' and b.科目代號  is not null 
     group by a.科目代號,a.會計科目,b.乘數
) a
left join (select  left(m.科目代號,6) 科目代號, sum(amount) MIS from accounting.dbo.MIS m 
              where m.tag='本年' and dept='金交處合計' and m.年月 = '202209'
              group by left(m.科目代號,6) 
) m on a.科目代號 =m.科目代號--case when left(m.科目代號,6)   and m.amount<>0

select * ,a.同業-isnull(m.MIS,0) as Diff
from (
     select a.科目代號,a.會計科目,b.乘數, sum(b.乘數*a.本月金額) as 同業--sum(b.乘數*a.本月金額) 
     from  [PL].[dbo].[同業交換報表_收支概況表] a
     left join dbmain.[dbo].[交換報表科目對應] b on b.[科目代號]=a.科目代號
     where a.年月='202210' and a.券商名稱='台新證券' and b.科目代號  is not null 
     group by a.科目代號,a.會計科目,b.乘數
) a
join (select  left(m.科目代號,6) 科目代號, sum(amount) MIS from accounting.dbo.MIS m 
              where m.tag='本月' and dept='金交處合計' and m.年月 = '202210'
              group by left(m.科目代號,6) 
) m on a.科目代號 =m.科目代號--case when left(m.科目代號,6)   and m.amount<>0

/*
SELECT left(科目代號,6) as 科目代號,sum(Amount) 
  FROM [Accounting].[dbo].[MIS]
  where 年月='202209' and Dept='金交處合計' and Tag='本月'
  and left(科目代號,6) in ('521200','528000','533060','533130','533230')
  group by left(科目代號,6)
  order by left(科目代號,6)

SELECT 年月,left(科目代號,6) as 科目代號,sum(Amount) as 金額
  FROM [Accounting].[dbo].[MIS]
  where 年月 in ('202209','202210') and Dept='金交處合計' and Tag='本年'
  and left(科目代號,6) in ('521200','528000','533060','533130','533230')
  group by 年月,left(科目代號,6)
  order by left(科目代號,6)

SELECT left(科目代號,6) as 科目代號,sum(Amount) 
  FROM [Accounting].[dbo].[MIS]
  where 年月='202210' and Dept='金交處合計' and Tag='本年'
  and left(科目代號,6) in ('521200','528000','533060','533130','533230')
  group by left(科目代號,6)
  order by left(科目代號,6)

  select *
  from pl.[dbo].[同業交換報表_收支概況表] a
  where a.年月='202210' and a.會計科目 in ('股利收入','受託買賣手續費收入-經紀','受託買賣手續費收入-櫃檯','受託買賣手續費收入-期貨','受託買賣手續費收入-票券','受託買賣手續費收入-其他') and a.券商名稱 ='台新證券'

 */
