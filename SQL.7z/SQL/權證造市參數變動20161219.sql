
select w.Txdate,z.Trader,w.WarrantID,w.WarrantName,w.StockID,avg(abs(i.Volume/1000.)) as OS�i
,max(x.QV-case when w.txdate=w.availabledate then w.QuoteVol*100 else y.QV end) as ���W��
,min(x.QV-case when w.txdate=w.availabledate then w.QuoteVol*100 else y.QV end) as ���U��
from dbmain.dbo.WarrantProfileTS_Daily w
left join (
	select dbmain.dbo.DateTranslatorInv(TX_Date,3) as TxDate,Wrr_ID,cast(QV as decimal(20,4)) as QV
	from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Tmp] 
	where TX_Date between '20161214' and '20161219'
	and QV is not null

	union all
	select dbmain.dbo.DateTranslatorInv(TX_Date,3) as TxDate,Wrr_ID,cast(QV as decimal(20,4)) as QV
	from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
	where TX_Date between '20161213' and '20161220'
	and QV is not null

	union all
	select dbmain.dbo.tradingdateadd(1,dbmain.dbo.DateTranslatorInv(TX_Date,3)) as TxDate,Wrr_ID,cast(QV as decimal(20,4)) as QV
	from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
	where TX_Date between '20161213' and '20161220'
	and QV is not null
) x on x.TxDate=w.txdate and x.Wrr_ID=w.WarrantID
left join (
	select dbmain.dbo.tradingdateadd(1,dbmain.dbo.DateTranslatorInv(TX_Date,3)) as TxDate,Wrr_ID,cast(QV as decimal(20,4)) as QV
	from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
	where TX_Date between '20161213' and '20161220'
	and QV is not null
) y on y.TxDate=x.txdate and y.Wrr_ID=x.Wrr_ID
left join dbmain.[dbo].[DailyDefaultPortfolio] z on z.TxDate=w.txdate and z.StockID=w.WarrantID
left join pl.dbo.inventory i on i.stadate=w.txdate and i.portfolio=w.WarrantKey and i.StockID=w.WarrantID
where w.expireddate>='2016/12/19'
and w.txdate between '2016/12/14' and '2016/12/19'
and w.AvailableDate<=w.txdate
group by w.Txdate,z.Trader,w.WarrantID,w.WarrantName,w.StockID
order by w.Txdate,z.Trader,w.StockID,w.WarrantID,w.WarrantName
