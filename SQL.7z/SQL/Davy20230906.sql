/*
exec [MDoutput].dbo.投資部位餘額會計計算方式 '2023/9/5'
*/
alter procedure dbo.投資部位餘額會計計算方式 @t datetime
as
--declare @t datetime 
if @t=''
  begin set @t= (select max([日期]) from [MDoutput].[dbo].[Cht_tsftd_InvestmentReportW_table]) end

declare @期貨權益數 table(日期 datetime,交易代號 nvarchar(50),權益數 decimal(20,4))
insert @期貨權益數
select x.日期,x.交易代號,sum(x.權益數) as 權益數
from (
	--台新期貨虛擬子帳
	select x.生效日期 as 日期,x.交易代號
		, x.權益數*x.佔比 as [權益數]
	from (
	select 生效日期,交易代號,原始保證金上限 as 原始保證金上限
		,case when sum(原始保證金上限) over (partition by 客戶帳號) =0 then 0 else 原始保證金上限 / sum(原始保證金上限) over (partition by 客戶帳號) end as 佔比
		,isnull(b1.原始保證金,0) as 已使用原始保證金,b.權益數 as 權益數,isnull(c.自有資金,0) as 自有資金
	from pl.dbo.期貨_MARGIN_台新 a
		left join dbmain.dbo.tbl期自營帳號對應 b0 on b0.上手帳號 = a.交易代號 
		left join pl.dbo.期貨_凱基格式F_台新 b on b.交易員 = a.客戶帳號 and b.幣別 = 'TWD' and a.生效日期 = b.匯入日期
		left join pl.dbo.期貨_凱基格式F子帳_台新 b1 on b1.交易員 = a.交易代號 and b1.幣別 = 'TWD' and a.生效日期 = b1.匯入日期 and len(b1.交易員) = 4
		left join (
			SELECT @t as 日期,sum(交割金額) as 自有資金
			FROM [DB75].[IntraWeb].[dbo].[tbl資金調撥申請] 
			where 用途 = 2 and 交割日期 <= @t and 狀態 = 4 and 交易對象 in ('288','321')
		) c on  c.日期 = a.生效日期
		where a.生效日期= @t 
	) x
	join dbmain.dbo.AccountList_Temp ac on ac.FuAcc00 = x.交易代號 and x.生效日期 between ac.Bdate and ac.Edate
	join dbmain.dbo.strategy名稱轉換 s on s.strategy = ac.Portfolio and x.生效日期 between s.Bdate and s.Edate
	--台新
	union all
	SELECT a.[匯入日期],b.交易帳號,a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳_台新] a
	join DBmain.[dbo].[tbl期自營帳號對應] b on b.上手帳號=a.[交易員]
	where a.匯入日期=@t and a.[交易員] like '9800%' and a.幣別 in ('NTD','TWD')
	--凱基
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳] a
	where a.匯入日期=@t and a.幣別 in ('NTD','TWD')
	--元大
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳_元大] a
	where a.匯入日期=@t and a.幣別 in ('NTD','TWD')
	--元大香港
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]*b.匯率
	FROM [PL].[dbo].[期貨_凱基格式F子帳_元大香港] a
	left join cmoney.[dbo].[台新銀行每日匯率] b on b.日期=a.日期 and b.幣別=a.幣別
	where a.匯入日期=@t and a.幣別 in ('VND')
	--國泰
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳_國泰] a
	where a.匯入日期=@t and a.幣別 in ('NTD','TWD')
	--統一
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳_統一] a
	where a.匯入日期=@t and a.幣別 in ('NTD','TWD')
	--群益
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳_群益] a
	where a.匯入日期=@t and a.幣別 in ('NTD','TWD')
	--群益香港
	union all
	SELECT a.[匯入日期],a.[交易員],a.[權益數]
	FROM [PL].[dbo].[期貨_凱基格式F子帳_群益香港] a
	where a.匯入日期=@t and a.幣別 in ('NTD','TWD')
) x
group by x.日期,x.交易代號

SELECT a.[日期],a.[部門],a.[交易策略]
,b.現股部位,b.券賣部位,b.[自籌(或負債)],b.實際使用資金
,b.現股部位+b.券賣部位+b.期貨權益數 as [現股+券賣+期貨]
,a.[本年損益]/1000. as [本年損益]
,b.期貨權益數
FROM [MDoutput].[dbo].[Cht_tsftd_InvestmentReportW_table] a
left join (
	select a.Txdate as 日期, a.Dept as 部門
	,case when a.Dept in ('衍商部','計量部') THEN LEFT(a.Dept,2) when a.Dept in ('債券部') THEN a.Dept when a.Dept in ('衍商部權證') THEN '衍商' when a.Dept in ('期交部','策交部') THEN '計量' when a.Dept in ('自營部')  then '自營三組' else a.Dept end +'_'+isnull(c.策略盤中顯示,b.策略)
	 as Desk 
	,sum(a.部位_400市值+a.部位_國外股票市值+a.部位_債券面額)/1000000. as 現股部位
	,sum(a.部位_400券賣市值)/1000000. as 券賣部位
	,sum(a.自籌)/1000000. as [自籌(或負債)]
	,sum(a.部位資金+case when a.策略='Warrant' then 0 else 自籌 end )/1000000. as 實際使用資金
	,sum(isnull(f.權益數,0))/1000000. as [期貨權益數]
	from [PL].[dbo].[資金使用_new] a
	left join [OperationDesk].[dbo].[Delta_LS] b on b.TxDate=a.Txdate and b.acc=a.acc
	left join dbmain.dbo.AccountList_Temp acc on a.TxDate between acc.BDate and acc.EDate and acc.Acc00=a.acc
	left join @期貨權益數 f on f.交易代號=acc.FuAcc00
	left join (select 策略,Dept,策略盤中顯示 from dbmain.dbo.Strategy名稱轉換 where @t between BDate and EDate group by 策略,Dept,策略盤中顯示)
	 c on c.策略 = b.策略 and a.Dept = c.Dept
	where a.Txdate=@t and a.acc not in ('309','791','792')
	group by a.Dept, a.Txdate
	,case when a.Dept in ('衍商部','計量部') THEN LEFT(a.Dept,2) when a.Dept in ('債券部') THEN a.Dept when a.Dept in ('衍商部權證') THEN '衍商' when a.Dept in ('期交部','策交部') THEN '計量' when a.Dept in ('自營部')  then '自營三組' else a.Dept end +'_'+isnull(c.策略盤中顯示,b.策略)
) b on b.Desk=a.[交易策略]
where a.日期=@t
order by a.[部門],a.[交易策略]