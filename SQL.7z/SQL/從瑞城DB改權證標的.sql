	update FrontDeskW.[dbo].[�v�ҼЪ���TraderBE]
	set EDate='2017/8/8'
	where '2017/8/8' between BDate and EDate

insert FrontDeskW.[dbo].[�v�ҼЪ���TraderBE]
select x.StockID
,case when isnull(y.UserId,x.Trader)='Arielle' then 'Ariel' else isnull(y.UserId,x.Trader) end
,'2017/8/9'
,'2018/12/31'
from (
	select StockID,Trader
	from FrontDeskW.[dbo].[�v�ҼЪ���TraderBE]
	where '2017/8/8' between BDate and EDate
) x
left join db39.[Trade_DB].[dbo].[tblWrr_UnderlyingMapping] y on y.UnderlyingID=x.StockID
