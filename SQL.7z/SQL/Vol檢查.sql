declare @t datetime set @t='2015/7/17'

declare @r decimal(20,6) set @r=0.01

declare @Warrant table(ser int,TimeTag nvarchar(50),Portfolio nvarchar(50),Trader nvarchar(50),WarrantID nvarchar(50)
,Pb1 decimal(20,6),SPot decimal(20,6),Strike decimal(20,6),Exer decimal(20,6),Barrier decimal(20,6),ED datetime)
insert @Warrant
select t.ser,t.TimeTag,mm.Portfolio,mm.Trader,mm.WarrantID
,mm.Pb1
,case when w.callput='C' then u.[B1_Price] else u.[A1_Price] end 
 as SPot
,w.CurrentStrikePrice,w.AdjustedExerciseRate,w.BarrierPrice
,w.expireddate
from dbmain.[dbo].[TimeTag] t
left join [Intraday].[dbo].[WarrantMMOrder] mm on mm.TxDate=@t and t.TimeTag>=mm.BTime and t.TimeTag<mm.ETime
left join dbmain.[dbo].[WarrantProfileTS_daily] w on w.TxDate=@t and w.warrantid=mm.WarrantID
left join db2.[Intraday].[dbo].[DailyTick_Underlying] u on u.TxDate=@t and u.[Stockid]=w.stockid and t.TimeTag>=u.BTime and t.TimeTag<u.ETime
where t.ser between 1 and 265

declare @WarrantVol table(Ser int,TimeTag nvarchar(50),Portfolio nvarchar(50),Trader nvarchar(50),WarrantID nvarchar(50)
,Vol decimal(20,8))
insert @WarrantVol
select w.ser,w.TimeTag,w.Portfolio,w.Trader,w.WarrantID
,Theodata.[dbo].[Implied_vol] (Pb1,SPot,Strike,Barrier,dbmain.dbo.tradingdatediff(@t,w.ED)/252. ,@r,warrantid,Exer)
from @Warrant w

select *
from dbmain.[dbo].[TimeTag] t
where t.ser between 1 and 265
and theodata.dbo.[MOD](t.ser,5)=0
