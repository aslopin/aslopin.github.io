declare @t datetime set @t='2017/4/11'


select x.StockID,x.ULast
,case when x.Gamma<0 then 
          x.ULast+case when speed<>0 and gamma*gamma-2*delta*Speed>0 then (-1*Gamma-sqrt(gamma*gamma-2*delta*Speed))/speed else 0 end
      else
		  x.ULast+case when speed<>0 and gamma*gamma-2*delta*Speed>0 then (-1*Gamma+sqrt(gamma*gamma-2*delta*Speed))/speed else 0 end
      end
 as NP
,case when speed<>0 and gamma*gamma-2*delta*Speed>0 then (-1*Gamma+sqrt(gamma*gamma-2*delta*Speed))/speed else 0 end as [dS+]
,case when speed<>0 and gamma*gamma-2*delta*Speed>0 then (-1*Gamma-sqrt(gamma*gamma-2*delta*Speed))/speed else 0 end as [dS-]
,x.ULast+case when speed<>0 and gamma*gamma-2*delta*Speed>0 then (-1*Gamma+sqrt(gamma*gamma-2*delta*Speed))/speed else 0 end as [Np+]
,x.ULast+case when speed<>0 and gamma*gamma-2*delta*Speed>0 then (-1*Gamma-sqrt(gamma*gamma-2*delta*Speed))/speed else 0 end as [Np-]
,x.Gamma
,x.delta
,x.Speed
from (
	select w.StockID
	,sum(TheoData.dbo.OptGamma(pro.SLast, pro.Strike, pro.Barrier, pro.T�����, pro.PricingVol, pro.r, pro.WarrantID)*pro.Exer*pro.SLast*i.volume)
	 as Gamma
	,sum(TheoData.dbo.OptSpeed(pro.SLast, pro.Strike, pro.Barrier, pro.T�����, pro.PricingVol, pro.r, pro.WarrantID)*pro.Exer*pro.SLast*i.volume)
	 as Speed
	,sum(case when dbmain.dbo.�P�_���O(i.stockid)='warrant' then TheoData.dbo.Optdelta(pro.SLast, pro.Strike, pro.Barrier, pro.T�����, pro.PricingVol, pro.r, pro.WarrantID)*pro.Exer*pro.SLast*i.volume
			  else i.volume*i.Delta*i.LastPrice
			  end)
	 as delta
	,avg(q.���L��) as ULast
	from dbmain.dbo.WarrantProfileTS_Daily w
	join pl.dbo.inventory i on i.Stadate=w.txdate and i.portfolio=w.WarrantKey and i.volume<>0
	left join pro.dbo.�v�ҵ������ pro on pro.TxDate=w.txdate and pro.UnderlyingID=w.StockID and pro.WarrantID=i.StockID
	left join cmoney.dbo.�馬�L���Ʀ� q on q.���=w.txdate and q.�Ѳ��N��=w.stockid
	where w.TxDate=@t
	--and w.StockID='3481'
	group by w.StockID
) x

