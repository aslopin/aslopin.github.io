declare @t datetime set @t=(select max(stadate) from pl.dbo.inventory)

select x.Underlying
,case when y.�̰���-y.�̧C��<>0 then abs(x.�R��-x.�槡)/(y.�̰���-y.�̧C��) end
 as ���椣�X�z
from (
	select x.Underlying
	,case when sum(case when BuySell='B' then DeltaLot else 0 end)<>0 then
	 sum(case when BuySell='B' then DeltaLot*UPrice else 0 end)
	/sum(case when BuySell='B' then DeltaLot else 0 end)
	 end
	 as �R��
	,case when sum(case when BuySell='S' then DeltaLot else 0 end)<>0 then
	 sum(case when BuySell='S' then DeltaLot*UPrice else 0 end)
	/sum(case when BuySell='S' then DeltaLot else 0 end)
	 end
	 as �槡
	from (
		select case when a.Underlying like 'WTXF%' then 'TWA00' else a.Underlying end as Underlying
		,case when (a.BuySell='S' and right(a.StockID,1)<>'P') or (a.BuySell='B' and right(a.StockID,1)='P') then 'S'
			  when (a.BuySell='B' and right(a.StockID,1)<>'P') or (a.BuySell='S' and right(a.StockID,1)='P') then 'B'
			  end
		 as BuySell
		,abs(DeltaLot) as DeltaLot
		,UPrice
		from pl.[dbo].[�v�ҨC��Markup_����PV] a
		where a.Txdate=@t
		union all
		select b.StockID,case when a.DealVolume*d.Delta>0 then 'B' else 'S' end as BuySell
		,abs(a.DealVolume*d.Delta)
		,abs(a.DealAmt/d.Delta/a.DealVolume)
		from pl.dbo.deallist a
		join dbmain.dbo.WarrantProfileTS_Daily b on b.TxDate=a.Txdate and b.WarrantKey=a.Portfolio
		left join cmoney.dbo.�v�Ұ򥻸�ƪ��C�� c on c.���=a.Txdate and c.�N��=a.StockID
		join pl.dbo.inventory d on d.stadate=a.Txdate and d.portfolio=a.portfolio and d.stockid=a.stockid and d.[Type]=a.[Type]
		where a.Txdate=@t and c.��� is null
	) x
	group by x.Underlying
) x
left join cmoney.dbo.�馬�L���Ʀ� y on y.���=@t and y.�Ѳ��N��=x.Underlying
order by case when y.�̰���-y.�̧C��<>0 then abs(x.�R��-x.�槡)/(y.�̰���-y.�̧C��) end desc


    select *
	from (
		select case when a.Underlying like 'WTXF%' then 'TWA00' else a.Underlying end as Underlying
		,case when (a.BuySell='S' and right(a.StockID,1)<>'P') or (a.BuySell='B' and right(a.StockID,1)='P') then 'S'
			  when (a.BuySell='B' and right(a.StockID,1)<>'P') or (a.BuySell='S' and right(a.StockID,1)='P') then 'B'
			  end
		 as BuySell
		,abs(DeltaLot) as DeltaLot
		,UPrice
		from pl.[dbo].[�v�ҨC��Markup_����PV] a
		where a.Txdate=@t
		union all
		select b.StockID,case when a.DealVolume*d.Delta>0 then 'B' else 'S' end as BuySell
		,abs(a.DealVolume*d.Delta)
		,abs(a.DealAmt/d.Delta/a.DealVolume)
		from pl.dbo.deallist a
		join dbmain.dbo.WarrantProfileTS_Daily b on b.TxDate=a.Txdate and b.WarrantKey=a.Portfolio
		left join cmoney.dbo.�v�Ұ򥻸�ƪ��C�� c on c.���=a.Txdate and c.�N��=a.StockID
		join pl.dbo.inventory d on d.stadate=a.Txdate and d.portfolio=a.portfolio and d.stockid=a.stockid and d.[Type]=a.[Type]
		where a.Txdate=@t and c.��� is null
	) x
	where x.Underlying='6269'

		select *
		from pl.[dbo].[�v�ҨC��Markup_����PV] a
		where a.Txdate=@t and a.Underlying='6269'

			select b.StockID,case when a.DealVolume*d.Delta>0 then 'B' else 'S' end as BuySell
		,abs(a.DealVolume*d.Delta)
		,abs(a.DealAmt/d.Delta/a.DealVolume)
		,*
		from pl.dbo.deallist a
		join dbmain.dbo.WarrantProfileTS_Daily b on b.TxDate=a.Txdate and b.WarrantKey=a.Portfolio and b.StockID='6269'
		left join cmoney.dbo.�v�Ұ򥻸�ƪ��C�� c on c.���=a.Txdate and c.�N��=a.StockID
		join pl.dbo.inventory d on d.stadate=a.Txdate and d.portfolio=a.portfolio and d.stockid=a.stockid and d.[Type]=a.[Type]
		where a.Txdate=@t and c.��� is null


select x.�Ъ��N��
,x.Theta/sum(x.Theta) over() as [Pct%]
,x.ThetaNet/sum(x.ThetaNet) over() as [Pct%Net]
from (
select �Ъ��N��,sum(Theta�ۮa) as Theta,sum(Theta�ۮa+Theta�L�a) as ThetaNet
from pl.[dbo].[DailyPLReport_WPV]
where Stadate='2017/4/19'
group by �Ъ��N��
) x
order by x.ThetaNet desc