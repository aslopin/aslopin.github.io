/*
MarkupChg�G
[dealprice-BV(Sm,Vb)]-[PV(Sl,IVm)-BV(Sl,Vb)]

MarkupChg byS�G
[PV(Sm,IVm)-BV(Sm,Vb)]-[PV(Sl,IVm)-BV(Sl,Vb)]
Spread�G
dealprice-W����
MarkupChg byV�G
W����-PV(Sm,IVm)
*/
declare @t datetime set @t='2015/7/15'
declare @tt nvarchar(50) set @tt=dbmain.dbo.datetranslator(@t,3)
--declare @y datetime set @y=dbmain.dbo.tradingdateadd(-1,@t)
--declare @yy nvarchar(50) set @yy=dbmain.dbo.datetranslator(@y,3)
declare @ser decimal(20,4) set @ser=(select ser from dbmain.dbo.tradingdate where tradingdate=@t)

declare @qv table( WarrantID nvarchar(50),qv decimal(20,6))
insert @qv
select [WarrantID],[M1Vol�����]
from intraday.[dbo].[�v�ҽL�����Rnew2]
where [TxDate]=@t
/*
select Wrr_ID,cast(case when QV=''   then null else QV end as decimal(20,6))/100.
from db2.[Tick].[dbo].[tbl_WrrMMPlcPrms_QV_Last]
where TX_Date=@tt  and QV<>''
order by Wrr_ID

select [WarrantID],[M1Vol�����]
from intraday.[dbo].[�v�ҽL�����Rnew2]
where [TxDate]=@t and [WarrantID] between '034506' and '034510'
order by [WarrantID]
*/
declare @TRP table(StockId nvarchar(50),TRP decimal(20,4),Up decimal(20,4),Down decimal(20,4))
insert @TRP
select a.StockID,a.FairPrice,a.UpMaxPrice,a.DownMinPrice
from DB2.Tick.[dbo].[tbl_Day_MinMax] a
where a.In_Time=@tt


--delete pl.[dbo].[MarkupAnalysis_���鳡��] where txdate=@t
--insert pl.[dbo].[MarkupAnalysis_���鳡��](Txdate, portfolio, stockid, underlying, �`MarkupT, Markup�h�^, B����Mkplbs, S����Mkplbs, BLots, SLots, NetLots)
 

SELECT a.txdate,a.portfolio,a.stockid,a.underlying--,a.txtime,a.buysell,a.price,a.volume,a.MMPL,a.�L�aMMPL, B1_price,A1_Price 
, sum((a.price
    -TheoData.dbo.optvlu(0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.HV ,0.01,a.Stockid, w.ExerciseRate))
	*isnull(case when a.BuySell='B' then -1 else 1 end*a.Volume,0)  ) as �`MarkupT --����-�������bv
, sum((TheoData.dbo.optvlu(q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252., qv.qv ,0.01,a.Stockid, w.ExerciseRate)
    -TheoData.dbo.optvlu(q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.HV ,0.01,a.Stockid, w.ExerciseRate))
	*isnull(case when a.BuySell='B' then -1 else 1 end*a.Volume,0))  as Markup�h�^--���Lpv-���Lbv 

, sum(
   (TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
    -TheoData.dbo.optvlu( q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
	-TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.hv,0.01,a.Stockid, w.ExerciseRate)
	+TheoData.dbo.optvlu( q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.hv,0.01,a.Stockid, w.ExerciseRate)
	)	*isnull(case when a.BuySell='B' then -1 else 0 end*a.Volume ,0) 
  )
  as B����Mkplbs-- ����-pv

, sum(
   (a.price
    -0.5*(isnull(case when wba.Pb1=0 then a.price else wba.Pb1 end,case when wba.Ps1=0 then a.price else wba.Ps1 end)+isnull(case when wba.Ps1=0 then a.price else wba.Ps1 end,case when wba.Pb1=0 then a.price else wba.Pb1 end))
	)	*isnull(case when a.BuySell='B' then -1 else 0 end*a.Volume ,0) 
  )
  as BSpread-- ����-pv

, sum(
   (0.5*(isnull(case when wba.Pb1=0 then a.price else wba.Pb1 end,case when wba.Ps1=0 then a.price else wba.Ps1 end)+isnull(case when wba.Ps1=0 then a.price else wba.Ps1 end,case when wba.Pb1=0 then a.price else wba.Pb1 end))
    -TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
	)	*isnull(case when a.BuySell='B' then -1 else 0 end*a.Volume ,0) 
  )
  as BVChg-- ����-pv

, sum(
   ( TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
    -TheoData.dbo.optvlu( q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
	-TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.hv,0.01,a.Stockid, w.ExerciseRate)
	+TheoData.dbo.optvlu( q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.hv,0.01,a.Stockid, w.ExerciseRate)
	)	*isnull(case when a.BuySell='S' then 1 else 0 end*a.Volume ,0) 
  )
  as S����Mkplbs-- ����-pv

, sum(
   (a.price
    -0.5*(isnull(case when wba.Pb1=0 then a.price else wba.Pb1 end,case when wba.Ps1=0 then a.price else wba.Ps1 end)+isnull(case when wba.Ps1=0 then a.price else wba.Ps1 end,case when wba.Pb1=0 then a.price else wba.Pb1 end))
	)	*isnull(case when a.BuySell='S' then 1 else 0 end*a.Volume ,0) 
  )
  as SSpread-- ����-pv

, sum(
   (0.5*(isnull(case when wba.Pb1=0 then a.price else wba.Pb1 end,case when wba.Ps1=0 then a.price else wba.Ps1 end)+isnull(case when wba.Ps1=0 then a.price else wba.Ps1 end,case when wba.Pb1=0 then a.price else wba.Pb1 end))
    -TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
	)	*isnull(case when a.BuySell='S' then 1 else 0 end*a.Volume ,0) 
  )
  as SVChg-- ����-pv

, sum( (a.price
    -TheoData.dbo.optvlu( q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  qv.qv,0.01,a.Stockid, w.ExerciseRate)
	-TheoData.dbo.optvlu( 0.5*(isnull(B1_price,ip2.Down)+isnull(A1_price,ip2.Up)),w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.hv,0.01,a.Stockid, w.ExerciseRate)
	+TheoData.dbo.optvlu( q.���L��,w.strike,w.barrier,dbmain.dbo.tradingdatediff(a.txdate,w.[ExpiredDate])/252.,  bv.hv,0.01,a.Stockid, w.ExerciseRate)
	)	*isnull(case when a.BuySell='S' then 1 else 0 end*a.Volume ,0) )  as S����Mkplbs-- ����-pv


 , sum( case when a.BuySell='B' then 1 else 0 end*a.Volume )  AS BLots
  , sum( case when a.BuySell='S' then -1 else 0 end*a.Volume )  AS SLots
   , sum( case when a.BuySell='B' then 1 else -1 end*a.Volume )  AS NetLots
   

  FROM [PL].[dbo].[�v�ҨC��Markup_����] a 
  join dbmain.dbo.warrantdata w on w.txdate=a.txdate and w.warrantid=a.stockid   
  --left join dbmain.dbo.warrantdata wy on wy.txdate=@y and wy.warrantid=a.stockid  
  join @qv qv on qv.WarrantID=a.stockid
  --left join @qvy qvy on qvy.WarrantID=a.stockid
  join marketdata.dbo.DailyQuote q on q.���=a.TxDate and q.�Ѳ��N��=w.StockID 
  left join @TRP ip2 on  w.stockid=ip2.stockid
 -- join marketdata.dbo.DailyQuote qy on qy.���=@y and qy.�Ѳ��N��=w.StockID 
  join dbmain.dbo.[WarrantHedgeVolTS_BE]() bv on bv.StockID=w.stockID
and @t between bv.bdate and bv.edate
left join intraday.[dbo].[WarrantMMOrder] wba on wba.[TxDate]=@t and wba.[WarrantID]=a.stockid and a.TxTime>wba.BTime and a.TxTime<=wba.ETime
 where a.TxDate =@t  /* and   a.stockid='034507'*/  and a.account='8888885'  
 group by     a.txdate,a.portfolio,a.stockid,a.underlying --order by a.txdate,a.txtime

 
