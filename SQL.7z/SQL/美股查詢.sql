select isnull(b.[現金股利(元)],0) as [現金股利(元)],isnull(b.[現金股利(元)],0)/a.收盤價 as 殖利率,c.[中文產業分類名稱(第二級)] as 分類,a.*  
from cmoney.[dbo].[美股日收盤表排行] a  
left join (select 代號,sum([現金股利(元)]) as [現金股利(元)] from cmoney.[dbo].[美股股利政策表] where 年度='2021' group by 代號) b on b.代號=a.代號  
left join cmoney.[dbo].[美股上市公司基本資料] c on c.代號=a.代號 and c.年度='2021'  
where a.日期=(select max(日期) from cmoney.[dbo].[美股日收盤表排行])  
order by isnull(b.[現金股利(元)],0)/a.收盤價 desc

select isnull(b.[現金股利(元)],0) as [現金股利(元)],isnull(b.[現金股利(元)],0)/a.收盤價 as 殖利率,c.[中文產業分類名稱(第二級)] as 分類,a.*  
from cmoney.[dbo].[美股日收盤表排行] a  
left join (select 代號,sum([現金股利(元)]) as [現金股利(元)] from cmoney.[dbo].[美股股利政策表] where 年度='2021' group by 代號) b on b.代號=a.代號  
left join cmoney.[dbo].[美股上市公司基本資料] c on c.代號=a.代號 and c.年度='2021'  
where a.日期=(select max(日期) from cmoney.[dbo].[美股日收盤表排行])  
order by a.代號

select *
from cmoney.[dbo].[美股日收盤表排行] a  
where a.日期=(select max(日期) from cmoney.[dbo].[美股日收盤表排行])  
order by a.代號

select 年度,代號,sum([現金股利(元)]) as [現金股利(元)] from cmoney.[dbo].[美股股利政策表] group by 代號,年度 order by 代號,年度

