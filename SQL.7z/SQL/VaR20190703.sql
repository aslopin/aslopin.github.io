declare @t datetime set @t='2019/7/1'

create table #Data (date datetime ,id nvarchar(4), [close] decimal(20,4))
insert #Data
select  cast( DBMain.dbo.DateTranslator(Dates,1) as datetime),'ZS' as id,[close] 
 from web.dbo.s1 where convert(varchar, Dates, 114) ='13:30:00:000'  --133
union all
select cast( DBMain.dbo.DateTranslator(Date,1) as datetime)  as [Dates],
case when [COMDTY_CODE]='S 1 Comdty' then 'ZS'
              when [COMDTY_CODE]='XU1 Index' then 'CN'
              when [COMDTY_CODE]='GC1 Comdty' then 'GC'
              when [COMDTY_CODE]='UX1 Index' then 'VX' end  as id
,[PX_CLOSE] 
from db192.[BloombergDataSet].[dbo].[DAILY] 
where COMDTY_CODE in ('S 1 Comdty') 
and  cast( DBMain.dbo.DateTranslator(Date,1) as datetime)<'2018/12/19'
  union all
select  cast( DBMain.dbo.DateTranslator(Dates,1) as datetime),'CN',[close] 
 from web.dbo.XU1 
 where convert(varchar, Dates, 114) ='13:30:00:000' --140
  union all
select cast( DBMain.dbo.DateTranslator(Date,1) as datetime)  as [Dates],
case when [COMDTY_CODE]='S 1 Comdty' then 'ZS'
              when [COMDTY_CODE]='XU1 Index' then 'CN'
              when [COMDTY_CODE]='GC1 Comdty' then 'GC'
              when [COMDTY_CODE]='UX1 Index' then 'VX' end  as id
,[PX_CLOSE] 
from db192.[BloombergDataSet].[dbo].[DAILY] 
where COMDTY_CODE in ('XU1 Index') 
and  cast( DBMain.dbo.DateTranslator(Date,1) as datetime)<'2018/12/19'
union all
select cast( DBMain.dbo.DateTranslator(Dates,1) as datetime),'GC',[close] 
 from web.dbo.GC1 where convert(varchar, Dates, 114) ='13:30:00:000'  --138
  union all
select cast( DBMain.dbo.DateTranslator(Date,1) as datetime)  as [Dates],
case when [COMDTY_CODE]='S 1 Comdty' then 'ZS'
              when [COMDTY_CODE]='XU1 Index' then 'CN'
              when [COMDTY_CODE]='GC1 Comdty' then 'GC'
              when [COMDTY_CODE]='UX1 Index' then 'VX' end  as id
,[PX_CLOSE] 
from db192.[BloombergDataSet].[dbo].[DAILY] 
where COMDTY_CODE in ('GC1 Comdty') 
and  cast( DBMain.dbo.DateTranslator(Date,1) as datetime)<'2018/12/19'
  union all
  select cast( DBMain.dbo.DateTranslator(Dates,1) as datetime),'VX',[close] 
  from web.dbo.UX1 where convert(varchar, Dates, 114) ='13:30:00:000'  --138
   union all
select cast( DBMain.dbo.DateTranslator(Date,1) as datetime)  as [Dates],
case when [COMDTY_CODE]='S 1 Comdty' then 'ZS'
              when [COMDTY_CODE]='XU1 Index' then 'CN'
              when [COMDTY_CODE]='GC1 Comdty' then 'GC'
              when [COMDTY_CODE]='UX1 Index' then 'VX' end  as id
,[PX_CLOSE] 
from db192.[BloombergDataSet].[dbo].[DAILY] 
where COMDTY_CODE in ('UX1 Index')
and  cast( DBMain.dbo.DateTranslator(Date,1) as datetime)<'2018/12/19'





create table #temp(TxDate datetime,StockID nvarchar(50),Volume decimal(20,10),Delta decimal(20,10)
,Tradingdate datetime,ser int,Ret decimal(20,10))
insert #temp
select x.Txdate
,x.StockID
,x.Volume
,coalesce(x.Volume*cb.Delta_�C���,x.Delta) as Delta
,t2.tradingdate
,t1.ser-t2.ser
,coalesce(y1.���^/(y1.���L��-y1.���^),y2.���^/(y2.���L��-y2.���^),y3.���^/(y3.���L��-y3.���^),y4.ret,case when x.StockID not like '%201[89]__' then 0 end)
 as Ret
from (
	select TxDate,StockID,sum(�|�p_Delta) as Delta,sum(Volume) as Volume
	from pl.dbo.DailyPLReport_�l�Ӧ���
	where TxDate=@t and acc not in ('791','7991','792','7992')
	group by TxDate,StockID
	having sum(�|�p_Delta)<>0
) x
left join dbmain.dbo.tradingdate t1 on t1.Tradingdate=x.Txdate
left join dbmain.dbo.tradingdate t2 on t2.ser between t1.ser-252 and t1.ser
left join cmoney.dbo.�馬�L���Ʀ� y1 on y1.���=t2.Tradingdate and y1.�Ѳ��N��=x.StockID
left join pl.[dbo].[CB_Delta] cb on cb.���=x.Txdate and cb.�N��=x.StockID
left join cmoney.dbo.�馬�L���Ʀ� y2 on y2.���=t2.Tradingdate and y2.�Ѳ��N��=cb.�Ъ��N��
left join cmoney.dbo.���f����污��	y3 on y3.���=t2.Tradingdate and y3.�N��=case when x.StockID like 'EXF______' then 'TE' when x.StockID like 'FXF______' then 'TF' when x.StockID like 'MXF______' then 'TX' end
left join (
	select b.Tradingdate,a.id
	,a.[close]
	,a.[close]/lag(a.[close]) over(partition by a.id order by b.Tradingdate)-1 as Ret
	from #Data a
	join (
		select a.Tradingdate,b.id,max(b.date) as date
		from dbmain.dbo.tradingdate a
		left join #Data b on b.[date]<=a.Tradingdate
		group by a.Tradingdate,b.id
	) b on b.date=a.date and b.id=a.id
) y4 on y4.Tradingdate=t2.Tradingdate and y4.id=left(x.StockID,2)
--order by case when coalesce(y1.���^/(y1.���L��-y1.���^),y2.���^/(y2.���L��-y2.���^),y3.���^/(y3.���L��-y3.���^)) is null then 0 else 1 end,x.StockID

select Top 13 tradingdate,ser
,sum(Delta*Ret) as PL
from #temp
group by tradingdate,ser
order by sum(Delta*Ret)

select x.StockID,x.Tradingdate,x.ser,x.Volume,x.Delta,x.Ret,x.Delta*x.Ret as PL
from #temp x
order by x.ser,x.StockID


drop table #temp
drop table #Data


