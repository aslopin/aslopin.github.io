USE [master]
GO

/****** Object:  DdlTrigger [tr_connection_limit_MD]    Script Date: 2021/8/4 �U�� 04:03:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
























































alter TRIGGER [tr_connection_limit_MD]
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS

declare @ap nvarchar(max)
set @ap=APP_NAME()
declare @host nvarchar(max)
set @host=HOST_NAME()
declare @ip nvarchar(50)
set @ip=(SELECT EVENTDATA().value('(/EVENT_INSTANCE/ClientHost)[1]', 'NVARCHAR(15)')) 

declare @file nvarchar(max)
IF ORIGINAL_LOGIN()= 'MD' 

     begin
		 if @ip in (select IP from DailyInsert.[dbo].[MDBreakList]) and @ap like '%Office%'
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 insert web.[dbo].PhpHubertLogBreak(IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 else if @ip in (select b.[IP] from dbmain.dbo.EmployeeID a join [DailyInsert].[dbo].[IPList] b on b.ID=a.ID where a.TDept in ('�Ũ�','�l��')) 
		         and ( @ap like '%Microsoft SQL Server Management Studio%' or @ap like '%.Net SqlClient Data Provider%' or @ap like '%Python%' or @ap like '%RStudio%' or @ap not like '%SSIS%' or @ap like '%Office%')
			 begin
			 set @file='MDBreak'
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 --else if @host like '%J1050048%'
			-- begin
			-- set @file='MDBreak'
			-- insert web.[dbo].PhpHubertLogBreak(IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			-- ROLLBACK;
			-- end
		 --if @ip not IN('172.24.26.102','172.24.26.195','172.24.26.109','172.24.26.101','172.24.26.106','172.24.26.206','172.24.26.105','172.24.26.100','172.24.26.41','172.24.26.43','172.24.26.46','172.24.26.129','172.24.26.72','172.24.26.128','172.24.26.169','172.24.26.192','172.24.26.167','172.24.26.42')
		 --        and ( @ap like '%Microsoft SQL Server Management Studio%' or @ap like '%.Net SqlClient Data Provider%' or @ap like '%Python%' or @ap like '%RStudio%' or @ap not like '%SSIS%')
			-- begin
			-- set @file='UseSQLBreak'
			-- insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			-- insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			-- ROLLBACK;
			-- end

		 else if @ip in ('172.24.26.70','172.24.26.171','172.24.26.65') 
		 	 and @ap in ('RStudio','Python','Microsoft Office 2010')
         --2021/4/12�p�W��A���q��MD
		     begin
			 set @file='MDBreak'
			 --insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 ROLLBACK;
			 end
		 else if @ip not in ('172.24.26.43','172.24.26.42','172.24.26.192','172.24.26.102','172.24.26.105'
		    ,'172.24.26.195','172.24.26.109','172.24.26.167','172.24.26.169','172.24.26.164','172.24.26.128') 
		     begin
			 set @file='LoginMonitor'
			 --insert web.[dbo].[PhpHubertLog](IP,TTime,Host,App,[File]) select @ip,getdate(),@host,@ap,@file
			 insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end
		 else
		     begin
			 set @file='MDLogin'
			 --insert web.[dbo].[PhpHubertLog2](IP,TTime,Host,App,[File],Acc) select @ip,getdate(),@host,@ap,@file,ORIGINAL_LOGIN()
			 end

	 end


  



































GO

ENABLE TRIGGER [tr_connection_limit_MD] ON ALL SERVER
GO


