CREATE TRIGGER log_queries_on_login
ON ALL SERVER
FOR LOGON
AS
BEGIN
    DECLARE @username nvarchar(128)
    SELECT @username = ORIGINAL_LOGIN()

    IF @username = 'it'
    BEGIN
        EXEC ('CREATE TRIGGER log_queries
        ON ALL SERVER
        FOR SQL_BATCH_COMPLETED, SQL_BATCH_ABORTED
        AS
        BEGIN
            SET NOCOUNT ON;
            INSERT INTO pl.dbo.request_log(username, query_text)
            SELECT ''' + @username + ''', text
            FROM sys.dm_exec_sql_text(@@SPID)
        END
        ')
    END
END