--insert [DailyInsert].[dbo].[ProbMonitorList]
select a.NameEn,b.TraderName
from dbmain.dbo.EmployeeID a
left join [DailyInsert].[dbo].[ProbMonitorList] b on b.UserName='Maggie'
left join [DailyInsert].[dbo].[ProbMonitorList] c on c.UserName=a.NameEn and c.TraderName=b.TraderName
where a.NameEn in ('Jeff','JeffChen','Sandy','Ashley')
and c.UserName is null
and b.TraderName not in ('Maggie','CBAS','交易簿貳與機制套利部位_合計')
order by a.NameEn,b.TraderName


