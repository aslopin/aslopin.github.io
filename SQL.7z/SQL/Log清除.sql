create procedure dbo.���Y��Ʈw
as
select 1
/*
use Cmoney
DBCC shrinkfile(Cmoney_log, 1)

use Pro
DBCC shrinkfile(Pro_log, 1)

use Trade_DB
DBCC shrinkfile(Trade_DB_log, 1)

use MarketData
DBCC shrinkfile(MarketData_log, 1)

use PL
DBCC shrinkfile(PL_log, 1)

use DBMain
DBCC shrinkfile(DBMain_log, 1)

use Intraday
DBCC shrinkfile(Intraday_log, 1)

use FrontDeskW
DBCC shrinkfile(FrontDeskW_log, 1)

use Theodata
DBCC shrinkfile(Theodata_log, 1)

use Tick
DBCC shrinkfile(Tick_log, 1)
*/